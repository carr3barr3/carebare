﻿#pragma once

/**
 * Name: LetItDie
 * Version: 15585480
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Enums
	// --------------------------------------------------
	/**
	 * Enum Engine.Actor.EActorMetricsType
	 */
	enum class EActorMetricsType : uint8_t
	{
		METRICS_VERTS    = 0,
		METRICS_TRIS     = 1,
		METRICS_SECTIONS = 2,
		METRICS_MAX      = 3
	};

	/**
	 * Enum Engine.Actor.EMoveDir
	 */
	enum class EMoveDir : uint8_t
	{
		MD_Stationary = 0,
		MD_Forward    = 1,
		MD_Backward   = 2,
		MD_Left       = 3,
		MD_Right      = 4,
		MD_Up         = 5,
		MD_Down       = 6,
		MD_MAX        = 7
	};

	/**
	 * Enum Engine.Actor.EPhysics
	 */
	enum class EPhysics : uint8_t
	{
		PHYS_None           = 0,
		PHYS_Walking        = 1,
		PHYS_Falling        = 2,
		PHYS_Swimming       = 3,
		PHYS_Flying         = 4,
		PHYS_Rotating       = 5,
		PHYS_Projectile     = 6,
		PHYS_Interpolating  = 7,
		PHYS_Spider         = 8,
		PHYS_Ladder         = 9,
		PHYS_RigidBody      = 10,
		PHYS_SoftBody       = 11,
		PHYS_NavMeshWalking = 12,
		PHYS_Unused         = 13,
		PHYS_Custom         = 14,
		PHYS_MAX            = 15
	};

	/**
	 * Enum Engine.Actor.ECollisionType
	 */
	enum class ECollisionType : uint8_t
	{
		COLLIDE_CustomDefault        = 0,
		COLLIDE_NoCollision          = 1,
		COLLIDE_BlockAll             = 2,
		COLLIDE_BlockWeapons         = 3,
		COLLIDE_TouchAll             = 4,
		COLLIDE_TouchWeapons         = 5,
		COLLIDE_BlockAllButWeapons   = 6,
		COLLIDE_TouchAllButWeapons   = 7,
		COLLIDE_BlockWeaponsKickable = 8,
		COLLIDE_BlockWeaponsBrg      = 9,
		COLLIDE_MAX                  = 10
	};

	/**
	 * Enum Engine.Actor.EBrgCollisionType
	 */
	enum class EBrgCollisionType : uint8_t
	{
		Nothing                                            = 0,
		BlockAll                                           = 1,
		BlockAll_NotNav                                    = 2,
		BlockAll_NotFootplacement                          = 3,
		EbrgCollisionType_BlockAll_NotFootplacement_NotNav = 4,
		BlockWeapon                                        = 5,
		BlockWeaponAndCamera                               = 6,
		TouchPawn_BlockWeapon                              = 7,
		NoCollision                                        = 8,
		BlockWeaponAndFootPlacement                        = 9,
		BlockAll_ButWeapons                                = 10,
		BlockAll_ButWeaponsAndCamera                       = 11,
		MAX                                                = 12
	};

	/**
	 * Enum Engine.Actor.ETravelType
	 */
	enum class ETravelType : uint8_t
	{
		TRAVEL_Absolute = 0,
		TRAVEL_Partial  = 1,
		TRAVEL_Relative = 2,
		TRAVEL_MAX      = 3
	};

	/**
	 * Enum Engine.Actor.EDoubleClickDir
	 */
	enum class EDoubleClickDir : uint8_t
	{
		DCLICK_None    = 0,
		DCLICK_Left    = 1,
		DCLICK_Right   = 2,
		DCLICK_Forward = 3,
		DCLICK_Back    = 4,
		DCLICK_Active  = 5,
		DCLICK_Done    = 6,
		DCLICK_MAX     = 7
	};

	/**
	 * Enum Engine.Actor.ENetRole
	 */
	enum class ENetRole : uint8_t
	{
		ROLE_None            = 0,
		ROLE_SimulatedProxy  = 1,
		ROLE_AutonomousProxy = 2,
		ROLE_Authority       = 3,
		ROLE_MAX             = 4
	};

	/**
	 * Enum Engine.OnlineSubsystem.EUserMessageDialogStyle
	 */
	enum class EUserMessageDialogStyle : uint8_t
	{
		UserMessageDialogStyle_Ok       = 0,
		UserMessageDialogStyle_YesNo    = 1,
		UserMessageDialogStyle_OkCancel = 2,
		UserMessageDialogStyle_MAX      = 3
	};

	/**
	 * Enum Engine.OnlineSubsystem.EOnlineNewsType
	 */
	enum class EOnlineNewsType : uint8_t
	{
		ONT_Unknown              = 0,
		ONT_GameNews             = 1,
		ONT_ContentAnnouncements = 2,
		ONT_Misc                 = 3,
		ONT_MAX                  = 4
	};

	/**
	 * Enum Engine.OnlineSubsystem.ENATType
	 */
	enum class ENATType : uint8_t
	{
		NAT_Unknown  = 0,
		NAT_Open     = 1,
		NAT_Moderate = 2,
		NAT_Strict   = 3,
		NAT_MAX      = 4
	};

	/**
	 * Enum Engine.OnlineSubsystem.EOnlineServerConnectionStatus
	 */
	enum class EOnlineServerConnectionStatus : uint8_t
	{
		OSCS_NotConnected           = 0,
		OSCS_Connected              = 1,
		OSCS_ConnectionDropped      = 2,
		OSCS_NoNetworkConnection    = 3,
		OSCS_ServiceUnavailable     = 4,
		OSCS_UpdateRequired         = 5,
		OSCS_ServersTooBusy         = 6,
		OSCS_DuplicateLoginDetected = 7,
		OSCS_InvalidUser            = 8,
		OSCS_Banned                 = 9,
		OSCS_TooYoung               = 10,
		OSCS_PSNUnavailable         = 11,
		OSCS_MAX                    = 12
	};

	/**
	 * Enum Engine.Settings.ESettingsDataType
	 */
	enum class ESettingsDataType : uint8_t
	{
		SDT_Empty    = 0,
		SDT_Int32    = 1,
		SDT_Int64    = 2,
		SDT_Double   = 3,
		SDT_String   = 4,
		SDT_Float    = 5,
		SDT_Blob     = 6,
		SDT_DateTime = 7,
		SDT_MAX      = 8
	};

	/**
	 * Enum Engine.Settings.EOnlineDataAdvertisementType
	 */
	enum class EOnlineDataAdvertisementType : uint8_t
	{
		ODAT_DontAdvertise       = 0,
		ODAT_OnlineService       = 1,
		ODAT_QoS                 = 2,
		ODAT_OnlineServiceAndQoS = 3,
		ODAT_MAX                 = 4
	};

	/**
	 * Enum Engine.OnlineSubsystem.EOnlineEnumerationReadState
	 */
	enum class EOnlineEnumerationReadState : uint8_t
	{
		OERS_NotStarted = 0,
		OERS_InProgress = 1,
		OERS_Done       = 2,
		OERS_Failed     = 3,
		OERS_MAX        = 4
	};

	/**
	 * Enum Engine.OnlineSubsystem.EOnlineGameState
	 */
	enum class EOnlineGameState : uint8_t
	{
		OGS_NoSession  = 0,
		OGS_Pending    = 1,
		OGS_Starting   = 2,
		OGS_InProgress = 3,
		OGS_Ending     = 4,
		OGS_Ended      = 5,
		OGS_MAX        = 6
	};

	/**
	 * Enum Engine.OnlineSubsystem.EOnlineAccountCreateStatus
	 */
	enum class EOnlineAccountCreateStatus : uint8_t
	{
		OACS_CreateSuccessful      = 0,
		OACS_UnknownError          = 1,
		OACS_InvalidUserName       = 2,
		OACS_InvalidPassword       = 3,
		OACS_InvalidUniqueUserName = 4,
		OACS_UniqueUserNameInUse   = 5,
		OACS_ServiceUnavailable    = 6,
		OACS_MAX                   = 7
	};

	/**
	 * Enum Engine.OnlineSubsystem.ELanBeaconState
	 */
	enum class ELanBeaconState : uint8_t
	{
		LANB_NotUsingLanBeacon = 0,
		LANB_Hosting           = 1,
		LANB_Searching         = 2,
		LANB_MAX               = 3
	};

	/**
	 * Enum Engine.OnlineSubsystem.EOnlineContentType
	 */
	enum class EOnlineContentType : uint8_t
	{
		OCT_Downloaded = 0,
		OCT_SaveGame   = 1,
		OCT_MAX        = 2
	};

	/**
	 * Enum Engine.OnlineSubsystem.EOnlineFriendState
	 */
	enum class EOnlineFriendState : uint8_t
	{
		OFS_Offline = 0,
		OFS_Online  = 1,
		OFS_Away    = 2,
		OFS_Busy    = 3,
		OFS_MAX     = 4
	};

	/**
	 * Enum Engine.OnlineSubsystem.ENetworkNotificationPosition
	 */
	enum class ENetworkNotificationPosition : uint8_t
	{
		NNP_TopLeft      = 0,
		NNP_TopCenter    = 1,
		NNP_TopRight     = 2,
		NNP_CenterLeft   = 3,
		NNP_Center       = 4,
		NNP_CenterRight  = 5,
		NNP_BottomLeft   = 6,
		NNP_BottomCenter = 7,
		NNP_BottomRight  = 8,
		NNP_MAX          = 9
	};

	/**
	 * Enum Engine.OnlineSubsystem.EFeaturePrivilegeLevel
	 */
	enum class EFeaturePrivilegeLevel : uint8_t
	{
		FPL_Disabled           = 0,
		FPL_EnabledFriendsOnly = 1,
		FPL_Enabled            = 2,
		FPL_MAX                = 3
	};

	/**
	 * Enum Engine.OnlineSubsystem.ELoginStatus
	 */
	enum class ELoginStatus : uint8_t
	{
		LS_NotLoggedIn       = 0,
		LS_UsingLocalProfile = 1,
		LS_LoggedIn          = 2,
		LS_MAX               = 3
	};

	/**
	 * Enum Engine.Settings.EPropertyValueMappingType
	 */
	enum class EPropertyValueMappingType : uint8_t
	{
		PVMT_RawValue         = 0,
		PVMT_PredefinedValues = 1,
		PVMT_Ranged           = 2,
		PVMT_IdMapped         = 3,
		PVMT_MAX              = 4
	};

	/**
	 * Enum Engine.OnlineAuthInterface.EAuthStatus
	 */
	enum class EAuthStatus : uint8_t
	{
		AUS_NotStarted    = 0,
		AUS_Pending       = 1,
		AUS_Authenticated = 2,
		AUS_Failed        = 3,
		AUS_MAX           = 4
	};

	/**
	 * Enum Engine.Scene.EDetailMode
	 */
	enum class EDetailMode : uint8_t
	{
		DM_Low    = 0,
		DM_Medium = 1,
		DM_High   = 2,
		DM_MAX    = 3
	};

	/**
	 * Enum Engine.Scene.ESceneSubDepthPriorityGroup
	 */
	enum class ESceneSubDepthPriorityGroup : uint8_t
	{
		SSUBDPG_Default                    = 0,
		SSUBDPG_AfterShadowing             = 1,
		SSUBDPG_AfterPostProcessAndDefault = 2,
		SSUBDPG_MAX                        = 3
	};

	/**
	 * Enum Engine.Scene.ESceneDepthPriorityGroup
	 */
	enum class ESceneDepthPriorityGroup : uint8_t
	{
		SDPG_UnrealEdBackground = 0,
		SDPG_World              = 1,
		SDPG_Foreground         = 2,
		SDPG_UnrealEdForeground = 3,
		SDPG_PostProcess        = 4,
		SDPG_MAX                = 5
	};

	/**
	 * Enum Engine.PrimitiveComponent.GJKResult
	 */
	enum class EGJKResult : uint8_t
	{
		GJK_Intersect      = 0,
		GJK_NoIntersection = 1,
		GJK_Fail           = 2,
		GJK_MAX            = 3
	};

	/**
	 * Enum Engine.PrimitiveComponent.ERadialImpulseFalloff
	 */
	enum class ERadialImpulseFalloff : uint8_t
	{
		RIF_Constant = 0,
		RIF_Linear   = 1,
		RIF_MAX      = 2
	};

	/**
	 * Enum Engine.PrimitiveComponent.ERBCollisionChannel
	 */
	enum class ERBCollisionChannel : uint8_t
	{
		RBCC_Default           = 0,
		RBCC_Nothing           = 1,
		RBCC_Pawn              = 2,
		RBCC_Vehicle           = 3,
		RBCC_Water             = 4,
		RBCC_GameplayPhysics   = 5,
		RBCC_EffectPhysics     = 6,
		RBCC_Untitled1         = 7,
		RBCC_Untitled2         = 8,
		RBCC_Untitled3         = 9,
		RBCC_Untitled4         = 10,
		RBCC_Cloth             = 11,
		RBCC_FluidDrain        = 12,
		RBCC_SoftBody          = 13,
		RBCC_FracturedMeshPart = 14,
		RBCC_BlockingVolume    = 15,
		RBCC_DeadPawn          = 16,
		RBCC_Clothing          = 17,
		RBCC_ClothingCollision = 18,
		RBCC_GhM0              = 19,
		RBCC_GhM1              = 20,
		RBCC_GhM2              = 21,
		RBCC_GhM3              = 22,
		RBCC_GhM4              = 23,
		RBCC_GhM5              = 24,
		RBCC_GhM6              = 25,
		RBCC_GhM7              = 26,
		RBCC_GhM8              = 27,
		RBCC_GhM9              = 28,
		RBCC_GhM10             = 29,
		RBCC_GhM11             = 30,
		RBCC_GhM12             = 31,
		RBCC_MAX               = 32
	};

	/**
	 * Enum Engine.Camera.EViewTargetBlendFunction
	 */
	enum class EViewTargetBlendFunction : uint8_t
	{
		VTBlend_Linear    = 0,
		VTBlend_Cubic     = 1,
		VTBlend_EaseIn    = 2,
		VTBlend_EaseOut   = 3,
		VTBlend_EaseInOut = 4,
		VTBlend_MAX       = 5
	};

	/**
	 * Enum Engine.DOFEffect.EFocusType
	 */
	enum class EFocusType : uint8_t
	{
		FOCUS_Distance = 0,
		FOCUS_Position = 1,
		FOCUS_MAX      = 2
	};

	/**
	 * Enum Engine.Camera.ECameraAnimPlaySpace
	 */
	enum class ECameraAnimPlaySpace : uint8_t
	{
		CAPS_CameraLocal = 0,
		CAPS_World       = 1,
		CAPS_UserDefined = 2,
		CAPS_MAX         = 3
	};

	/**
	 * Enum Engine.SeqAct_ControlMovieTexture.EMovieControlType
	 */
	enum class EMovieControlType : uint8_t
	{
		MCT_Play  = 0,
		MCT_Stop  = 1,
		MCT_Pause = 2,
		MCT_MAX   = 3
	};

	/**
	 * Enum Engine.OnlineGameSearch.EOnlineGameSearchComparisonType
	 */
	enum class EOnlineGameSearchComparisonType : uint8_t
	{
		OGSCT_Equals            = 0,
		OGSCT_NotEquals         = 1,
		OGSCT_GreaterThan       = 2,
		OGSCT_GreaterThanEquals = 3,
		OGSCT_LessThan          = 4,
		OGSCT_LessThanEquals    = 5,
		OGSCT_MAX               = 6
	};

	/**
	 * Enum Engine.OnlineGameSearch.EOnlineGameSearchEntryType
	 */
	enum class EOnlineGameSearchEntryType : uint8_t
	{
		OGSET_Property         = 0,
		OGSET_LocalizedSetting = 1,
		OGSET_ObjectProperty   = 2,
		OGSET_MAX              = 3
	};

	/**
	 * Enum Engine.OnlineGameSearch.EOnlineGameSearchSortType
	 */
	enum class EOnlineGameSearchSortType : uint8_t
	{
		OGSSO_Ascending  = 0,
		OGSSO_Descending = 1,
		OGSSO_MAX        = 2
	};

	/**
	 * Enum Engine.PlayerController.EProgressMessageType
	 */
	enum class EProgressMessageType : uint8_t
	{
		PMT_Clear                    = 0,
		PMT_Information              = 1,
		PMT_AdminMessage             = 2,
		PMT_DownloadProgress         = 3,
		PMT_ConnectionFailure        = 4,
		PMT_PeerConnectionFailure    = 5,
		PMT_PeerHostMigrationFailure = 6,
		PMT_SocketFailure            = 7,
		PMT_MAX                      = 8
	};

	/**
	 * Enum Engine.SkeletalMeshComponent.EPhysBodyOp
	 */
	enum class EPhysBodyOp : uint8_t
	{
		PBO_None    = 0,
		PBO_Term    = 1,
		PBO_Disable = 2,
		PBO_MAX     = 3
	};

	/**
	 * Enum Engine.SkeletalMeshComponent.EBoneVisibilityStatus
	 */
	enum class EBoneVisibilityStatus : uint8_t
	{
		BVS_HiddenByParent   = 0,
		BVS_Visible          = 1,
		BVS_ExplicitlyHidden = 2,
		BVS_MAX              = 3
	};

	/**
	 * Enum Engine.SkeletalMeshComponent.EFaceFXRegOp
	 */
	enum class EFaceFXRegOp : uint8_t
	{
		FXRO_Add      = 0,
		FXRO_Multiply = 1,
		FXRO_Replace  = 2,
		FXRO_MAX      = 3
	};

	/**
	 * Enum Engine.SkeletalMeshComponent.EFaceFXBlendMode
	 */
	enum class EFaceFXBlendMode : uint8_t
	{
		FXBM_Overwrite = 0,
		FXBM_Additive  = 1,
		FXBM_MAX       = 2
	};

	/**
	 * Enum Engine.SkeletalMeshComponent.EInstanceWeightUsage
	 */
	enum class EInstanceWeightUsage : uint8_t
	{
		IWU_PartialSwap = 0,
		IWU_FullSwap    = 1,
		IWU_MAX         = 2
	};

	/**
	 * Enum Engine.SkeletalMeshComponent.EAnimRotationOnly
	 */
	enum class EAnimRotationOnly : uint8_t
	{
		EARO_AnimSet       = 0,
		EARO_ForceEnabled  = 1,
		EARO_ForceDisabled = 2,
		EARO_MAX           = 3
	};

	/**
	 * Enum Engine.SkeletalMeshComponent.ERootMotionRotationMode
	 */
	enum class ERootMotionRotationMode : uint8_t
	{
		RMRM_Ignore      = 0,
		RMRM_RotateActor = 1,
		RMRM_MAX         = 2
	};

	/**
	 * Enum Engine.SkeletalMeshComponent.ERootMotionMode
	 */
	enum class ERootMotionMode : uint8_t
	{
		RMM_Translate = 0,
		RMM_Velocity  = 1,
		RMM_Ignore    = 2,
		RMM_Accel     = 3,
		RMM_Relative  = 4,
		RMM_MAX       = 5
	};

	/**
	 * Enum Engine.SkeletalMeshComponent.EMaxDistanceScaleMode
	 */
	enum class EMaxDistanceScaleMode : uint8_t
	{
		MDSM_Multiply  = 0,
		MDSM_Substract = 1,
		MDSM_MAX       = 2
	};

	/**
	 * Enum Engine.PlayerController.EInputMatchAction
	 */
	enum class EInputMatchAction : uint8_t
	{
		IMA_GreaterThan = 0,
		IMA_LessThan    = 1,
		IMA_MAX         = 2
	};

	/**
	 * Enum Engine.PlayerController.EInputTypes
	 */
	enum class EInputTypes : uint8_t
	{
		IT_XAxis = 0,
		IT_YAxis = 1,
		IT_MAX   = 2
	};

	/**
	 * Enum Engine.Pylon.ENavMeshEdgeType
	 */
	enum class ENavMeshEdgeType : uint8_t
	{
		NAVEDGE_Normal       = 0,
		NAVEDGE_Mantle       = 1,
		NAVEDGE_Coverslip    = 2,
		NAVEDGE_SwatTurn     = 3,
		NAVEDGE_DropDown     = 4,
		NAVEDGE_PathObject   = 5,
		NAVEDGE_BackRefDummy = 6,
		NAVEDGE_Jump         = 7,
		NAVEDGE_MAX          = 8
	};

	/**
	 * Enum Engine.AmbientOcclusionEffect.EAmbientOcclusionQuality
	 */
	enum class EAmbientOcclusionQuality : uint8_t
	{
		AO_High   = 0,
		AO_Medium = 1,
		AO_Low    = 2,
		AO_MAX    = 3
	};

	/**
	 * Enum Engine.Brush.ECsgOper
	 */
	enum class ECsgOper : uint8_t
	{
		CSG_Active      = 0,
		CSG_Add         = 1,
		CSG_Subtract    = 2,
		CSG_Intersect   = 3,
		CSG_Deintersect = 4,
		CSG_MAX         = 5
	};

	/**
	 * Enum Engine.ReverbVolume.ReverbPreset
	 */
	enum class EReverbPreset : uint8_t
	{
		REVERB_Default           = 0,
		REVERB_Bathroom          = 1,
		REVERB_StoneRoom         = 2,
		REVERB_Auditorium        = 3,
		REVERB_ConcertHall       = 4,
		REVERB_Cave              = 5,
		REVERB_Hallway           = 6,
		REVERB_StoneCorridor     = 7,
		REVERB_Alley             = 8,
		REVERB_Forest            = 9,
		REVERB_City              = 10,
		REVERB_Mountains         = 11,
		REVERB_Quarry            = 12,
		REVERB_Plain             = 13,
		REVERB_ParkingLot        = 14,
		REVERB_SewerPipe         = 15,
		REVERB_Underwater        = 16,
		REVERB_SmallRoom         = 17,
		REVERB_MediumRoom        = 18,
		REVERB_LargeRoom         = 19,
		REVERB_MediumHall        = 20,
		REVERB_LargeHall         = 21,
		REVERB_Plate             = 22,
		REVERB_Custom            = 23,
		REVERB_Metro_Hall        = 24,
		REVERB_Metro_Corridor    = 25,
		REVERB_Amusement_OutSide = 26,
		REVERB_Amusement_InSide  = 27,
		REVERB_Arcade_OutSide    = 28,
		REVERB_Arcade_InSide     = 29,
		REVERB_Roof_OutSide      = 30,
		REVERB_Roof_InSide       = 31,
		REVERB_MAX               = 32
	};

	/**
	 * Enum Engine.EngineTypes.EPathFindingError
	 */
	enum class EPathFindingError : uint8_t
	{
		PATHERROR_STARTPOLYNOTFOUND          = 0,
		PATHERROR_GOALPOLYNOTFOUND           = 1,
		PATHERROR_ANCHORPYLONNOTFOUND        = 2,
		PATHERROR_NOPATHFOUND                = 3,
		PATHERROR_COMPUTEVALIDFINALDEST_FAIL = 4,
		PATHERROR_GETNEXTMOVELOCATION_FAIL   = 5,
		PATHERROR_MOVETIMEOUT                = 6,
		PATHERROR_MAX                        = 7
	};

	/**
	 * Enum Engine.AudioDevice.EDebugState
	 */
	enum class EDebugState : uint8_t
	{
		DEBUGSTATE_None            = 0,
		DEBUGSTATE_IsolateDryAudio = 1,
		DEBUGSTATE_IsolateReverb   = 2,
		DEBUGSTATE_TestLPF         = 3,
		DEBUGSTATE_TestStereoBleed = 4,
		DEBUGSTATE_TestLFEBleed    = 5,
		DEBUGSTATE_DisableLPF      = 6,
		DEBUGSTATE_DisableRadio    = 7,
		DEBUGSTATE_MAX             = 8
	};

	/**
	 * Enum Engine.AudioDevice.ESoundClassName
	 */
	enum class ESoundClassName : uint8_t
	{
		SCL_AMB              = 0,
		SCL_BGM_Radio        = 1,
		SCL_VOX_INGAME       = 2,
		SCL_VOX_Base_Humming = 3,
		Master               = 4,
		SCL_AMB_Base         = 5,
		SCL_BGM              = 6,
		SCL_BGM_Battle       = 7,
		SCL_BGM_Load         = 8,
		SCL_BGM_Menu         = 9,
		SCL_BGM_Shop         = 10,
		SCL_BGM_Stage        = 11,
		SCL_Boss02_Alarm     = 12,
		SCL_Boss_Loop        = 13,
		SCL_CS               = 14,
		SCL_CS_Music         = 15,
		SCL_CS_SE            = 16,
		SCL_SE               = 17,
		SCL_SE_Dry           = 18,
		SCL_SE_IT            = 19,
		SCL_SE_Phone         = 20,
		SCL_SE_WP_Loop       = 21,
		SCL_SYS              = 22,
		SCL_VOX              = 23,
		SCL_VOX_CH           = 24,
		SCL_VOX_CS           = 25,
		MAX                  = 26
	};

	/**
	 * Enum Engine.AudioDevice.ETTSSpeaker
	 */
	enum class ETTSSpeaker : uint8_t
	{
		TTSSPEAKER_Paul   = 0,
		TTSSPEAKER_Harry  = 1,
		TTSSPEAKER_Frank  = 2,
		TTSSPEAKER_Dennis = 3,
		TTSSPEAKER_Kit    = 4,
		TTSSPEAKER_Betty  = 5,
		TTSSPEAKER_Ursula = 6,
		TTSSPEAKER_Rita   = 7,
		TTSSPEAKER_Wendy  = 8,
		TTSSPEAKER_MAX    = 9
	};

	/**
	 * Enum Engine.AudioDevice.MultiChannelMode
	 */
	enum class EMultiChannelMode : uint8_t
	{
		MultiChannelMode_Default    = 0,
		MultiChannelMode_DolbyPLIIz = 1,
		MultiChannelMode_MAX        = 2
	};

	/**
	 * Enum Engine.SoundNodeAttenuation.ESoundDistanceCalc
	 */
	enum class ESoundDistanceCalc : uint8_t
	{
		SOUNDDISTANCE_Normal          = 0,
		SOUNDDISTANCE_InfiniteXYPlane = 1,
		SOUNDDISTANCE_InfiniteXZPlane = 2,
		SOUNDDISTANCE_InfiniteYZPlane = 3,
		SOUNDDISTANCE_MAX             = 4
	};

	/**
	 * Enum Engine.SoundNodeAttenuation.SoundDistanceModel
	 */
	enum class ESoundDistanceModel : uint8_t
	{
		ATTENUATION_Linear       = 0,
		ATTENUATION_Logarithmic  = 1,
		ATTENUATION_Inverse      = 2,
		ATTENUATION_LogReverse   = 3,
		ATTENUATION_NaturalSound = 4,
		ATTENUATION_MAX          = 5
	};

	/**
	 * Enum Engine.PlatformInterfaceBase.EPlatformInterfaceDataType
	 */
	enum class EPlatformInterfaceDataType : uint8_t
	{
		PIDT_None   = 0,
		PIDT_Int    = 1,
		PIDT_Float  = 2,
		PIDT_String = 3,
		PIDT_Object = 4,
		PIDT_Custom = 5,
		PIDT_MAX    = 6
	};

	/**
	 * Enum Engine.AnimSequence.AnimationCompressionFormat
	 */
	enum class EAnimationCompressionFormat : uint8_t
	{
		ACF_None               = 0,
		ACF_Float96NoW         = 1,
		ACF_Fixed48NoW         = 2,
		ACF_IntervalFixed32NoW = 3,
		ACF_Fixed32NoW         = 4,
		ACF_Float32NoW         = 5,
		ACF_Identity           = 6,
		ACF_MAX                = 7
	};

	/**
	 * Enum Engine.AnimSequence.AnimationKeyFormat
	 */
	enum class EAnimationKeyFormat : uint8_t
	{
		AKF_ConstantKeyLerp     = 0,
		AKF_VariableKeyLerp     = 1,
		AKF_PerTrackCompression = 2,
		AKF_MAX                 = 3
	};

	/**
	 * Enum Engine.AnimNode.ESliderType
	 */
	enum class ESliderType : uint8_t
	{
		ST_1D  = 0,
		ST_2D  = 1,
		ST_MAX = 2
	};

	/**
	 * Enum Engine.AnimNode_MultiBlendPerBone.EWeightCheck
	 */
	enum class EWeightCheck : uint8_t
	{
		EWC_AnimNodeSlotNotPlaying = 0,
		EWC_MAX                    = 1
	};

	/**
	 * Enum Engine.AnimNode_MultiBlendPerBone.EBlendType
	 */
	enum class EBlendType : uint8_t
	{
		EBT_ParentBoneSpace = 0,
		EBT_MeshSpace       = 1,
		EBT_MAX             = 2
	};

	/**
	 * Enum Engine.AnimNodeAimOffset.EAnimAimDir
	 */
	enum class EAnimAimDir : uint8_t
	{
		ANIMAIM_LEFTUP       = 0,
		ANIMAIM_CENTERUP     = 1,
		ANIMAIM_RIGHTUP      = 2,
		ANIMAIM_LEFTCENTER   = 3,
		ANIMAIM_CENTERCENTER = 4,
		ANIMAIM_RIGHTCENTER  = 5,
		ANIMAIM_LEFTDOWN     = 6,
		ANIMAIM_CENTERDOWN   = 7,
		ANIMAIM_RIGHTDOWN    = 8,
		ANIMAIM_MAX          = 9
	};

	/**
	 * Enum Engine.AnimNodeAimOffset.EAimID
	 */
	enum class EAimID : uint8_t
	{
		EAID_LeftUp    = 0,
		EAID_LeftDown  = 1,
		EAID_RightUp   = 2,
		EAID_RightDown = 3,
		EAID_ZeroUp    = 4,
		EAID_ZeroDown  = 5,
		EAID_ZeroLeft  = 6,
		EAID_ZeroRight = 7,
		EAID_CellLU    = 8,
		EAID_CellCU    = 9,
		EAID_CellRU    = 10,
		EAID_CellLC    = 11,
		EAID_CellCC    = 12,
		EAID_CellRC    = 13,
		EAID_CellLD    = 14,
		EAID_CellCD    = 15,
		EAID_CellRD    = 16,
		EAID_MAX       = 17
	};

	/**
	 * Enum Engine.AnimNodeBlendByBase.EBaseBlendType
	 */
	enum class EBaseBlendType : uint8_t
	{
		BBT_ByActorTag   = 0,
		BBT_ByActorClass = 1,
		BBT_MAX          = 2
	};

	/**
	 * Enum Engine.AnimNodeSequence.ERootRotationOption
	 */
	enum class ERootRotationOption : uint8_t
	{
		RRO_Default = 0,
		RRO_Discard = 1,
		RRO_Extract = 2,
		RRO_MAX     = 3
	};

	/**
	 * Enum Engine.AnimNodeSequence.ERootBoneAxis
	 */
	enum class ERootBoneAxis : uint8_t
	{
		RBA_Default   = 0,
		RBA_Discard   = 1,
		RBA_Translate = 2,
		RBA_MAX       = 3
	};

	/**
	 * Enum Engine.EngineTypes.EBlendMode
	 */
	enum class EBlendMode : uint8_t
	{
		BLEND_Opaque              = 0,
		BLEND_Masked              = 1,
		BLEND_Translucent         = 2,
		BLEND_Additive            = 3,
		BLEND_Modulate            = 4,
		BLEND_ModulateAndAdd      = 5,
		BLEND_SoftMasked          = 6,
		BLEND_AlphaComposite      = 7,
		BLEND_DitheredTranslucent = 8,
		BLEND_MAX                 = 9
	};

	/**
	 * Enum Engine.EngineTypes.EMaterialLightingModel
	 */
	enum class EMaterialLightingModel : uint8_t
	{
		MLM_Phong          = 0,
		MLM_NonDirectional = 1,
		MLM_Unlit          = 2,
		MLM_SHPRT          = 3,
		MLM_Custom         = 4,
		MLM_Anisotropic    = 5,
		MLM_MAX            = 6
	};

	/**
	 * Enum Engine.EngineTypes.EMaterialTessellationMode
	 */
	enum class EMaterialTessellationMode : uint8_t
	{
		MTM_NoTessellation   = 0,
		MTM_FlatTessellation = 1,
		MTM_PNTriangles      = 2,
		MTM_MAX              = 3
	};

	/**
	 * Enum Engine.EngineTypes.EMobileValueSource
	 */
	enum class EMobileValueSource : uint8_t
	{
		MVS_Constant             = 0,
		MVS_VertexColorRed       = 1,
		MVS_VertexColorGreen     = 2,
		MVS_VertexColorBlue      = 3,
		MVS_VertexColorAlpha     = 4,
		MVS_BaseTextureRed       = 5,
		MVS_BaseTextureGreen     = 6,
		MVS_BaseTextureBlue      = 7,
		MVS_BaseTextureAlpha     = 8,
		MVS_MaskTextureRed       = 9,
		MVS_MaskTextureGreen     = 10,
		MVS_MaskTextureBlue      = 11,
		MVS_MaskTextureAlpha     = 12,
		MVS_NormalTextureAlpha   = 13,
		MVS_EmissiveTextureRed   = 14,
		MVS_EmissiveTextureGreen = 15,
		MVS_EmissiveTextureBlue  = 16,
		MVS_EmissiveTextureAlpha = 17,
		MVS_MAX                  = 18
	};

	/**
	 * Enum Engine.EngineTypes.EMobileTextureBlendFactorSource
	 */
	enum class EMobileTextureBlendFactorSource : uint8_t
	{
		MTBFS_VertexColor = 0,
		MTBFS_MaskTexture = 1,
		MTBFS_MAX         = 2
	};

	/**
	 * Enum Engine.EngineTypes.EMobileTexCoordsSource
	 */
	enum class EMobileTexCoordsSource : uint8_t
	{
		MTCS_TexCoords0 = 0,
		MTCS_TexCoords1 = 1,
		MTCS_TexCoords2 = 2,
		MTCS_TexCoords3 = 3,
		MTCS_MAX        = 4
	};

	/**
	 * Enum Engine.EngineTypes.EMobileAlphaValueSource
	 */
	enum class EMobileAlphaValueSource : uint8_t
	{
		MAVS_DiffuseTextureAlpha = 0,
		MAVS_MaskTextureRed      = 1,
		MAVS_MaskTextureGreen    = 2,
		MAVS_MaskTextureBlue     = 3,
		MAVS_MAX                 = 4
	};

	/**
	 * Enum Engine.EngineTypes.EMobileColorMultiplySource
	 */
	enum class EMobileColorMultiplySource : uint8_t
	{
		MCMS_None             = 0,
		MCMS_BaseTextureRed   = 1,
		MCMS_BaseTextureGreen = 2,
		MCMS_BaseTextureBlue  = 3,
		MCMS_BaseTextureAlpha = 4,
		MCMS_MaskTextureRed   = 5,
		MCMS_MaskTextureGreen = 6,
		MCMS_MaskTextureBlue  = 7,
		MCMS_MaskTextureAlpha = 8,
		MCMS_MAX              = 9
	};

	/**
	 * Enum Engine.EngineTypes.EMobileEmissiveColorSource
	 */
	enum class EMobileEmissiveColorSource : uint8_t
	{
		MECS_EmissiveTexture = 0,
		MECS_BaseTexture     = 1,
		MECS_Constant        = 2,
		MECS_MAX             = 3
	};

	/**
	 * Enum Engine.EngineTypes.EMobileEnvironmentBlendMode
	 */
	enum class EMobileEnvironmentBlendMode : uint8_t
	{
		MEBM_Add  = 0,
		MEBM_Lerp = 1,
		MEBM_MAX  = 2
	};

	/**
	 * Enum Engine.EngineTypes.EMobileSpecularMask
	 */
	enum class EMobileSpecularMask : uint8_t
	{
		MSM_Constant         = 0,
		MSM_Luminance        = 1,
		MSM_DiffuseRed       = 2,
		MSM_DiffuseGreen     = 3,
		MSM_DiffuseBlue      = 4,
		MSM_DiffuseAlpha     = 5,
		MSM_MaskTextureRGB   = 6,
		MSM_MaskTextureRed   = 7,
		MSM_MaskTextureGreen = 8,
		MSM_MaskTextureBlue  = 9,
		MSM_MaskTextureAlpha = 10,
		MSM_MAX              = 11
	};

	/**
	 * Enum Engine.EngineTypes.EMobileAmbientOcclusionSource
	 */
	enum class EMobileAmbientOcclusionSource : uint8_t
	{
		MAOS_Disabled         = 0,
		MAOS_VertexColorRed   = 1,
		MAOS_VertexColorGreen = 2,
		MAOS_VertexColorBlue  = 3,
		MAOS_VertexColorAlpha = 4,
		MAOS_MAX              = 5
	};

	/**
	 * Enum Engine.EngineTypes.ELightingBuildQuality
	 */
	enum class ELightingBuildQuality : uint8_t
	{
		Quality_Preview              = 0,
		Quality_Medium               = 1,
		Quality_High                 = 2,
		Quality_Production           = 3,
		Quality_NoGlobalIllumination = 4,
		Quality_MAX                  = 5
	};

	/**
	 * Enum Engine.Pawn.EPathSearchType
	 */
	enum class EPathSearchType : uint8_t
	{
		PST_Default       = 0,
		PST_Breadth       = 1,
		PST_NewBestPathTo = 2,
		PST_Constraint    = 3,
		PST_MAX           = 4
	};

	/**
	 * Enum Engine.DynamicLightEnvironmentComponent.EDynamicLightEnvironmentBoundsMethod
	 */
	enum class EDynamicLightEnvironmentBoundsMethod : uint8_t
	{
		DLEB_OwnerComponents  = 0,
		DLEB_ManualOverride   = 1,
		DLEB_ActiveComponents = 2,
		DLEB_MAX              = 3
	};

	/**
	 * Enum Engine.ApexDestructibleAsset.EImpactDamageOverride
	 */
	enum class EImpactDamageOverride : uint8_t
	{
		IDO_None = 0,
		IDO_On   = 1,
		IDO_Off  = 2,
		IDO_MAX  = 3
	};

	/**
	 * Enum Engine.ApexDestructibleDamageParameters.EDamageParameterOverrideMode
	 */
	enum class EDamageParameterOverrideMode : uint8_t
	{
		DPOM_Absolute   = 0,
		DPOM_Multiplier = 1,
		DPOM_MAX        = 2
	};

	/**
	 * Enum Engine.CameraShake.EInitialOscillatorOffset
	 */
	enum class EInitialOscillatorOffset : uint8_t
	{
		EOO_OffsetRandom = 0,
		EOO_OffsetZero   = 1,
		EOO_MAX          = 2
	};

	/**
	 * Enum Engine.Texture.TextureCompressionSettings
	 */
	enum class ETextureCompressionSettings : uint8_t
	{
		TC_Default                    = 0,
		TC_Normalmap                  = 1,
		TC_Displacementmap            = 2,
		TC_NormalmapAlpha             = 3,
		TC_Grayscale                  = 4,
		TC_HighDynamicRange           = 5,
		TC_OneBitAlpha                = 6,
		TC_NormalmapUncompressed      = 7,
		TC_NormalmapBC5               = 8,
		TC_OneBitMonochrome           = 9,
		TC_SimpleLightmapModification = 10,
		TC_VectorDisplacementmap      = 11,
		TC_MAX                        = 12
	};

	/**
	 * Enum Engine.Texture.EPixelFormat
	 */
	enum class EPixelFormat : uint8_t
	{
		PF_Unknown             = 0,
		PF_A32B32G32R32F       = 1,
		PF_A8R8G8B8            = 2,
		PF_G8                  = 3,
		PF_G16                 = 4,
		PF_DXT1                = 5,
		PF_DXT3                = 6,
		PF_DXT5                = 7,
		PF_UYVY                = 8,
		PF_FloatRGB            = 9,
		PF_FloatRGBA           = 10,
		PF_DepthStencil        = 11,
		PF_ShadowDepth         = 12,
		PF_FilteredShadowDepth = 13,
		PF_R32F                = 14,
		PF_G16R16              = 15,
		PF_G16R16F             = 16,
		PF_G16R16F_FILTER      = 17,
		PF_G32R32F             = 18,
		PF_A2B10G10R10         = 19,
		PF_A16B16G16R16        = 20,
		PF_D24                 = 21,
		PF_R16F                = 22,
		PF_R16F_FILTER         = 23,
		PF_BC5                 = 24,
		PF_V8U8                = 25,
		PF_A1                  = 26,
		PF_FloatR11G11B10      = 27,
		PF_A4R4G4B4            = 28,
		_PF_MAX_               = 29
	};

	/**
	 * Enum Engine.Texture.TextureFilter
	 */
	enum class ETextureFilter : uint8_t
	{
		TF_Nearest = 0,
		TF_Linear  = 1,
		TF_MAX     = 2
	};

	/**
	 * Enum Engine.Texture.TextureAddress
	 */
	enum class ETextureAddress : uint8_t
	{
		TA_Wrap   = 0,
		TA_Clamp  = 1,
		TA_Mirror = 2,
		TA_MAX    = 3
	};

	/**
	 * Enum Engine.Texture.TextureGroup
	 */
	enum class ETextureGroup : uint8_t
	{
		TEXTUREGROUP_World                  = 0,
		TEXTUREGROUP_WorldNormalMap         = 1,
		TEXTUREGROUP_WorldSpecular          = 2,
		TEXTUREGROUP_Character              = 3,
		TEXTUREGROUP_CharacterNormalMap     = 4,
		TEXTUREGROUP_CharacterSpecular      = 5,
		TEXTUREGROUP_Weapon                 = 6,
		TEXTUREGROUP_WeaponNormalMap        = 7,
		TEXTUREGROUP_WeaponSpecular         = 8,
		TEXTUREGROUP_Vehicle                = 9,
		TEXTUREGROUP_VehicleNormalMap       = 10,
		TEXTUREGROUP_VehicleSpecular        = 11,
		TEXTUREGROUP_Cinematic              = 12,
		TEXTUREGROUP_Effects                = 13,
		TEXTUREGROUP_EffectsNotFiltered     = 14,
		TEXTUREGROUP_Skybox                 = 15,
		TEXTUREGROUP_UI                     = 16,
		TEXTUREGROUP_Lightmap               = 17,
		TEXTUREGROUP_RenderTarget           = 18,
		TEXTUREGROUP_MobileFlattened        = 19,
		TEXTUREGROUP_ProcBuilding_Face      = 20,
		TEXTUREGROUP_ProcBuilding_LightMap  = 21,
		TEXTUREGROUP_Shadowmap              = 22,
		TEXTUREGROUP_ColorLookupTable       = 23,
		TEXTUREGROUP_Terrain_Heightmap      = 24,
		TEXTUREGROUP_Terrain_Weightmap      = 25,
		TEXTUREGROUP_ImageBasedReflection   = 26,
		TEXTUREGROUP_Bokeh                  = 27,
		TEXTUREGROUP_Default                = 28,
		TEXTUREGROUP_CharacterHero          = 29,
		TEXTUREGROUP_CharacterHeroNormalMap = 30,
		TEXTUREGROUP_CharacterHeroSpecular  = 31,
		TEXTUREGROUP_MAX                    = 32
	};

	/**
	 * Enum Engine.Texture.TextureMipGenSettings
	 */
	enum class ETextureMipGenSettings : uint8_t
	{
		TMGS_FromTextureGroup  = 0,
		TMGS_SimpleAverage     = 1,
		TMGS_Sharpen0          = 2,
		TMGS_Sharpen1          = 3,
		TMGS_Sharpen2          = 4,
		TMGS_Sharpen3          = 5,
		TMGS_Sharpen4          = 6,
		TMGS_Sharpen5          = 7,
		TMGS_Sharpen6          = 8,
		TMGS_Sharpen7          = 9,
		TMGS_Sharpen8          = 10,
		TMGS_Sharpen9          = 11,
		TMGS_Sharpen10         = 12,
		TMGS_NoMipmaps         = 13,
		TMGS_LeaveExistingMips = 14,
		TMGS_Blur1             = 15,
		TMGS_Blur2             = 16,
		TMGS_Blur3             = 17,
		TMGS_Blur4             = 18,
		TMGS_Blur5             = 19,
		TMGS_MAX               = 20
	};

	/**
	 * Enum Engine.Texture.ETextureMipCount
	 */
	enum class ETextureMipCount : uint8_t
	{
		TMC_ResidentMips  = 0,
		TMC_AllMips       = 1,
		TMC_AllMipsBiased = 2,
		TMC_MAX           = 3
	};

	/**
	 * Enum Engine.CloudStorageBase.ECloudStorageDelegate
	 */
	enum class ECloudStorageDelegate : uint8_t
	{
		CSD_KeyValueReadComplete     = 0,
		CSD_KeyValueWriteComplete    = 1,
		CSD_ValueChanged             = 2,
		CSD_DocumentQueryComplete    = 3,
		CSD_DocumentReadComplete     = 4,
		CSD_DocumentWriteComplete    = 5,
		CSD_DocumentConflictDetected = 6,
		CSD_MAX                      = 7
	};

	/**
	 * Enum Engine.UIRoot.EInputPlatformType
	 */
	enum class EInputPlatformType : uint8_t
	{
		IPT_PC  = 0,
		IPT     = 1,
		IPT_PS3 = 2,
		IPT_MAX = 3
	};

	/**
	 * Enum Engine.Interaction.ETouchType
	 */
	enum class ETouchType : uint8_t
	{
		Touch_Began      = 0,
		Touch_Moved      = 1,
		Touch_Stationary = 2,
		Touch_Ended      = 3,
		Touch_Cancelled  = 4,
		Touch_MAX        = 5
	};

	/**
	 * Enum Engine.CoverGroup.ECoverGroupFillAction
	 */
	enum class ECoverGroupFillAction : uint8_t
	{
		CGFA_Overwrite = 0,
		CGFA_Add       = 1,
		CGFA_Remove    = 2,
		CGFA_Clear     = 3,
		CGFA_Cylinder  = 4,
		CGFA_MAX       = 5
	};

	/**
	 * Enum Engine.CoverLink.ECoverLocationDescription
	 */
	enum class ECoverLocationDescription : uint8_t
	{
		CoverDesc_None           = 0,
		CoverDesc_InWindow       = 1,
		CoverDesc_InDoorway      = 2,
		CoverDesc_BehindCar      = 3,
		CoverDesc_BehindTruck    = 4,
		CoverDesc_OnTruck        = 5,
		CoverDesc_BehindBarrier  = 6,
		CoverDesc_BehindColumn   = 7,
		CoverDesc_BehindCrate    = 8,
		CoverDesc_BehindWall     = 9,
		CoverDesc_BehindStatue   = 10,
		CoverDesc_BehindSandbags = 11,
		CoverDesc_MAX            = 12
	};

	/**
	 * Enum Engine.CoverLink.ECoverType
	 */
	enum class ECoverType : uint8_t
	{
		CT_None     = 0,
		CT_Standing = 1,
		CT_MidLevel = 2,
		CT_MAX      = 3
	};

	/**
	 * Enum Engine.CoverLink.ECoverAction
	 */
	enum class ECoverAction : uint8_t
	{
		CA_Default    = 0,
		CA_BlindLeft  = 1,
		CA_BlindRight = 2,
		CA_LeanLeft   = 3,
		CA_LeanRight  = 4,
		CA_PopUp      = 5,
		CA_BlindUp    = 6,
		CA_PeekLeft   = 7,
		CA_PeekRight  = 8,
		CA_PeekUp     = 9,
		CA_MAX        = 10
	};

	/**
	 * Enum Engine.CoverLink.ECoverDirection
	 */
	enum class ECoverDirection : uint8_t
	{
		CD_Default = 0,
		CD_Left    = 1,
		CD_Right   = 2,
		CD_Up      = 3,
		CD_MAX     = 4
	};

	/**
	 * Enum Engine.CoverLink.EFireLinkID
	 */
	enum class EFireLinkID : uint8_t
	{
		FLI_FireLink         = 0,
		FLI_RejectedFireLink = 1,
		FLI_MAX              = 2
	};

	/**
	 * Enum Engine.StaticMeshComponent.ELightmapModificationFunction
	 */
	enum class ELightmapModificationFunction : uint8_t
	{
		MLMF_Modulate      = 0,
		MLMF_ModulateAlpha = 1,
		MLMF_MAX           = 2
	};

	/**
	 * Enum Engine.DecalComponent.EFilterMode
	 */
	enum class EFilterMode : uint8_t
	{
		FM_None   = 0,
		FM_Ignore = 1,
		FM_Affect = 2,
		FM_MAX    = 3
	};

	/**
	 * Enum Engine.DecalComponent.EDecalTransform
	 */
	enum class EDecalTransform : uint8_t
	{
		DecalTransform_OwnerAbsolute = 0,
		DecalTransform_OwnerRelative = 1,
		DecalTransform_SpawnRelative = 2,
		DecalTransform_MAX           = 3
	};

	/**
	 * Enum Engine.MaterialInterface.EMaterialUsage
	 */
	enum class EMaterialUsage : uint8_t
	{
		MATUSAGE_SkeletalMesh           = 0,
		MATUSAGE_FracturedMeshes        = 1,
		MATUSAGE_ParticleSprites        = 2,
		MATUSAGE_BeamTrails             = 3,
		MATUSAGE_ParticleSubUV          = 4,
		MATUSAGE_SpeedTree              = 5,
		MATUSAGE_StaticLighting         = 6,
		MATUSAGE_GammaCorrection        = 7,
		MATUSAGE_LensFlare              = 8,
		MATUSAGE_InstancedMeshParticles = 9,
		MATUSAGE_FluidSurface           = 10,
		MATUSAGE_Decals                 = 11,
		MATUSAGE_MaterialEffect         = 12,
		MATUSAGE_MorphTargets           = 13,
		MATUSAGE_FogVolumes             = 14,
		MATUSAGE_RadialBlur             = 15,
		MATUSAGE_InstancedMeshes        = 16,
		MATUSAGE_SplineMesh             = 17,
		MATUSAGE_ScreenDoorFade         = 18,
		MATUSAGE_APEXMesh               = 19,
		MATUSAGE_Terrain                = 20,
		MATUSAGE_Landscape              = 21,
		MATUSAGE_GlareFilter            = 22,
		MATUSAGE_MAX                    = 23
	};

	/**
	 * Enum Engine.LightComponent.EShadowFilterQuality
	 */
	enum class EShadowFilterQuality : uint8_t
	{
		SFQ_Low    = 0,
		SFQ_Medium = 1,
		SFQ_High   = 2,
		SFQ_MAX    = 3
	};

	/**
	 * Enum Engine.LightComponent.EShadowProjectionTechnique
	 */
	enum class EShadowProjectionTechnique : uint8_t
	{
		ShadowProjTech_Default     = 0,
		ShadowProjTech_PCF         = 1,
		ShadowProjTech_VSM         = 2,
		ShadowProjTech_BPCF_Low    = 3,
		ShadowProjTech_BPCF_Medium = 4,
		ShadowProjTech_BPCF_High   = 5,
		ShadowProjTech_MAX         = 6
	};

	/**
	 * Enum Engine.LightComponent.ELightShadowMode
	 */
	enum class ELightShadowMode : uint8_t
	{
		LightShadow_Normal         = 0,
		LightShadow_Modulate       = 1,
		LightShadow_ModulateBetter = 2,
		LightShadow_MAX            = 3
	};

	/**
	 * Enum Engine.LightComponent.ELightAffectsClassification
	 */
	enum class ELightAffectsClassification : uint8_t
	{
		LAC_USER_SELECTED                = 0,
		LAC_DYNAMIC_AFFECTING            = 1,
		LAC_STATIC_AFFECTING             = 2,
		LAC_DYNAMIC_AND_STATIC_AFFECTING = 3,
		LAC_MAX                          = 4
	};

	/**
	 * Enum Engine.DistributionFloatParameterBase.DistributionParamMode
	 */
	enum class EDistributionParamMode : uint8_t
	{
		DPM_Normal = 0,
		DPM_Abs    = 1,
		DPM_Direct = 2,
		DPM_MAX    = 3
	};

	/**
	 * Enum Engine.DOFAndBloomEffect.EDOFQuality
	 */
	enum class EDOFQuality : uint8_t
	{
		DOFQuality_Low    = 0,
		DOFQuality_Medium = 1,
		DOFQuality_High   = 2,
		DOFQuality_MAX    = 3
	};

	/**
	 * Enum Engine.DOFAndBloomEffect.EDOFType
	 */
	enum class EDOFType : uint8_t
	{
		DOFType_SimpleDOF    = 0,
		DOFType_ReferenceDOF = 1,
		DOFType_BokehDOF     = 2,
		DOFType_MAX          = 3
	};

	/**
	 * Enum Engine.DoorMarker.EDoorType
	 */
	enum class EDoorType : uint8_t
	{
		DOOR_Shoot = 0,
		DOOR_Touch = 1,
		DOOR_MAX   = 2
	};

	/**
	 * Enum Engine.ParticleSystemComponent.EParticleSysParamType
	 */
	enum class EParticleSysParamType : uint8_t
	{
		PSPT_None       = 0,
		PSPT_Scalar     = 1,
		PSPT_ScalarRand = 2,
		PSPT_Vector     = 3,
		PSPT_VectorRand = 4,
		PSPT_Color      = 5,
		PSPT_Actor      = 6,
		PSPT_Material   = 7,
		PSPT_MAX        = 8
	};

	/**
	 * Enum Engine.ParticleSystemComponent.ParticleReplayState
	 */
	enum class EParticleReplayState : uint8_t
	{
		PRS_Disabled  = 0,
		PRS_Capturing = 1,
		PRS_Replaying = 2,
		PRS_MAX       = 3
	};

	/**
	 * Enum Engine.ParticleSystemComponent.EParticleEventType
	 */
	enum class EParticleEventType : uint8_t
	{
		EPET_Any                     = 0,
		EPET_Spawn                   = 1,
		EPET_Death                   = 2,
		EPET_Collision               = 3,
		EPET_WorldAttractorCollision = 4,
		EPET_Kismet                  = 5,
		EPET_MAX                     = 6
	};

	/**
	 * Enum Engine.ParticleSystem.ParticleSystemLODMethod
	 */
	enum class EParticleSystemLODMethod : uint8_t
	{
		PARTICLESYSTEMLODMETHOD_Automatic         = 0,
		PARTICLESYSTEMLODMETHOD_DirectSet         = 1,
		PARTICLESYSTEMLODMETHOD_ActivateAutomatic = 2,
		PARTICLESYSTEMLODMETHOD_MAX               = 3
	};

	/**
	 * Enum Engine.Engine.ETransitionType
	 */
	enum class ETransitionType : uint8_t
	{
		TT_None       = 0,
		TT_Paused     = 1,
		TT_Loading    = 2,
		TT_Saving     = 3,
		TT_Connecting = 4,
		TT_Precaching = 5,
		TT_MAX        = 6
	};

	/**
	 * Enum Engine.FacebookIntegration.EFacebookIntegrationDelegate
	 */
	enum class EFacebookIntegrationDelegate : uint8_t
	{
		FID_AuthorizationComplete   = 0,
		FID_FacebookRequestComplete = 1,
		FID_DialogComplete          = 2,
		FID_FriendsListComplete     = 3,
		FID_MAX                     = 4
	};

	/**
	 * Enum Engine.FileWriter.FWFileType
	 */
	enum class EFWFileType : uint8_t
	{
		FWFT_Log   = 0,
		FWFT_Stats = 1,
		FWFT_HTML  = 2,
		FWFT_User  = 3,
		FWFT_Debug = 4,
		FWFT_MAX   = 5
	};

	/**
	 * Enum Engine.FluidInfluenceComponent.EInfluenceType
	 */
	enum class EInfluenceType : uint8_t
	{
		Fluid_Flow      = 0,
		Fluid_Raindrops = 1,
		Fluid_Wave      = 2,
		Fluid_Sphere    = 3,
		Fluid_MAX       = 4
	};

	/**
	 * Enum Engine.FontImportOptions.EFontImportCharacterSet
	 */
	enum class EFontImportCharacterSet : uint8_t
	{
		FontICS_Default = 0,
		FontICS_Ansi    = 1,
		FontICS_Symbol  = 2,
		FontICS_MAX     = 3
	};

	/**
	 * Enum Engine.ForceFeedbackWaveform.EWaveformFunction
	 */
	enum class EWaveformFunction : uint8_t
	{
		WF_Constant         = 0,
		WF_LinearIncreasing = 1,
		WF_LinearDecreasing = 2,
		WF_Sin0to90         = 3,
		WF_Sin90to180       = 4,
		WF_Sin0to180        = 5,
		WF_Noise            = 6,
		WF_MAX              = 7
	};

	/**
	 * Enum Engine.WorldInfo.EHostMigrationProgress
	 */
	enum class EHostMigrationProgress : uint8_t
	{
		HostMigration_None              = 0,
		HostMigration_FindingNewHost    = 1,
		HostMigration_MigratingAsHost   = 2,
		HostMigration_MigratingAsClient = 3,
		HostMigration_ClientTravel      = 4,
		HostMigration_HostReadyToTravel = 5,
		HostMigration_Failed            = 6,
		HostMigration_MAX               = 7
	};

	/**
	 * Enum Engine.WorldInfo.EConsoleType
	 */
	enum class EConsoleType : uint8_t
	{
		CONSOLE_Any     = 0,
		CONSOLE_Xbox360 = 1,
		CONSOLE_PS3     = 2,
		CONSOLE_Mobile  = 3,
		CONSOLE_IPhone  = 4,
		CONSOLE_Android = 5,
		CONSOLE_WiiU    = 6,
		CONSOLE_Flash   = 7,
		CONSOLE_Orbis   = 8,
		CONSOLE_MAX     = 9
	};

	/**
	 * Enum Engine.WorldInfo.EPreferredLightmapType
	 */
	enum class EPreferredLightmapType : uint8_t
	{
		EPLT_Default     = 0,
		EPLT_Directional = 1,
		EPLT_Simple      = 2,
		EPLT_MAX         = 3
	};

	/**
	 * Enum Engine.WorldInfo.EVisibilityAggressiveness
	 */
	enum class EVisibilityAggressiveness : uint8_t
	{
		VIS_LeastAggressive      = 0,
		VIS_ModeratelyAggressive = 1,
		VIS_MostAggressive       = 2,
		VIS_Max                  = 3
	};

	/**
	 * Enum Engine.WorldInfo.ENetMode
	 */
	enum class ENetMode : uint8_t
	{
		NM_Standalone      = 0,
		NM_DedicatedServer = 1,
		NM_ListenServer    = 2,
		NM_Client          = 3,
		NM_MAX             = 4
	};

	/**
	 * Enum Engine.GameEngine.EFullyLoadPackageType
	 */
	enum class EFullyLoadPackageType : uint8_t
	{
		FULLYLOAD_Map                = 0,
		FULLYLOAD_Game_PreLoadClass  = 1,
		FULLYLOAD_Game_PostLoadClass = 2,
		FULLYLOAD_Always             = 3,
		FULLYLOAD_Mutator            = 4,
		FULLYLOAD_MAX                = 5
	};

	/**
	 * Enum Engine.GameInfo.EStandbyType
	 */
	enum class EStandbyType : uint8_t
	{
		STDBY_Rx      = 0,
		STDBY_Tx      = 1,
		STDBY_BadPing = 2,
		STDBY_MAX     = 3
	};

	/**
	 * Enum Engine.GamePadLightbarSubsystem.LightBarState
	 */
	enum class ELightBarState : uint8_t
	{
		ELBS_Standby = 0,
		ELBS_Lerping = 1,
		ELBS_Pulsing = 2,
		ELBS_MAX     = 3
	};

	/**
	 * Enum Engine.GameplayEvents.EGameStatGroups
	 */
	enum class EGameStatGroups : uint8_t
	{
		GSG_EngineStats  = 0,
		GSG_Game         = 1,
		GSG_Team         = 2,
		GSG_Player       = 3,
		GSG_Weapon       = 4,
		GSG_Damage       = 5,
		GSG_Projectile   = 6,
		GSG_Pawn         = 7,
		GSG_GameSpecific = 8,
		GSG_Aggregate    = 9,
		GSG_MAX          = 10
	};

	/**
	 * Enum Engine.GameViewportClient.ESplitScreenType
	 */
	enum class ESplitScreenType : uint8_t
	{
		eSST_NONE            = 0,
		eSST_2P_HORIZONTAL   = 1,
		eSST_2P_VERTICAL     = 2,
		eSST_3P_FAVOR_TOP    = 3,
		eSST_3P_FAVOR_BOTTOM = 4,
		eSST_4P              = 5,
		eSST_MAX             = 6
	};

	/**
	 * Enum Engine.GameViewportClient.ESafeZoneType
	 */
	enum class ESafeZoneType : uint8_t
	{
		eSZ_TOP    = 0,
		eSZ_BOTTOM = 1,
		eSZ_LEFT   = 2,
		eSZ_RIGHT  = 3,
		eSZ_MAX    = 4
	};

	/**
	 * Enum Engine.GHM_SoundManager_Base.ESoundResult
	 */
	enum class ESoundResult : uint8_t
	{
		SoundResult_NotPerformed = 0,
		SoundResult_Success      = 1,
		SoundResult_Failure      = 2,
		SoundResult_Count        = 3,
		SoundResult_MAX          = 4
	};

	/**
	 * Enum Engine.InGameAdManager.EAdManagerDelegate
	 */
	enum class EAdManagerDelegate : uint8_t
	{
		AMD_ClickedBanner = 0,
		AMD_UserClosedAd  = 1,
		AMD_MAX           = 2
	};

	/**
	 * Enum Engine.InstancedFoliageSettings.FoliageCullOption
	 */
	enum class EFoliageCullOption : uint8_t
	{
		FOLIAGECULL_Cull       = 0,
		FOLIAGECULL_ScaleZ     = 1,
		FOLIAGECULL_ScaleXYZ   = 2,
		FOLIAGECULL_TranslateZ = 3,
		FOLIAGECULL_MAX        = 4
	};

	/**
	 * Enum Engine.Interface_NavMeshPathObstacle.EEdgeHandlingStatus
	 */
	enum class EEdgeHandlingStatus : uint8_t
	{
		EHS_AddedBothDirs = 0,
		EHS_Added0to1     = 1,
		EHS_Added1to0     = 2,
		EHS_AddedNone     = 3,
		EHS_MAX           = 4
	};

	/**
	 * Enum Engine.InterpTrack.ETrackActiveCondition
	 */
	enum class ETrackActiveCondition : uint8_t
	{
		ETAC_Always       = 0,
		ETAC_GoreEnabled  = 1,
		ETAC_GoreDisabled = 2,
		ETAC_MAX          = 3
	};

	/**
	 * Enum Engine.InterpTrackHeadTracking.EHeadTrackingAction
	 */
	enum class EHeadTrackingAction : uint8_t
	{
		EHTA_DisableHeadTracking = 0,
		EHTA_EnableHeadTracking  = 1,
		EHTA_MAX                 = 2
	};

	/**
	 * Enum Engine.InterpTrackToggle.ETrackToggleAction
	 */
	enum class ETrackToggleAction : uint8_t
	{
		ETTA_Off     = 0,
		ETTA_On      = 1,
		ETTA_Toggle  = 2,
		ETTA_Trigger = 3,
		ETTA_MAX     = 4
	};

	/**
	 * Enum Engine.InterpTrackVisibility.EVisibilityTrackCondition
	 */
	enum class EVisibilityTrackCondition : uint8_t
	{
		EVTC_Always       = 0,
		EVTC_GoreEnabled  = 1,
		EVTC_GoreDisabled = 2,
		EVTC_MAX          = 3
	};

	/**
	 * Enum Engine.InterpTrackVisibility.EVisibilityTrackAction
	 */
	enum class EVisibilityTrackAction : uint8_t
	{
		EVTA_Hide   = 0,
		EVTA_Show   = 1,
		EVTA_Toggle = 2,
		EVTA_MAX    = 3
	};

	/**
	 * Enum Engine.InterpTrackMove.EInterpTrackMoveRotMode
	 */
	enum class EInterpTrackMoveRotMode : uint8_t
	{
		IMR_Keyframed   = 0,
		IMR_LookAtGroup = 1,
		IMR_Ignore      = 2,
		IMR_MAX         = 3
	};

	/**
	 * Enum Engine.InterpTrackMove.EInterpTrackMoveFrame
	 */
	enum class EInterpTrackMoveFrame : uint8_t
	{
		IMF_World             = 0,
		IMF_RelativeToInitial = 1,
		IMF_MAX               = 2
	};

	/**
	 * Enum Engine.InterpTrackMoveAxis.EInterpMoveAxis
	 */
	enum class EInterpMoveAxis : uint8_t
	{
		AXIS_TranslationX = 0,
		AXIS_TranslationY = 1,
		AXIS_TranslationZ = 2,
		AXIS_RotationX    = 3,
		AXIS_RotationY    = 4,
		AXIS_RotationZ    = 5,
		AXIS_MAX          = 6
	};

	/**
	 * Enum Engine.Landscape.ELandscapeSetupErrors
	 */
	enum class ELandscapeSetupErrors : uint8_t
	{
		LSE_None            = 0,
		LSE_NoLandscapeInfo = 1,
		LSE_CollsionXY      = 2,
		LSE_NoLayerInfo     = 3,
		LSE_MAX             = 4
	};

	/**
	 * Enum Engine.LandscapeGizmoActiveActor.ELandscapeGizmoType
	 */
	enum class ELandscapeGizmoType : uint8_t
	{
		LGT_None   = 0,
		LGT_Height = 1,
		LGT_Weight = 2,
		LGT_MAX    = 3
	};

	/**
	 * Enum Engine.LevelGridVolume.LevelGridCellShape
	 */
	enum class ELevelGridCellShape : uint8_t
	{
		LGCS_Box = 0,
		LGCS_Hex = 1,
		LGCS_MAX = 2
	};

	/**
	 * Enum Engine.LevelStreaming.ERandomGenerateLevelEdgeGroup
	 */
	enum class ERandomGenerateLevelEdgeGroup : uint8_t
	{
		A   = 0,
		B   = 1,
		C   = 2,
		D   = 3,
		E   = 4,
		F   = 5,
		G   = 6,
		H   = 7,
		I   = 8,
		J   = 9,
		K   = 10,
		L   = 11,
		M   = 12,
		N   = 13,
		O   = 14,
		P   = 15,
		MAX = 16
	};

	/**
	 * Enum Engine.LevelStreaming.ERandomGenerateLevelShopType
	 */
	enum class ERandomGenerateLevelShopType : uint8_t
	{
		None     = 0,
		Parts    = 1,
		Mushroom = 2,
		MAX      = 3
	};

	/**
	 * Enum Engine.LevelStreaming.ERandomGenerateLevelEdgeId
	 */
	enum class ERandomGenerateLevelEdgeId : uint8_t
	{
		RightUp   = 0,
		Right     = 1,
		RightDown = 2,
		LeftDown  = 3,
		Left      = 4,
		LeftUp    = 5,
		MAX       = 6
	};

	/**
	 * Enum Engine.LevelStreamingVolume.EStreamingVolumeUsage
	 */
	enum class EStreamingVolumeUsage : uint8_t
	{
		SVB_Loading                  = 0,
		SVB_LoadingAndVisibility     = 1,
		SVB_VisibilityBlockingOnLoad = 2,
		SVB_BlockingOnLoad           = 3,
		SVB_LoadingNotVisible        = 4,
		SVB_MAX                      = 5
	};

	/**
	 * Enum Engine.MaterialExpressionAntialiasedTextureMask.ETextureColorChannel
	 */
	enum class ETextureColorChannel : uint8_t
	{
		TCC_Red   = 0,
		TCC_Green = 1,
		TCC_Blue  = 2,
		TCC_Alpha = 3,
		TCC_MAX   = 4
	};

	/**
	 * Enum Engine.MaterialExpressionCustom.ECustomMaterialOutputType
	 */
	enum class ECustomMaterialOutputType : uint8_t
	{
		CMOT_Float1 = 0,
		CMOT_Float2 = 1,
		CMOT_Float3 = 2,
		CMOT_Float4 = 3,
		CMOT_MAX    = 4
	};

	/**
	 * Enum Engine.MaterialExpressionDepthOfFieldFunction.EDepthOfFieldFunctionValue
	 */
	enum class EDepthOfFieldFunctionValue : uint8_t
	{
		TDOF_NearAndFarMask = 0,
		TDOF_NearMask       = 1,
		TDOF_FarMask        = 2,
		TDOF_MAX            = 3
	};

	/**
	 * Enum Engine.MaterialExpressionFunctionInput.EFunctionInputType
	 */
	enum class EFunctionInputType : uint8_t
	{
		FunctionInput_Scalar      = 0,
		FunctionInput_Vector2     = 1,
		FunctionInput_Vector3     = 2,
		FunctionInput_Vector4     = 3,
		FunctionInput_Texture2D   = 4,
		FunctionInput_TextureCube = 5,
		FunctionInput_StaticBool  = 6,
		FunctionInput_MAX         = 7
	};

	/**
	 * Enum Engine.MaterialExpressionLandscapeLayerBlend.ELandscapeLayerBlendType
	 */
	enum class ELandscapeLayerBlendType : uint8_t
	{
		LB_AlphaBlend  = 0,
		LB_HeightBlend = 1,
		LB_MAX         = 2
	};

	/**
	 * Enum Engine.MaterialExpressionSceneTexture.ESceneTextureType
	 */
	enum class ESceneTextureType : uint8_t
	{
		SceneTex_Lighting = 0,
		SceneTex_MAX      = 1
	};

	/**
	 * Enum Engine.MaterialExpressionTerrainLayerCoords.ETerrainCoordMappingType
	 */
	enum class ETerrainCoordMappingType : uint8_t
	{
		TCMT_Auto = 0,
		TCMT_XY   = 1,
		TCMT_XZ   = 2,
		TCMT_YZ   = 3,
		TCMT_MAX  = 4
	};

	/**
	 * Enum Engine.MaterialExpressionTransform.EMaterialVectorCoordTransform
	 */
	enum class EMaterialVectorCoordTransform : uint8_t
	{
		TRANSFORM_World   = 0,
		TRANSFORM_View    = 1,
		TRANSFORM_Local   = 2,
		TRANSFORM_Tangent = 3,
		TRANSFORM_MAX     = 4
	};

	/**
	 * Enum Engine.MaterialExpressionTransform.EMaterialVectorCoordTransformSource
	 */
	enum class EMaterialVectorCoordTransformSource : uint8_t
	{
		TRANSFORMSOURCE_World   = 0,
		TRANSFORMSOURCE_Local   = 1,
		TRANSFORMSOURCE_Tangent = 2,
		TRANSFORMSOURCE_View    = 3,
		TRANSFORMSOURCE_MAX     = 4
	};

	/**
	 * Enum Engine.MaterialExpressionTransformPosition.EMaterialPositionTransform
	 */
	enum class EMaterialPositionTransform : uint8_t
	{
		TRANSFORMPOS_World = 0,
		TRANSFORMPOS_MAX   = 1
	};

	/**
	 * Enum Engine.MaterialExpressionTransformPosition.EMaterialPositionTransformSource
	 */
	enum class EMaterialPositionTransformSource : uint8_t
	{
		TRANSFORMPOSSOURCE_Local          = 0,
		TRANSFORMPOSSOURCE_PostProjection = 1,
		TRANSFORMPOSSOURCE_MAX            = 2
	};

	/**
	 * Enum Engine.MicroTransactionBase.EMicroTransactionDelegate
	 */
	enum class EMicroTransactionDelegate : uint8_t
	{
		MTD_PurchaseQueryComplete = 0,
		MTD_PurchaseComplete      = 1,
		MTD_MAX                   = 2
	};

	/**
	 * Enum Engine.MicroTransactionBase.EMicroTransactionResult
	 */
	enum class EMicroTransactionResult : uint8_t
	{
		MTR_Succeeded          = 0,
		MTR_Failed             = 1,
		MTR_Canceled           = 2,
		MTR_RestoredFromServer = 3,
		MTR_MAX                = 4
	};

	/**
	 * Enum Engine.NxForceFieldGeneric.FFG_ForceFieldCoordinates
	 */
	enum class EFFG_ForceFieldCoordinates : uint8_t
	{
		FFG_CARTESIAN   = 0,
		FFG_SPHERICAL   = 1,
		FFG_CYLINDRICAL = 2,
		FFG_TOROIDAL    = 3,
		FFG_MAX         = 4
	};

	/**
	 * Enum Engine.NxGenericForceFieldBrush.FFB_ForceFieldCoordinates
	 */
	enum class EFFB_ForceFieldCoordinates : uint8_t
	{
		FFB_CARTESIAN   = 0,
		FFB_SPHERICAL   = 1,
		FFB_CYLINDRICAL = 2,
		FFB_TOROIDAL    = 3,
		FFB_MAX         = 4
	};

	/**
	 * Enum Engine.OnlineGameDownloadInterface.EDownloadSpeed
	 */
	enum class EDownloadSpeed : uint8_t
	{
		EDLS_Pause = 0,
		EDLS_Slow  = 1,
		EDLS_Fast  = 2,
		EDLS_MAX   = 3
	};

	/**
	 * Enum Engine.OnlinePartyInterface.EPartyError
	 */
	enum class EPartyError : uint8_t
	{
		EPE_Ok                    = 0,
		EPE_UnknownError          = 1,
		EPE_TheyAlreadyInParty    = 2,
		EPE_YouAlreadyInParty     = 3,
		EPE_NotLeader             = 4,
		EPE_PartyDoesNotExist     = 5,
		EPE_PartyAtCapacity       = 6,
		EPE_TheyPendingOtherParty = 7,
		EPE_TheyPendingOwnParty   = 8,
		EPE_MAX                   = 9
	};

	/**
	 * Enum Engine.OnlinePlayerStorage.EOnlineProfilePropertyOwner
	 */
	enum class EOnlineProfilePropertyOwner : uint8_t
	{
		OPPO_None          = 0,
		OPPO_OnlineService = 1,
		OPPO_Game          = 2,
		OPPO_MAX           = 3
	};

	/**
	 * Enum Engine.OnlinePlayerStorage.EOnlinePlayerStorageAsyncState
	 */
	enum class EOnlinePlayerStorageAsyncState : uint8_t
	{
		OPAS_NotStarted = 0,
		OPAS_Read       = 1,
		OPAS_Write      = 2,
		OPAS_Finished   = 3,
		OPAS_MAX        = 4
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileSettingID
	 */
	enum class EProfileSettingID : uint8_t
	{
		PSI_Unknown                 = 0,
		PSI_ControllerVibration     = 1,
		PSI_YInversion              = 2,
		PSI_GamerCred               = 3,
		PSI_GamerRep                = 4,
		PSI_VoiceMuted              = 5,
		PSI_VoiceThruSpeakers       = 6,
		PSI_VoiceVolume             = 7,
		PSI_GamerPictureKey         = 8,
		PSI_GamerMotto              = 9,
		PSI_GamerTitlesPlayed       = 10,
		PSI_GamerAchievementsEarned = 11,
		PSI_GameDifficulty          = 12,
		PSI_ControllerSensitivity   = 13,
		PSI_PreferredColor1         = 14,
		PSI_PreferredColor2         = 15,
		PSI_AutoAim                 = 16,
		PSI_AutoCenter              = 17,
		PSI_MovementControl         = 18,
		PSI_RaceTransmission        = 19,
		PSI_RaceCameraLocation      = 20,
		PSI_RaceBrakeControl        = 21,
		PSI_RaceAcceleratorControl  = 22,
		PSI_GameCredEarned          = 23,
		PSI_GameAchievementsEarned  = 24,
		PSI_EndLiveIds              = 25,
		PSI_ProfileVersionNum       = 26,
		PSI_ProfileSaveCount        = 27,
		PSI_MAX                     = 28
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileDifficultyOptions
	 */
	enum class EProfileDifficultyOptions : uint8_t
	{
		PDO_Normal = 0,
		PDO_Easy   = 1,
		PDO_Hard   = 2,
		PDO_MAX    = 3
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileControllerSensitivityOptions
	 */
	enum class EProfileControllerSensitivityOptions : uint8_t
	{
		PCSO_Medium = 0,
		PCSO_Low    = 1,
		PCSO_High   = 2,
		PCSO_MAX    = 3
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfilePreferredColorOptions
	 */
	enum class EProfilePreferredColorOptions : uint8_t
	{
		PPCO_None   = 0,
		PPCO_Black  = 1,
		PPCO_White  = 2,
		PPCO_Yellow = 3,
		PPCO_Orange = 4,
		PPCO_Pink   = 5,
		PPCO_Red    = 6,
		PPCO_Purple = 7,
		PPCO_Blue   = 8,
		PPCO_Green  = 9,
		PPCO_Brown  = 10,
		PPCO_Silver = 11,
		PPCO_MAX    = 12
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileAutoAimOptions
	 */
	enum class EProfileAutoAimOptions : uint8_t
	{
		PAAO_Off = 0,
		PAAO_On  = 1,
		PAAO_MAX = 2
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileAutoCenterOptions
	 */
	enum class EProfileAutoCenterOptions : uint8_t
	{
		PACO_Off = 0,
		PACO_On  = 1,
		PACO_MAX = 2
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileMovementControlOptions
	 */
	enum class EProfileMovementControlOptions : uint8_t
	{
		PMCO_L_Thumbstick = 0,
		PMCO_R_Thumbstick = 1,
		PMCO_MAX          = 2
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileRaceTransmissionOptions
	 */
	enum class EProfileRaceTransmissionOptions : uint8_t
	{
		PRTO_Auto   = 0,
		PRTO_Manual = 1,
		PRTO_MAX    = 2
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileRaceCameraLocationOptions
	 */
	enum class EProfileRaceCameraLocationOptions : uint8_t
	{
		PRCLO_Behind = 0,
		PRCLO_Front  = 1,
		PRCLO_Inside = 2,
		PRCLO_MAX    = 3
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileRaceBrakeControlOptions
	 */
	enum class EProfileRaceBrakeControlOptions : uint8_t
	{
		PRBCO_Trigger = 0,
		PRBCO_Button  = 1,
		PRBCO_MAX     = 2
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileRaceAcceleratorControlOptions
	 */
	enum class EProfileRaceAcceleratorControlOptions : uint8_t
	{
		PRACO_Trigger = 0,
		PRACO_Button  = 1,
		PRACO_MAX     = 2
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileYInversionOptions
	 */
	enum class EProfileYInversionOptions : uint8_t
	{
		PYIO_Off = 0,
		PYIO_On  = 1,
		PYIO_MAX = 2
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileXInversionOptions
	 */
	enum class EProfileXInversionOptions : uint8_t
	{
		PXIO_Off = 0,
		PXIO_On  = 1,
		PXIO_MAX = 2
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileOmniDirEvadeOptions
	 */
	enum class EProfileOmniDirEvadeOptions : uint8_t
	{
		PODI_Off = 0,
		PODI_On  = 1,
		PODI_MAX = 2
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileControllerVibrationToggleOptions
	 */
	enum class EProfileControllerVibrationToggleOptions : uint8_t
	{
		PCVTO_Off         = 0,
		PCVTO_IgnoreThis  = 1,
		PCVTO_IgnoreThis2 = 2,
		PCVTO_On          = 3,
		PCVTO_MAX         = 4
	};

	/**
	 * Enum Engine.OnlineProfileSettings.EProfileVoiceThruSpeakersOptions
	 */
	enum class EProfileVoiceThruSpeakersOptions : uint8_t
	{
		PVTSO_Off  = 0,
		PVTSO_On   = 1,
		PVTSO_Both = 2,
		PVTSO_MAX  = 3
	};

	/**
	 * Enum Engine.ParticleEmitter.EEmitterRenderMode
	 */
	enum class EEmitterRenderMode : uint8_t
	{
		ERM_Normal = 0,
		ERM_Point  = 1,
		ERM_Cross  = 2,
		ERM_None   = 3,
		ERM_MAX    = 4
	};

	/**
	 * Enum Engine.ParticleEmitter.EParticleSubUVInterpMethod
	 */
	enum class EParticleSubUVInterpMethod : uint8_t
	{
		PSUVIM_None         = 0,
		PSUVIM_Linear       = 1,
		PSUVIM_Linear_Blend = 2,
		PSUVIM_Random       = 3,
		PSUVIM_Random_Blend = 4,
		PSUVIM_MAX          = 5
	};

	/**
	 * Enum Engine.ParticleEmitter.EParticleBurstMethod
	 */
	enum class EParticleBurstMethod : uint8_t
	{
		EPBM_Instant      = 0,
		EPBM_Interpolated = 1,
		EPBM_MAX          = 2
	};

	/**
	 * Enum Engine.ParticleModule.EModuleType
	 */
	enum class EModuleType : uint8_t
	{
		EPMT_General  = 0,
		EPMT_TypeData = 1,
		EPMT_Beam     = 2,
		EPMT_Trail    = 3,
		EPMT_Spawn    = 4,
		EPMT_Required = 5,
		EPMT_Event    = 6,
		EPMT_MAX      = 7
	};

	/**
	 * Enum Engine.ParticleModule.EParticleSourceSelectionMethod
	 */
	enum class EParticleSourceSelectionMethod : uint8_t
	{
		EPSSM_Random     = 0,
		EPSSM_Sequential = 1,
		EPSSM_MAX        = 2
	};

	/**
	 * Enum Engine.ParticleModuleAttractorBoneSocket.EBoneSocketAttractorFalloffType
	 */
	enum class EBoneSocketAttractorFalloffType : uint8_t
	{
		BSFOFF_Constant = 0,
		BSFOFF_Linear   = 1,
		BSFOFF_Exponent = 2,
		BSFOFF_MAX      = 3
	};

	/**
	 * Enum Engine.ParticleModuleAttractorBoneSocket.ELocationBoneSocketDestSelectionMethod
	 */
	enum class ELocationBoneSocketDestSelectionMethod : uint8_t
	{
		BONESOCKETDESTSEL_Sequential       = 0,
		BONESOCKETDESTSEL_Random           = 1,
		BONESOCKETDESTSEL_RandomExhaustive = 2,
		BONESOCKETDESTSEL_BlendAll         = 3,
		BONESOCKETDESTSEL_MAX              = 4
	};

	/**
	 * Enum Engine.ParticleModuleAttractorBoneSocket.ELocationBoneSocketDestination
	 */
	enum class ELocationBoneSocketDestination : uint8_t
	{
		BONESOCKETDEST_Bones   = 0,
		BONESOCKETDEST_Sockets = 1,
		BONESOCKETDEST_MAX     = 2
	};

	/**
	 * Enum Engine.ParticleModuleAttractorParticle.EAttractorParticleSelectionMethod
	 */
	enum class EAttractorParticleSelectionMethod : uint8_t
	{
		EAPSM_Random     = 0,
		EAPSM_Sequential = 1,
		EAPSM_MAX        = 2
	};

	/**
	 * Enum Engine.ParticleModuleAttractorSkelVertSurface.EVertSurfaceAttractorFalloffType
	 */
	enum class EVertSurfaceAttractorFalloffType : uint8_t
	{
		VSFOFF_Constant = 0,
		VSFOFF_Linear   = 1,
		VSFOFF_Exponent = 2,
		VSFOFF_MAX      = 3
	};

	/**
	 * Enum Engine.ParticleModuleAttractorSkelVertSurface.EAttractorSkelVertSurfaceDestination
	 */
	enum class EAttractorSkelVertSurfaceDestination : uint8_t
	{
		VERTSURFACEDEST_Vert    = 0,
		VERTSURFACEDEST_Surface = 1,
		VERTSURFACEDEST_MAX     = 2
	};

	/**
	 * Enum Engine.ParticleModuleBeamBase.Beam2SourceTargetMethod
	 */
	enum class EBeam2SourceTargetMethod : uint8_t
	{
		PEB2STM_Default  = 0,
		PEB2STM_UserSet  = 1,
		PEB2STM_Emitter  = 2,
		PEB2STM_Particle = 3,
		PEB2STM_Actor    = 4,
		PEB2STM_MAX      = 5
	};

	/**
	 * Enum Engine.ParticleModuleBeamBase.Beam2SourceTargetTangentMethod
	 */
	enum class EBeam2SourceTargetTangentMethod : uint8_t
	{
		PEB2STTM_Direct       = 0,
		PEB2STTM_UserSet      = 1,
		PEB2STTM_Distribution = 2,
		PEB2STTM_Emitter      = 3,
		PEB2STTM_MAX          = 4
	};

	/**
	 * Enum Engine.ParticleModuleBeamModifier.BeamModifierType
	 */
	enum class EBeamModifierType : uint8_t
	{
		PEB2MT_Source = 0,
		PEB2MT_Target = 1,
		PEB2MT_MAX    = 2
	};

	/**
	 * Enum Engine.ParticleModuleCameraOffset.EParticleCameraOffsetUpdateMethod
	 */
	enum class EParticleCameraOffsetUpdateMethod : uint8_t
	{
		EPCOUM_DirectSet = 0,
		EPCOUM_Additive  = 1,
		EPCOUM_Scalar    = 2,
		EPCOUM_MAX       = 3
	};

	/**
	 * Enum Engine.ParticleModuleCollisionBase.EParticleCollisionComplete
	 */
	enum class EParticleCollisionComplete : uint8_t
	{
		EPCC_Kill              = 0,
		EPCC_Freeze            = 1,
		EPCC_HaltCollisions    = 2,
		EPCC_FreezeTranslation = 3,
		EPCC_FreezeRotation    = 4,
		EPCC_FreezeMovement    = 5,
		EPCC_MAX               = 6
	};

	/**
	 * Enum Engine.ParticleModuleCollision.ParticleAttractorActionType
	 */
	enum class EParticleAttractorActionType : uint8_t
	{
		PAAT_None    = 0,
		PAAT_Destroy = 1,
		PAAT_Freeze  = 2,
		PAAT_Event   = 3,
		PAAT_MAX     = 4
	};

	/**
	 * Enum Engine.ParticleModuleLocationBoneSocket.ELocationBoneSocketSource
	 */
	enum class ELocationBoneSocketSource : uint8_t
	{
		BONESOCKETSOURCE_Bones   = 0,
		BONESOCKETSOURCE_Sockets = 1,
		BONESOCKETSOURCE_MAX     = 2
	};

	/**
	 * Enum Engine.ParticleModuleLocationBoneSocket.ELocationBoneSocketSelectionMethod
	 */
	enum class ELocationBoneSocketSelectionMethod : uint8_t
	{
		BONESOCKETSEL_Sequential       = 0,
		BONESOCKETSEL_Random           = 1,
		BONESOCKETSEL_RandomExhaustive = 2,
		BONESOCKETSEL_MAX              = 3
	};

	/**
	 * Enum Engine.ParticleModuleLocationEmitter.ELocationEmitterSelectionMethod
	 */
	enum class ELocationEmitterSelectionMethod : uint8_t
	{
		ELESM_Random     = 0,
		ELESM_Sequential = 1,
		ELESM_MAX        = 2
	};

	/**
	 * Enum Engine.ParticleModuleLocationPrimitiveCylinder.CylinderHeightAxis
	 */
	enum class ECylinderHeightAxis : uint8_t
	{
		PMLPC_HEIGHTAXIS_X   = 0,
		PMLPC_HEIGHTAXIS_Y   = 1,
		PMLPC_HEIGHTAXIS_Z   = 2,
		PMLPC_HEIGHTAXIS_MAX = 3
	};

	/**
	 * Enum Engine.ParticleModuleLocationSkelVertSurface.ELocationSkelVertSurfaceSource
	 */
	enum class ELocationSkelVertSurfaceSource : uint8_t
	{
		VERTSURFACESOURCE_Vert    = 0,
		VERTSURFACESOURCE_Surface = 1,
		VERTSURFACESOURCE_MAX     = 2
	};

	/**
	 * Enum Engine.ParticleModuleLocationStaticVertSurface.ELocationStaticVertSurfaceSource
	 */
	enum class ELocationStaticVertSurfaceSource : uint8_t
	{
		VERTSTATICSURFACESOURCE_Vert    = 0,
		VERTSTATICSURFACESOURCE_Surface = 1,
		VERTSTATICSURFACESOURCE_MAX     = 2
	};

	/**
	 * Enum Engine.ParticleModuleOrbit.EOrbitChainMode
	 */
	enum class EOrbitChainMode : uint8_t
	{
		EOChainMode_Add   = 0,
		EOChainMode_Scale = 1,
		EOChainMode_Link  = 2,
		EOChainMode_MAX   = 3
	};

	/**
	 * Enum Engine.ParticleModuleOrientationAxisLock.EParticleAxisLock
	 */
	enum class EParticleAxisLock : uint8_t
	{
		EPAL_NONE       = 0,
		EPAL_X          = 1,
		EPAL_Y          = 2,
		EPAL_Z          = 3,
		EPAL_NEGATIVE_X = 4,
		EPAL_NEGATIVE_Y = 5,
		EPAL_NEGATIVE_Z = 6,
		EPAL_ROTATE_X   = 7,
		EPAL_ROTATE_Y   = 8,
		EPAL_ROTATE_Z   = 9,
		EPAL_MAX        = 10
	};

	/**
	 * Enum Engine.ParticleModuleParameterDynamic.EEmitterDynamicParameterValue
	 */
	enum class EEmitterDynamicParameterValue : uint8_t
	{
		EDPV_UserSet     = 0,
		EDPV_VelocityX   = 1,
		EDPV_VelocityY   = 2,
		EDPV_VelocityZ   = 3,
		EDPV_VelocityMag = 4,
		EDPV_MAX         = 5
	};

	/**
	 * Enum Engine.ParticleModulePhysicsVolumes.EParticleLevelInfluenceType
	 */
	enum class EParticleLevelInfluenceType : uint8_t
	{
		LIT_Never                 = 0,
		LIT_OutsidePhysicsVolumes = 1,
		LIT_Always                = 2,
		LIT_MAX                   = 3
	};

	/**
	 * Enum Engine.ParticleSpriteEmitter.EParticleScreenAlignment
	 */
	enum class EParticleScreenAlignment : uint8_t
	{
		PSA_Square       = 0,
		PSA_Rectangle    = 1,
		PSA_Velocity     = 2,
		PSA_TypeSpecific = 3,
		PSA_MAX          = 4
	};

	/**
	 * Enum Engine.ParticleModuleRequired.EEmitterNormalsMode
	 */
	enum class EEmitterNormalsMode : uint8_t
	{
		ENM_CameraFacing = 0,
		ENM_Spherical    = 1,
		ENM_Cylindrical  = 2,
		ENM_MAX          = 3
	};

	/**
	 * Enum Engine.ParticleModuleRequired.EParticleSortMode
	 */
	enum class EParticleSortMode : uint8_t
	{
		PSORTMODE_None            = 0,
		PSORTMODE_ViewProjDepth   = 1,
		PSORTMODE_DistanceToView  = 2,
		PSORTMODE_Age_OldestFirst = 3,
		PSORTMODE_Age_NewestFirst = 4,
		PSORTMODE_MAX             = 5
	};

	/**
	 * Enum Engine.ParticleModuleTrailSource.ETrail2SourceMethod
	 */
	enum class ETrail2SourceMethod : uint8_t
	{
		PET2SRCM_Default  = 0,
		PET2SRCM_Particle = 1,
		PET2SRCM_Actor    = 2,
		PET2SRCM_MAX      = 3
	};

	/**
	 * Enum Engine.ParticleModuleTrailSpawn.ETrail2SpawnMethod
	 */
	enum class ETrail2SpawnMethod : uint8_t
	{
		PET2SM_Emitter  = 0,
		PET2SM_Velocity = 1,
		PET2SM_Distance = 2,
		PET2SM_MAX      = 3
	};

	/**
	 * Enum Engine.ParticleModuleTrailTaper.ETrailTaperMethod
	 */
	enum class ETrailTaperMethod : uint8_t
	{
		PETTM_None    = 0,
		PETTM_Full    = 1,
		PETTM_Partial = 2,
		PETTM_MAX     = 3
	};

	/**
	 * Enum Engine.ParticleModuleTypeDataBeam.EBeamMethod
	 */
	enum class EBeamMethod : uint8_t
	{
		PEBM_Distance                       = 0,
		PEBM_EndPoints                      = 1,
		PEBM_EndPoints_Interpolated         = 2,
		PEBM_UserSet_EndPoints              = 3,
		PEBM_UserSet_EndPoints_Interpolated = 4,
		PEBM_MAX                            = 5
	};

	/**
	 * Enum Engine.ParticleModuleTypeDataBeam.EBeamEndPointMethod
	 */
	enum class EBeamEndPointMethod : uint8_t
	{
		PEBEPM_Calculated            = 0,
		PEBEPM_Distribution          = 1,
		PEBEPM_Distribution_Constant = 2,
		PEBEPM_MAX                   = 3
	};

	/**
	 * Enum Engine.ParticleModuleTypeDataBeam2.EBeam2Method
	 */
	enum class EBeam2Method : uint8_t
	{
		PEB2M_Distance = 0,
		PEB2M_Target   = 1,
		PEB2M_Branch   = 2,
		PEB2M_MAX      = 3
	};

	/**
	 * Enum Engine.ParticleModuleTypeDataBeam2.EBeamTaperMethod
	 */
	enum class EBeamTaperMethod : uint8_t
	{
		PEBTM_None    = 0,
		PEBTM_Full    = 1,
		PEBTM_Partial = 2,
		PEBTM_MAX     = 3
	};

	/**
	 * Enum Engine.ParticleModuleTypeDataMesh.EMeshCameraFacingOptions
	 */
	enum class EMeshCameraFacingOptions : uint8_t
	{
		XAxisFacing_NoUp                    = 0,
		XAxisFacing_ZUp                     = 1,
		XAxisFacing_NegativeZUp             = 2,
		XAxisFacing_YUp                     = 3,
		XAxisFacing_NegativeYUp             = 4,
		LockedAxis_ZAxisFacing              = 5,
		LockedAxis_NegativeZAxisFacing      = 6,
		LockedAxis_YAxisFacing              = 7,
		LockedAxis_NegativeYAxisFacing      = 8,
		VelocityAligned_ZAxisFacing         = 9,
		VelocityAligned_NegativeZAxisFacing = 10,
		VelocityAligned_YAxisFacing         = 11,
		VelocityAligned_NegativeYAxisFacing = 12,
		MAX                                 = 13
	};

	/**
	 * Enum Engine.ParticleModuleTypeDataMesh.EMeshCameraFacingUpAxis
	 */
	enum class EMeshCameraFacingUpAxis : uint8_t
	{
		CameraFacing_NoneUP      = 0,
		CameraFacing_ZUp         = 1,
		CameraFacing_NegativeZUp = 2,
		CameraFacing_YUp         = 3,
		CameraFacing_NegativeYUp = 4,
		CameraFacing_MAX         = 5
	};

	/**
	 * Enum Engine.ParticleModuleTypeDataMesh.EMeshScreenAlignment
	 */
	enum class EMeshScreenAlignment : uint8_t
	{
		PSMA_MeshFaceCameraWithRoll       = 0,
		PSMA_MeshFaceCameraWithSpin       = 1,
		PSMA_MeshFaceCameraWithLockedAxis = 2,
		PSMA_MAX                          = 3
	};

	/**
	 * Enum Engine.ParticleModuleTypeDataMeshPhysX.EPhysXMeshRotationMethod
	 */
	enum class EPhysXMeshRotationMethod : uint8_t
	{
		PMRM_Disabled  = 0,
		PMRM_Spherical = 1,
		PMRM_Box       = 2,
		PMRM_LongBox   = 3,
		PMRM_FlatBox   = 4,
		PMRM_Velocity  = 5,
		PMRM_MAX       = 6
	};

	/**
	 * Enum Engine.ParticleModuleTypeDataRibbon.ETrailsRenderAxisOption
	 */
	enum class ETrailsRenderAxisOption : uint8_t
	{
		Trails_CameraUp = 0,
		Trails_SourceUp = 1,
		Trails_WorldUp  = 2,
		Trails_MAX      = 3
	};

	/**
	 * Enum Engine.ParticleSystem.EParticleSystemOcclusionBoundsMethod
	 */
	enum class EParticleSystemOcclusionBoundsMethod : uint8_t
	{
		EPSOBM_None           = 0,
		EPSOBM_ParticleBounds = 1,
		EPSOBM_CustomBounds   = 2,
		EPSOBM_MAX            = 3
	};

	/**
	 * Enum Engine.ParticleSystem.EParticleSystemUpdateMode
	 */
	enum class EParticleSystemUpdateMode : uint8_t
	{
		EPSUM_RealTime  = 0,
		EPSUM_FixedTime = 1,
		EPSUM_MAX       = 2
	};

	/**
	 * Enum Engine.ProcBuildingRuleset.EProcBuildingAxis
	 */
	enum class EProcBuildingAxis : uint8_t
	{
		EPBAxis_X   = 0,
		EPBAxis_Z   = 1,
		EPBAxis_MAX = 2
	};

	/**
	 * Enum Engine.ProcBuilding.EScopeEdge
	 */
	enum class EScopeEdge : uint8_t
	{
		EPSA_Top    = 0,
		EPSA_Bottom = 1,
		EPSA_Left   = 2,
		EPSA_Right  = 3,
		EPSA_None   = 4,
		EPSA_MAX    = 5
	};

	/**
	 * Enum Engine.ProcBuilding.EBuildingStatsBrowserColumns
	 */
	enum class EBuildingStatsBrowserColumns : uint8_t
	{
		BSBC_Name                        = 0,
		BSBC_Ruleset                     = 1,
		BSBC_NumStaticMeshComps          = 2,
		BSBC_NumInstancedStaticMeshComps = 3,
		BSBC_NumInstancedTris            = 4,
		BSBC_LightmapMemBytes            = 5,
		BSBC_ShadowmapMemBytes           = 6,
		BSBC_LODDiffuseMemBytes          = 7,
		BSBC_LODLightingMemBytes         = 8,
		BSBC_MAX                         = 9
	};

	/**
	 * Enum Engine.ProcBuilding.EPBCornerType
	 */
	enum class EPBCornerType : uint8_t
	{
		EPBC_Default = 0,
		EPBC_Chamfer = 1,
		EPBC_Round   = 2,
		EPBC_MAX     = 3
	};

	/**
	 * Enum Engine.PBRuleNodeEdgeAngle.EProcBuildingEdge
	 */
	enum class EProcBuildingEdge : uint8_t
	{
		EPBE_Top    = 0,
		EPBE_Bottom = 1,
		EPBE_Left   = 2,
		EPBE_Right  = 3,
		EPBE_MAX    = 4
	};

	/**
	 * Enum Engine.PhysicalMaterial.EPhysEffectType
	 */
	enum class EPhysEffectType : uint8_t
	{
		EPMET_Impact = 0,
		EPMET_Slide  = 1,
		EPMET_MAX    = 2
	};

	/**
	 * Enum Engine.PhysXParticleSystem.ESimulationMethod
	 */
	enum class ESimulationMethod : uint8_t
	{
		ESM_SPH                     = 0,
		ESM_NO_PARTICLE_INTERACTION = 1,
		ESM_MIXED_MODE              = 2,
		ESM_MAX                     = 3
	};

	/**
	 * Enum Engine.PhysXParticleSystem.EPacketSizeMultiplier
	 */
	enum class EPacketSizeMultiplier : uint8_t
	{
		EPSM     = 0,
		EPSM01   = 1,
		EPSM02   = 2,
		EPSM03   = 3,
		EPSM04   = 4,
		EPSM05   = 5,
		EPSM_MAX = 6
	};

	/**
	 * Enum Engine.SceneCaptureComponent.ESceneCaptureViewMode
	 */
	enum class ESceneCaptureViewMode : uint8_t
	{
		SceneCapView_Lit          = 0,
		SceneCapView_Unlit        = 1,
		SceneCapView_LitNoShadows = 2,
		SceneCapView_Wire         = 3,
		SceneCapView_MAX          = 4
	};

	/**
	 * Enum Engine.RB_BodySetup.ESleepFamily
	 */
	enum class ESleepFamily : uint8_t
	{
		SF_Normal    = 0,
		SF_Sensitive = 1,
		SF_MAX       = 2
	};

	/**
	 * Enum Engine.RB_RadialForceActor.ERadialForceType
	 */
	enum class ERadialForceType : uint8_t
	{
		RFT_Force   = 0,
		RFT_Impulse = 1,
		RFT_MAX     = 2
	};

	/**
	 * Enum Engine.Route.ERouteDirection
	 */
	enum class ERouteDirection : uint8_t
	{
		ERD_Forward = 0,
		ERD_Reverse = 1,
		ERD_MAX     = 2
	};

	/**
	 * Enum Engine.Route.ERouteFillAction
	 */
	enum class ERouteFillAction : uint8_t
	{
		RFA_Overwrite = 0,
		RFA_Add       = 1,
		RFA_Remove    = 2,
		RFA_Clear     = 3,
		RFA_MAX       = 4
	};

	/**
	 * Enum Engine.Route.ERouteType
	 */
	enum class ERouteType : uint8_t
	{
		ERT_Linear = 0,
		ERT_Loop   = 1,
		ERT_Circle = 2,
		ERT_MAX    = 3
	};

	/**
	 * Enum Engine.SeqAct_ActorFactory.EPointSelection
	 */
	enum class EPointSelection : uint8_t
	{
		PS_Normal  = 0,
		PS_Random  = 1,
		PS_Reverse = 2,
		PS_MAX     = 3
	};

	/**
	 * Enum Engine.SeqAct_SetMesh.EMeshType
	 */
	enum class EMeshType : uint8_t
	{
		MeshType_StaticMesh   = 0,
		MeshType_SkeletalMesh = 1,
		MeshType_MAX          = 2
	};

	/**
	 * Enum Engine.WorldAttractor.EWorldAttractorFalloffType
	 */
	enum class EWorldAttractorFalloffType : uint8_t
	{
		FOFF_Constant = 0,
		FOFF_Linear   = 1,
		FOFF_Exponent = 2,
		FOFF_MAX      = 3
	};

	/**
	 * Enum Engine.SeqEvent_ParticleEvent.EParticleEventOutputType
	 */
	enum class EParticleEventOutputType : uint8_t
	{
		ePARTICLEOUT_Spawn              = 0,
		ePARTICLEOUT_Death              = 1,
		ePARTICLEOUT_Collision          = 2,
		ePARTICLEOUT_AttractorCollision = 3,
		ePARTICLEOUT_Kismet             = 4,
		ePARTICLEOUT_MAX                = 5
	};

	/**
	 * Enum Engine.SkelControlBase.EBoneControlSpace
	 */
	enum class EBoneControlSpace : uint8_t
	{
		BCS_WorldSpace      = 0,
		BCS_ActorSpace      = 1,
		BCS_ComponentSpace  = 2,
		BCS_ParentBoneSpace = 3,
		BCS_BoneSpace       = 4,
		BCS_OtherBoneSpace  = 5,
		BCS_BaseMeshSpace   = 6,
		BCS_MAX             = 7
	};

	/**
	 * Enum Engine.SkelControlSpline.ESplineControlRotMode
	 */
	enum class ESplineControlRotMode : uint8_t
	{
		SCR_NoChange    = 0,
		SCR_AlongSpline = 1,
		SCR_Interpolate = 2,
		SCR_MAX         = 3
	};

	/**
	 * Enum Engine.SkeletalMesh.SoftBodyBoneType
	 */
	enum class ESoftBodyBoneType : uint8_t
	{
		SOFTBODYBONE_Fixed               = 0,
		SOFTBODYBONE_BreakableAttachment = 1,
		SOFTBODYBONE_TwoWayAttachment    = 2,
		SOFTBODYBONE_MAX                 = 3
	};

	/**
	 * Enum Engine.SkeletalMesh.ClothBoneType
	 */
	enum class EClothBoneType : uint8_t
	{
		CLOTHBONE_Fixed               = 0,
		CLOTHBONE_BreakableAttachment = 1,
		CLOTHBONE_TearLine            = 2,
		CLOTHBONE_MAX                 = 3
	};

	/**
	 * Enum Engine.SkeletalMesh.SkeletalMeshOptimizationNormalMode
	 */
	enum class ESkeletalMeshOptimizationNormalMode : uint8_t
	{
		SMONM_Recalculate     = 0,
		SMONM_RecalculateSoft = 1,
		SMONM_RecalculateHard = 2,
		SMONM_MAX             = 3
	};

	/**
	 * Enum Engine.SkeletalMesh.SkeletalMeshOptimizationImportance
	 */
	enum class ESkeletalMeshOptimizationImportance : uint8_t
	{
		SMOI_Normal  = 0,
		SMOI_High    = 1,
		SMOI_Highest = 2,
		SMOI_MAX     = 3
	};

	/**
	 * Enum Engine.SkeletalMesh.TriangleSortOption
	 */
	enum class ETriangleSortOption : uint8_t
	{
		TRISORT_None                 = 0,
		TRISORT_CenterRadialDistance = 1,
		TRISORT_Random               = 2,
		TRISORT_MergeContiguous      = 3,
		TRISORT_Custom               = 4,
		TRISORT_CustomLeftRight      = 5,
		TRISORT_MAX                  = 6
	};

	/**
	 * Enum Engine.SkeletalMesh.BoneBreakOption
	 */
	enum class EBoneBreakOption : uint8_t
	{
		BONEBREAK_SoftPreferred  = 0,
		BONEBREAK_AutoDetect     = 1,
		BONEBREAK_RigidPreferred = 2,
		BONEBREAK_MAX            = 3
	};

	/**
	 * Enum Engine.SkeletalMesh.TriangleSortAxis
	 */
	enum class ETriangleSortAxis : uint8_t
	{
		TSA_X_Axis = 0,
		TSA_Y_Axis = 1,
		TSA_Z_Axis = 2,
		TSA_MAX    = 3
	};

	/**
	 * Enum Engine.SkeletalMesh.ClothMovementScaleGen
	 */
	enum class EClothMovementScaleGen : uint8_t
	{
		ECMDM_DistToFixedVert  = 0,
		ECMDM_VertexBoneWeight = 1,
		ECMDM_Empty            = 2,
		ECMDM_MAX              = 3
	};

	/**
	 * Enum Engine.SoundNodeWave.EDecompressionType
	 */
	enum class EDecompressionType : uint8_t
	{
		DTYPE_Setup      = 0,
		DTYPE_Invalid    = 1,
		DTYPE_Preview    = 2,
		DTYPE_Native     = 3,
		DTYPE_RealTime   = 4,
		DTYPE_Procedural = 5,
		DTYPE_Xenon      = 6,
		DTYPE_MAX        = 7
	};

	/**
	 * Enum Engine.SpeedTreeComponent.ESpeedTreeMeshType
	 */
	enum class ESpeedTreeMeshType : uint8_t
	{
		STMT_MinMinusOne = 0,
		STMT_Branches1   = 1,
		STMT_Branches2   = 2,
		STMT_Fronds      = 3,
		STMT_LeafCards   = 4,
		STMT_LeafMeshes  = 5,
		STMT_Billboards  = 6,
		STMT_Max         = 7
	};

	/**
	 * Enum Engine.SVehicleWheel.EWheelSide
	 */
	enum class EWheelSide : uint8_t
	{
		SIDE_None  = 0,
		SIDE_Left  = 1,
		SIDE_Right = 2,
		SIDE_MAX   = 3
	};

	/**
	 * Enum Engine.TerrainMaterial.ETerrainMappingType
	 */
	enum class ETerrainMappingType : uint8_t
	{
		TMT_Auto = 0,
		TMT_XY   = 1,
		TMT_XZ   = 2,
		TMT_YZ   = 3,
		TMT_MAX  = 4
	};

	/**
	 * Enum Engine.TextureFlipBook.TextureFlipBookMethod
	 */
	enum class ETextureFlipBookMethod : uint8_t
	{
		TFBM_UL_ROW = 0,
		TFBM_UL_COL = 1,
		TFBM_UR_ROW = 2,
		TFBM_UR_COL = 3,
		TFBM_LL_ROW = 4,
		TFBM_LL_COL = 5,
		TFBM_LR_ROW = 6,
		TFBM_LR_COL = 7,
		TFBM_RANDOM = 8,
		TFBM_MAX    = 9
	};

	/**
	 * Enum Engine.TextureMovie.EMovieStreamSource
	 */
	enum class EMovieStreamSource : uint8_t
	{
		MovieStream_File   = 0,
		MovieStream_Memory = 1,
		MovieStream_MAX    = 2
	};

	/**
	 * Enum Engine.TwitterIntegrationBase.ETwitterRequestMethod
	 */
	enum class ETwitterRequestMethod : uint8_t
	{
		TRM_Get    = 0,
		TRM_Post   = 1,
		TRM_Delete = 2,
		TRM_MAX    = 3
	};

	/**
	 * Enum Engine.TwitterIntegrationBase.ETwitterIntegrationDelegate
	 */
	enum class ETwitterIntegrationDelegate : uint8_t
	{
		TID_AuthorizeComplete = 0,
		TID_TweetUIComplete   = 1,
		TID_RequestComplete   = 2,
		TID_MAX               = 3
	};

	/**
	 * Enum Engine.UberPostProcessEffect.EPostProcessAAType
	 */
	enum class EPostProcessAAType : uint8_t
	{
		PostProcessAA_Off   = 0,
		PostProcessAA_FXAA0 = 1,
		PostProcessAA_FXAA1 = 2,
		PostProcessAA_FXAA2 = 3,
		PostProcessAA_FXAA3 = 4,
		PostProcessAA_FXAA4 = 5,
		PostProcessAA_FXAA5 = 6,
		PostProcessAA_MLAA  = 7,
		PostProcessAA_MAX   = 8
	};

	/**
	 * Enum Engine.UberPostProcessEffect.ETonemapperType
	 */
	enum class ETonemapperType : uint8_t
	{
		Tonemapper_Off          = 0,
		Tonemapper_Filmic       = 1,
		Tonemapper_Customizable = 2,
		Tonemapper_MAX          = 3
	};

	/**
	 * Enum Engine.UIDataProvider_MenuItem.EMenuOptionType
	 */
	enum class EMenuOptionType : uint8_t
	{
		MENUOT_ComboReadOnly      = 0,
		MENUOT_ComboNumeric       = 1,
		MENUOT_CheckBox           = 2,
		MENUOT_Slider             = 3,
		MENUOT_Spinner            = 4,
		MENUOT_EditBox            = 5,
		MENUOT_CollectionCheckBox = 6,
		MENUOT_CollapsingList     = 7,
		MENUOT_MAX                = 8
	};

	/**
	 * Enum Engine.UIDataStore_OnlineStats.EStatsFetchType
	 */
	enum class EStatsFetchType : uint8_t
	{
		SFT_Player           = 0,
		SFT_CenteredOnPlayer = 1,
		SFT_Friends          = 2,
		SFT_TopRankings      = 3,
		SFT_MAX              = 4
	};

	/**
	 * Enum Engine.Weapon.EWeaponFireType
	 */
	enum class EWeaponFireType : uint8_t
	{
		EWFT_InstantHit = 0,
		EWFT_Projectile = 1,
		EWFT_Custom     = 2,
		EWFT_None       = 3,
		EWFT_MAX        = 4
	};

	// --------------------------------------------------
	// # Structs
	// --------------------------------------------------
	/**
	 * ScriptStruct Engine.Actor.RigidBodyContactInfo
	 * Size -> 0x0044
	 */
	struct FRigidBodyContactInfo
	{
	public:
		struct FVector                                             ContactPosition;                                         // 0x0000(0x000C)
		struct FVector                                             ContactNormal;                                           // 0x000C(0x000C)
		float                                                      ContactPenetration;                                      // 0x0018(0x0004)
		struct FVector                                             ContactVelocity[0x2];                                    // 0x001C(0x0018)
		class UPhysicalMaterial*                                   PhysMaterial[0x2];                                       // 0x0034(0x0010)
	};

	/**
	 * ScriptStruct Engine.Actor.CollisionImpactData
	 * Size -> 0x0028
	 */
	struct FCollisionImpactData
	{
	public:
		TArray<struct FRigidBodyContactInfo>                       ContactInfos;                                            // 0x0000(0x0010) NeedCtorLink
		struct FVector                                             TotalNormalForceVector;                                  // 0x0010(0x000C)
		struct FVector                                             TotalFrictionForceVector;                                // 0x001C(0x000C)
	};

	/**
	 * ScriptStruct Engine.Actor.TraceHitInfo
	 * Size -> 0x0028
	 */
	struct FTraceHitInfo
	{
	public:
		class UMaterial*                                           Material;                                                // 0x0000(0x0008) AlwaysInit
		class UPhysicalMaterial*                                   PhysMaterial;                                            // 0x0008(0x0008) AlwaysInit
		int32_t                                                    Item;                                                    // 0x0010(0x0004) AlwaysInit
		int32_t                                                    LevelIndex;                                              // 0x0014(0x0004) AlwaysInit
		class FName                                                BoneName;                                                // 0x0018(0x0008) AlwaysInit
		class UPrimitiveComponent*                                 HitComponent;                                            // 0x0020(0x0008) ExportObject, Component, AlwaysInit, EditInline
	};

	/**
	 * ScriptStruct Engine.Actor.ImpactInfo
	 * Size -> 0x0060
	 */
	struct FImpactInfo
	{
	public:
		class AActor*                                              HitActor;                                                // 0x0000(0x0008) AlwaysInit
		struct FVector                                             HitLocation;                                             // 0x0008(0x000C) AlwaysInit
		struct FVector                                             HitNormal;                                               // 0x0014(0x000C) AlwaysInit
		struct FVector                                             RayDir;                                                  // 0x0020(0x000C) AlwaysInit
		struct FVector                                             StartTrace;                                              // 0x002C(0x000C) AlwaysInit
		struct FTraceHitInfo                                       HitInfo;                                                 // 0x0038(0x0028) Component, AlwaysInit
	};

	/**
	 * ScriptStruct Engine.Actor.BasedPosition
	 * Size -> 0x0038
	 */
	struct FBasedPosition
	{
	public:
		class AActor*                                              Base;                                                    // 0x0000(0x0008) Edit
		struct FVector                                             Position;                                                // 0x0008(0x000C) Edit
		struct FVector                                             CachedBaseLocation;                                      // 0x0014(0x000C)
		struct FRotator                                            CachedBaseRotation;                                      // 0x0020(0x000C)
		struct FVector                                             CachedTransPosition;                                     // 0x002C(0x000C)
	};

	/**
	 * ScriptStruct Engine.Actor.TimerData
	 * Size -> 0x0020
	 */
	struct FTimerData
	{
	public:
		unsigned long                                              bLoop : 1;                                               // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bPaused : 1;                                             // 0x0000(0x0001) BIT_FIELD
		class FName                                                FuncName;                                                // 0x0004(0x0008)
		float                                                      Rate;                                                    // 0x000C(0x0004)
		float                                                      Count;                                                   // 0x0010(0x0004)
		float                                                      TimerTimeDilation;                                       // 0x0014(0x0004)
		class UObject*                                             TimerObj;                                                // 0x0018(0x0008)
	};

	/**
	 * ScriptStruct Engine.Actor.AutoDisappearPSCData
	 * Size -> 0x0010
	 */
	struct FAutoDisappearPSCData
	{
	public:
		class UParticleSystemComponent*                            PSC;                                                     // 0x0000(0x0008) ExportObject, Component, EditInline
		float                                                      CurrentSeconds;                                          // 0x0008(0x0004)
		float                                                      FadeOutSeconds;                                          // 0x000C(0x0004)
	};

	/**
	 * ScriptStruct Engine.WorldInfo.WorldFractureSettings
	 * Size -> 0x001C
	 */
	struct FWorldFractureSettings
	{
	public:
		float                                                      ChanceOfPhysicsChunkOverride;                            // 0x0000(0x0004)
		unsigned long                                              bEnableChanceOfPhysicsChunkOverride : 1;                 // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bLimitExplosionChunkSize : 1;                            // 0x0004(0x0001) BIT_FIELD
		float                                                      MaxExplosionChunkSize;                                   // 0x0008(0x0004)
		unsigned long                                              bLimitDamageChunkSize : 1;                               // 0x000C(0x0001) BIT_FIELD
		float                                                      MaxDamageChunkSize;                                      // 0x0010(0x0004)
		int32_t                                                    MaxNumFacturedChunksToSpawnInAFrame;                     // 0x0014(0x0004)
		float                                                      FractureExplosionVelScale;                               // 0x0018(0x0004)
	};

	/**
	 * ScriptStruct Engine.MusicTrackDataStructures.MusicTrackStruct
	 * Size -> 0x002C
	 */
	struct FMusicTrackStruct
	{
	public:
		class USoundCue*                                           TheSoundCue;                                             // 0x0000(0x0008) Edit
		unsigned long                                              bAutoPlay : 1;                                           // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bPersistentAcrossLevels : 1;                             // 0x0008(0x0001) BIT_FIELD Edit
		float                                                      FadeInTime;                                              // 0x000C(0x0004) Edit
		float                                                      FadeInVolumeLevel;                                       // 0x0010(0x0004) Edit
		float                                                      FadeOutTime;                                             // 0x0014(0x0004) Edit
		float                                                      FadeOutVolumeLevel;                                      // 0x0018(0x0004) Edit
		class FString                                              MP3Filename;                                             // 0x001C(0x0010) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.Brush.GeomSelection
	 * Size -> 0x000C
	 */
	struct FGeomSelection
	{
	public:
		int32_t                                                    Type;                                                    // 0x0000(0x0004)
		int32_t                                                    Index;                                                   // 0x0004(0x0004)
		int32_t                                                    SelectionIndex;                                          // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.Volume.GHM_Volume_CheckpointRecord
	 * Size -> 0x0014
	 */
	struct FGHM_Volume_CheckpointRecord
	{
	public:
		unsigned long                                              bBlockActors : 1;                                        // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bCollideActors : 1;                                      // 0x0000(0x0001) BIT_FIELD
		class FString                                              Base_PathName;                                           // 0x0004(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.PostProcessVolume.GHM_PostProcessVolume_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_PostProcessVolume_CheckpointRecord
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.PostProcessVolume.LUTBlender
	 * Size -> 0x0024
	 */
	struct FLUTBlender
	{
	public:
		TArray<class UTexture*>                                    LUTTextures;                                             // 0x0000(0x0010) NeedCtorLink
		TArray<float>                                              LUTWeights;                                              // 0x0010(0x0010) NeedCtorLink
		unsigned long                                              bHasChanged : 1;                                         // 0x0020(0x0001) BIT_FIELD Const, Native, Transient
	};

	/**
	 * ScriptStruct Engine.PostProcessVolume.MobileColorGradingParams
	 * Size -> 0x003C
	 */
	struct FMobileColorGradingParams
	{
	public:
		float                                                      TransitionTime;                                          // 0x0000(0x0004) Edit
		float                                                      Blend;                                                   // 0x0004(0x0004) Edit
		float                                                      Desaturation;                                            // 0x0008(0x0004) Edit
		struct FLinearColor                                        HighLights;                                              // 0x000C(0x0010) Edit
		struct FLinearColor                                        MidTones;                                                // 0x001C(0x0010) Edit
		struct FLinearColor                                        Shadows;                                                 // 0x002C(0x0010) Edit
	};

	/**
	 * ScriptStruct Engine.PostProcessVolume.MobilePostProcessSettings
	 * Size -> 0x0038
	 */
	struct FMobilePostProcessSettings
	{
	public:
		unsigned long                                              bOverride_Mobile_BlurAmount : 1;                         // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Mobile_TransitionTime : 1;                     // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Mobile_Bloom_Scale : 1;                        // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Mobile_Bloom_Threshold : 1;                    // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Mobile_Bloom_Tint : 1;                         // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Mobile_DOF_Distance : 1;                       // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Mobile_DOF_MinRange : 1;                       // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Mobile_DOF_MaxRange : 1;                       // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Mobile_DOF_NearBlurFactor : 1;                 // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Mobile_DOF_FarBlurFactor : 1;                  // 0x0000(0x0001) BIT_FIELD
		float                                                      Mobile_BlurAmount;                                       // 0x0004(0x0004) Edit, Interp
		float                                                      Mobile_TransitionTime;                                   // 0x0008(0x0004) Edit
		float                                                      Mobile_Bloom_Scale;                                      // 0x000C(0x0004) Edit, Interp
		float                                                      Mobile_Bloom_Threshold;                                  // 0x0010(0x0004) Edit, Interp
		struct FLinearColor                                        Mobile_Bloom_Tint;                                       // 0x0014(0x0010) Edit, Interp
		float                                                      Mobile_DOF_Distance;                                     // 0x0024(0x0004) Edit, Interp
		float                                                      Mobile_DOF_MinRange;                                     // 0x0028(0x0004) Edit, Interp
		float                                                      Mobile_DOF_MaxRange;                                     // 0x002C(0x0004) Edit, Interp
		float                                                      Mobile_DOF_NearBlurFactor;                               // 0x0030(0x0004) Edit, Interp
		float                                                      Mobile_DOF_FarBlurFactor;                                // 0x0034(0x0004) Edit, Interp
	};

	/**
	 * ScriptStruct Engine.PostProcessVolume.GlareGhostInfo
	 * Size -> 0x0018
	 */
	struct FGlareGhostInfo
	{
	public:
		struct FVector2D                                           Offset;                                                  // 0x0000(0x0008) Edit
		struct FLinearColor                                        Color;                                                   // 0x0008(0x0010) Edit
	};

	/**
	 * ScriptStruct Engine.PostProcessVolume.PostProcessSettings
	 * Size -> 0x0214
	 */
	struct FPostProcessSettings
	{
	public:
		unsigned long                                              bOverride_EnableBloom : 1;                               // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_EnableDOF : 1;                                 // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_EnableMotionBlur : 1;                          // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_EnableSceneEffect : 1;                         // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_AllowAmbientOcclusion : 1;                     // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_OverrideRimShaderColor : 1;                    // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Bloom_Scale : 1;                               // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Bloom_Threshold : 1;                           // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Bloom_Tint : 1;                                // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Bloom_ScreenBlendThreshold : 1;                // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Bloom_InterpolationDuration : 1;               // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_DOF_FalloffExponent : 1;                       // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_DOF_BlurKernelSize : 1;                        // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_DOF_BlurBloomKernelSize : 1;                   // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_DOF_MaxNearBlurAmount : 1;                     // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_DOF_MinBlurAmount : 1;                         // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_DOF_MaxFarBlurAmount : 1;                      // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_DOF_FocusType : 1;                             // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_DOF_FocusInnerRadius : 1;                      // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_DOF_FocusDistance : 1;                         // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_DOF_FocusPosition : 1;                         // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_DOF_InterpolationDuration : 1;                 // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_DOF_BokehTexture : 1;                          // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_MotionBlur_MaxVelocity : 1;                    // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_MotionBlur_Amount : 1;                         // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_MotionBlur_FullMotionBlur : 1;                 // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_MotionBlur_CameraRotationThreshold : 1;        // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_MotionBlur_CameraTranslationThreshold : 1;     // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_MotionBlur_InterpolationDuration : 1;          // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Scene_Desaturation : 1;                        // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Scene_Colorize : 1;                            // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Scene_TonemapperScale : 1;                     // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Scene_ImageGrainScale : 1;                     // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Scene_HighLights : 1;                          // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Scene_MidTones : 1;                            // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Scene_Shadows : 1;                             // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Scene_InterpolationDuration : 1;               // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Scene_ColorGradingLUT : 1;                     // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_RimShader_Color : 1;                           // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_RimShader_InterpolationDuration : 1;           // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_EnableGlare : 1;                               // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_Scale : 1;                               // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_Threshold : 1;                           // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_KernelSize : 1;                          // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_ColorShiftTable : 1;                     // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_Directions : 1;                          // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_BlurDistanceFalloffBase : 1;             // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_BlurDistanceFalloffExponentScale : 1;    // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_Ghosts : 1;                              // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_InterpolationDuration : 1;               // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_Rotation : 1;                            // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_FilterMaterial : 1;                      // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_bEnableGlareHistory : 1;                 // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_HistoryToGlareBufferColor : 1;           // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_Glare_GlareBufferToHistoryColor : 1;           // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_EnableFastBloom : 1;                           // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_FastBloom_Scale : 1;                           // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_FastBloom_KernelSizeScale : 1;                 // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_FastBloom_OriginalKernelSizeScale : 1;         // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_FastBloom_InterpolationDuration : 1;           // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_EnableNearBokeh : 1;                           // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_NearBokeh_KernelRadiusScale : 1;               // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_NearBokeh_BlurWeightScale : 1;                 // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_NearBokeh_PostBlurKernelRadius : 1;            // 0x0004(0x0001) BIT_FIELD
		unsigned long                                              bOverride_NearBokeh_InterpolationDuration : 1;           // 0x0008(0x0001) BIT_FIELD
		unsigned long                                              bOverride_MobileColorGrading : 1;                        // 0x0008(0x0001) BIT_FIELD
		unsigned long                                              bEnableBloom : 1;                                        // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bEnableDOF : 1;                                          // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bEnableMotionBlur : 1;                                   // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bEnableSceneEffect : 1;                                  // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bAllowAmbientOcclusion : 1;                              // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bOverrideRimShaderColor : 1;                             // 0x0008(0x0001) BIT_FIELD Edit
		float                                                      Bloom_Scale;                                             // 0x000C(0x0004) Edit, Interp
		float                                                      Bloom_Threshold;                                         // 0x0010(0x0004) Edit, Interp
		struct FColor                                              Bloom_Tint;                                              // 0x0014(0x0004) Edit, Interp
		float                                                      Bloom_ScreenBlendThreshold;                              // 0x0018(0x0004) Edit, Interp
		float                                                      Bloom_InterpolationDuration;                             // 0x001C(0x0004) Edit
		float                                                      DOF_BlurBloomKernelSize;                                 // 0x0020(0x0004) Edit, Interp
		float                                                      DOF_FalloffExponent;                                     // 0x0024(0x0004) Edit, Interp
		float                                                      DOF_BlurKernelSize;                                      // 0x0028(0x0004) Edit, Interp
		float                                                      DOF_MaxNearBlurAmount;                                   // 0x002C(0x0004) Edit, Interp
		float                                                      DOF_MinBlurAmount;                                       // 0x0030(0x0004) Edit, Interp
		float                                                      DOF_MaxFarBlurAmount;                                    // 0x0034(0x0004) Edit, Interp
		EFocusType                                                 DOF_FocusType;                                           // 0x0038(0x0001) Edit
		unsigned char                                              UnknownData_VA8S[0x3];                                   // 0x0039(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      DOF_FocusInnerRadius;                                    // 0x003C(0x0004) Edit, Interp
		float                                                      DOF_FocusDistance;                                       // 0x0040(0x0004) Edit, Interp
		struct FVector                                             DOF_FocusPosition;                                       // 0x0044(0x000C) Edit
		float                                                      DOF_InterpolationDuration;                               // 0x0050(0x0004) Edit
		class UTexture2D*                                          DOF_BokehTexture;                                        // 0x0054(0x0008) Edit
		float                                                      MotionBlur_MaxVelocity;                                  // 0x005C(0x0004) Edit, Interp
		float                                                      MotionBlur_Amount;                                       // 0x0060(0x0004) Edit, Interp
		unsigned long                                              MotionBlur_FullMotionBlur : 1;                           // 0x0064(0x0001) BIT_FIELD Edit
		float                                                      MotionBlur_CameraRotationThreshold;                      // 0x0068(0x0004) Edit, Interp
		float                                                      MotionBlur_CameraTranslationThreshold;                   // 0x006C(0x0004) Edit, Interp
		float                                                      MotionBlur_InterpolationDuration;                        // 0x0070(0x0004) Edit
		float                                                      Scene_Desaturation;                                      // 0x0074(0x0004) Edit, Interp
		struct FVector                                             Scene_Colorize;                                          // 0x0078(0x000C) Edit, Interp
		float                                                      Scene_TonemapperScale;                                   // 0x0084(0x0004) Edit, Interp
		float                                                      Scene_ImageGrainScale;                                   // 0x0088(0x0004) Edit, Interp
		struct FVector                                             Scene_HighLights;                                        // 0x008C(0x000C) Edit, Interp
		struct FVector                                             Scene_MidTones;                                          // 0x0098(0x000C) Edit, Interp
		struct FVector                                             Scene_Shadows;                                           // 0x00A4(0x000C) Edit, Interp
		float                                                      Scene_InterpolationDuration;                             // 0x00B0(0x0004) Edit
		struct FLinearColor                                        RimShader_Color;                                         // 0x00B4(0x0010) Edit
		float                                                      RimShader_InterpolationDuration;                         // 0x00C4(0x0004) Edit
		class UTexture*                                            ColorGrading_LookupTable;                                // 0x00C8(0x0008) Edit
		struct FLUTBlender                                         ColorGradingLUT;                                         // 0x00D0(0x0024) Const, Transient, NeedCtorLink
		struct FMobileColorGradingParams                           MobileColorGrading;                                      // 0x00F4(0x003C) Edit
		struct FMobilePostProcessSettings                          MobilePostProcess;                                       // 0x0130(0x0038) Edit, Interp
		unsigned long                                              bEnableGlare : 1;                                        // 0x0168(0x0001) BIT_FIELD Edit
		float                                                      Glare_Scale;                                             // 0x016C(0x0004) Edit, Interp
		float                                                      Glare_Threshold;                                         // 0x0170(0x0004) Edit, Interp
		float                                                      Glare_KernelSize;                                        // 0x0174(0x0004) Edit, Interp
		TArray<struct FLinearColor>                                Glare_ColorShiftTable;                                   // 0x0178(0x0010) Edit, NeedCtorLink
		TArray<struct FVector2D>                                   Glare_Directions;                                        // 0x0188(0x0010) Edit, NeedCtorLink
		float                                                      Glare_BlurDistanceFalloffBase;                           // 0x0198(0x0004) Edit, Interp
		float                                                      Glare_BlurDistanceFalloffExponentScale;                  // 0x019C(0x0004) Edit, Interp
		TArray<struct FGlareGhostInfo>                             Glare_Ghosts;                                            // 0x01A0(0x0010) Edit, NeedCtorLink
		float                                                      Glare_InterpolationDuration;                             // 0x01B0(0x0004) Edit
		struct FVector                                             Glare_Rotation;                                          // 0x01B4(0x000C) Edit, Interp
		class UMaterialInterface*                                  Glare_FilterMaterial;                                    // 0x01C0(0x0008) Edit
		unsigned long                                              Glare_bEnableGlareHistory : 1;                           // 0x01C8(0x0001) BIT_FIELD Edit
		struct FLinearColor                                        Glare_HistoryToGlareBufferColor;                         // 0x01CC(0x0010) Edit, Interp
		struct FLinearColor                                        Glare_GlareBufferToHistoryColor;                         // 0x01DC(0x0010) Edit, Interp
		unsigned long                                              bEnableFastBloom : 1;                                    // 0x01EC(0x0001) BIT_FIELD Edit
		float                                                      FastBloom_Scale;                                         // 0x01F0(0x0004) Edit, Interp
		float                                                      FastBloom_KernelSizeScale;                               // 0x01F4(0x0004) Edit, Interp
		float                                                      FastBloom_OriginalKernelSizeScale;                       // 0x01F8(0x0004) Edit, Interp
		float                                                      FastBloom_InterpolationDuration;                         // 0x01FC(0x0004) Edit
		unsigned long                                              bEnableNearBokeh : 1;                                    // 0x0200(0x0001) BIT_FIELD Edit
		float                                                      NearBokeh_KernelRadiusScale;                             // 0x0204(0x0004) Edit, Interp
		float                                                      NearBokeh_BlurWeightScale;                               // 0x0208(0x0004) Edit, Interp
		float                                                      NearBokeh_PostBlurKernelRadius;                          // 0x020C(0x0004) Edit, Interp
		float                                                      NearBokeh_InterpolationDuration;                         // 0x0210(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.ReverbVolume.InteriorSettings
	 * Size -> 0x0024
	 */
	struct FInteriorSettings
	{
	public:
		unsigned long                                              bIsWorldInfo : 1;                                        // 0x0000(0x0001) BIT_FIELD
		float                                                      ExteriorVolume;                                          // 0x0004(0x0004) Edit
		float                                                      ExteriorTime;                                            // 0x0008(0x0004) Edit
		float                                                      ExteriorLPF;                                             // 0x000C(0x0004) Edit
		float                                                      ExteriorLPFTime;                                         // 0x0010(0x0004) Edit
		float                                                      InteriorVolume;                                          // 0x0014(0x0004) Edit
		float                                                      InteriorTime;                                            // 0x0018(0x0004) Edit
		float                                                      InteriorLPF;                                             // 0x001C(0x0004) Edit
		float                                                      InteriorLPFTime;                                         // 0x0020(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.ReverbVolume.CustomReverbPreset
	 * Size -> 0x0040
	 */
	struct FCustomReverbPreset
	{
	public:
		float                                                      Room;                                                    // 0x0000(0x0004) Edit
		float                                                      RoomHF;                                                  // 0x0004(0x0004) Edit
		float                                                      RoomRolloffFactor;                                       // 0x0008(0x0004) Edit
		float                                                      DecayTime;                                               // 0x000C(0x0004) Edit
		float                                                      DecayHFRatio;                                            // 0x0010(0x0004) Edit
		float                                                      Reflections;                                             // 0x0014(0x0004) Edit
		float                                                      ReflectionsDelay;                                        // 0x0018(0x0004) Edit
		float                                                      Reverb;                                                  // 0x001C(0x0004) Edit
		float                                                      ReverbDelay;                                             // 0x0020(0x0004) Edit
		float                                                      Diffusion;                                               // 0x0024(0x0004) Edit
		float                                                      Density;                                                 // 0x0028(0x0004) Edit
		float                                                      AirAbsorption;                                           // 0x002C(0x0004) Edit
		class FString                                              OwnerVolumeName;                                         // 0x0030(0x0010) Transient, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.ReverbVolume.ReverbSettings
	 * Size -> 0x0050
	 */
	struct FReverbSettings
	{
	public:
		unsigned long                                              bApplyReverb : 1;                                        // 0x0000(0x0001) BIT_FIELD Edit
		EReverbPreset                                              ReverbType;                                              // 0x0004(0x0001) Edit
		unsigned char                                              UnknownData_8ZEV[0x3];                                   // 0x0005(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      Volume;                                                  // 0x0008(0x0004) Edit
		float                                                      FadeTime;                                                // 0x000C(0x0004) Edit
		struct FCustomReverbPreset                                 CustomReverb;                                            // 0x0010(0x0040) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.WorldInfo.NetViewer
	 * Size -> 0x0028
	 */
	struct FNetViewer
	{
	public:
		class APlayerController*                                   InViewer;                                                // 0x0000(0x0008)
		class AActor*                                              Viewer;                                                  // 0x0008(0x0008)
		struct FVector                                             ViewLocation;                                            // 0x0010(0x000C)
		struct FVector                                             ViewDir;                                                 // 0x001C(0x000C)
	};

	/**
	 * ScriptStruct Engine.WorldInfo.PhysXSimulationProperties
	 * Size -> 0x000C
	 */
	struct FPhysXSimulationProperties
	{
	public:
		unsigned long                                              bUseHardware : 1;                                        // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bFixedTimeStep : 1;                                      // 0x0000(0x0001) BIT_FIELD Edit
		float                                                      TimeStep;                                                // 0x0004(0x0004) Edit
		int32_t                                                    MaxSubSteps;                                             // 0x0008(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.WorldInfo.PhysXSceneProperties
	 * Size -> 0x003C
	 */
	struct FPhysXSceneProperties
	{
	public:
		struct FPhysXSimulationProperties                          PrimaryScene;                                            // 0x0000(0x000C) Edit, EditInline
		struct FPhysXSimulationProperties                          CompartmentRigidBody;                                    // 0x000C(0x000C) Edit, EditInline
		struct FPhysXSimulationProperties                          CompartmentFluid;                                        // 0x0018(0x000C) Edit, EditInline
		struct FPhysXSimulationProperties                          CompartmentCloth;                                        // 0x0024(0x000C) Edit, EditInline
		struct FPhysXSimulationProperties                          CompartmentSoftBody;                                     // 0x0030(0x000C) Edit, EditInline
	};

	/**
	 * ScriptStruct Engine.WorldInfo.CompartmentRunList
	 * Size -> 0x0004
	 */
	struct FCompartmentRunList
	{
	public:
		unsigned long                                              RigidBody : 1;                                           // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Fluid : 1;                                               // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Cloth : 1;                                               // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              SoftBody : 1;                                            // 0x0000(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.WorldInfo.ApexModuleDestructibleSettings
	 * Size -> 0x0014
	 */
	struct FApexModuleDestructibleSettings
	{
	public:
		int32_t                                                    MaxChunkIslandCount;                                     // 0x0000(0x0004) Edit
		int32_t                                                    MaxShapeCount;                                           // 0x0004(0x0004) Edit
		int32_t                                                    MaxRrbActorCount;                                        // 0x0008(0x0004)
		float                                                      MaxChunkSeparationLOD;                                   // 0x000C(0x0004) Edit
		unsigned long                                              bOverrideMaxChunkSeparationLOD : 1;                      // 0x0010(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.WorldInfo.PhysXEmitterVerticalProperties
	 * Size -> 0x0018
	 */
	struct FPhysXEmitterVerticalProperties
	{
	public:
		unsigned long                                              bDisableLod : 1;                                         // 0x0000(0x0001) BIT_FIELD Edit
		int32_t                                                    ParticlesLodMin;                                         // 0x0004(0x0004) Edit
		int32_t                                                    ParticlesLodMax;                                         // 0x0008(0x0004) Edit
		int32_t                                                    PacketsPerPhysXParticleSystemMax;                        // 0x000C(0x0004) Edit
		unsigned long                                              bApplyCylindricalPacketCulling : 1;                      // 0x0010(0x0001) BIT_FIELD Edit
		float                                                      SpawnLodVsFifoBias;                                      // 0x0014(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.WorldInfo.PhysXVerticalProperties
	 * Size -> 0x0018
	 */
	struct FPhysXVerticalProperties
	{
	public:
		struct FPhysXEmitterVerticalProperties                     Emitters;                                                // 0x0000(0x0018) Edit, EditInline
	};

	/**
	 * ScriptStruct Engine.WorldInfo.ScreenMessageString
	 * Size -> 0x0024
	 */
	struct FScreenMessageString
	{
	public:
		struct FQWord                                              Key;                                                     // 0x0000(0x0008) Transient, AlwaysInit
		class FString                                              ScreenMessage;                                           // 0x0008(0x0010) Transient, AlwaysInit, NeedCtorLink
		struct FColor                                              DisplayColor;                                            // 0x0018(0x0004) Transient, AlwaysInit
		float                                                      TimeToDisplay;                                           // 0x001C(0x0004) Transient, AlwaysInit
		float                                                      CurrentTimeDisplayed;                                    // 0x0020(0x0004) Transient, AlwaysInit
	};

	/**
	 * ScriptStruct Engine.WorldInfo.LightmassWorldInfoSettings
	 * Size -> 0x0058
	 */
	struct FLightmassWorldInfoSettings
	{
	public:
		float                                                      StaticLightingLevelScale;                                // 0x0000(0x0004) Edit
		int32_t                                                    NumIndirectLightingBounces;                              // 0x0004(0x0004) Edit
		struct FColor                                              EnvironmentColor;                                        // 0x0008(0x0004) Edit
		float                                                      EnvironmentIntensity;                                    // 0x000C(0x0004) Edit
		unsigned long                                              bEnableAdvancedEnvironmentColor : 1;                     // 0x0010(0x0001) BIT_FIELD Edit
		struct FColor                                              EnvironmentSunColor;                                     // 0x0014(0x0004) Edit
		float                                                      EnvironmentSunIntensity;                                 // 0x0018(0x0004) Edit
		float                                                      EnvironmentLightTerminatorAngle;                         // 0x001C(0x0004) Edit
		struct FVector                                             EnvironmentLightDirection;                               // 0x0020(0x000C) Edit
		float                                                      EmissiveBoost;                                           // 0x002C(0x0004) Edit
		float                                                      DiffuseBoost;                                            // 0x0030(0x0004) Edit
		float                                                      SpecularBoost;                                           // 0x0034(0x0004)
		float                                                      IndirectNormalInfluenceBoost;                            // 0x0038(0x0004) Edit
		unsigned long                                              bUseAmbientOcclusion : 1;                                // 0x003C(0x0001) BIT_FIELD Edit
		unsigned long                                              bEnableImageReflectionShadowing : 1;                     // 0x003C(0x0001) BIT_FIELD Edit
		float                                                      DirectIlluminationOcclusionFraction;                     // 0x0040(0x0004) Edit
		float                                                      IndirectIlluminationOcclusionFraction;                   // 0x0044(0x0004) Edit
		float                                                      OcclusionExponent;                                       // 0x0048(0x0004) Edit
		float                                                      FullyOccludedSamplesFraction;                            // 0x004C(0x0004) Edit
		float                                                      MaxOcclusionDistance;                                    // 0x0050(0x0004) Edit
		unsigned long                                              bVisualizeMaterialDiffuse : 1;                           // 0x0054(0x0001) BIT_FIELD Edit
		unsigned long                                              bVisualizeAmbientOcclusion : 1;                          // 0x0054(0x0001) BIT_FIELD Edit
		unsigned long                                              bCompressShadowmap : 1;                                  // 0x0054(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.WorldInfo.HostMigrationState
	 * Size -> 0x0020
	 */
	struct FHostMigrationState
	{
	public:
		EHostMigrationProgress                                     HostMigrationProgress;                                   // 0x0000(0x0001)
		unsigned char                                              UnknownData_BND7[0x3];                                   // 0x0001(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      HostMigrationElapsedTime;                                // 0x0004(0x0004)
		float                                                      HostMigrationTravelCountdown;                            // 0x0008(0x0004)
		class FString                                              HostMigrationTravelURL;                                  // 0x000C(0x0010) NeedCtorLink
		unsigned long                                              bHostMigrationEnabled : 1;                               // 0x001C(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.UniqueNetId
	 * Size -> 0x0008
	 */
	struct FUniqueNetId
	{
	public:
		struct FQWord                                              Uid;                                                     // 0x0000(0x0008)
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.UpdateFriendListData
	 * Size -> 0x0014
	 */
	struct FUpdateFriendListData
	{
	public:
		unsigned long                                              isAddFriend : 1;                                         // 0x0000(0x0001) BIT_FIELD
		class FString                                              psnId;                                                   // 0x0004(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.NamedInterface
	 * Size -> 0x0010
	 */
	struct FNamedInterface
	{
	public:
		class FName                                                InterfaceName;                                           // 0x0000(0x0008)
		class UObject*                                             InterfaceObject;                                         // 0x0008(0x0008)
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.NamedInterfaceDef
	 * Size -> 0x0018
	 */
	struct FNamedInterfaceDef
	{
	public:
		class FName                                                InterfaceName;                                           // 0x0000(0x0008)
		class FString                                              InterfaceClassName;                                      // 0x0008(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.OnlineRegistrant
	 * Size -> 0x0008
	 */
	struct FOnlineRegistrant
	{
	public:
		struct FUniqueNetId                                        PlayerNetId;                                             // 0x0000(0x0008) Const
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.OnlineArbitrationRegistrant
	 * Size -> 0x000C (FullSize[0x0014] - InheritedSize[0x0008])
	 */
	struct FOnlineArbitrationRegistrant : public FOnlineRegistrant
	{
	public:
		struct FQWord                                              MachineId;                                               // 0x0008(0x0008) Const
		int32_t                                                    Trustworthiness;                                         // 0x0010(0x0004) Const
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.NamedSession
	 * Size -> 0x0038
	 */
	struct FNamedSession
	{
	public:
		class FName                                                SessionName;                                             // 0x0000(0x0008)
		struct FPointer                                            SessionInfo;                                             // 0x0008(0x0008) Const, Native, Transient
		class UOnlineGameSettings*                                 GameSettings;                                            // 0x0010(0x0008)
		TArray<struct FOnlineRegistrant>                           Registrants;                                             // 0x0018(0x0010) NeedCtorLink
		TArray<struct FOnlineArbitrationRegistrant>                ArbitrationRegistrants;                                  // 0x0028(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.OnlineContent
	 * Size -> 0x0060
	 */
	struct FOnlineContent
	{
	public:
		EOnlineContentType                                         ContentType;                                             // 0x0000(0x0001)
		unsigned char                                              UserIndex;                                               // 0x0001(0x0001)
		unsigned char                                              UnknownData_C6AC[0x2];                                   // 0x0002(0x0002) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		unsigned long                                              bIsCorrupt : 1;                                          // 0x0004(0x0001) BIT_FIELD
		int32_t                                                    DeviceID;                                                // 0x0008(0x0004)
		int32_t                                                    LicenseMask;                                             // 0x000C(0x0004)
		class FString                                              FriendlyName;                                            // 0x0010(0x0010) NeedCtorLink
		class FString                                              Filename;                                                // 0x0020(0x0010) NeedCtorLink
		class FString                                              ContentPath;                                             // 0x0030(0x0010) NeedCtorLink
		TArray<class FString>                                      ContentPackages;                                         // 0x0040(0x0010) NeedCtorLink
		TArray<class FString>                                      ContentFiles;                                            // 0x0050(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.Engine.StatColorMapEntry
	 * Size -> 0x0008
	 */
	struct FStatColorMapEntry
	{
	public:
		float                                                      In;                                                      // 0x0000(0x0004) Config, GlobalConfig
		struct FColor                                              Out;                                                     // 0x0004(0x0004) Config, GlobalConfig
	};

	/**
	 * ScriptStruct Engine.Engine.StatColorMapping
	 * Size -> 0x0024
	 */
	struct FStatColorMapping
	{
	public:
		class FString                                              StatName;                                                // 0x0000(0x0010) Config, GlobalConfig, NeedCtorLink
		TArray<struct FStatColorMapEntry>                          ColorMap;                                                // 0x0010(0x0010) Config, GlobalConfig, NeedCtorLink
		unsigned long                                              DisableBlend : 1;                                        // 0x0020(0x0001) BIT_FIELD Config, GlobalConfig
	};

	/**
	 * ScriptStruct Engine.Engine.DropNoteInfo
	 * Size -> 0x0028
	 */
	struct FDropNoteInfo
	{
	public:
		struct FVector                                             Location;                                                // 0x0000(0x000C)
		struct FRotator                                            Rotation;                                                // 0x000C(0x000C)
		class FString                                              Comment;                                                 // 0x0018(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.GameEngine.URL
	 * Size -> 0x0058
	 */
	struct FURL
	{
	public:
		class FString                                              Protocol;                                                // 0x0000(0x0010) AlwaysInit, NeedCtorLink
		class FString                                              Host;                                                    // 0x0010(0x0010) AlwaysInit, NeedCtorLink
		int32_t                                                    Port;                                                    // 0x0020(0x0004) AlwaysInit
		class FString                                              Map;                                                     // 0x0024(0x0010) AlwaysInit, NeedCtorLink
		TArray<class FString>                                      Op;                                                      // 0x0034(0x0010) AlwaysInit, NeedCtorLink
		class FString                                              Portal;                                                  // 0x0044(0x0010) AlwaysInit, NeedCtorLink
		int32_t                                                    Valid;                                                   // 0x0054(0x0004) AlwaysInit
	};

	/**
	 * ScriptStruct Engine.GameEngine.LevelStreamingStatus
	 * Size -> 0x000C
	 */
	struct FLevelStreamingStatus
	{
	public:
		class FName                                                PackageName;                                             // 0x0000(0x0008)
		unsigned long                                              bShouldBeLoaded : 1;                                     // 0x0008(0x0001) BIT_FIELD
		unsigned long                                              bShouldBeVisible : 1;                                    // 0x0008(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.GameEngine.FullyLoadedPackagesInfo
	 * Size -> 0x0034
	 */
	struct FFullyLoadedPackagesInfo
	{
	public:
		EFullyLoadPackageType                                      FullyLoadType;                                           // 0x0000(0x0001)
		unsigned char                                              UnknownData_B21S[0x3];                                   // 0x0001(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class FString                                              Tag;                                                     // 0x0004(0x0010) NeedCtorLink
		TArray<class FName>                                        PackagesToLoad;                                          // 0x0014(0x0010) NeedCtorLink
		TArray<class UObject*>                                     LoadedObjects;                                           // 0x0024(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.GameEngine.NamedNetDriver
	 * Size -> 0x0010
	 */
	struct FNamedNetDriver
	{
	public:
		class FName                                                NetDriverName;                                           // 0x0000(0x0008)
		struct FPointer                                            NetDriver;                                               // 0x0008(0x0008) Const, Native
	};

	/**
	 * ScriptStruct Engine.GameEngine.AnimTag
	 * Size -> 0x0020
	 */
	struct FAnimTag
	{
	public:
		class FString                                              Tag;                                                     // 0x0000(0x0010) NeedCtorLink
		TArray<class FString>                                      Contains;                                                // 0x0010(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.BlockingVolume.GHM_BlockingVolume_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_BlockingVolume_CheckpointRecord
	{
	public:
		unsigned long                                              bBlockRigidBody : 1;                                     // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.DynamicBlockingVolume.CheckpointRecord
	 * Size -> 0x001C
	 */
	struct ADynamicBlockingVolume_FCheckpointRecord
	{
	public:
		struct FVector                                             Location;                                                // 0x0000(0x000C)
		struct FRotator                                            Rotation;                                                // 0x000C(0x000C)
		unsigned long                                              bCollideActors : 1;                                      // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bBlockActors : 1;                                        // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bNeedsReplication : 1;                                   // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bEnabled : 1;                                            // 0x0018(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.CullDistanceVolume.CullDistanceSizePair
	 * Size -> 0x0008
	 */
	struct FCullDistanceSizePair
	{
	public:
		float                                                      Size;                                                    // 0x0000(0x0004) Edit
		float                                                      CullDistance;                                            // 0x0004(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.KMeshProps.KSphereElem
	 * Size -> 0x0048
	 */
	struct FKSphereElem
	{
	public:
		struct FMatrix                                             TM;                                                      // 0x0000(0x0040) Edit, EditConst
		float                                                      Radius;                                                  // 0x0040(0x0004) Edit, EditConst
		unsigned long                                              bNoRBCollision : 1;                                      // 0x0044(0x0001) BIT_FIELD Edit
		unsigned long                                              bPerPolyShape : 1;                                       // 0x0044(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.KMeshProps.KBoxElem
	 * Size -> 0x0050
	 */
	struct FKBoxElem
	{
	public:
		struct FMatrix                                             TM;                                                      // 0x0000(0x0040) Edit, EditConst
		float                                                      X;                                                       // 0x0040(0x0004) Edit, EditConst
		float                                                      Y;                                                       // 0x0044(0x0004) Edit, EditConst
		float                                                      Z;                                                       // 0x0048(0x0004) Edit, EditConst
		unsigned long                                              bNoRBCollision : 1;                                      // 0x004C(0x0001) BIT_FIELD Edit
		unsigned long                                              bPerPolyShape : 1;                                       // 0x004C(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.KMeshProps.KSphylElem
	 * Size -> 0x004C
	 */
	struct FKSphylElem
	{
	public:
		struct FMatrix                                             TM;                                                      // 0x0000(0x0040) Edit, EditConst
		float                                                      Radius;                                                  // 0x0040(0x0004) Edit, EditConst
		float                                                      Length;                                                  // 0x0044(0x0004) Edit, EditConst
		unsigned long                                              bNoRBCollision : 1;                                      // 0x0048(0x0001) BIT_FIELD Edit
		unsigned long                                              bPerPolyShape : 1;                                       // 0x0048(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.KMeshProps.KConvexElem
	 * Size -> 0x007C
	 */
	struct FKConvexElem
	{
	public:
		TArray<struct FVector>                                     VertexData;                                              // 0x0000(0x0010) NeedCtorLink
		TArray<struct FPlane>                                      PermutedVertexData;                                      // 0x0010(0x0010) NeedCtorLink
		TArray<int32_t>                                            FaceTriData;                                             // 0x0020(0x0010) NeedCtorLink
		TArray<struct FVector>                                     EdgeDirections;                                          // 0x0030(0x0010) NeedCtorLink
		TArray<struct FVector>                                     FaceNormalDirections;                                    // 0x0040(0x0010) NeedCtorLink
		TArray<struct FPlane>                                      FacePlaneData;                                           // 0x0050(0x0010) NeedCtorLink
		struct FBox                                                ElemBox;                                                 // 0x0060(0x001C)
	};

	/**
	 * ScriptStruct Engine.KMeshProps.KAggregateGeom
	 * Size -> 0x004C
	 */
	struct FKAggregateGeom
	{
	public:
		TArray<struct FKSphereElem>                                SphereElems;                                             // 0x0000(0x0010) Edit, EditFixedSize, NeedCtorLink
		TArray<struct FKBoxElem>                                   BoxElems;                                                // 0x0010(0x0010) Edit, EditFixedSize, NeedCtorLink
		TArray<struct FKSphylElem>                                 SphylElems;                                              // 0x0020(0x0010) Edit, EditFixedSize, NeedCtorLink
		TArray<struct FKConvexElem>                                ConvexElems;                                             // 0x0030(0x0010) Edit, EditFixedSize, NeedCtorLink
		struct FPointer                                            RenderInfo;                                              // 0x0040(0x0008) Native, NoImport, NonTransactional
		unsigned long                                              bSkipCloseAndParallelChecks : 1;                         // 0x0048(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.LevelStreamingVolume.CheckpointRecord
	 * Size -> 0x0004
	 */
	struct ALevelStreamingVolume_FCheckpointRecord
	{
	public:
		unsigned long                                              bDisabled : 1;                                           // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.PhysicsVolume.CheckpointRecord
	 * Size -> 0x0004
	 */
	struct APhysicsVolume_FCheckpointRecord
	{
	public:
		unsigned long                                              bPainCausing : 1;                                        // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bActive : 1;                                             // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.DynamicSMActor.GHM_DynamicSMActor_CheckpointRecord
	 * Size -> 0x0034
	 */
	struct FGHM_DynamicSMActor_CheckpointRecord
	{
	public:
		class FString                                              ReplacedMaterial0_PathName;                              // 0x0000(0x0010) NeedCtorLink
		class FString                                              ReplacedMaterial1_PathName;                              // 0x0010(0x0010) NeedCtorLink
		class FString                                              ReplacedMesh_PathName;                                   // 0x0020(0x0010) NeedCtorLink
		unsigned long                                              bForceStaticDecals : 1;                                  // 0x0030(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.InterpActor.CheckpointRecord
	 * Size -> 0x0020
	 */
	struct AInterpActor_FCheckpointRecord
	{
	public:
		struct FVector                                             Location;                                                // 0x0000(0x000C)
		struct FRotator                                            Rotation;                                                // 0x000C(0x000C)
		ECollisionType                                             CollisionType;                                           // 0x0018(0x0001)
		unsigned char                                              UnknownData_5KF0[0x3];                                   // 0x0019(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		unsigned long                                              bHidden : 1;                                             // 0x001C(0x0001) BIT_FIELD
		unsigned long                                              bIsShutdown : 1;                                         // 0x001C(0x0001) BIT_FIELD
		unsigned long                                              bNeedsPositionReplication : 1;                           // 0x001C(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.Emitter.CheckpointRecord
	 * Size -> 0x0004
	 */
	struct AEmitter_FCheckpointRecord
	{
	public:
		unsigned long                                              bIsActive : 1;                                           // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.EmitterPool.EmitterBaseInfo
	 * Size -> 0x002C
	 */
	struct FEmitterBaseInfo
	{
	public:
		class UParticleSystemComponent*                            PSC;                                                     // 0x0000(0x0008) ExportObject, Component, EditInline
		class AActor*                                              Base;                                                    // 0x0008(0x0008)
		struct FVector                                             RelativeLocation;                                        // 0x0010(0x000C)
		struct FRotator                                            RelativeRotation;                                        // 0x001C(0x000C)
		unsigned long                                              bInheritBaseScale : 1;                                   // 0x0028(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.Canvas.CanvasIcon
	 * Size -> 0x0018
	 */
	struct FCanvasIcon
	{
	public:
		class UTexture*                                            Texture;                                                 // 0x0000(0x0008) Edit
		float                                                      U;                                                       // 0x0008(0x0004) Edit
		float                                                      V;                                                       // 0x000C(0x0004) Edit
		float                                                      UL;                                                      // 0x0010(0x0004) Edit
		float                                                      VL;                                                      // 0x0014(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.Canvas.CanvasUVTri
	 * Size -> 0x0030
	 */
	struct FCanvasUVTri
	{
	public:
		struct FVector2D                                           V0_Pos;                                                  // 0x0000(0x0008) Edit
		struct FVector2D                                           V0_UV;                                                   // 0x0008(0x0008) Edit
		struct FVector2D                                           V1_Pos;                                                  // 0x0010(0x0008) Edit
		struct FVector2D                                           V1_UV;                                                   // 0x0018(0x0008) Edit
		struct FVector2D                                           V2_Pos;                                                  // 0x0020(0x0008) Edit
		struct FVector2D                                           V2_UV;                                                   // 0x0028(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.Canvas.DepthFieldGlowInfo
	 * Size -> 0x0024
	 */
	struct FDepthFieldGlowInfo
	{
	public:
		unsigned long                                              bEnableGlow : 1;                                         // 0x0000(0x0001) BIT_FIELD
		struct FLinearColor                                        GlowColor;                                               // 0x0004(0x0010)
		struct FVector2D                                           GlowOuterRadius;                                         // 0x0014(0x0008)
		struct FVector2D                                           GlowInnerRadius;                                         // 0x001C(0x0008)
	};

	/**
	 * ScriptStruct Engine.Canvas.FontRenderInfo
	 * Size -> 0x0028
	 */
	struct FFontRenderInfo
	{
	public:
		unsigned long                                              bClipText : 1;                                           // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bEnableShadow : 1;                                       // 0x0000(0x0001) BIT_FIELD
		struct FDepthFieldGlowInfo                                 GlowInfo;                                                // 0x0004(0x0024)
	};

	/**
	 * ScriptStruct Engine.HUD.HudLocalizedMessage
	 * Size -> 0x0054
	 */
	struct FHudLocalizedMessage
	{
	public:
		class UClass*                                              Message;                                                 // 0x0000(0x0008)
		class FString                                              StringMessage;                                           // 0x0008(0x0010) NeedCtorLink
		int32_t                                                    Switch;                                                  // 0x0018(0x0004)
		struct FDouble                                             EndOfLife;                                               // 0x001C(0x0008)
		float                                                      Lifetime;                                                // 0x0024(0x0004)
		float                                                      PosY;                                                    // 0x0028(0x0004)
		struct FColor                                              DrawColor;                                               // 0x002C(0x0004)
		int32_t                                                    FontSize;                                                // 0x0030(0x0004)
		class UFont*                                               StringFont;                                              // 0x0034(0x0008)
		float                                                      DX;                                                      // 0x003C(0x0004)
		float                                                      DY;                                                      // 0x0040(0x0004)
		unsigned long                                              Drawn : 1;                                               // 0x0044(0x0001) BIT_FIELD
		int32_t                                                    Count;                                                   // 0x0048(0x0004)
		class UObject*                                             OptionalObject;                                          // 0x004C(0x0008)
	};

	/**
	 * ScriptStruct Engine.HUD.ConsoleMessage
	 * Size -> 0x0024
	 */
	struct FConsoleMessage
	{
	public:
		class FString                                              Text;                                                    // 0x0000(0x0010) NeedCtorLink
		struct FColor                                              TextColor;                                               // 0x0010(0x0004)
		struct FDouble                                             MessageLife;                                             // 0x0014(0x0008)
		class APlayerReplicationInfo*                              PRI;                                                     // 0x001C(0x0008)
	};

	/**
	 * ScriptStruct Engine.HUD.KismetDrawTextInfo
	 * Size -> 0x0044
	 */
	struct FKismetDrawTextInfo
	{
	public:
		class FString                                              MessageText;                                             // 0x0000(0x0010) Edit, NeedCtorLink
		class FString                                              AppendedText;                                            // 0x0010(0x0010) NeedCtorLink
		class UFont*                                               MessageFont;                                             // 0x0020(0x0008) Edit
		struct FVector2D                                           MessageFontScale;                                        // 0x0028(0x0008) Edit
		struct FVector2D                                           MessageOffset;                                           // 0x0030(0x0008) Edit
		struct FColor                                              MessageColor;                                            // 0x0038(0x0004) Edit
		struct FDouble                                             MessageEndTime;                                          // 0x003C(0x0008)
	};

	/**
	 * ScriptStruct Engine.Actor.ActorReference
	 * Size -> 0x0018
	 */
	struct FActorReference
	{
	public:
		class AActor*                                              Actor;                                                   // 0x0000(0x0008) Edit
		struct FGuid                                               Guid;                                                    // 0x0008(0x0010) Edit, Const, EditConst
	};

	/**
	 * ScriptStruct Engine.GameInfo.GameTypePrefix
	 * Size -> 0x0044
	 */
	struct FGameTypePrefix
	{
	public:
		class FString                                              Prefix;                                                  // 0x0000(0x0010) NeedCtorLink
		unsigned long                                              bUsesCommonPackage : 1;                                  // 0x0010(0x0001) BIT_FIELD
		class FString                                              GameType;                                                // 0x0014(0x0010) NeedCtorLink
		TArray<class FString>                                      AdditionalGameTypes;                                     // 0x0024(0x0010) NeedCtorLink
		TArray<class FString>                                      ForcedObjects;                                           // 0x0034(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.GameInfo.GameClassShortName
	 * Size -> 0x0020
	 */
	struct FGameClassShortName
	{
	public:
		class FString                                              ShortName;                                               // 0x0000(0x0010) NeedCtorLink
		class FString                                              GameClassName;                                           // 0x0010(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.NavigationPoint.CheckpointRecord
	 * Size -> 0x0004
	 */
	struct ANavigationPoint_FCheckpointRecord
	{
	public:
		unsigned long                                              bDisabled : 1;                                           // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bBlocked : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.NavigationPoint.NavigationOctreeObject
	 * Size -> 0x0039
	 */
	struct FNavigationOctreeObject
	{
	public:
		struct FBox                                                BoundingBox;                                             // 0x0000(0x001C)
		struct FVector                                             BoxCenter;                                               // 0x001C(0x000C)
		struct FPointer                                            OctreeNode;                                              // 0x0028(0x0008) Const, Native, Transient
		class UObject*                                             Owner;                                                   // 0x0030(0x0008) Const, NoExport
		unsigned char                                              OwnerType;                                               // 0x0038(0x0001) Const, NoExport
	};

	/**
	 * ScriptStruct Engine.NavigationPoint.DebugNavCost
	 * Size -> 0x0014
	 */
	struct FDebugNavCost
	{
	public:
		class FString                                              Desc;                                                    // 0x0000(0x0010) NeedCtorLink
		int32_t                                                    Cost;                                                    // 0x0010(0x0004)
	};

	/**
	 * ScriptStruct Engine.CoverLink.CoverInfo
	 * Size -> 0x000C
	 */
	struct FCoverInfo
	{
	public:
		class ACoverLink*                                          Link;                                                    // 0x0000(0x0008) Edit, EditConst
		int32_t                                                    SlotIdx;                                                 // 0x0008(0x0004) Edit, EditConst
	};

	/**
	 * ScriptStruct Engine.CoverLink.FireLink
	 * Size -> 0x0018
	 */
	struct FFireLink
	{
	public:
		TArray<unsigned char>                                      Interactions;                                            // 0x0000(0x0010) NeedCtorLink
		int32_t                                                    PackedProperties_CoverPairRefAndDynamicInfo;             // 0x0010(0x0004) Const
		unsigned long                                              bFallbackLink : 1;                                       // 0x0014(0x0001) BIT_FIELD
		unsigned long                                              bDynamicIndexInited : 1;                                 // 0x0014(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.Pylon.GHM_Pylon_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_Pylon_CheckpointRecord
	{
	public:
		unsigned long                                              bDisabled : 1;                                           // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.Pylon.PolyReference
	 * Size -> 0x0024
	 */
	struct FPolyReference
	{
	public:
		struct FActorReference                                     OwningPylon;                                             // 0x0000(0x0018)
		int32_t                                                    PolyId;                                                  // 0x0018(0x0004)
		struct FPointer                                            CachedPoly;                                              // 0x001C(0x0008) Native
	};

	/**
	 * ScriptStruct Engine.CoverLink.SlotMoveRef
	 * Size -> 0x0060
	 */
	struct FSlotMoveRef
	{
	public:
		struct FPolyReference                                      Poly;                                                    // 0x0000(0x0024) Edit
		struct FBasedPosition                                      Dest;                                                    // 0x0024(0x0038) Edit
		int32_t                                                    Direction;                                               // 0x005C(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.CoverLink.CoverSlot
	 * Size -> 0x0090
	 */
	struct FCoverSlot
	{
	public:
		class APawn*                                               SlotOwner;                                               // 0x0000(0x0008)
		float                                                      SlotValidAfterTime;                                      // 0x0008(0x0004) Transient
		ECoverType                                                 ForceCoverType;                                          // 0x000C(0x0001) Edit
		ECoverType                                                 CoverType;                                               // 0x000D(0x0001) Edit, EditConst
		ECoverLocationDescription                                  LocationDescription;                                     // 0x000E(0x0001) Edit
		unsigned char                                              UnknownData_XYQ7[0x1];                                   // 0x000F(0x0001) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct FVector                                             LocationOffset;                                          // 0x0010(0x000C)
		struct FRotator                                            RotationOffset;                                          // 0x001C(0x000C)
		TArray<ECoverAction>                                       Actions;                                                 // 0x0028(0x0010) NeedCtorLink
		TArray<struct FFireLink>                                   FireLinks;                                               // 0x0038(0x0010) Edit, EditConst, NeedCtorLink
		TArray<struct FFireLink>                                   RejectedFireLinks;                                       // 0x0048(0x0010) Edit, Transient, EditConst, NeedCtorLink
		TArray<int32_t>                                            ExposedCoverPackedProperties;                            // 0x0058(0x0010) NeedCtorLink
		int32_t                                                    TurnTargetPackedProperties;                              // 0x0068(0x0004)
		TArray<struct FSlotMoveRef>                                SlipRefs;                                                // 0x006C(0x0010) NeedCtorLink
		TArray<struct FCoverInfo>                                  OverlapClaimsList;                                       // 0x007C(0x0010) Edit, EditConst, NeedCtorLink
		unsigned long                                              bLeanLeft : 1;                                           // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bLeanRight : 1;                                          // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bForceCanPopUp : 1;                                      // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bCanPopUp : 1;                                           // 0x008C(0x0001) BIT_FIELD Edit, EditConst
		unsigned long                                              bCanMantle : 1;                                          // 0x008C(0x0001) BIT_FIELD Edit, EditConst
		unsigned long                                              bCanClimbUp : 1;                                         // 0x008C(0x0001) BIT_FIELD Edit, EditConst
		unsigned long                                              bForceCanCoverSlip_Left : 1;                             // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bForceCanCoverSlip_Right : 1;                            // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bCanCoverSlip_Left : 1;                                  // 0x008C(0x0001) BIT_FIELD Edit, EditConst
		unsigned long                                              bCanCoverSlip_Right : 1;                                 // 0x008C(0x0001) BIT_FIELD Edit, EditConst
		unsigned long                                              bCanSwatTurn_Left : 1;                                   // 0x008C(0x0001) BIT_FIELD Edit, EditConst
		unsigned long                                              bCanSwatTurn_Right : 1;                                  // 0x008C(0x0001) BIT_FIELD Edit, EditConst
		unsigned long                                              bEnabled : 1;                                            // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bAllowPopup : 1;                                         // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bAllowMantle : 1;                                        // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bAllowCoverSlip : 1;                                     // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bAllowClimbUp : 1;                                       // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bAllowSwatTurn : 1;                                      // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bForceNoGroundAdjust : 1;                                // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bPlayerOnly : 1;                                         // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bPreferLeanOverPopup : 1;                                // 0x008C(0x0001) BIT_FIELD Edit
		unsigned long                                              bDestructible : 1;                                       // 0x008C(0x0001) BIT_FIELD Transient
		unsigned long                                              bSelected : 1;                                           // 0x008C(0x0001) BIT_FIELD Transient
		unsigned long                                              bFailedToFindSurface : 1;                                // 0x008C(0x0001) BIT_FIELD Edit, Transient, EditConst
	};

	/**
	 * ScriptStruct Engine.CoverLink.DynamicLinkInfo
	 * Size -> 0x0018
	 */
	struct FDynamicLinkInfo
	{
	public:
		struct FVector                                             LastTargetLocation;                                      // 0x0000(0x000C)
		struct FVector                                             LastSrcLocation;                                         // 0x000C(0x000C)
	};

	/**
	 * ScriptStruct Engine.PlayerStart.GHM_PlayerStart_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_PlayerStart_CheckpointRecord
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.SceneCaptureActor.GHM_SceneCaptureActor_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_SceneCaptureActor_CheckpointRecord
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.StaticMeshActorBasedOnExtremeContent.SMMaterialSetterDatum
	 * Size -> 0x000C
	 */
	struct FSMMaterialSetterDatum
	{
	public:
		int32_t                                                    MaterialIndex;                                           // 0x0000(0x0004) Edit
		class UMaterialInterface*                                  TheMaterial;                                             // 0x0004(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.Trigger.CheckpointRecord
	 * Size -> 0x0004
	 */
	struct ATrigger_FCheckpointRecord
	{
	public:
		unsigned long                                              bCollideActors : 1;                                      // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.EngineTypes.SubtitleCue
	 * Size -> 0x001C
	 */
	struct FSubtitleCue
	{
	public:
		class FString                                              Text;                                                    // 0x0000(0x0010) Edit, Const, Localized, NeedCtorLink
		float                                                      Time;                                                    // 0x0010(0x0004) Edit, Const, Localized
		struct FDouble                                             TimeD;                                                   // 0x0014(0x0008) Transient
	};

	/**
	 * ScriptStruct Engine.AudioComponent.AudioComponentParam
	 * Size -> 0x0014
	 */
	struct FAudioComponentParam
	{
	public:
		class FName                                                ParamName;                                               // 0x0000(0x0008) Edit
		float                                                      FloatParam;                                              // 0x0008(0x0004) Edit
		class USoundNodeWave*                                      WaveParam;                                               // 0x000C(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.SplineAudioComponent.InterpPointOnSpline
	 * Size -> 0x0014
	 */
	struct FInterpPointOnSpline
	{
	public:
		struct FVector                                             Position;                                                // 0x0000(0x000C) Edit
		float                                                      InVal;                                                   // 0x000C(0x0004) Edit
		float                                                      Length;                                                  // 0x0010(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.MultiCueSplineAudioComponent.MultiCueSplineSoundSlot
	 * Size -> 0x0034
	 */
	struct FMultiCueSplineSoundSlot
	{
	public:
		class USoundCue*                                           SoundCue;                                                // 0x0000(0x0008) Edit
		float                                                      PitchScale;                                              // 0x0008(0x0004) Edit
		float                                                      VolumeScale;                                             // 0x000C(0x0004) Edit
		int32_t                                                    StartPoint;                                              // 0x0010(0x0004) Edit
		int32_t                                                    EndPoint;                                                // 0x0014(0x0004) Edit
		struct FDouble                                             LastUpdateTime;                                          // 0x0018(0x0008) Const, Native
		float                                                      SourceInteriorVolume;                                    // 0x0020(0x0004) Const, Native
		float                                                      SourceInteriorLPF;                                       // 0x0024(0x0004) Const, Native
		float                                                      CurrentInteriorVolume;                                   // 0x0028(0x0004) Const, Native
		float                                                      CurrentInteriorLPF;                                      // 0x002C(0x0004) Const, Native
		unsigned long                                              bPlaying : 1;                                            // 0x0030(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.SimpleSplineAudioComponent.SplineSoundSlot
	 * Size -> 0x0034
	 */
	struct FSplineSoundSlot
	{
	public:
		class USoundNodeWave*                                      Wave;                                                    // 0x0000(0x0008) Edit
		float                                                      PitchScale;                                              // 0x0008(0x0004) Edit
		float                                                      VolumeScale;                                             // 0x000C(0x0004) Edit
		int32_t                                                    StartPoint;                                              // 0x0010(0x0004) Edit
		int32_t                                                    EndPoint;                                                // 0x0014(0x0004) Edit
		float                                                      Weight;                                                  // 0x0018(0x0004) Edit
		struct FDouble                                             LastUpdateTime;                                          // 0x001C(0x0008) Const, Native
		float                                                      SourceInteriorVolume;                                    // 0x0024(0x0004) Const, Native
		float                                                      SourceInteriorLPF;                                       // 0x0028(0x0004) Const, Native
		float                                                      CurrentInteriorVolume;                                   // 0x002C(0x0004) Const, Native
		float                                                      CurrentInteriorLPF;                                      // 0x0030(0x0004) Const, Native
	};

	/**
	 * ScriptStruct Engine.LightComponent.LightingChannelContainer
	 * Size -> 0x0004
	 */
	struct FLightingChannelContainer
	{
	public:
		unsigned long                                              bInitialized : 1;                                        // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              BSP : 1;                                                 // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Static : 1;                                              // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Dynamic : 1;                                             // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              CompositeDynamic : 1;                                    // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Skybox : 1;                                              // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Hero : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Enemy : 1;                                               // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Boss : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              DynamicObject : 1;                                       // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Unnamed_6 : 1;                                           // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Unnamed_7 : 1;                                           // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Cinematic_2 : 1;                                         // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Cinematic_3 : 1;                                         // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Cinematic_4 : 1;                                         // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Cinematic_5 : 1;                                         // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Cinematic_6 : 1;                                         // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Cinematic_7 : 1;                                         // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Cinematic_8 : 1;                                         // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Cinematic_9 : 1;                                         // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Cinematic_10 : 1;                                        // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Cinematic_11 : 1;                                        // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Gameplay_2 : 1;                                          // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Gameplay_3 : 1;                                          // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Gameplay_4 : 1;                                          // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Gameplay_5 : 1;                                          // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              Crowd : 1;                                               // 0x0000(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.PrimitiveComponent.RBCollisionChannelContainer
	 * Size -> 0x0004
	 */
	struct FRBCollisionChannelContainer
	{
	public:
		unsigned long                                              Default : 1;                                             // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              Nothing : 1;                                             // 0x0000(0x0001) BIT_FIELD Const
		unsigned long                                              Pawn : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              Vehicle : 1;                                             // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              Water : 1;                                               // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GameplayPhysics : 1;                                     // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              EffectPhysics : 1;                                       // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              Untitled1 : 1;                                           // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              Untitled2 : 1;                                           // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              Untitled3 : 1;                                           // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              Untitled4 : 1;                                           // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              Cloth : 1;                                               // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              FluidDrain : 1;                                          // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              SoftBody : 1;                                            // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              FracturedMeshPart : 1;                                   // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              BlockingVolume : 1;                                      // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              DeadPawn : 1;                                            // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              Clothing : 1;                                            // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              ClothingCollision : 1;                                   // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GhM0 : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GhM1 : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GhM2 : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GhM3 : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GhM4 : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GhM5 : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GhM6 : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GhM7 : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GhM8 : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GhM9 : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GhM10 : 1;                                               // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GhM11 : 1;                                               // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              GhM12 : 1;                                               // 0x0000(0x0001) BIT_FIELD Edit, Const
	};

	/**
	 * ScriptStruct Engine.BrushComponent.KCachedConvexData_Mirror
	 * Size -> 0x0010
	 */
	struct FKCachedConvexData_Mirror
	{
	public:
		TArray<int32_t>                                            CachedConvexElements;                                    // 0x0000(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.Controller.VisiblePortalInfo
	 * Size -> 0x0010
	 */
	struct FVisiblePortalInfo
	{
	public:
		class AActor*                                              Source;                                                  // 0x0000(0x0008)
		class AActor*                                              Destination;                                             // 0x0008(0x0008)
	};

	/**
	 * ScriptStruct Engine.Settings.LocalizedStringSetting
	 * Size -> 0x0009
	 */
	struct FLocalizedStringSetting
	{
	public:
		int32_t                                                    Id;                                                      // 0x0000(0x0004)
		int32_t                                                    ValueIndex;                                              // 0x0004(0x0004)
		EOnlineDataAdvertisementType                               AdvertisementType;                                       // 0x0008(0x0001)
	};

	/**
	 * ScriptStruct Engine.Settings.SettingsData
	 * Size -> 0x0010
	 */
	struct FSettingsData
	{
	public:
		ESettingsDataType                                          Type;                                                    // 0x0000(0x0001) Const
		unsigned char                                              UnknownData_HGC8[0x3];                                   // 0x0001(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    Value1;                                                  // 0x0004(0x0004) Const
		struct FPointer                                            Value2;                                                  // 0x0008(0x0008) Const, Native, Transient
	};

	/**
	 * ScriptStruct Engine.Settings.SettingsProperty
	 * Size -> 0x0015
	 */
	struct FSettingsProperty
	{
	public:
		int32_t                                                    PropertyId;                                              // 0x0000(0x0004)
		struct FSettingsData                                       Data;                                                    // 0x0004(0x0010)
		EOnlineDataAdvertisementType                               AdvertisementType;                                       // 0x0014(0x0001)
	};

	/**
	 * ScriptStruct Engine.Settings.IdToStringMapping
	 * Size -> 0x000C
	 */
	struct FIdToStringMapping
	{
	public:
		int32_t                                                    Id;                                                      // 0x0000(0x0004) Const
		class FName                                                Name;                                                    // 0x0004(0x0008) Const, Localized
	};

	/**
	 * ScriptStruct Engine.Settings.StringIdToStringMapping
	 * Size -> 0x0010
	 */
	struct FStringIdToStringMapping
	{
	public:
		int32_t                                                    Id;                                                      // 0x0000(0x0004) Const
		class FName                                                Name;                                                    // 0x0004(0x0008) Const, Localized
		unsigned long                                              bIsWildcard : 1;                                         // 0x000C(0x0001) BIT_FIELD Const
	};

	/**
	 * ScriptStruct Engine.Settings.LocalizedStringSettingMetaData
	 * Size -> 0x002C
	 */
	struct FLocalizedStringSettingMetaData
	{
	public:
		int32_t                                                    Id;                                                      // 0x0000(0x0004) Const
		class FName                                                Name;                                                    // 0x0004(0x0008) Const
		class FString                                              ColumnHeaderText;                                        // 0x000C(0x0010) Const, Localized, NeedCtorLink
		TArray<struct FStringIdToStringMapping>                    ValueMappings;                                           // 0x001C(0x0010) Const, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.Settings.SettingsPropertyPropertyMetaData
	 * Size -> 0x004C
	 */
	struct FSettingsPropertyPropertyMetaData
	{
	public:
		int32_t                                                    Id;                                                      // 0x0000(0x0004) Const
		class FName                                                Name;                                                    // 0x0004(0x0008) Const
		class FString                                              ColumnHeaderText;                                        // 0x000C(0x0010) Const, Localized, NeedCtorLink
		EPropertyValueMappingType                                  MappingType;                                             // 0x001C(0x0001) Const
		unsigned char                                              UnknownData_6YE9[0x3];                                   // 0x001D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		TArray<struct FIdToStringMapping>                          ValueMappings;                                           // 0x0020(0x0010) Const, NeedCtorLink
		TArray<struct FSettingsData>                               PredefinedValues;                                        // 0x0030(0x0010) Const, NeedCtorLink
		float                                                      MinVal;                                                  // 0x0040(0x0004) Const
		float                                                      MaxVal;                                                  // 0x0044(0x0004) Const
		float                                                      RangeIncrement;                                          // 0x0048(0x0004) Const
	};

	/**
	 * ScriptStruct Engine.OnlineGameSearch.OverrideSkill
	 * Size -> 0x0034
	 */
	struct FOverrideSkill
	{
	public:
		int32_t                                                    LeaderboardId;                                           // 0x0000(0x0004)
		TArray<struct FUniqueNetId>                                Players;                                                 // 0x0004(0x0010) NeedCtorLink
		TArray<struct FDouble>                                     Mus;                                                     // 0x0014(0x0010) NeedCtorLink
		TArray<struct FDouble>                                     Sigmas;                                                  // 0x0024(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineGameSearch.NamedObjectProperty
	 * Size -> 0x0018
	 */
	struct FNamedObjectProperty
	{
	public:
		class FName                                                ObjectPropertyName;                                      // 0x0000(0x0008)
		class FString                                              ObjectPropertyValue;                                     // 0x0008(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineGameSearch.OnlineGameSearchParameter
	 * Size -> 0x000E
	 */
	struct FOnlineGameSearchParameter
	{
	public:
		int32_t                                                    EntryId;                                                 // 0x0000(0x0004)
		class FName                                                ObjectPropertyName;                                      // 0x0004(0x0008)
		EOnlineGameSearchEntryType                                 EntryType;                                               // 0x000C(0x0001)
		EOnlineGameSearchComparisonType                            ComparisonType;                                          // 0x000D(0x0001)
	};

	/**
	 * ScriptStruct Engine.OnlineGameSearch.OnlineGameSearchORClause
	 * Size -> 0x0010
	 */
	struct FOnlineGameSearchORClause
	{
	public:
		TArray<struct FOnlineGameSearchParameter>                  OrParams;                                                // 0x0000(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineGameSearch.OnlineGameSearchSortClause
	 * Size -> 0x000E
	 */
	struct FOnlineGameSearchSortClause
	{
	public:
		int32_t                                                    EntryId;                                                 // 0x0000(0x0004)
		class FName                                                ObjectPropertyName;                                      // 0x0004(0x0008)
		EOnlineGameSearchEntryType                                 EntryType;                                               // 0x000C(0x0001)
		EOnlineGameSearchSortType                                  SortType;                                                // 0x000D(0x0001)
	};

	/**
	 * ScriptStruct Engine.OnlineGameSearch.OnlineGameSearchQuery
	 * Size -> 0x0020
	 */
	struct FOnlineGameSearchQuery
	{
	public:
		TArray<struct FOnlineGameSearchORClause>                   OrClauses;                                               // 0x0000(0x0010) NeedCtorLink
		TArray<struct FOnlineGameSearchSortClause>                 SortClauses;                                             // 0x0010(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineGameSearch.OnlineGameSearchResult
	 * Size -> 0x0010
	 */
	struct FOnlineGameSearchResult
	{
	public:
		class UOnlineGameSettings*                                 GameSettings;                                            // 0x0000(0x0008) Const
		struct FPointer                                            PlatformData;                                            // 0x0008(0x0008) Const, Native
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.OnlinePlayerScore
	 * Size -> 0x0010
	 */
	struct FOnlinePlayerScore
	{
	public:
		struct FUniqueNetId                                        PlayerID;                                                // 0x0000(0x0008)
		int32_t                                                    TeamID;                                                  // 0x0008(0x0004)
		int32_t                                                    Score;                                                   // 0x000C(0x0004)
	};

	/**
	 * ScriptStruct Engine.Camera.TViewTarget
	 * Size -> 0x0038
	 */
	struct FTViewTarget
	{
	public:
		class AActor*                                              Target;                                                  // 0x0000(0x0008) Edit
		class AController*                                         Controller;                                              // 0x0008(0x0008) Edit
		struct FTPOV                                               POV;                                                     // 0x0010(0x001C) Edit
		float                                                      AspectRatio;                                             // 0x002C(0x0004) Edit
		class APlayerReplicationInfo*                              PRI;                                                     // 0x0030(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.EngineBaseTypes.RenderingPerformanceOverrides
	 * Size -> 0x0004
	 */
	struct FRenderingPerformanceOverrides
	{
	public:
		unsigned long                                              bAllowAmbientOcclusion : 1;                              // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bAllowDominantWholeSceneDynamicShadows : 1;              // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bAllowMotionBlurSkinning : 1;                            // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bAllowTemporalAA : 1;                                    // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bAllowLightShafts : 1;                                   // 0x0000(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.Camera.TCameraCache
	 * Size -> 0x0024
	 */
	struct FTCameraCache
	{
	public:
		struct FDouble                                             TimeStamp;                                               // 0x0000(0x0008)
		struct FTPOV                                               POV;                                                     // 0x0008(0x001C)
	};

	/**
	 * ScriptStruct Engine.Camera.ViewTargetTransitionParams
	 * Size -> 0x0010
	 */
	struct FViewTargetTransitionParams
	{
	public:
		float                                                      BlendTime;                                               // 0x0000(0x0004) Edit
		EViewTargetBlendFunction                                   BlendFunction;                                           // 0x0004(0x0001) Edit
		unsigned char                                              UnknownData_K8MJ[0x3];                                   // 0x0005(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      BlendExp;                                                // 0x0008(0x0004) Edit
		unsigned long                                              bLockOutgoing : 1;                                       // 0x000C(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.PlayerController.ConnectedPeerInfo
	 * Size -> 0x0010
	 */
	struct FConnectedPeerInfo
	{
	public:
		struct FUniqueNetId                                        PlayerID;                                                // 0x0000(0x0008)
		ENATType                                                   NatType;                                                 // 0x0008(0x0001)
		unsigned char                                              UnknownData_AR2F[0x3];                                   // 0x0009(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		unsigned long                                              bLostConnectionToHost : 1;                               // 0x000C(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.PlayerController.ClientAdjustment
	 * Size -> 0x0039
	 */
	struct FClientAdjustment
	{
	public:
		struct FDouble                                             TimeStamp;                                               // 0x0000(0x0008)
		EPhysics                                                   newPhysics;                                              // 0x0008(0x0001)
		unsigned char                                              UnknownData_ZCDI[0x3];                                   // 0x0009(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct FVector                                             NewLoc;                                                  // 0x000C(0x000C)
		struct FVector                                             NewVel;                                                  // 0x0018(0x000C)
		class AActor*                                              NewBase;                                                 // 0x0024(0x0008)
		struct FVector                                             NewFloor;                                                // 0x002C(0x000C)
		unsigned char                                              bAckGoodMove;                                            // 0x0038(0x0001)
	};

	/**
	 * ScriptStruct Engine.PlayerController.InputEntry
	 * Size -> 0x000D
	 */
	struct FInputEntry
	{
	public:
		EInputTypes                                                Type;                                                    // 0x0000(0x0001)
		unsigned char                                              UnknownData_8ZXZ[0x3];                                   // 0x0001(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      Value;                                                   // 0x0004(0x0004)
		float                                                      TimeDelta;                                               // 0x0008(0x0004)
		EInputMatchAction                                          Action;                                                  // 0x000C(0x0001)
	};

	/**
	 * ScriptStruct Engine.PlayerController.InputMatchRequest
	 * Size -> 0x004C
	 */
	struct FInputMatchRequest
	{
	public:
		TArray<struct FInputEntry>                                 Inputs;                                                  // 0x0000(0x0010) NeedCtorLink
		class AActor*                                              MatchActor;                                              // 0x0010(0x0008)
		class FName                                                MatchFuncName;                                           // 0x0018(0x0008)
		class FScriptDelegate                                      MatchDelegate;                                           // 0x0020(0x000C) ELEMENT_SIZE_MISMATCH NeedCtorLink
		unsigned char                                              UnknownData_P0EZ[0x4];                                   // 0x002C(0x0004) FIX WRONG TYPE SIZE OF PREVIOUS PROPERTY
		class FName                                                FailedFuncName;                                          // 0x0030(0x0008)
		class FName                                                RequestName;                                             // 0x0038(0x0008)
		int32_t                                                    MatchIdx;                                                // 0x0040(0x0004) Transient
		struct FDouble                                             LastMatchTime;                                           // 0x0044(0x0008) Transient
	};

	/**
	 * ScriptStruct Engine.PlayerController.DebugTextInfo
	 * Size -> 0x0054
	 */
	struct FDebugTextInfo
	{
	public:
		class AActor*                                              SrcActor;                                                // 0x0000(0x0008)
		struct FVector                                             SrcActorOffset;                                          // 0x0008(0x000C)
		struct FVector                                             SrcActorDesiredOffset;                                   // 0x0014(0x000C)
		class FString                                              DebugText;                                               // 0x0020(0x0010) NeedCtorLink
		float                                                      TimeRemaining;                                           // 0x0030(0x0004) Transient
		float                                                      Duration;                                                // 0x0034(0x0004)
		struct FColor                                              TextColor;                                               // 0x0038(0x0004)
		unsigned long                                              bAbsoluteLocation : 1;                                   // 0x003C(0x0001) BIT_FIELD
		unsigned long                                              bKeepAttachedToActor : 1;                                // 0x003C(0x0001) BIT_FIELD
		struct FVector                                             OrigActorLocation;                                       // 0x0040(0x000C)
		class UFont*                                               Font;                                                    // 0x004C(0x0008)
	};

	/**
	 * ScriptStruct Engine.PlatformInterfaceBase.PlatformInterfaceData
	 * Size -> 0x002C
	 */
	struct FPlatformInterfaceData
	{
	public:
		class FName                                                DataName;                                                // 0x0000(0x0008)
		EPlatformInterfaceDataType                                 Type;                                                    // 0x0008(0x0001)
		unsigned char                                              UnknownData_7ZEJ[0x3];                                   // 0x0009(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    IntValue;                                                // 0x000C(0x0004)
		float                                                      FloatValue;                                              // 0x0010(0x0004)
		class FString                                              StringValue;                                             // 0x0014(0x0010) AlwaysInit, NeedCtorLink
		class UObject*                                             ObjectValue;                                             // 0x0024(0x0008)
	};

	/**
	 * ScriptStruct Engine.PlatformInterfaceBase.PlatformInterfaceDelegateResult
	 * Size -> 0x0030
	 */
	struct FPlatformInterfaceDelegateResult
	{
	public:
		unsigned long                                              bSuccessful : 1;                                         // 0x0000(0x0001) BIT_FIELD
		struct FPlatformInterfaceData                              Data;                                                    // 0x0004(0x002C) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.PlatformInterfaceBase.DelegateArray
	 * Size -> 0x0010
	 */
	struct FDelegateArray
	{
	public:
		TArray<class FScriptDelegate>                              Delegates;                                               // 0x0000(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.AppNotificationsBase.NotificationMessageInfo
	 * Size -> 0x0020
	 */
	struct FNotificationMessageInfo
	{
	public:
		class FString                                              Key;                                                     // 0x0000(0x0010) NeedCtorLink
		class FString                                              Value;                                                   // 0x0010(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.AppNotificationsBase.NotificationInfo
	 * Size -> 0x0028
	 */
	struct FNotificationInfo
	{
	public:
		unsigned long                                              bIsLocal : 1;                                            // 0x0000(0x0001) BIT_FIELD
		class FString                                              MessageBody;                                             // 0x0004(0x0010) NeedCtorLink
		int32_t                                                    BadgeNumber;                                             // 0x0014(0x0004)
		TArray<struct FNotificationMessageInfo>                    MessageInfo;                                             // 0x0018(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.AppNotificationsBase.LaunchNotificationInfo
	 * Size -> 0x002C
	 */
	struct FLaunchNotificationInfo
	{
	public:
		unsigned long                                              bWasLaunchedViaNotification : 1;                         // 0x0000(0x0001) BIT_FIELD
		struct FNotificationInfo                                   Notification;                                            // 0x0004(0x0028) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.CurveEdPresetCurve.PresetGeneratedPoint
	 * Size -> 0x0015
	 */
	struct FPresetGeneratedPoint
	{
	public:
		float                                                      KeyIn;                                                   // 0x0000(0x0004)
		float                                                      KeyOut;                                                  // 0x0004(0x0004)
		unsigned long                                              TangentsValid : 1;                                       // 0x0008(0x0001) BIT_FIELD
		float                                                      TangentIn;                                               // 0x000C(0x0004)
		float                                                      TangentOut;                                              // 0x0010(0x0004)
		EInterpCurveMode                                           IntepMode;                                               // 0x0014(0x0001)
	};

	/**
	 * ScriptStruct Engine.Font.FontCharacter
	 * Size -> 0x0018
	 */
	struct FFontCharacter
	{
	public:
		int32_t                                                    StartU;                                                  // 0x0000(0x0004) Edit
		int32_t                                                    StartV;                                                  // 0x0004(0x0004) Edit
		int32_t                                                    USize;                                                   // 0x0008(0x0004) Edit
		int32_t                                                    VSize;                                                   // 0x000C(0x0004) Edit
		unsigned char                                              TextureIndex;                                            // 0x0010(0x0001) Edit
		unsigned char                                              UnknownData_1RF5[0x3];                                   // 0x0011(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    VerticalOffset;                                          // 0x0014(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.Font.FontCharacterAddInfo
	 * Size -> 0x0008
	 */
	struct FFontCharacterAddInfo
	{
	public:
		int32_t                                                    HorizontalOffset;                                        // 0x0000(0x0004) Edit
		int32_t                                                    NextDrawHorizontalOffset;                                // 0x0004(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.FontImportOptions.FontImportOptionsData
	 * Size -> 0x00A8
	 */
	struct FFontImportOptionsData
	{
	public:
		class FString                                              FontName;                                                // 0x0000(0x0010) Edit, NeedCtorLink
		float                                                      Height;                                                  // 0x0010(0x0004) Edit
		unsigned long                                              bEnableAntialiasing : 1;                                 // 0x0014(0x0001) BIT_FIELD Edit
		unsigned long                                              bEnableBold : 1;                                         // 0x0014(0x0001) BIT_FIELD Edit
		unsigned long                                              bEnableItalic : 1;                                       // 0x0014(0x0001) BIT_FIELD Edit
		unsigned long                                              bEnableUnderline : 1;                                    // 0x0014(0x0001) BIT_FIELD Edit
		unsigned long                                              bAlphaOnly : 1;                                          // 0x0014(0x0001) BIT_FIELD Edit
		EFontImportCharacterSet                                    CharacterSet;                                            // 0x0018(0x0001) Edit
		unsigned char                                              UnknownData_QH2G[0x3];                                   // 0x0019(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class FString                                              Chars;                                                   // 0x001C(0x0010) Edit, NeedCtorLink
		class FString                                              UnicodeRange;                                            // 0x002C(0x0010) Edit, NeedCtorLink
		class FString                                              CharsFilePath;                                           // 0x003C(0x0010) Edit, NeedCtorLink
		class FString                                              CharsFileWildcard;                                       // 0x004C(0x0010) Edit, NeedCtorLink
		unsigned long                                              bCreatePrintableOnly : 1;                                // 0x005C(0x0001) BIT_FIELD Edit
		unsigned long                                              bIncludeASCIIRange : 1;                                  // 0x005C(0x0001) BIT_FIELD Edit
		struct FLinearColor                                        ForegroundColor;                                         // 0x0060(0x0010) Edit
		unsigned long                                              bEnableDropShadow : 1;                                   // 0x0070(0x0001) BIT_FIELD Edit
		int32_t                                                    TexturePageWidth;                                        // 0x0074(0x0004) Edit
		int32_t                                                    TexturePageMaxHeight;                                    // 0x0078(0x0004) Edit
		int32_t                                                    XPadding;                                                // 0x007C(0x0004) Edit
		int32_t                                                    YPadding;                                                // 0x0080(0x0004) Edit
		int32_t                                                    ExtendBoxTop;                                            // 0x0084(0x0004) Edit
		int32_t                                                    ExtendBoxBottom;                                         // 0x0088(0x0004) Edit
		int32_t                                                    ExtendBoxRight;                                          // 0x008C(0x0004) Edit
		int32_t                                                    ExtendBoxLeft;                                           // 0x0090(0x0004) Edit
		unsigned long                                              bEnableLegacyMode : 1;                                   // 0x0094(0x0001) BIT_FIELD Edit
		int32_t                                                    Kerning;                                                 // 0x0098(0x0004) Edit
		unsigned long                                              bUseDistanceFieldAlpha : 1;                              // 0x009C(0x0001) BIT_FIELD Edit
		int32_t                                                    DistanceFieldScaleFactor;                                // 0x00A0(0x0004) Edit
		float                                                      DistanceFieldScanRadiusScale;                            // 0x00A4(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.ForceFeedbackWaveform.WaveformSample
	 * Size -> 0x0008
	 */
	struct FWaveformSample
	{
	public:
		unsigned char                                              LeftAmplitude;                                           // 0x0000(0x0001) Edit
		unsigned char                                              RightAmplitude;                                          // 0x0001(0x0001) Edit
		EWaveformFunction                                          LeftFunction;                                            // 0x0002(0x0001) Edit
		EWaveformFunction                                          RightFunction;                                           // 0x0003(0x0001) Edit
		float                                                      Duration;                                                // 0x0004(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.GamePadLightbarSubsystem.ColorDefinition
	 * Size -> 0x0013
	 */
	struct FColorDefinition
	{
	public:
		class FString                                              Id;                                                      // 0x0000(0x0010) AlwaysInit, NeedCtorLink
		unsigned char                                              R;                                                       // 0x0010(0x0001)
		unsigned char                                              G;                                                       // 0x0011(0x0001)
		unsigned char                                              B;                                                       // 0x0012(0x0001)
	};

	/**
	 * ScriptStruct Engine.GamePadLightbarSubsystem.LerpToInstruction
	 * Size -> 0x0024
	 */
	struct FLerpToInstruction
	{
	public:
		class FString                                              Id;                                                      // 0x0000(0x0010) AlwaysInit, NeedCtorLink
		float                                                      Time;                                                    // 0x0010(0x0004)
		class FString                                              LerpToId;                                                // 0x0014(0x0010) AlwaysInit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.GamePadLightbarSubsystem.SetAndLerpInstruction
	 * Size -> 0x0010 (FullSize[0x0034] - InheritedSize[0x0024])
	 */
	struct FSetAndLerpInstruction : public FLerpToInstruction
	{
	public:
		class FString                                              LerpFromId;                                              // 0x0024(0x0010) AlwaysInit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.GamePadLightbarSubsystem.PulseInstruction
	 * Size -> 0x0000 (FullSize[0x0034] - InheritedSize[0x0034])
	 */
	struct FPulseInstruction : public FSetAndLerpInstruction
	{	};

	/**
	 * ScriptStruct Engine.GameplayEvents.GameplayEventsHeader
	 * Size -> 0x0030
	 */
	struct FGameplayEventsHeader
	{
	public:
		int32_t                                                    EngineVersion;                                           // 0x0000(0x0004) Const
		int32_t                                                    StatsWriterVersion;                                      // 0x0004(0x0004) Const
		int32_t                                                    StreamOffset;                                            // 0x0008(0x0004) Const
		int32_t                                                    AggregateOffset;                                         // 0x000C(0x0004) Const
		int32_t                                                    FooterOffset;                                            // 0x0010(0x0004) Const
		int32_t                                                    TotalStreamSize;                                         // 0x0014(0x0004) Const
		int32_t                                                    FileSize;                                                // 0x0018(0x0004) Const
		class FString                                              FilterClass;                                             // 0x001C(0x0010) NeedCtorLink
		int32_t                                                    Flags;                                                   // 0x002C(0x0004)
	};

	/**
	 * ScriptStruct Engine.GameplayEvents.GameSessionInformation
	 * Size -> 0x0090
	 */
	struct FGameSessionInformation
	{
	public:
		int32_t                                                    AppTitleID;                                              // 0x0000(0x0004)
		int32_t                                                    PlatformType;                                            // 0x0004(0x0004)
		class FString                                              Language;                                                // 0x0008(0x0010) NeedCtorLink
		class FString                                              GameplaySessionTimestamp;                                // 0x0018(0x0010) Const, NeedCtorLink
		struct FDouble                                             GameplaySessionStartTime;                                // 0x0028(0x0008) Const
		struct FDouble                                             GameplaySessionEndTime;                                  // 0x0030(0x0008) Const
		unsigned long                                              bGameplaySessionInProgress : 1;                          // 0x0038(0x0001) BIT_FIELD Const
		class FString                                              GameplaySessionID;                                       // 0x003C(0x0010) Const, NeedCtorLink
		class FString                                              GameClassName;                                           // 0x004C(0x0010) Const, NeedCtorLink
		class FString                                              MapName;                                                 // 0x005C(0x0010) Const, NeedCtorLink
		class FString                                              MapURL;                                                  // 0x006C(0x0010) Const, NeedCtorLink
		int32_t                                                    SessionInstance;                                         // 0x007C(0x0004) Const
		int32_t                                                    GameTypeId;                                              // 0x0080(0x0004) Const
		struct FUniqueNetId                                        OwningNetId;                                             // 0x0084(0x0008) Const
		int32_t                                                    PlaylistId;                                              // 0x008C(0x0004)
	};

	/**
	 * ScriptStruct Engine.GameplayEvents.PlayerInformation
	 * Size -> 0x0024
	 */
	struct FPlayerInformation
	{
	public:
		class FName                                                ControllerName;                                          // 0x0000(0x0008)
		class FString                                              PlayerName;                                              // 0x0008(0x0010) NeedCtorLink
		struct FUniqueNetId                                        UniqueId;                                                // 0x0018(0x0008)
		unsigned long                                              bIsBot : 1;                                              // 0x0020(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.GameplayEvents.TeamInformation
	 * Size -> 0x001C
	 */
	struct FTeamInformation
	{
	public:
		int32_t                                                    TeamIndex;                                               // 0x0000(0x0004)
		class FString                                              TeamName;                                                // 0x0004(0x0010) NeedCtorLink
		struct FColor                                              TeamColor;                                               // 0x0014(0x0004)
		int32_t                                                    MaxSize;                                                 // 0x0018(0x0004)
	};

	/**
	 * ScriptStruct Engine.GameplayEvents.GameStatGroup
	 * Size -> 0x0008
	 */
	struct FGameStatGroup
	{
	public:
		EGameStatGroups                                            Group;                                                   // 0x0000(0x0001)
		unsigned char                                              UnknownData_RHZO[0x3];                                   // 0x0001(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    Level;                                                   // 0x0004(0x0004)
	};

	/**
	 * ScriptStruct Engine.GameplayEvents.GameplayEventMetaData
	 * Size -> 0x0018
	 */
	struct FGameplayEventMetaData
	{
	public:
		int32_t                                                    EventID;                                                 // 0x0000(0x0004) Const
		class FName                                                EventName;                                               // 0x0004(0x0008) Const
		struct FGameStatGroup                                      StatGroup;                                               // 0x000C(0x0008) Const
		int32_t                                                    EventDataType;                                           // 0x0014(0x0004) Const
	};

	/**
	 * ScriptStruct Engine.GameplayEvents.WeaponClassEventData
	 * Size -> 0x0008
	 */
	struct FWeaponClassEventData
	{
	public:
		class FName                                                WeaponClassName;                                         // 0x0000(0x0008)
	};

	/**
	 * ScriptStruct Engine.GameplayEvents.DamageClassEventData
	 * Size -> 0x0008
	 */
	struct FDamageClassEventData
	{
	public:
		class FName                                                DamageClassName;                                         // 0x0000(0x0008)
	};

	/**
	 * ScriptStruct Engine.GameplayEvents.ProjectileClassEventData
	 * Size -> 0x0008
	 */
	struct FProjectileClassEventData
	{
	public:
		class FName                                                ProjectileClassName;                                     // 0x0000(0x0008)
	};

	/**
	 * ScriptStruct Engine.GameplayEvents.PawnClassEventData
	 * Size -> 0x0008
	 */
	struct FPawnClassEventData
	{
	public:
		class FName                                                PawnClassName;                                           // 0x0000(0x0008)
	};

	/**
	 * ScriptStruct Engine.IniLocPatcher.IniLocFileEntry
	 * Size -> 0x0035
	 */
	struct FIniLocFileEntry
	{
	public:
		class FString                                              Filename;                                                // 0x0000(0x0010) NeedCtorLink
		class FString                                              DLName;                                                  // 0x0010(0x0010) NeedCtorLink
		class FString                                              HashCode;                                                // 0x0020(0x0010) NeedCtorLink
		unsigned long                                              bIsUnicode : 1;                                          // 0x0030(0x0001) BIT_FIELD
		EOnlineEnumerationReadState                                ReadState;                                               // 0x0034(0x0001)
	};

	/**
	 * ScriptStruct Engine.InterpCurveEdSetup.CurveEdEntry
	 * Size -> 0x0034
	 */
	struct FCurveEdEntry
	{
	public:
		class UObject*                                             CurveObject;                                             // 0x0000(0x0008)
		struct FColor                                              CurveColor;                                              // 0x0008(0x0004)
		class FString                                              CurveName;                                               // 0x000C(0x0010) NeedCtorLink
		int32_t                                                    bHideCurve;                                              // 0x001C(0x0004)
		int32_t                                                    bColorCurve;                                             // 0x0020(0x0004)
		int32_t                                                    bFloatingPointColorCurve;                                // 0x0024(0x0004)
		int32_t                                                    bClamp;                                                  // 0x0028(0x0004)
		float                                                      ClampLow;                                                // 0x002C(0x0004)
		float                                                      ClampHigh;                                               // 0x0030(0x0004)
	};

	/**
	 * ScriptStruct Engine.InterpCurveEdSetup.CurveEdTab
	 * Size -> 0x0030
	 */
	struct FCurveEdTab
	{
	public:
		class FString                                              TabName;                                                 // 0x0000(0x0010) NeedCtorLink
		TArray<struct FCurveEdEntry>                               Curves;                                                  // 0x0010(0x0010) NeedCtorLink
		float                                                      ViewStartInput;                                          // 0x0020(0x0004)
		float                                                      ViewEndInput;                                            // 0x0024(0x0004)
		float                                                      ViewStartOutput;                                         // 0x0028(0x0004)
		float                                                      ViewEndOutput;                                           // 0x002C(0x0004)
	};

	/**
	 * ScriptStruct Engine.InterpTrack.SubTrackGroup
	 * Size -> 0x0024
	 */
	struct FSubTrackGroup
	{
	public:
		class FString                                              GroupName;                                               // 0x0000(0x0010) NeedCtorLink
		TArray<int32_t>                                            TrackIndices;                                            // 0x0010(0x0010) NeedCtorLink
		unsigned long                                              bIsCollapsed : 1;                                        // 0x0020(0x0001) BIT_FIELD
		unsigned long                                              bIsSelected : 1;                                         // 0x0020(0x0001) BIT_FIELD Transient
	};

	/**
	 * ScriptStruct Engine.InterpTrack.SupportedSubTrackInfo
	 * Size -> 0x001C
	 */
	struct FSupportedSubTrackInfo
	{
	public:
		class UClass*                                              SupportedClass;                                          // 0x0000(0x0008)
		class FString                                              SubTrackName;                                            // 0x0008(0x0010) NeedCtorLink
		int32_t                                                    GroupIndex;                                              // 0x0018(0x0004)
	};

	/**
	 * ScriptStruct Engine.LevelStreaming.RandomGenerateLevelGroupSetting
	 * Size -> 0x001C
	 */
	struct FRandomGenerateLevelGroupSetting
	{
	public:
		class FName                                                LevelName;                                               // 0x0000(0x0008) Edit
		int32_t                                                    mRelativeLocationX;                                      // 0x0008(0x0004) Edit
		int32_t                                                    mRelativeLocationRDLU;                                   // 0x000C(0x0004) Edit
		int32_t                                                    mRelativeLocationLDRU;                                   // 0x0010(0x0004) Edit
		int32_t                                                    mRelativeRotation;                                       // 0x0014(0x0004) Edit
		float                                                      mRelativeHeight;                                         // 0x0018(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.EngineTypes.LightmassPrimitiveSettings
	 * Size -> 0x001C
	 */
	struct FLightmassPrimitiveSettings
	{
	public:
		unsigned long                                              bUseTwoSidedLighting : 1;                                // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bShadowIndirectOnly : 1;                                 // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bUseEmissiveForStaticLighting : 1;                       // 0x0000(0x0001) BIT_FIELD Edit
		float                                                      EmissiveLightFalloffExponent;                            // 0x0004(0x0004) Edit
		float                                                      EmissiveLightExplicitInfluenceRadius;                    // 0x0008(0x0004) Edit
		float                                                      EmissiveBoost;                                           // 0x000C(0x0004) Edit
		float                                                      DiffuseBoost;                                            // 0x0010(0x0004) Edit
		float                                                      SpecularBoost;                                           // 0x0014(0x0004)
		float                                                      FullyOccludedSamplesFraction;                            // 0x0018(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.OnlineAuthInterface.BaseAuthSession
	 * Size -> 0x0010
	 */
	struct FBaseAuthSession
	{
	public:
		int32_t                                                    EndPointIP;                                              // 0x0000(0x0004) Const
		int32_t                                                    EndPointPort;                                            // 0x0004(0x0004) Const
		struct FUniqueNetId                                        EndPointUID;                                             // 0x0008(0x0008) Const
	};

	/**
	 * ScriptStruct Engine.OnlineAuthInterface.LocalAuthSession
	 * Size -> 0x0004 (FullSize[0x0014] - InheritedSize[0x0010])
	 */
	struct FLocalAuthSession : public FBaseAuthSession
	{
	public:
		int32_t                                                    SessionUID;                                              // 0x0010(0x0004) Const
	};

	/**
	 * ScriptStruct Engine.OnlineAuthInterface.AuthSession
	 * Size -> 0x0008 (FullSize[0x0018] - InheritedSize[0x0010])
	 */
	struct FAuthSession : public FBaseAuthSession
	{
	public:
		EAuthStatus                                                AuthStatus;                                              // 0x0010(0x0001) Const
		unsigned char                                              UnknownData_3JRE[0x3];                                   // 0x0011(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    AuthTicketUID;                                           // 0x0014(0x0004) Const
	};

	/**
	 * ScriptStruct Engine.OnlineMatchmakingStats.MMStats_Timer
	 * Size -> 0x000C
	 */
	struct FMMStats_Timer
	{
	public:
		unsigned long                                              bInProgress : 1;                                         // 0x0000(0x0001) BIT_FIELD
		struct FDouble                                             MSecs;                                                   // 0x0004(0x0008)
	};

	/**
	 * ScriptStruct Engine.OnlinePlayerStorage.OnlineProfileSetting
	 * Size -> 0x001C
	 */
	struct FOnlineProfileSetting
	{
	public:
		EOnlineProfilePropertyOwner                                Owner;                                                   // 0x0000(0x0001)
		unsigned char                                              UnknownData_8UZX[0x3];                                   // 0x0001(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct FSettingsProperty                                   ProfileSetting;                                          // 0x0004(0x0018)
	};

	/**
	 * ScriptStruct Engine.OnlineStatsRead.OnlineStatsColumn
	 * Size -> 0x0014
	 */
	struct FOnlineStatsColumn
	{
	public:
		int32_t                                                    ColumnNo;                                                // 0x0000(0x0004)
		struct FSettingsData                                       StatValue;                                               // 0x0004(0x0010)
	};

	/**
	 * ScriptStruct Engine.OnlineStatsRead.OnlineStatsRow
	 * Size -> 0x0048
	 */
	struct FOnlineStatsRow
	{
	public:
		struct FUniqueNetId                                        PlayerID;                                                // 0x0000(0x0008) Const
		struct FSettingsData                                       Rank;                                                    // 0x0008(0x0010) Const
		struct FSettingsData                                       Rating;                                                  // 0x0018(0x0010) Const
		class FString                                              NickName;                                                // 0x0028(0x0010) Const, NeedCtorLink
		TArray<struct FOnlineStatsColumn>                          Columns;                                                 // 0x0038(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineStatsRead.ColumnMetaData
	 * Size -> 0x001C
	 */
	struct FColumnMetaData
	{
	public:
		int32_t                                                    Id;                                                      // 0x0000(0x0004) Const
		class FName                                                Name;                                                    // 0x0004(0x0008) Const
		class FString                                              ColumnName;                                              // 0x000C(0x0010) Const, Localized, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.LocalPlayer.SynchronizedActorVisibilityHistory
	 * Size -> 0x0010
	 */
	struct FSynchronizedActorVisibilityHistory
	{
	public:
		struct FPointer                                            State;                                                   // 0x0000(0x0008)
		struct FPointer                                            CriticalSection;                                         // 0x0008(0x0008)
	};

	/**
	 * ScriptStruct Engine.LocalPlayer.CurrentPostProcessVolumeInfo
	 * Size -> 0x022C
	 */
	struct FCurrentPostProcessVolumeInfo
	{
	public:
		struct FPostProcessSettings                                LastSettings;                                            // 0x0000(0x0214) NeedCtorLink
		class APostProcessVolume*                                  LastVolumeUsed;                                          // 0x0214(0x0008)
		struct FDouble                                             BlendStartTime;                                          // 0x021C(0x0008)
		struct FDouble                                             LastBlendTime;                                           // 0x0224(0x0008)
	};

	/**
	 * ScriptStruct Engine.LocalPlayer.PostProcessSettingsOverride
	 * Size -> 0x0230
	 */
	struct FPostProcessSettingsOverride
	{
	public:
		struct FPostProcessSettings                                Settings;                                                // 0x0000(0x0214) NeedCtorLink
		unsigned long                                              bBlendingIn : 1;                                         // 0x0214(0x0001) BIT_FIELD
		unsigned long                                              bBlendingOut : 1;                                        // 0x0214(0x0001) BIT_FIELD
		float                                                      CurrentBlendInTime;                                      // 0x0218(0x0004)
		float                                                      CurrentBlendOutTime;                                     // 0x021C(0x0004)
		float                                                      BlendInDuration;                                         // 0x0220(0x0004)
		float                                                      BlendOutDuration;                                        // 0x0224(0x0004)
		struct FDouble                                             BlendStartTime;                                          // 0x0228(0x0008)
	};

	/**
	 * ScriptStruct Engine.GameViewportClient.ShowFlags_Mirror
	 * Size -> 0x0010
	 */
	struct FShowFlags_Mirror
	{
	public:
		struct FQWord                                              flags0;                                                  // 0x0000(0x0008) Const, Native
		struct FQWord                                              flags1;                                                  // 0x0008(0x0008) Const, Native
	};

	/**
	 * ScriptStruct Engine.GameViewportClient.ExportShowFlags_Mirror
	 * Size -> 0x0000 (FullSize[0x0010] - InheritedSize[0x0010])
	 */
	struct FExportShowFlags_Mirror : public FShowFlags_Mirror
	{	};

	/**
	 * ScriptStruct Engine.GameViewportClient.TitleSafeZoneArea
	 * Size -> 0x0010
	 */
	struct FTitleSafeZoneArea
	{
	public:
		float                                                      MaxPercentX;                                             // 0x0000(0x0004)
		float                                                      MaxPercentY;                                             // 0x0004(0x0004)
		float                                                      RecommendedPercentX;                                     // 0x0008(0x0004)
		float                                                      RecommendedPercentY;                                     // 0x000C(0x0004)
	};

	/**
	 * ScriptStruct Engine.GameViewportClient.PerPlayerSplitscreenData
	 * Size -> 0x0010
	 */
	struct FPerPlayerSplitscreenData
	{
	public:
		float                                                      SizeX;                                                   // 0x0000(0x0004)
		float                                                      SizeY;                                                   // 0x0004(0x0004)
		float                                                      OriginX;                                                 // 0x0008(0x0004)
		float                                                      OriginY;                                                 // 0x000C(0x0004)
	};

	/**
	 * ScriptStruct Engine.GameViewportClient.SplitscreenData
	 * Size -> 0x0010
	 */
	struct FSplitscreenData
	{
	public:
		TArray<struct FPerPlayerSplitscreenData>                   PlayerData;                                              // 0x0000(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.GameViewportClient.DebugDisplayProperty
	 * Size -> 0x0014
	 */
	struct FDebugDisplayProperty
	{
	public:
		class UObject*                                             Obj;                                                     // 0x0000(0x0008)
		class FName                                                PropertyName;                                            // 0x0008(0x0008)
		unsigned long                                              bSpecialProperty : 1;                                    // 0x0010(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.SpeechRecognition.RecognisableWord
	 * Size -> 0x0024
	 */
	struct FRecognisableWord
	{
	public:
		int32_t                                                    Id;                                                      // 0x0000(0x0004) Edit
		class FString                                              ReferenceWord;                                           // 0x0004(0x0010) Edit, NeedCtorLink
		class FString                                              PhoneticWord;                                            // 0x0014(0x0010) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.SpeechRecognition.RecogVocabulary
	 * Size -> 0x0060
	 */
	struct FRecogVocabulary
	{
	public:
		TArray<struct FRecognisableWord>                           WhoDictionary;                                           // 0x0000(0x0010) Edit, NeedCtorLink
		TArray<struct FRecognisableWord>                           WhatDictionary;                                          // 0x0010(0x0010) Edit, NeedCtorLink
		TArray<struct FRecognisableWord>                           WhereDictionary;                                         // 0x0020(0x0010) Edit, NeedCtorLink
		class FString                                              VocabName;                                               // 0x0030(0x0010) NeedCtorLink
		TArray<unsigned char>                                      VocabData;                                               // 0x0040(0x0010) NeedCtorLink
		TArray<unsigned char>                                      WorkingVocabData;                                        // 0x0050(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.SpeechRecognition.RecogUserData
	 * Size -> 0x0014
	 */
	struct FRecogUserData
	{
	public:
		int32_t                                                    ActiveVocabularies;                                      // 0x0000(0x0004)
		TArray<unsigned char>                                      UserData;                                                // 0x0004(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.StaticMesh.StaticMeshLODElement
	 * Size -> 0x0014
	 */
	struct FStaticMeshLODElement
	{
	public:
		unsigned char                                              UnknownData_J8BY[0x10];                                  // 0x0000(0x0010) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		unsigned long                                              bEnableCollision : 1;                                    // 0x0010(0x0001) BIT_FIELD Edit, Native
		unsigned long                                              UnknownData_MZRT : 31;                                   // 0x0010(0x0001) BIT_FIELD (PADDING)
		unsigned long                                              bEnableShadowCasting : 1;                                // 0x0008(0x0001) BIT_FIELD Edit, Native
		class UMaterialInterface*                                  Material;                                                // 0x0000(0x0008) Edit
		unsigned char                                              UnknownData_DS44[0xC];                                   // 0x0008(0x000C) MISSED OFFSET (PADDING)
	};

	/**
	 * ScriptStruct Engine.StaticMesh.StaticMeshLODInfo
	 * Size -> 0x0010
	 */
	struct FStaticMeshLODInfo
	{
	public:
		TArray<struct FStaticMeshLODElement>                       Elements;                                                // 0x0000(0x0010) Edit, EditFixedSize, Native
	};

	/**
	 * ScriptStruct Engine.MaterialInterface.LightmassMaterialInterfaceSettings
	 * Size -> 0x001C
	 */
	struct FLightmassMaterialInterfaceSettings
	{
	public:
		unsigned long                                              bCastShadowAsMasked : 1;                                 // 0x0000(0x0001) BIT_FIELD Edit
		float                                                      EmissiveBoost;                                           // 0x0004(0x0004) Edit
		float                                                      DiffuseBoost;                                            // 0x0008(0x0004) Edit
		float                                                      SpecularBoost;                                           // 0x000C(0x0004)
		float                                                      ExportResolutionScale;                                   // 0x0010(0x0004) Edit
		float                                                      DistanceFieldPenumbraScale;                              // 0x0014(0x0004) Edit
		unsigned long                                              bOverrideCastShadowAsMasked : 1;                         // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bOverrideEmissiveBoost : 1;                              // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bOverrideDiffuseBoost : 1;                               // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bOverrideSpecularBoost : 1;                              // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bOverrideExportResolutionScale : 1;                      // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bOverrideDistanceFieldPenumbraScale : 1;                 // 0x0018(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.RB_BodySetup.KCachedConvexDataElement
	 * Size -> 0x0010
	 */
	struct FKCachedConvexDataElement
	{
	public:
		TArray<unsigned char>                                      ConvexElementData;                                       // 0x0000(0x0010) Native
	};

	/**
	 * ScriptStruct Engine.RB_BodySetup.KCachedConvexData
	 * Size -> 0x0010
	 */
	struct FKCachedConvexData
	{
	public:
		TArray<struct FKCachedConvexDataElement>                   CachedConvexElements;                                    // 0x0000(0x0010) Native
	};

	/**
	 * ScriptStruct Engine.ParticleSystem.ParticleSystemLOD
	 * Size -> 0x0004
	 */
	struct FParticleSystemLOD
	{
	public:
		unsigned long                                              bLit : 1;                                                // 0x0000(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.ParticleSystem.LODSoloTrack
	 * Size -> 0x0010
	 */
	struct FLODSoloTrack
	{
	public:
		TArray<unsigned char>                                      SoloEnableSetting;                                       // 0x0000(0x0010) Transient, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.Texture2D.TextureLinkedListMirror
	 * Size -> 0x0018
	 */
	struct FTextureLinkedListMirror
	{
	public:
		struct FPointer                                            Element;                                                 // 0x0000(0x0008) Const, Native
		struct FPointer                                            Next;                                                    // 0x0008(0x0008) Const, Native
		struct FPointer                                            PrevLink;                                                // 0x0010(0x0008) Const, Native
	};

	/**
	 * ScriptStruct Engine.UIInteraction.UIKeyRepeatData
	 * Size -> 0x0010
	 */
	struct FUIKeyRepeatData
	{
	public:
		class FName                                                CurrentRepeatKey;                                        // 0x0000(0x0008) AlwaysInit
		struct FDouble                                             NextRepeatTime;                                          // 0x0008(0x0008) AlwaysInit
	};

	/**
	 * ScriptStruct Engine.UIInteraction.UIAxisEmulationData
	 * Size -> 0x0004 (FullSize[0x0014] - InheritedSize[0x0010])
	 */
	struct FUIAxisEmulationData : public FUIKeyRepeatData
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0010(0x0001) BIT_FIELD AlwaysInit
	};

	/**
	 * ScriptStruct Engine.UIRoot.UIAxisEmulationDefinition
	 * Size -> 0x0024
	 */
	struct FUIAxisEmulationDefinition
	{
	public:
		class FName                                                AxisInputKey;                                            // 0x0000(0x0008)
		class FName                                                AdjacentAxisInputKey;                                    // 0x0008(0x0008)
		unsigned long                                              bEmulateButtonPress : 1;                                 // 0x0010(0x0001) BIT_FIELD
		class FName                                                InputKeyToEmulate[0x2];                                  // 0x0014(0x0010)
	};

	/**
	 * ScriptStruct Engine.NavMeshObstacle.CheckpointRecord
	 * Size -> 0x0004
	 */
	struct ANavMeshObstacle_FCheckpointRecord
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.StaticMeshComponent.PaintedVertex
	 * Size -> 0x0014
	 */
	struct FPaintedVertex
	{
	public:
		struct FVector                                             Position;                                                // 0x0000(0x000C)
		struct FPackedNormal                                       Normal;                                                  // 0x000C(0x0004)
		struct FColor                                              Color;                                                   // 0x0010(0x0004)
	};

	/**
	 * ScriptStruct Engine.StaticMeshComponent.StaticMeshComponentLODInfo
	 * Size -> 0x0040
	 */
	struct FStaticMeshComponentLODInfo
	{
	public:
		TArray<class UShadowMap2D*>                                ShadowMaps;                                              // 0x0000(0x0010) Const, NeedCtorLink
		TArray<class UObject*>                                     ShadowVertexBuffers;                                     // 0x0010(0x0010) Const, NeedCtorLink
		struct FPointer                                            LightMap;                                                // 0x0020(0x0008) Const, Native
		struct FPointer                                            OverrideVertexColors;                                    // 0x0028(0x0008) Const, Native
		TArray<struct FPaintedVertex>                              PaintedVertices;                                         // 0x0030(0x0010) Const, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.CoverMeshComponent.CoverMeshes
	 * Size -> 0x0068
	 */
	struct FCoverMeshes
	{
	public:
		class UStaticMesh*                                         Base;                                                    // 0x0000(0x0008)
		class UStaticMesh*                                         LeanLeft;                                                // 0x0008(0x0008)
		class UStaticMesh*                                         LeanRight;                                               // 0x0010(0x0008)
		class UStaticMesh*                                         LeanLeftPref;                                            // 0x0018(0x0008)
		class UStaticMesh*                                         LeanRightPref;                                           // 0x0020(0x0008)
		class UStaticMesh*                                         Climb;                                                   // 0x0028(0x0008)
		class UStaticMesh*                                         Mantle;                                                  // 0x0030(0x0008)
		class UStaticMesh*                                         SlipLeft;                                                // 0x0038(0x0008)
		class UStaticMesh*                                         SlipRight;                                               // 0x0040(0x0008)
		class UStaticMesh*                                         SwatLeft;                                                // 0x0048(0x0008)
		class UStaticMesh*                                         SwatRight;                                               // 0x0050(0x0008)
		class UStaticMesh*                                         PopUp;                                                   // 0x0058(0x0008)
		class UStaticMesh*                                         PlayerOnly;                                              // 0x0060(0x0008)
	};

	/**
	 * ScriptStruct Engine.NavigationHandle.EdgePointer
	 * Size -> 0x0008
	 */
	struct FEdgePointer
	{
	public:
		struct FPointer                                            Dummy;                                                   // 0x0000(0x0008) Const, Native
	};

	/**
	 * ScriptStruct Engine.NavigationHandle.PathStore
	 * Size -> 0x0010
	 */
	struct FPathStore
	{
	public:
		TArray<struct FEdgePointer>                                EdgeList;                                                // 0x0000(0x0010) Native
	};

	/**
	 * ScriptStruct Engine.NavigationHandle.NavMeshPathParams
	 * Size -> 0x0034
	 */
	struct FNavMeshPathParams
	{
	public:
		struct FPointer                                            Interface;                                               // 0x0000(0x0008) Native
		unsigned long                                              bCanMantle : 1;                                          // 0x0008(0x0001) BIT_FIELD
		unsigned long                                              bNeedsMantleValidityTest : 1;                            // 0x0008(0x0001) BIT_FIELD
		unsigned long                                              bAbleToSearch : 1;                                       // 0x0008(0x0001) BIT_FIELD
		struct FVector                                             SearchExtent;                                            // 0x000C(0x000C)
		float                                                      SearchLaneMultiplier;                                    // 0x0018(0x0004)
		struct FVector                                             SearchStart;                                             // 0x001C(0x000C)
		float                                                      MaxDropHeight;                                           // 0x0028(0x0004)
		float                                                      MinWalkableZ;                                            // 0x002C(0x0004)
		float                                                      MaxHoverDistance;                                        // 0x0030(0x0004)
	};

	/**
	 * ScriptStruct Engine.NavMeshPathGoalEvaluator.BiasedGoalActor
	 * Size -> 0x000C
	 */
	struct FBiasedGoalActor
	{
	public:
		class AActor*                                              Goal;                                                    // 0x0000(0x0008)
		int32_t                                                    ExtraCost;                                               // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.SkeletalMeshActor.CheckpointRecord
	 * Size -> 0x004C
	 */
	struct ASkeletalMeshActor_FCheckpointRecord
	{
	public:
		unsigned long                                              bPlaying : 1;                                            // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bReplicated : 1;                                         // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bHidden : 1;                                             // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bSavedPosition : 1;                                      // 0x0000(0x0001) BIT_FIELD
		struct FVector                                             Location;                                                // 0x0004(0x000C)
		struct FRotator                                            Rotation;                                                // 0x0010(0x000C)
		class FString                                              ReplacedMaterial0_PathName;                              // 0x001C(0x0010) NeedCtorLink
		class FString                                              ReplacedMaterial1_PathName;                              // 0x002C(0x0010) NeedCtorLink
		class FString                                              ReplacedMesh_PathName;                                   // 0x003C(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.SkeletalMeshActor.SkelMeshActorControlTarget
	 * Size -> 0x0010
	 */
	struct FSkelMeshActorControlTarget
	{
	public:
		class FName                                                ControlName;                                             // 0x0000(0x0008) Edit
		class AActor*                                              TargetActor;                                             // 0x0008(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.SkeletalMeshActorBasedOnExtremeContent.SkelMaterialSetterDatum
	 * Size -> 0x000C
	 */
	struct FSkelMaterialSetterDatum
	{
	public:
		int32_t                                                    MaterialIndex;                                           // 0x0000(0x0004) Edit
		class UMaterialInterface*                                  TheMaterial;                                             // 0x0004(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.Actor.AnimSlotInfo
	 * Size -> 0x0018
	 */
	struct FAnimSlotInfo
	{
	public:
		class FName                                                SlotName;                                                // 0x0000(0x0008) AlwaysInit
		TArray<float>                                              ChannelWeights;                                          // 0x0008(0x0010) AlwaysInit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.AnimSequence.AnimNotifyEvent
	 * Size -> 0x0018
	 */
	struct FAnimNotifyEvent
	{
	public:
		float                                                      Time;                                                    // 0x0000(0x0004) Edit
		class UAnimNotify*                                         Notify;                                                  // 0x0004(0x0008) Edit, ExportObject, NeedCtorLink, EditInline
		class FName                                                Comment;                                                 // 0x000C(0x0008) Edit, EditorOnly
		float                                                      Duration;                                                // 0x0014(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.AnimSequence.TimeModifier
	 * Size -> 0x0008
	 */
	struct FTimeModifier
	{
	public:
		float                                                      Time;                                                    // 0x0000(0x0004) Edit
		float                                                      TargetStrength;                                          // 0x0004(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.AnimSequence.SkelControlModifier
	 * Size -> 0x0018
	 */
	struct FSkelControlModifier
	{
	public:
		class FName                                                SkelControlName;                                         // 0x0000(0x0008) Edit
		TArray<struct FTimeModifier>                               Modifiers;                                               // 0x0008(0x0010) Edit, NeedCtorLink, EditInline
	};

	/**
	 * ScriptStruct Engine.AnimSequence.RawAnimSequenceTrack
	 * Size -> 0x0020
	 */
	struct FRawAnimSequenceTrack
	{
	public:
		TArray<struct FVector>                                     PosKeys;                                                 // 0x0000(0x0010) NeedCtorLink
		TArray<struct FQuat>                                       RotKeys;                                                 // 0x0010(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.AnimSequence.TranslationTrack
	 * Size -> 0x0020
	 */
	struct FTranslationTrack
	{
	public:
		TArray<struct FVector>                                     PosKeys;                                                 // 0x0000(0x0010) NeedCtorLink
		TArray<float>                                              Times;                                                   // 0x0010(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.AnimSequence.RotationTrack
	 * Size -> 0x0020
	 */
	struct FRotationTrack
	{
	public:
		TArray<struct FQuat>                                       RotKeys;                                                 // 0x0000(0x0010) NeedCtorLink
		TArray<float>                                              Times;                                                   // 0x0010(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.AnimSequence.CurveTrack
	 * Size -> 0x0018
	 */
	struct FCurveTrack
	{
	public:
		class FName                                                CurveName;                                               // 0x0000(0x0008)
		TArray<float>                                              CurveWeights;                                            // 0x0008(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.EngineTypes.RootMotionCurve
	 * Size -> 0x0020
	 */
	struct FRootMotionCurve
	{
	public:
		class FName                                                AnimName;                                                // 0x0000(0x0008) Edit
		struct FInterpCurveVector                                  Curve;                                                   // 0x0008(0x0014) Edit, NeedCtorLink
		float                                                      MaxCurveTime;                                            // 0x001C(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.Pawn.ScalarParameterInterpStruct
	 * Size -> 0x0014
	 */
	struct FScalarParameterInterpStruct
	{
	public:
		class FName                                                ParameterName;                                           // 0x0000(0x0008) Edit
		float                                                      ParameterValue;                                          // 0x0008(0x0004) Edit
		float                                                      InterpTime;                                              // 0x000C(0x0004) Edit
		float                                                      WarmupTime;                                              // 0x0010(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.AnimNotify_Trails.TrailSocketSamplePoint
	 * Size -> 0x0018
	 */
	struct FTrailSocketSamplePoint
	{
	public:
		struct FVector                                             Position;                                                // 0x0000(0x000C)
		struct FVector                                             Velocity;                                                // 0x000C(0x000C)
	};

	/**
	 * ScriptStruct Engine.AnimNotify_Trails.TrailSamplePoint
	 * Size -> 0x004C
	 */
	struct FTrailSamplePoint
	{
	public:
		float                                                      RelativeTime;                                            // 0x0000(0x0004)
		struct FTrailSocketSamplePoint                             FirstEdgeSample;                                         // 0x0004(0x0018)
		struct FTrailSocketSamplePoint                             ControlPointSample;                                      // 0x001C(0x0018)
		struct FTrailSocketSamplePoint                             SecondEdgeSample;                                        // 0x0034(0x0018)
	};

	/**
	 * ScriptStruct Engine.AnimNotify_Trails.TrailSample
	 * Size -> 0x0028
	 */
	struct FTrailSample
	{
	public:
		float                                                      RelativeTime;                                            // 0x0000(0x0004)
		struct FVector                                             FirstEdgeSample;                                         // 0x0004(0x000C)
		struct FVector                                             ControlPointSample;                                      // 0x0010(0x000C)
		struct FVector                                             SecondEdgeSample;                                        // 0x001C(0x000C)
	};

	/**
	 * ScriptStruct Engine.AnimNode.CurveKey
	 * Size -> 0x000C
	 */
	struct FCurveKey
	{
	public:
		class FName                                                CurveName;                                               // 0x0000(0x0008)
		float                                                      Weight;                                                  // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.AnimNodeBlendBase.AnimBlendChild
	 * Size -> 0x0020
	 */
	struct FAnimBlendChild
	{
	public:
		class FName                                                Name;                                                    // 0x0000(0x0008) Edit
		class UAnimNode*                                           Anim;                                                    // 0x0008(0x0008) ExportObject, NeedCtorLink, EditInline
		float                                                      Weight;                                                  // 0x0010(0x0004)
		float                                                      BlendWeight;                                             // 0x0014(0x0004) Const, Transient
		unsigned long                                              bMirrorSkeleton : 1;                                     // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bIsAdditive : 1;                                         // 0x0018(0x0001) BIT_FIELD
		int32_t                                                    DrawY;                                                   // 0x001C(0x0004) EditorOnly
	};

	/**
	 * ScriptStruct Engine.AnimNode_MultiBlendPerBone.BranchInfo
	 * Size -> 0x000C
	 */
	struct FBranchInfo
	{
	public:
		class FName                                                BoneName;                                                // 0x0000(0x0008) Edit
		float                                                      PerBoneWeightIncrease;                                   // 0x0008(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.AnimNode_MultiBlendPerBone.WeightNodeRule
	 * Size -> 0x0020
	 */
	struct FWeightNodeRule
	{
	public:
		class FName                                                NodeName;                                                // 0x0000(0x0008) Edit
		class UAnimNodeBlendBase*                                  CachedNode;                                              // 0x0008(0x0008)
		class UAnimNodeSlot*                                       CachedSlotNode;                                          // 0x0010(0x0008)
		EWeightCheck                                               WeightCheck;                                             // 0x0018(0x0001) Edit
		unsigned char                                              UnknownData_UEX3[0x3];                                   // 0x0019(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    ChildIndex;                                              // 0x001C(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.AnimNode_MultiBlendPerBone.WeightRule
	 * Size -> 0x0040
	 */
	struct FWeightRule
	{
	public:
		struct FWeightNodeRule                                     FirstNode;                                               // 0x0000(0x0020) Edit
		struct FWeightNodeRule                                     SecondNode;                                              // 0x0020(0x0020) Edit
	};

	/**
	 * ScriptStruct Engine.AnimNode_MultiBlendPerBone.PerBoneMaskInfo
	 * Size -> 0x0050
	 */
	struct FPerBoneMaskInfo
	{
	public:
		TArray<struct FBranchInfo>                                 BranchList;                                              // 0x0000(0x0010) Edit, NeedCtorLink
		float                                                      DesiredWeight;                                           // 0x0010(0x0004) Edit
		float                                                      BlendTimeToGo;                                           // 0x0014(0x0004) Edit
		TArray<struct FWeightRule>                                 WeightRuleList;                                          // 0x0018(0x0010) Edit, NeedCtorLink
		unsigned long                                              bWeightBasedOnNodeRules : 1;                             // 0x0028(0x0001) BIT_FIELD Edit
		unsigned long                                              bDisableForNonLocalHumanPlayers : 1;                     // 0x0028(0x0001) BIT_FIELD Edit
		unsigned long                                              bPendingBlend : 1;                                       // 0x0028(0x0001) BIT_FIELD Transient
		TArray<float>                                              PerBoneWeights;                                          // 0x002C(0x0010) Transient, NeedCtorLink
		TArray<unsigned char>                                      TransformReqBone;                                        // 0x003C(0x0010) Transient, NeedCtorLink
		int32_t                                                    TransformReqBoneIndex;                                   // 0x004C(0x0004) Transient
	};

	/**
	 * ScriptStruct Engine.AnimNodeAimOffset.AimTransform
	 * Size -> 0x001C
	 */
	struct FAimTransform
	{
	public:
		struct FQuat                                               Quaternion;                                              // 0x0000(0x0010) Edit
		struct FVector                                             Translation;                                             // 0x0010(0x000C) Edit
	};

	/**
	 * ScriptStruct Engine.AnimNodeAimOffset.AimComponent
	 * Size -> 0x0130
	 */
	struct FAimComponent
	{
	public:
		class FName                                                BoneName;                                                // 0x0000(0x0008) Edit
		unsigned char                                              UnknownData_7DIG[0x8];                                   // 0x0008(0x0008) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct FAimTransform                                       LU;                                                      // 0x0010(0x0020) Edit
		struct FAimTransform                                       LC;                                                      // 0x0030(0x0020) Edit
		struct FAimTransform                                       LD;                                                      // 0x0050(0x0020) Edit
		struct FAimTransform                                       CU;                                                      // 0x0070(0x0020) Edit
		struct FAimTransform                                       CC;                                                      // 0x0090(0x0020) Edit
		struct FAimTransform                                       CD;                                                      // 0x00B0(0x0020) Edit
		struct FAimTransform                                       RU;                                                      // 0x00D0(0x0020) Edit
		struct FAimTransform                                       RC;                                                      // 0x00F0(0x0020) Edit
		struct FAimTransform                                       RD;                                                      // 0x0110(0x0020) Edit
	};

	/**
	 * ScriptStruct Engine.AnimNodeAimOffset.AimOffsetProfile
	 * Size -> 0x0070
	 */
	struct FAimOffsetProfile
	{
	public:
		class FName                                                ProfileName;                                             // 0x0000(0x0008) Edit, Const, EditConst
		struct FVector2D                                           HorizontalRange;                                         // 0x0008(0x0008) Edit
		struct FVector2D                                           VerticalRange;                                           // 0x0010(0x0008) Edit
		TArray<struct FAimComponent>                               AimComponents;                                           // 0x0018(0x0010) NeedCtorLink
		class FName                                                AnimName_LU;                                             // 0x0028(0x0008) Edit
		class FName                                                AnimName_LC;                                             // 0x0030(0x0008) Edit
		class FName                                                AnimName_LD;                                             // 0x0038(0x0008) Edit
		class FName                                                AnimName_CU;                                             // 0x0040(0x0008) Edit
		class FName                                                AnimName_CC;                                             // 0x0048(0x0008) Edit
		class FName                                                AnimName_CD;                                             // 0x0050(0x0008) Edit
		class FName                                                AnimName_RU;                                             // 0x0058(0x0008) Edit
		class FName                                                AnimName_RC;                                             // 0x0060(0x0008) Edit
		class FName                                                AnimName_RD;                                             // 0x0068(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.AnimNodeRandom.RandomAnimInfo
	 * Size -> 0x0020
	 */
	struct FRandomAnimInfo
	{
	public:
		float                                                      Chance;                                                  // 0x0000(0x0004) Edit
		unsigned char                                              LoopCountMin;                                            // 0x0004(0x0001) Edit
		unsigned char                                              LoopCountMax;                                            // 0x0005(0x0001) Edit
		unsigned char                                              UnknownData_028M[0x2];                                   // 0x0006(0x0002) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      BlendInTime;                                             // 0x0008(0x0004) Edit
		struct FVector2D                                           PlayRateRange;                                           // 0x000C(0x0008) Edit
		unsigned long                                              bStillFrame : 1;                                         // 0x0014(0x0001) BIT_FIELD Edit
		unsigned char                                              LoopCount;                                               // 0x0018(0x0001) Transient
		unsigned char                                              UnknownData_VU5P[0x3];                                   // 0x0019(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      LastPosition;                                            // 0x001C(0x0004) Transient
	};

	/**
	 * ScriptStruct Engine.AnimNodeBlendMultiBone.ChildBoneBlendInfo
	 * Size -> 0x0038
	 */
	struct FChildBoneBlendInfo
	{
	public:
		TArray<float>                                              TargetPerBoneWeight;                                     // 0x0000(0x0010) NeedCtorLink
		class FName                                                InitTargetStartBone;                                     // 0x0010(0x0008) Edit
		float                                                      InitPerBoneIncrease;                                     // 0x0018(0x0004) Edit
		class FName                                                OldStartBone;                                            // 0x001C(0x0008) Const
		float                                                      OldBoneIncrease;                                         // 0x0024(0x0004) Const
		TArray<unsigned char>                                      TargetRequiredBones;                                     // 0x0028(0x0010) Transient, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.AnimNodeSynch.SynchGroup
	 * Size -> 0x0028
	 */
	struct FSynchGroup
	{
	public:
		TArray<class UAnimNodeSequence*>                           SeqNodes;                                                // 0x0000(0x0010) NeedCtorLink
		class UAnimNodeSequence*                                   MasterNode;                                              // 0x0010(0x0008) Transient
		class FName                                                GroupName;                                               // 0x0018(0x0008) Edit
		unsigned long                                              bFireSlaveNotifies : 1;                                  // 0x0020(0x0001) BIT_FIELD Edit
		float                                                      RateScale;                                               // 0x0024(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.AnimTree.AnimGroup
	 * Size -> 0x0030
	 */
	struct FAnimGroup
	{
	public:
		TArray<class UAnimNodeSequence*>                           SeqNodes;                                                // 0x0000(0x0010) Const, Transient, NeedCtorLink
		class UAnimNodeSequence*                                   SynchMaster;                                             // 0x0010(0x0008) Const, Transient
		class UAnimNodeSequence*                                   NotifyMaster;                                            // 0x0018(0x0008) Const, Transient
		class FName                                                GroupName;                                               // 0x0020(0x0008) Edit, Const
		float                                                      RateScale;                                               // 0x0028(0x0004) Edit, Const
		float                                                      SynchPctPosition;                                        // 0x002C(0x0004) Const
	};

	/**
	 * ScriptStruct Engine.AnimTree.SkelControlListHead
	 * Size -> 0x0014
	 */
	struct FSkelControlListHead
	{
	public:
		class FName                                                BoneName;                                                // 0x0000(0x0008)
		class USkelControlBase*                                    ControlHead;                                             // 0x0008(0x0008) ExportObject, NeedCtorLink, EditInline
		int32_t                                                    DrawY;                                                   // 0x0010(0x0004) EditorOnly
	};

	/**
	 * ScriptStruct Engine.AnimTree.PreviewSkelMeshStruct
	 * Size -> 0x0020
	 */
	struct FPreviewSkelMeshStruct
	{
	public:
		class FName                                                DisplayName;                                             // 0x0000(0x0008) Edit
		class USkeletalMesh*                                       PreviewSkelMesh;                                         // 0x0008(0x0008) Edit
		TArray<class UMorphTargetSet*>                             PreviewMorphSets;                                        // 0x0010(0x0010) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.AnimTree.PreviewSocketStruct
	 * Size -> 0x0020
	 */
	struct FPreviewSocketStruct
	{
	public:
		class FName                                                DisplayName;                                             // 0x0000(0x0008) Edit
		class FName                                                SocketName;                                              // 0x0008(0x0008) Edit
		class USkeletalMesh*                                       PreviewSkelMesh;                                         // 0x0010(0x0008) Edit
		class UStaticMesh*                                         PreviewStaticMesh;                                       // 0x0018(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.AnimTree.PreviewAnimSetsStruct
	 * Size -> 0x0018
	 */
	struct FPreviewAnimSetsStruct
	{
	public:
		class FName                                                DisplayName;                                             // 0x0000(0x0008) Edit
		TArray<class UAnimSet*>                                    PreviewAnimSets;                                         // 0x0008(0x0010) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.AnimNodeSequenceBlendBase.AnimInfo
	 * Size -> 0x0014
	 */
	struct FAnimInfo
	{
	public:
		class FName                                                AnimSeqName;                                             // 0x0000(0x0008) Const
		class UAnimSequence*                                       AnimSeq;                                                 // 0x0008(0x0008) Const, Transient
		int32_t                                                    AnimLinkupIndex;                                         // 0x0010(0x0004) Const, Transient
	};

	/**
	 * ScriptStruct Engine.AnimNodeSequenceBlendBase.AnimBlendInfo
	 * Size -> 0x0020
	 */
	struct FAnimBlendInfo
	{
	public:
		class FName                                                AnimName;                                                // 0x0000(0x0008) Edit
		struct FAnimInfo                                           AnimInfo;                                                // 0x0008(0x0014)
		float                                                      Weight;                                                  // 0x001C(0x0004) Transient
	};

	/**
	 * ScriptStruct Engine.MorphNodeWeightBase.MorphNodeConn
	 * Size -> 0x001C
	 */
	struct FMorphNodeConn
	{
	public:
		TArray<class UMorphNodeBase*>                              ChildNodes;                                              // 0x0000(0x0010) NeedCtorLink
		class FName                                                ConnName;                                                // 0x0010(0x0008)
		int32_t                                                    DrawY;                                                   // 0x0018(0x0004)
	};

	/**
	 * ScriptStruct Engine.MorphNodeWeightByBoneAngle.BoneAngleMorph
	 * Size -> 0x0008
	 */
	struct FBoneAngleMorph
	{
	public:
		float                                                      Angle;                                                   // 0x0000(0x0004) Edit
		float                                                      TargetWeight;                                            // 0x0004(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.AnimSet.AnimSetMeshLinkup
	 * Size -> 0x0010
	 */
	struct FAnimSetMeshLinkup
	{
	public:
		TArray<int32_t>                                            BoneToTrackTable;                                        // 0x0000(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.DecalManager.ActiveDecalInfo
	 * Size -> 0x000C
	 */
	struct FActiveDecalInfo
	{
	public:
		class UDecalComponent*                                     Decal;                                                   // 0x0000(0x0008) ExportObject, Component, EditInline
		float                                                      LifetimeRemaining;                                       // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.DecalComponent.DecalReceiver
	 * Size -> 0x0010
	 */
	struct FDecalReceiver
	{
	public:
		class UPrimitiveComponent*                                 Component;                                               // 0x0000(0x0008) Const, ExportObject, Component, EditInline
		struct FPointer                                            RenderData;                                              // 0x0008(0x0008) Const, Native
	};

	/**
	 * ScriptStruct Engine.Material.MaterialInput
	 * Size -> 0x0034
	 */
	struct FMaterialInput
	{
	public:
		class UMaterialExpression*                                 Expression;                                              // 0x0000(0x0008)
		int32_t                                                    OutputIndex;                                             // 0x0008(0x0004)
		class FString                                              InputName;                                               // 0x000C(0x0010) NeedCtorLink
		int32_t                                                    Mask;                                                    // 0x001C(0x0004)
		int32_t                                                    MaskR;                                                   // 0x0020(0x0004)
		int32_t                                                    MaskG;                                                   // 0x0024(0x0004)
		int32_t                                                    MaskB;                                                   // 0x0028(0x0004)
		int32_t                                                    MaskA;                                                   // 0x002C(0x0004)
		int32_t                                                    GCC64_Padding;                                           // 0x0030(0x0004)
	};

	/**
	 * ScriptStruct Engine.Material.ColorMaterialInput
	 * Size -> 0x0008 (FullSize[0x003C] - InheritedSize[0x0034])
	 */
	struct FColorMaterialInput : public FMaterialInput
	{
	public:
		unsigned long                                              UseConstant : 1;                                         // 0x0034(0x0001) BIT_FIELD
		struct FColor                                              Constant;                                                // 0x0038(0x0004)
	};

	/**
	 * ScriptStruct Engine.Material.ScalarMaterialInput
	 * Size -> 0x0008 (FullSize[0x003C] - InheritedSize[0x0034])
	 */
	struct FScalarMaterialInput : public FMaterialInput
	{
	public:
		unsigned long                                              UseConstant : 1;                                         // 0x0034(0x0001) BIT_FIELD
		float                                                      Constant;                                                // 0x0038(0x0004)
	};

	/**
	 * ScriptStruct Engine.Material.VectorMaterialInput
	 * Size -> 0x0010 (FullSize[0x0044] - InheritedSize[0x0034])
	 */
	struct FVectorMaterialInput : public FMaterialInput
	{
	public:
		unsigned long                                              UseConstant : 1;                                         // 0x0034(0x0001) BIT_FIELD
		struct FVector                                             Constant;                                                // 0x0038(0x000C)
	};

	/**
	 * ScriptStruct Engine.Material.Vector2MaterialInput
	 * Size -> 0x000C (FullSize[0x0040] - InheritedSize[0x0034])
	 */
	struct FVector2MaterialInput : public FMaterialInput
	{
	public:
		unsigned long                                              UseConstant : 1;                                         // 0x0034(0x0001) BIT_FIELD
		float                                                      ConstantX;                                               // 0x0038(0x0004)
		float                                                      ConstantY;                                               // 0x003C(0x0004)
	};

	/**
	 * ScriptStruct Engine.Material.MaterialFunctionInfo
	 * Size -> 0x0018
	 */
	struct FMaterialFunctionInfo
	{
	public:
		struct FGuid                                               StateId;                                                 // 0x0000(0x0010)
		class UMaterialFunction*                                   Function;                                                // 0x0010(0x0008)
	};

	/**
	 * ScriptStruct Engine.FogVolumeDensityInfo.CheckpointRecord
	 * Size -> 0x0004
	 */
	struct AFogVolumeDensityInfo_FCheckpointRecord
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.FracturedStaticMeshActor.CheckpointRecord
	 * Size -> 0x0014
	 */
	struct AFracturedStaticMeshActor_FCheckpointRecord
	{
	public:
		unsigned long                                              bIsShutdown : 1;                                         // 0x0000(0x0001) BIT_FIELD
		TArray<unsigned char>                                      FragmentVis;                                             // 0x0004(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.FracturedStaticMeshActor.DeferredPartToSpawn
	 * Size -> 0x0024
	 */
	struct FDeferredPartToSpawn
	{
	public:
		int32_t                                                    ChunkIndex;                                              // 0x0000(0x0004)
		struct FVector                                             InitialVel;                                              // 0x0004(0x000C)
		struct FVector                                             InitialAngVel;                                           // 0x0010(0x000C)
		float                                                      RelativeScale;                                           // 0x001C(0x0004)
		unsigned long                                              bExplosion : 1;                                          // 0x0020(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.Actor.PhysEffectInfo
	 * Size -> 0x0018
	 */
	struct FPhysEffectInfo
	{
	public:
		float                                                      Threshold;                                               // 0x0000(0x0004) Edit
		float                                                      ReFireDelay;                                             // 0x0004(0x0004) Edit
		class UParticleSystem*                                     Effect;                                                  // 0x0008(0x0008) Edit
		class USoundCue*                                           Sound;                                                   // 0x0010(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.ImageReflection.GHM_ImageReflection_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_ImageReflection_CheckpointRecord
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.ImageReflectionShadowPlane.GHM_ImageReflectionShadowPlane_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_ImageReflectionShadowPlane_CheckpointRecord
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.FracturedStaticMeshComponent.FragmentGroup
	 * Size -> 0x0014
	 */
	struct FFragmentGroup
	{
	public:
		TArray<int32_t>                                            FragmentIndices;                                         // 0x0000(0x0010) NeedCtorLink
		unsigned long                                              bGroupIsRooted : 1;                                      // 0x0010(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.InstancedStaticMeshComponent.InstancedStaticMeshInstanceData
	 * Size -> 0x0050
	 */
	struct FInstancedStaticMeshInstanceData
	{
	public:
		struct FMatrix                                             Transform;                                               // 0x0000(0x0040)
		struct FVector2D                                           LightmapUVBias;                                          // 0x0040(0x0008)
		struct FVector2D                                           ShadowmapUVBias;                                         // 0x0048(0x0008)
	};

	/**
	 * ScriptStruct Engine.InstancedStaticMeshComponent.InstancedStaticMeshMappingInfo
	 * Size -> 0x0020
	 */
	struct FInstancedStaticMeshMappingInfo
	{
	public:
		struct FPointer                                            Mapping;                                                 // 0x0000(0x0008) Native
		struct FPointer                                            LightMap;                                                // 0x0008(0x0008) Native
		class UTexture2D*                                          LightmapTexture;                                         // 0x0010(0x0008)
		class UShadowMap2D*                                        ShadowmapTexture;                                        // 0x0018(0x0008)
	};

	/**
	 * ScriptStruct Engine.SplineMeshComponent.SplineMeshParams
	 * Size -> 0x0058
	 */
	struct FSplineMeshParams
	{
	public:
		struct FVector                                             StartPos;                                                // 0x0000(0x000C)
		struct FVector                                             StartTangent;                                            // 0x000C(0x000C)
		struct FVector2D                                           StartScale;                                              // 0x0018(0x0008)
		float                                                      StartRoll;                                               // 0x0020(0x0004)
		struct FVector2D                                           StartOffset;                                             // 0x0024(0x0008)
		struct FVector                                             EndPos;                                                  // 0x002C(0x000C)
		struct FVector                                             EndTangent;                                              // 0x0038(0x000C)
		struct FVector2D                                           EndScale;                                                // 0x0044(0x0008)
		float                                                      EndRoll;                                                 // 0x004C(0x0004)
		struct FVector2D                                           EndOffset;                                               // 0x0050(0x0008)
	};

	/**
	 * ScriptStruct Engine.ApexClothingAsset.ClothingLodInfo
	 * Size -> 0x0010
	 */
	struct FClothingLodInfo
	{
	public:
		TArray<int32_t>                                            LODMaterialMap;                                          // 0x0000(0x0010) Edit, Const, EditFixedSize, AlwaysInit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.ApexDestructibleAsset.NxDestructibleDamageParameters
	 * Size -> 0x0014
	 */
	struct FNxDestructibleDamageParameters
	{
	public:
		float                                                      DamageThreshold;                                         // 0x0000(0x0004) Edit
		float                                                      DamageSpread;                                            // 0x0004(0x0004) Edit
		float                                                      ImpactDamage;                                            // 0x0008(0x0004) Edit
		float                                                      ImpactResistance;                                        // 0x000C(0x0004) Edit
		int32_t                                                    DefaultImpactDamageDepth;                                // 0x0010(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.ApexDestructibleAsset.NxDestructibleDebrisParameters
	 * Size -> 0x002C
	 */
	struct FNxDestructibleDebrisParameters
	{
	public:
		float                                                      DebrisLifetimeMin;                                       // 0x0000(0x0004) Edit
		float                                                      DebrisLifetimeMax;                                       // 0x0004(0x0004) Edit
		float                                                      DebrisMaxSeparationMin;                                  // 0x0008(0x0004) Edit
		float                                                      DebrisMaxSeparationMax;                                  // 0x000C(0x0004) Edit
		struct FBox                                                ValidBounds;                                             // 0x0010(0x001C) Edit
	};

	/**
	 * ScriptStruct Engine.ApexDestructibleAsset.NxDestructibleAdvancedParameters
	 * Size -> 0x0018
	 */
	struct FNxDestructibleAdvancedParameters
	{
	public:
		float                                                      DamageCap;                                               // 0x0000(0x0004) Edit
		float                                                      ImpactVelocityThreshold;                                 // 0x0004(0x0004) Edit
		float                                                      MaxChunkSpeed;                                           // 0x0008(0x0004) Edit
		float                                                      MassScaleExponent;                                       // 0x000C(0x0004) Edit
		float                                                      MassScale;                                               // 0x0010(0x0004) Edit
		float                                                      FractureImpulseScale;                                    // 0x0014(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.ApexDestructibleAsset.NxDestructibleParametersFlag
	 * Size -> 0x0004
	 */
	struct FNxDestructibleParametersFlag
	{
	public:
		unsigned long                                              ACCUMULATE_DAMAGE : 1;                                   // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              ASSET_DEFINED_SUPPORT : 1;                               // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              WORLD_SUPPORT : 1;                                       // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              DEBRIS_TIMEOUT : 1;                                      // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              DEBRIS_MAX_SEPARATION : 1;                               // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              CRUMBLE_SMALLEST_CHUNKS : 1;                             // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              ACCURATE_RAYCASTS : 1;                                   // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              USE_VALID_BOUNDS : 1;                                    // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              FORM_EXTENDED_STRUCTURES : 1;                            // 0x0000(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.ApexDestructibleAsset.NxDestructibleDepthParameters
	 * Size -> 0x0005
	 */
	struct FNxDestructibleDepthParameters
	{
	public:
		unsigned long                                              TAKE_IMPACT_DAMAGE : 1;                                  // 0x0000(0x0001) BIT_FIELD Deprecated
		unsigned long                                              IGNORE_POSE_UPDATES : 1;                                 // 0x0000(0x0001) BIT_FIELD Deprecated
		unsigned long                                              IGNORE_RAYCAST_CALLBACKS : 1;                            // 0x0000(0x0001) BIT_FIELD Deprecated
		unsigned long                                              IGNORE_CONTACT_CALLBACKS : 1;                            // 0x0000(0x0001) BIT_FIELD Deprecated
		unsigned long                                              USER_FLAG_1 : 1;                                         // 0x0000(0x0001) BIT_FIELD Deprecated
		unsigned long                                              USER_FLAG_2 : 1;                                         // 0x0000(0x0001) BIT_FIELD Deprecated
		unsigned long                                              USER_FLAG_3 : 1;                                         // 0x0000(0x0001) BIT_FIELD Deprecated
		unsigned long                                              USER_FLAG_4 : 1;                                         // 0x0000(0x0001) BIT_FIELD Deprecated
		EImpactDamageOverride                                      ImpactDamageOverride;                                    // 0x0004(0x0001) Edit
	};

	/**
	 * ScriptStruct Engine.ApexDestructibleAsset.NxDestructibleParameters
	 * Size -> 0x00F0
	 */
	struct FNxDestructibleParameters
	{
	public:
		struct FNxDestructibleDamageParameters                     DamageParameters;                                        // 0x0000(0x0014) Edit
		struct FNxDestructibleDebrisParameters                     DebrisParameters;                                        // 0x0014(0x002C) Edit
		struct FNxDestructibleAdvancedParameters                   AdvancedParameters;                                      // 0x0040(0x0018) Edit
		float                                                      DamageThreshold;                                         // 0x0058(0x0004) Deprecated
		float                                                      DamageToRadius;                                          // 0x005C(0x0004) Deprecated
		float                                                      DamageCap;                                               // 0x0060(0x0004) Deprecated
		float                                                      ForceToDamage;                                           // 0x0064(0x0004) Deprecated
		float                                                      ImpactVelocityThreshold;                                 // 0x0068(0x0004) Deprecated
		float                                                      MaterialStrength;                                        // 0x006C(0x0004) Deprecated
		float                                                      DamageToPercentDeformation;                              // 0x0070(0x0004) Deprecated
		float                                                      DeformationPercentLimit;                                 // 0x0074(0x0004) Deprecated
		unsigned long                                              bFormExtendedStructures : 1;                             // 0x0078(0x0001) BIT_FIELD Deprecated
		int32_t                                                    SupportDepth;                                            // 0x007C(0x0004) Edit
		int32_t                                                    MinimumFractureDepth;                                    // 0x0080(0x0004) Edit
		int32_t                                                    DebrisDepth;                                             // 0x0084(0x0004) Edit
		int32_t                                                    EssentialDepth;                                          // 0x0088(0x0004) Edit
		float                                                      DebrisLifetimeMin;                                       // 0x008C(0x0004) Deprecated
		float                                                      DebrisLifetimeMax;                                       // 0x0090(0x0004) Deprecated
		float                                                      DebrisMaxSeparationMin;                                  // 0x0094(0x0004) Deprecated
		float                                                      DebrisMaxSeparationMax;                                  // 0x0098(0x0004) Deprecated
		struct FBox                                                ValidBounds;                                             // 0x009C(0x001C) Deprecated
		float                                                      MaxChunkSpeed;                                           // 0x00B8(0x0004) Deprecated
		float                                                      MassScaleExponent;                                       // 0x00BC(0x0004) Deprecated
		struct FNxDestructibleParametersFlag                       Flags;                                                   // 0x00C0(0x0004) Edit
		float                                                      GrbVolumeLimit;                                          // 0x00C4(0x0004) Deprecated
		float                                                      GrbParticleSpacing;                                      // 0x00C8(0x0004) Deprecated
		float                                                      FractureImpulseScale;                                    // 0x00CC(0x0004) Deprecated
		TArray<struct FNxDestructibleDepthParameters>              DepthParameters;                                         // 0x00D0(0x0010) Edit, EditFixedSize, NeedCtorLink
		int32_t                                                    DynamicChunksDominanceGroup;                             // 0x00E0(0x0004) Edit
		unsigned long                                              UseDynamicChunksGroupsMask : 1;                          // 0x00E4(0x0001) BIT_FIELD Edit
		ERBCollisionChannel                                        DynamicChunksChannel;                                    // 0x00E8(0x0001) Edit, Const
		unsigned char                                              UnknownData_PC1E[0x3];                                   // 0x00E9(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct FRBCollisionChannelContainer                        DynamicChunksCollideWithChannels;                        // 0x00EC(0x0004) Edit, Const
	};

	/**
	 * ScriptStruct Engine.InterpGroupCamera.CameraPreviewInfo
	 * Size -> 0x0040
	 */
	struct FCameraPreviewInfo
	{
	public:
		class UClass*                                              PawnClass;                                               // 0x0000(0x0008) Edit
		TArray<class UAnimSet*>                                    PreviewAnimSets;                                         // 0x0008(0x0010) Edit, NeedCtorLink
		class FName                                                AnimSeqName;                                             // 0x0018(0x0008) Edit
		struct FVector                                             Location;                                                // 0x0020(0x000C) EditConst
		struct FRotator                                            Rotation;                                                // 0x002C(0x000C) EditConst
		class APawn*                                               PawnInst;                                                // 0x0038(0x0008) Transient
	};

	/**
	 * ScriptStruct Engine.InterpTrackBoolProp.BoolTrackKey
	 * Size -> 0x0008
	 */
	struct FBoolTrackKey
	{
	public:
		float                                                      Time;                                                    // 0x0000(0x0004)
		unsigned long                                              Value : 1;                                               // 0x0004(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.InterpTrackDirector.DirectorTrackCut
	 * Size -> 0x0014
	 */
	struct FDirectorTrackCut
	{
	public:
		float                                                      Time;                                                    // 0x0000(0x0004)
		float                                                      TransitionTime;                                          // 0x0004(0x0004)
		class FName                                                TargetCamGroup;                                          // 0x0008(0x0008) Edit
		int32_t                                                    ShotNumber;                                              // 0x0010(0x0004)
	};

	/**
	 * ScriptStruct Engine.InterpTrackEvent.EventTrackKey
	 * Size -> 0x000C
	 */
	struct FEventTrackKey
	{
	public:
		float                                                      Time;                                                    // 0x0000(0x0004)
		class FName                                                EventName;                                               // 0x0004(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.InterpTrackFaceFX.FaceFXTrackKey
	 * Size -> 0x0024
	 */
	struct FFaceFXTrackKey
	{
	public:
		float                                                      StartTime;                                               // 0x0000(0x0004)
		class FString                                              FaceFXGroupName;                                         // 0x0004(0x0010) NeedCtorLink
		class FString                                              FaceFXSeqName;                                           // 0x0014(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.InterpTrackFaceFX.FaceFXSoundCueKey
	 * Size -> 0x0008
	 */
	struct FFaceFXSoundCueKey
	{
	public:
		class USoundCue*                                           FaceFXSoundCue;                                          // 0x0000(0x0008) Const
	};

	/**
	 * ScriptStruct Engine.InterpTrackAnimControl.AnimControlTrackKey
	 * Size -> 0x001C
	 */
	struct FAnimControlTrackKey
	{
	public:
		float                                                      StartTime;                                               // 0x0000(0x0004)
		class FName                                                AnimSeqName;                                             // 0x0004(0x0008)
		float                                                      AnimStartOffset;                                         // 0x000C(0x0004)
		float                                                      AnimEndOffset;                                           // 0x0010(0x0004)
		float                                                      AnimPlayRate;                                            // 0x0014(0x0004)
		unsigned long                                              bLooping : 1;                                            // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bReverse : 1;                                            // 0x0018(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.EngineTypes.PrimitiveMaterialRef
	 * Size -> 0x000C
	 */
	struct FPrimitiveMaterialRef
	{
	public:
		class UPrimitiveComponent*                                 Primitive;                                               // 0x0000(0x0008) ExportObject, Component, EditInline
		int32_t                                                    MaterialIndex;                                           // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.EngineTypes.PostProcessMaterialRef
	 * Size -> 0x0008
	 */
	struct FPostProcessMaterialRef
	{
	public:
		class UMaterialEffect*                                     Effect;                                                  // 0x0000(0x0008)
	};

	/**
	 * ScriptStruct Engine.EngineTypes.MaterialReferenceList
	 * Size -> 0x0028
	 */
	struct FMaterialReferenceList
	{
	public:
		class UMaterialInterface*                                  TargetMaterial;                                          // 0x0000(0x0008) Edit
		TArray<struct FPrimitiveMaterialRef>                       AffectedMaterialRefs;                                    // 0x0008(0x0010) Component, NeedCtorLink, EditHide
		TArray<struct FPostProcessMaterialRef>                     AffectedPPChainMaterialRefs;                             // 0x0018(0x0010) NeedCtorLink, EditHide
	};

	/**
	 * ScriptStruct Engine.InterpTrackMove.InterpLookupPoint
	 * Size -> 0x000C
	 */
	struct FInterpLookupPoint
	{
	public:
		class FName                                                GroupName;                                               // 0x0000(0x0008)
		float                                                      Time;                                                    // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.InterpTrackMove.InterpLookupTrack
	 * Size -> 0x0010
	 */
	struct FInterpLookupTrack
	{
	public:
		TArray<struct FInterpLookupPoint>                          Points;                                                  // 0x0000(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.InterpTrackHeadTracking.HeadTrackingKey
	 * Size -> 0x0005
	 */
	struct FHeadTrackingKey
	{
	public:
		float                                                      Time;                                                    // 0x0000(0x0004)
		EHeadTrackingAction                                        Action;                                                  // 0x0004(0x0001) Edit
	};

	/**
	 * ScriptStruct Engine.InterpTrackParticleReplay.ParticleReplayTrackKey
	 * Size -> 0x000C
	 */
	struct FParticleReplayTrackKey
	{
	public:
		float                                                      Time;                                                    // 0x0000(0x0004)
		float                                                      Duration;                                                // 0x0004(0x0004) Edit
		int32_t                                                    ClipIDNumber;                                            // 0x0008(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.InterpTrackToggle.ToggleTrackKey
	 * Size -> 0x0005
	 */
	struct FToggleTrackKey
	{
	public:
		float                                                      Time;                                                    // 0x0000(0x0004)
		ETrackToggleAction                                         ToggleAction;                                            // 0x0004(0x0001) Edit
	};

	/**
	 * ScriptStruct Engine.InterpTrackSound.SoundTrackKey
	 * Size -> 0x0014
	 */
	struct FSoundTrackKey
	{
	public:
		float                                                      Time;                                                    // 0x0000(0x0004)
		float                                                      Volume;                                                  // 0x0004(0x0004)
		float                                                      Pitch;                                                   // 0x0008(0x0004)
		class USoundCue*                                           Sound;                                                   // 0x000C(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.InterpTrackVisibility.VisibilityTrackKey
	 * Size -> 0x0006
	 */
	struct FVisibilityTrackKey
	{
	public:
		float                                                      Time;                                                    // 0x0000(0x0004)
		EVisibilityTrackAction                                     Action;                                                  // 0x0004(0x0001) Edit
		EVisibilityTrackCondition                                  ActiveCondition;                                         // 0x0005(0x0001)
	};

	/**
	 * ScriptStruct Engine.InterpTrackInstFloatMaterialParam.FloatMaterialParamMICData
	 * Size -> 0x0020
	 */
	struct FFloatMaterialParamMICData
	{
	public:
		TArray<class UMaterialInstanceConstant*>                   MICs;                                                    // 0x0000(0x0010) Const, NeedCtorLink
		TArray<float>                                              MICResetFloats;                                          // 0x0010(0x0010) Const, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.InterpTrackInstVectorMaterialParam.VectorMaterialParamMICData
	 * Size -> 0x0020
	 */
	struct FVectorMaterialParamMICData
	{
	public:
		TArray<class UMaterialInstanceConstant*>                   MICs;                                                    // 0x0000(0x0010) Const, NeedCtorLink
		TArray<struct FVector>                                     MICResetVectors;                                         // 0x0010(0x0010) Const, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.MaterialExpression.ExpressionOutput
	 * Size -> 0x0024
	 */
	struct FExpressionOutput
	{
	public:
		class FString                                              OutputName;                                              // 0x0000(0x0010) NeedCtorLink
		int32_t                                                    Mask;                                                    // 0x0010(0x0004)
		int32_t                                                    MaskR;                                                   // 0x0014(0x0004)
		int32_t                                                    MaskG;                                                   // 0x0018(0x0004)
		int32_t                                                    MaskB;                                                   // 0x001C(0x0004)
		int32_t                                                    MaskA;                                                   // 0x0020(0x0004)
	};

	/**
	 * ScriptStruct Engine.MaterialExpression.ExpressionInput
	 * Size -> 0x0034
	 */
	struct FExpressionInput
	{
	public:
		class UMaterialExpression*                                 Expression;                                              // 0x0000(0x0008)
		int32_t                                                    OutputIndex;                                             // 0x0008(0x0004)
		class FString                                              InputName;                                               // 0x000C(0x0010) NeedCtorLink
		int32_t                                                    Mask;                                                    // 0x001C(0x0004)
		int32_t                                                    MaskR;                                                   // 0x0020(0x0004)
		int32_t                                                    MaskG;                                                   // 0x0024(0x0004)
		int32_t                                                    MaskB;                                                   // 0x0028(0x0004)
		int32_t                                                    MaskA;                                                   // 0x002C(0x0004)
		int32_t                                                    GCC64_Padding;                                           // 0x0030(0x0004)
	};

	/**
	 * ScriptStruct Engine.MaterialExpressionCustom.CustomInput
	 * Size -> 0x0044
	 */
	struct FCustomInput
	{
	public:
		class FString                                              InputName;                                               // 0x0000(0x0010) Edit, NeedCtorLink
		struct FExpressionInput                                    Input;                                                   // 0x0010(0x0034) NeedCtorLink, EditHide
	};

	/**
	 * ScriptStruct Engine.MaterialExpressionLandscapeLayerBlend.LayerBlendInput
	 * Size -> 0x0080
	 */
	struct FLayerBlendInput
	{
	public:
		class FName                                                LayerName;                                               // 0x0000(0x0008) Edit
		ELandscapeLayerBlendType                                   BlendType;                                               // 0x0008(0x0001) Edit
		unsigned char                                              UnknownData_5UQV[0x3];                                   // 0x0009(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct FExpressionInput                                    LayerInput;                                              // 0x000C(0x0034) NeedCtorLink, EditHide
		struct FExpressionInput                                    HeightInput;                                             // 0x0040(0x0034) NeedCtorLink, EditHide
		float                                                      PreviewWeight;                                           // 0x0074(0x0004) Edit
		struct FPointer                                            InstanceOverride;                                        // 0x0078(0x0008) Const, Native, Transient
	};

	/**
	 * ScriptStruct Engine.MaterialExpressionMaterialFunctionCall.FunctionExpressionInput
	 * Size -> 0x004C
	 */
	struct FFunctionExpressionInput
	{
	public:
		class UMaterialExpressionFunctionInput*                    ExpressionInput;                                         // 0x0000(0x0008) Transient
		struct FGuid                                               ExpressionInputId;                                       // 0x0008(0x0010)
		struct FExpressionInput                                    Input;                                                   // 0x0018(0x0034) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.MaterialExpressionMaterialFunctionCall.FunctionExpressionOutput
	 * Size -> 0x003C
	 */
	struct FFunctionExpressionOutput
	{
	public:
		class UMaterialExpressionFunctionOutput*                   ExpressionOutput;                                        // 0x0000(0x0008) Transient
		struct FGuid                                               ExpressionOutputId;                                      // 0x0008(0x0010)
		struct FExpressionOutput                                   Output;                                                  // 0x0018(0x0024) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.MaterialInstanceConstant.FontParameterValue
	 * Size -> 0x0024
	 */
	struct FFontParameterValue
	{
	public:
		class FName                                                ParameterName;                                           // 0x0000(0x0008) Edit
		class UFont*                                               FontValue;                                               // 0x0008(0x0008) Edit
		int32_t                                                    FontPage;                                                // 0x0010(0x0004) Edit
		struct FGuid                                               ExpressionGUID;                                          // 0x0014(0x0010)
	};

	/**
	 * ScriptStruct Engine.MaterialInstanceConstant.ScalarParameterValue
	 * Size -> 0x001C
	 */
	struct FScalarParameterValue
	{
	public:
		class FName                                                ParameterName;                                           // 0x0000(0x0008) Edit
		float                                                      ParameterValue;                                          // 0x0008(0x0004) Edit
		struct FGuid                                               ExpressionGUID;                                          // 0x000C(0x0010)
	};

	/**
	 * ScriptStruct Engine.MaterialInstanceConstant.TextureParameterValue
	 * Size -> 0x0020
	 */
	struct FTextureParameterValue
	{
	public:
		class FName                                                ParameterName;                                           // 0x0000(0x0008) Edit
		class UTexture*                                            ParameterValue;                                          // 0x0008(0x0008) Edit
		struct FGuid                                               ExpressionGUID;                                          // 0x0010(0x0010)
	};

	/**
	 * ScriptStruct Engine.MaterialInstanceConstant.VectorParameterValue
	 * Size -> 0x0028
	 */
	struct FVectorParameterValue
	{
	public:
		class FName                                                ParameterName;                                           // 0x0000(0x0008) Edit
		struct FLinearColor                                        ParameterValue;                                          // 0x0008(0x0010) Edit
		struct FGuid                                               ExpressionGUID;                                          // 0x0018(0x0010)
	};

	/**
	 * ScriptStruct Engine.MaterialInstanceTimeVarying.ParameterValueOverTime
	 * Size -> 0x0034
	 */
	struct FParameterValueOverTime
	{
	public:
		struct FGuid                                               ExpressionGUID;                                          // 0x0000(0x0010)
		struct FDouble                                             StartTime;                                               // 0x0010(0x0008)
		class FName                                                ParameterName;                                           // 0x0018(0x0008) Edit
		unsigned long                                              bLoop : 1;                                               // 0x0020(0x0001) BIT_FIELD Edit
		unsigned long                                              bAutoActivate : 1;                                       // 0x0020(0x0001) BIT_FIELD Edit
		float                                                      CycleTime;                                               // 0x0024(0x0004) Edit
		unsigned long                                              bNormalizeTime : 1;                                      // 0x0028(0x0001) BIT_FIELD Edit
		float                                                      OffsetTime;                                              // 0x002C(0x0004) Edit
		unsigned long                                              bOffsetFromEnd : 1;                                      // 0x0030(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.MaterialInstanceTimeVarying.FontParameterValueOverTime
	 * Size -> 0x000C (FullSize[0x0040] - InheritedSize[0x0034])
	 */
	struct FFontParameterValueOverTime : public FParameterValueOverTime
	{
	public:
		class UFont*                                               FontValue;                                               // 0x0034(0x0008) Edit
		int32_t                                                    FontPage;                                                // 0x003C(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.MaterialInstanceTimeVarying.ScalarParameterValueOverTime
	 * Size -> 0x0018 (FullSize[0x004C] - InheritedSize[0x0034])
	 */
	struct FScalarParameterValueOverTime : public FParameterValueOverTime
	{
	public:
		float                                                      ParameterValue;                                          // 0x0034(0x0004) Edit
		struct FInterpCurveFloat                                   ParameterValueCurve;                                     // 0x0038(0x0014) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.MaterialInstanceTimeVarying.TextureParameterValueOverTime
	 * Size -> 0x0008 (FullSize[0x003C] - InheritedSize[0x0034])
	 */
	struct FTextureParameterValueOverTime : public FParameterValueOverTime
	{
	public:
		class UTexture*                                            ParameterValue;                                          // 0x0034(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.MaterialInstanceTimeVarying.VectorParameterValueOverTime
	 * Size -> 0x0024 (FullSize[0x0058] - InheritedSize[0x0034])
	 */
	struct FVectorParameterValueOverTime : public FParameterValueOverTime
	{
	public:
		struct FLinearColor                                        ParameterValue;                                          // 0x0034(0x0010) Edit
		struct FInterpCurveVector                                  ParameterValueCurve;                                     // 0x0044(0x0014) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.MaterialInstanceTimeVarying.LinearColorParameterValueOverTime
	 * Size -> 0x0024 (FullSize[0x0058] - InheritedSize[0x0034])
	 */
	struct FLinearColorParameterValueOverTime : public FParameterValueOverTime
	{
	public:
		struct FLinearColor                                        ParameterValue;                                          // 0x0034(0x0010) Edit
		struct FInterpCurveLinearColor                             ParameterValueCurve;                                     // 0x0044(0x0014) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.ParticleSystemComponent.ViewParticleEmitterInstanceMotionBlurInfo
	 * Size -> 0x0048
	 */
	struct FViewParticleEmitterInstanceMotionBlurInfo
	{
	public:
		struct FMap_Mirror                                         EmitterInstanceMBInfoMap;                                // 0x0000(0x0048) Const, Native, Transient
	};

	/**
	 * ScriptStruct Engine.ParticleSystemComponent.ParticleSysParam
	 * Size -> 0x0040
	 */
	struct FParticleSysParam
	{
	public:
		class FName                                                Name;                                                    // 0x0000(0x0008) Edit
		EParticleSysParamType                                      ParamType;                                               // 0x0008(0x0001) Edit
		unsigned char                                              UnknownData_65SW[0x3];                                   // 0x0009(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      Scalar;                                                  // 0x000C(0x0004) Edit
		float                                                      Scalar_Low;                                              // 0x0010(0x0004) Edit
		struct FVector                                             Vector;                                                  // 0x0014(0x000C) Edit
		struct FVector                                             Vector_Low;                                              // 0x0020(0x000C) Edit
		struct FColor                                              Color;                                                   // 0x002C(0x0004) Edit
		class AActor*                                              Actor;                                                   // 0x0030(0x0008) Edit
		class UMaterialInterface*                                  Material;                                                // 0x0038(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.PrimitiveComponent.MaterialViewRelevance
	 * Size -> 0x0004
	 */
	struct FMaterialViewRelevance
	{
	public:
		unsigned long                                              bOpaque : 1;                                             // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bTranslucent : 1;                                        // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bDistortion : 1;                                         // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bOneLayerDistortionRelevance : 1;                        // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bLit : 1;                                                // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bUsesSceneColor : 1;                                     // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.ParticleSystemComponent.ParticleEventData
	 * Size -> 0x0034
	 */
	struct FParticleEventData
	{
	public:
		int32_t                                                    Type;                                                    // 0x0000(0x0004)
		class FName                                                EventName;                                               // 0x0004(0x0008)
		float                                                      EmitterTime;                                             // 0x000C(0x0004)
		struct FVector                                             Location;                                                // 0x0010(0x000C)
		struct FVector                                             Direction;                                               // 0x001C(0x000C)
		struct FVector                                             Velocity;                                                // 0x0028(0x000C)
	};

	/**
	 * ScriptStruct Engine.ParticleSystemComponent.ParticleEventSpawnData
	 * Size -> 0x0000 (FullSize[0x0034] - InheritedSize[0x0034])
	 */
	struct FParticleEventSpawnData : public FParticleEventData
	{	};

	/**
	 * ScriptStruct Engine.ParticleSystemComponent.ParticleEventDeathData
	 * Size -> 0x0004 (FullSize[0x0038] - InheritedSize[0x0034])
	 */
	struct FParticleEventDeathData : public FParticleEventData
	{
	public:
		float                                                      ParticleTime;                                            // 0x0034(0x0004)
	};

	/**
	 * ScriptStruct Engine.ParticleSystemComponent.ParticleEventCollideData
	 * Size -> 0x0020 (FullSize[0x0054] - InheritedSize[0x0034])
	 */
	struct FParticleEventCollideData : public FParticleEventData
	{
	public:
		float                                                      ParticleTime;                                            // 0x0034(0x0004)
		struct FVector                                             Normal;                                                  // 0x0038(0x000C)
		float                                                      Time;                                                    // 0x0044(0x0004)
		int32_t                                                    Item;                                                    // 0x0048(0x0004)
		class FName                                                BoneName;                                                // 0x004C(0x0008)
	};

	/**
	 * ScriptStruct Engine.ParticleSystemComponent.ParticleEventKismetData
	 * Size -> 0x0010 (FullSize[0x0044] - InheritedSize[0x0034])
	 */
	struct FParticleEventKismetData : public FParticleEventData
	{
	public:
		unsigned long                                              UsePSysCompLocation : 1;                                 // 0x0034(0x0001) BIT_FIELD
		struct FVector                                             Normal;                                                  // 0x0038(0x000C)
	};

	/**
	 * ScriptStruct Engine.ParticleSystemComponent.ParticleEventAttractorCollideData
	 * Size -> 0x0000 (FullSize[0x0054] - InheritedSize[0x0054])
	 */
	struct FParticleEventAttractorCollideData : public FParticleEventCollideData
	{	};

	/**
	 * ScriptStruct Engine.ParticleModuleAttractorBoneSocket.AttractLocationBoneSocketInfo
	 * Size -> 0x0014
	 */
	struct FAttractLocationBoneSocketInfo
	{
	public:
		class FName                                                BoneSocketName;                                          // 0x0000(0x0008) Edit
		struct FVector                                             Offset;                                                  // 0x0008(0x000C) Edit
	};

	/**
	 * ScriptStruct Engine.ParticleModuleBeamModifier.BeamModifierOptions
	 * Size -> 0x0004
	 */
	struct FBeamModifierOptions
	{
	public:
		unsigned long                                              bModify : 1;                                             // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bScale : 1;                                              // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bLock : 1;                                               // 0x0000(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.ParticleModuleCollision.ParticleAttractorCollisionAction
	 * Size -> 0x0014
	 */
	struct FParticleAttractorCollisionAction
	{
	public:
		EParticleAttractorActionType                               Type;                                                    // 0x0000(0x0001) Edit
		unsigned char                                              UnknownData_6E77[0x3];                                   // 0x0001(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class FString                                              EventName;                                               // 0x0004(0x0010) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.ParticleModule.ParticleRandomSeedInfo
	 * Size -> 0x001C
	 */
	struct FParticleRandomSeedInfo
	{
	public:
		class FName                                                ParameterName;                                           // 0x0000(0x0008) Edit
		unsigned long                                              bGetSeedFromInstance : 1;                                // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bInstanceSeedIsIndex : 1;                                // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bResetSeedOnEmitterLooping : 1;                          // 0x0008(0x0001) BIT_FIELD Edit
		TArray<int32_t>                                            RandomSeeds;                                             // 0x000C(0x0010) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.ParticleModuleEventGenerator.ParticleEvent_GenerateInfo
	 * Size -> 0x002C
	 */
	struct FParticleEvent_GenerateInfo
	{
	public:
		EParticleEventType                                         Type;                                                    // 0x0000(0x0001) Edit
		unsigned char                                              UnknownData_LRW8[0x3];                                   // 0x0001(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    Frequency;                                               // 0x0004(0x0004) Edit
		int32_t                                                    LowFreq;                                                 // 0x0008(0x0004) Edit
		int32_t                                                    ParticleFrequency;                                       // 0x000C(0x0004) Edit
		unsigned long                                              FirstTimeOnly : 1;                                       // 0x0010(0x0001) BIT_FIELD Edit
		unsigned long                                              LastTimeOnly : 1;                                        // 0x0010(0x0001) BIT_FIELD Edit
		unsigned long                                              UseReflectedImpactVector : 1;                            // 0x0010(0x0001) BIT_FIELD Edit
		class FName                                                CustomName;                                              // 0x0014(0x0008) Edit
		TArray<class UParticleModuleEventSendToGame*>              ParticleModuleEventsToSendToGame;                        // 0x001C(0x0010) Edit, NeedCtorLink, EditInline
	};

	/**
	 * ScriptStruct Engine.ParticleModuleLocationBoneSocket.LocationBoneSocketInfo
	 * Size -> 0x0014
	 */
	struct FLocationBoneSocketInfo
	{
	public:
		class FName                                                BoneSocketName;                                          // 0x0000(0x0008) Edit
		struct FVector                                             Offset;                                                  // 0x0008(0x000C) Edit
	};

	/**
	 * ScriptStruct Engine.ParticleModuleOrbit.OrbitOptions
	 * Size -> 0x0004
	 */
	struct FOrbitOptions
	{
	public:
		unsigned long                                              bProcessDuringSpawn : 1;                                 // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bProcessDuringUpdate : 1;                                // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bUseEmitterTime : 1;                                     // 0x0000(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.ParticleModuleParameterDynamic.EmitterDynamicParameter
	 * Size -> 0x0038
	 */
	struct FEmitterDynamicParameter
	{
	public:
		class FName                                                ParamName;                                               // 0x0000(0x0008) Edit, EditConst
		unsigned long                                              bUseEmitterTime : 1;                                     // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bSpawnTimeOnly : 1;                                      // 0x0008(0x0001) BIT_FIELD Edit
		EEmitterDynamicParameterValue                              ValueMethod;                                             // 0x000C(0x0001) Edit
		unsigned char                                              UnknownData_58DL[0x3];                                   // 0x000D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		unsigned long                                              bScaleVelocityByParamValue : 1;                          // 0x0010(0x0001) BIT_FIELD Edit
		struct FRawDistributionFloat                               ParamValue;                                              // 0x0014(0x0024) Edit, Component, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.ParticleEmitter.ParticleBurst
	 * Size -> 0x000C
	 */
	struct FParticleBurst
	{
	public:
		int32_t                                                    Count;                                                   // 0x0000(0x0004) Edit
		int32_t                                                    CountLow;                                                // 0x0004(0x0004) Edit
		float                                                      Time;                                                    // 0x0008(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.ParticleModuleTypeDataPhysX.PhysXEmitterVerticalLodProperties
	 * Size -> 0x0010
	 */
	struct FPhysXEmitterVerticalLodProperties
	{
	public:
		float                                                      WeightForFifo;                                           // 0x0000(0x0004) Edit
		float                                                      WeightForSpawnLod;                                       // 0x0004(0x0004) Edit
		float                                                      SpawnLodRateVsLifeBias;                                  // 0x0008(0x0004) Edit
		float                                                      RelativeFadeoutTime;                                     // 0x000C(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.ParticleSystemReplay.ParticleEmitterReplayFrame
	 * Size -> 0x0010
	 */
	struct FParticleEmitterReplayFrame
	{
	public:
		int32_t                                                    EmitterType;                                             // 0x0000(0x0004) Const, Native
		int32_t                                                    OriginalEmitterIndex;                                    // 0x0004(0x0004) Const, Native
		struct FPointer                                            FrameState;                                              // 0x0008(0x0008) Const, Native
	};

	/**
	 * ScriptStruct Engine.ParticleSystemReplay.ParticleSystemReplayFrame
	 * Size -> 0x0010
	 */
	struct FParticleSystemReplayFrame
	{
	public:
		TArray<struct FParticleEmitterReplayFrame>                 Emitters;                                                // 0x0000(0x0010) Const, Native
	};

	/**
	 * ScriptStruct Engine.Actor.RigidBodyState
	 * Size -> 0x0039
	 */
	struct FRigidBodyState
	{
	public:
		struct FVector                                             Position;                                                // 0x0000(0x000C)
		unsigned char                                              UnknownData_WWLI[0x4];                                   // 0x000C(0x0004) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct FQuat                                               Quaternion;                                              // 0x0010(0x0010)
		struct FVector                                             LinVel;                                                  // 0x0020(0x000C)
		struct FVector                                             AngVel;                                                  // 0x002C(0x000C)
		unsigned char                                              bNewData;                                                // 0x0038(0x0001)
	};

	/**
	 * ScriptStruct Engine.KAsset.GHM_KAsset_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_KAsset_CheckpointRecord
	{
	public:
		unsigned long                                              bRigidBodyIsAwake : 1;                                   // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.SVehicle.VehicleState
	 * Size -> 0x004C
	 */
	struct FVehicleState
	{
	public:
		struct FRigidBodyState                                     RBState;                                                 // 0x0000(0x0040)
		unsigned char                                              ServerBrake;                                             // 0x0040(0x0001)
		unsigned char                                              ServerGas;                                               // 0x0041(0x0001)
		unsigned char                                              ServerSteering;                                          // 0x0042(0x0001)
		unsigned char                                              ServerRise;                                              // 0x0043(0x0001)
		unsigned long                                              bServerHandbrake : 1;                                    // 0x0044(0x0001) BIT_FIELD
		int32_t                                                    ServerView;                                              // 0x0048(0x0004)
	};

	/**
	 * ScriptStruct Engine.RB_ConstraintActor.GHM_RB_ConstraintActor_CheckpointRecord
	 * Size -> 0x0001
	 */
	struct FGHM_RB_ConstraintActor_CheckpointRecord
	{
	public:
		EPhysics                                                   Physics;                                                 // 0x0000(0x0001)
	};

	/**
	 * ScriptStruct Engine.RB_Thruster.GHM_RB_Thruster_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_RB_Thruster_CheckpointRecord
	{
	public:
		unsigned long                                              bThrustEnabled : 1;                                      // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.ApexDestructibleDamageParameters.DamageParameters
	 * Size -> 0x0010
	 */
	struct FDamageParameters
	{
	public:
		EDamageParameterOverrideMode                               OverrideMode;                                            // 0x0000(0x0001) Edit
		unsigned char                                              UnknownData_P98O[0x3];                                   // 0x0001(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      BaseDamage;                                              // 0x0004(0x0004) Edit
		float                                                      Radius;                                                  // 0x0008(0x0004) Edit
		float                                                      Momentum;                                                // 0x000C(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.ApexDestructibleDamageParameters.DamagePair
	 * Size -> 0x0018
	 */
	struct FDamagePair
	{
	public:
		class FName                                                DamageCauserName;                                        // 0x0000(0x0008) Edit
		struct FDamageParameters                                   Params;                                                  // 0x0008(0x0010) Edit
	};

	/**
	 * ScriptStruct Engine.RB_ConstraintSetup.LinearDOFSetup
	 * Size -> 0x0008
	 */
	struct FLinearDOFSetup
	{
	public:
		unsigned char                                              bLimited;                                                // 0x0000(0x0001) Edit
		unsigned char                                              UnknownData_5XYD[0x3];                                   // 0x0001(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      LimitSize;                                               // 0x0004(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.NxForceField.GHM_NxForceField_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_NxForceField_CheckpointRecord
	{
	public:
		unsigned long                                              bForceActive : 1;                                        // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.NxForceFieldSpawnable.GHM_NxForceFieldSpawnable_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_NxForceFieldSpawnable_CheckpointRecord
	{
	public:
		unsigned long                                              bForceActive : 1;                                        // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.RB_CylindricalForceActor.GHM_RB_CylindricalForceActor_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_RB_CylindricalForceActor_CheckpointRecord
	{
	public:
		unsigned long                                              bForceActive : 1;                                        // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.RB_RadialForceActor.GHM_RB_RadialForceActor_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_RB_RadialForceActor_CheckpointRecord
	{
	public:
		unsigned long                                              bForceActive : 1;                                        // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.SequenceOp.SeqOpInputLink
	 * Size -> 0x0038
	 */
	struct FSeqOpInputLink
	{
	public:
		class FString                                              LinkDesc;                                                // 0x0000(0x0010) NeedCtorLink
		unsigned long                                              bHasImpulse : 1;                                         // 0x0010(0x0001) BIT_FIELD
		int32_t                                                    QueuedActivations;                                       // 0x0014(0x0004)
		unsigned long                                              bDisabled : 1;                                           // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bDisabledPIE : 1;                                        // 0x0018(0x0001) BIT_FIELD
		class USequenceOp*                                         LinkedOp;                                                // 0x001C(0x0008)
		int32_t                                                    DrawY;                                                   // 0x0024(0x0004)
		unsigned long                                              bHidden : 1;                                             // 0x0028(0x0001) BIT_FIELD
		float                                                      ActivateDelay;                                           // 0x002C(0x0004)
		unsigned long                                              bMoving : 1;                                             // 0x0030(0x0001) BIT_FIELD Transient, EditorOnly
		unsigned long                                              bClampedMax : 1;                                         // 0x0030(0x0001) BIT_FIELD EditorOnly
		unsigned long                                              bClampedMin : 1;                                         // 0x0030(0x0001) BIT_FIELD EditorOnly
		int32_t                                                    OverrideDelta;                                           // 0x0034(0x0004) EditorOnly
	};

	/**
	 * ScriptStruct Engine.SequenceOp.SeqOpOutputInputLink
	 * Size -> 0x000C
	 */
	struct FSeqOpOutputInputLink
	{
	public:
		class USequenceOp*                                         LinkedOp;                                                // 0x0000(0x0008)
		int32_t                                                    InputLinkIdx;                                            // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.SequenceOp.SeqOpOutputLink
	 * Size -> 0x0048
	 */
	struct FSeqOpOutputLink
	{
	public:
		TArray<struct FSeqOpOutputInputLink>                       Links;                                                   // 0x0000(0x0010) NeedCtorLink
		class FString                                              LinkDesc;                                                // 0x0010(0x0010) NeedCtorLink
		unsigned long                                              bHasImpulse : 1;                                         // 0x0020(0x0001) BIT_FIELD
		unsigned long                                              bDisabled : 1;                                           // 0x0020(0x0001) BIT_FIELD
		unsigned long                                              bDisabledPIE : 1;                                        // 0x0020(0x0001) BIT_FIELD
		class USequenceOp*                                         LinkedOp;                                                // 0x0024(0x0008)
		float                                                      ActivateDelay;                                           // 0x002C(0x0004)
		int32_t                                                    DrawY;                                                   // 0x0030(0x0004)
		unsigned long                                              bHidden : 1;                                             // 0x0034(0x0001) BIT_FIELD
		unsigned long                                              bMoving : 1;                                             // 0x0034(0x0001) BIT_FIELD Transient, EditorOnly
		unsigned long                                              bClampedMax : 1;                                         // 0x0034(0x0001) BIT_FIELD EditorOnly
		unsigned long                                              bClampedMin : 1;                                         // 0x0034(0x0001) BIT_FIELD EditorOnly
		int32_t                                                    OverrideDelta;                                           // 0x0038(0x0004) EditorOnly
		struct FDouble                                             PIEActivationTime;                                       // 0x003C(0x0008) Transient, EditorOnly
		unsigned long                                              bIsActivated : 1;                                        // 0x0044(0x0001) BIT_FIELD Transient, NoImport, NonTransactional, EditorOnly
	};

	/**
	 * ScriptStruct Engine.SequenceOp.SeqVarLink
	 * Size -> 0x0058
	 */
	struct FSeqVarLink
	{
	public:
		class UClass*                                              ExpectedType;                                            // 0x0000(0x0008)
		TArray<class USequenceVariable*>                           LinkedVariables;                                         // 0x0008(0x0010) NeedCtorLink
		class FString                                              LinkDesc;                                                // 0x0018(0x0010) NeedCtorLink
		class FName                                                LinkVar;                                                 // 0x0028(0x0008)
		class FName                                                PropertyName;                                            // 0x0030(0x0008)
		unsigned long                                              bWriteable : 1;                                          // 0x0038(0x0001) BIT_FIELD
		unsigned long                                              bSequenceNeverReadsOnlyWritesToThisVar : 1;              // 0x0038(0x0001) BIT_FIELD
		unsigned long                                              bModifiesLinkedObject : 1;                               // 0x0038(0x0001) BIT_FIELD
		unsigned long                                              bHidden : 1;                                             // 0x0038(0x0001) BIT_FIELD
		int32_t                                                    MinVars;                                                 // 0x003C(0x0004)
		int32_t                                                    MaxVars;                                                 // 0x0040(0x0004)
		int32_t                                                    DrawX;                                                   // 0x0044(0x0004)
		class UProperty*                                           CachedProperty;                                          // 0x0048(0x0008) Const, Transient
		unsigned long                                              bAllowAnyType : 1;                                       // 0x0050(0x0001) BIT_FIELD
		unsigned long                                              bMoving : 1;                                             // 0x0050(0x0001) BIT_FIELD Transient, EditorOnly
		unsigned long                                              bClampedMax : 1;                                         // 0x0050(0x0001) BIT_FIELD EditorOnly
		unsigned long                                              bClampedMin : 1;                                         // 0x0050(0x0001) BIT_FIELD EditorOnly
		int32_t                                                    OverrideDelta;                                           // 0x0054(0x0004) EditorOnly
	};

	/**
	 * ScriptStruct Engine.SequenceOp.SeqEventLink
	 * Size -> 0x0034
	 */
	struct FSeqEventLink
	{
	public:
		class UClass*                                              ExpectedType;                                            // 0x0000(0x0008)
		TArray<class USequenceEvent*>                              LinkedEvents;                                            // 0x0008(0x0010) NeedCtorLink
		class FString                                              LinkDesc;                                                // 0x0018(0x0010) NeedCtorLink
		int32_t                                                    DrawX;                                                   // 0x0028(0x0004)
		unsigned long                                              bHidden : 1;                                             // 0x002C(0x0001) BIT_FIELD
		unsigned long                                              bMoving : 1;                                             // 0x002C(0x0001) BIT_FIELD Transient, EditorOnly
		unsigned long                                              bClampedMax : 1;                                         // 0x002C(0x0001) BIT_FIELD EditorOnly
		unsigned long                                              bClampedMin : 1;                                         // 0x002C(0x0001) BIT_FIELD EditorOnly
		int32_t                                                    OverrideDelta;                                           // 0x0030(0x0004) EditorOnly
	};

	/**
	 * ScriptStruct Engine.Sequence.ActivateOp
	 * Size -> 0x0018
	 */
	struct FActivateOp
	{
	public:
		class USequenceOp*                                         ActivatorOp;                                             // 0x0000(0x0008)
		class USequenceOp*                                         Op;                                                      // 0x0008(0x0008)
		int32_t                                                    InputIdx;                                                // 0x0010(0x0004)
		float                                                      RemainingDelay;                                          // 0x0014(0x0004)
	};

	/**
	 * ScriptStruct Engine.Sequence.QueuedActivationInfo
	 * Size -> 0x002C
	 */
	struct FQueuedActivationInfo
	{
	public:
		class USequenceEvent*                                      ActivatedEvent;                                          // 0x0000(0x0008)
		class AActor*                                              InOriginator;                                            // 0x0008(0x0008)
		class AActor*                                              InInstigator;                                            // 0x0010(0x0008)
		TArray<int32_t>                                            ActivateIndices;                                         // 0x0018(0x0010) NeedCtorLink
		unsigned long                                              bPushTop : 1;                                            // 0x0028(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.SeqAct_Interp.CameraCutInfo
	 * Size -> 0x0010
	 */
	struct FCameraCutInfo
	{
	public:
		struct FVector                                             Location;                                                // 0x0000(0x000C)
		float                                                      TimeStamp;                                               // 0x000C(0x0004)
	};

	/**
	 * ScriptStruct Engine.SeqAct_MultiLevelStreaming.LevelStreamingNameCombo
	 * Size -> 0x0010
	 */
	struct FLevelStreamingNameCombo
	{
	public:
		class ULevelStreaming*                                     Level;                                                   // 0x0000(0x0008) Const
		class FName                                                LevelName;                                               // 0x0008(0x0008) Edit, Const
	};

	/**
	 * ScriptStruct Engine.Texture.TextureGroupContainer
	 * Size -> 0x0004
	 */
	struct FTextureGroupContainer
	{
	public:
		unsigned long                                              TEXTUREGROUP_World : 1;                                  // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_WorldNormalMap : 1;                         // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_WorldSpecular : 1;                          // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_Character : 1;                              // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_CharacterNormalMap : 1;                     // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_CharacterSpecular : 1;                      // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_Weapon : 1;                                 // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_WeaponNormalMap : 1;                        // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_WeaponSpecular : 1;                         // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_Vehicle : 1;                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_VehicleNormalMap : 1;                       // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_VehicleSpecular : 1;                        // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_Cinematic : 1;                              // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_Effects : 1;                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_EffectsNotFiltered : 1;                     // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_Skybox : 1;                                 // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_UI : 1;                                     // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_Lightmap : 1;                               // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_RenderTarget : 1;                           // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_MobileFlattened : 1;                        // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_ProcBuilding_Face : 1;                      // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_ProcBuilding_LightMap : 1;                  // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_Shadowmap : 1;                              // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_ColorLookupTable : 1;                       // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_Terrain_Heightmap : 1;                      // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_Terrain_Weightmap : 1;                      // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_ImageBasedReflection : 1;                   // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_Bokeh : 1;                                  // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_Default : 1;                                // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_CharacterHero : 1;                          // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_CharacterHeroNormalMap : 1;                 // 0x0000(0x0001) BIT_FIELD Edit, Const
		unsigned long                                              TEXTUREGROUP_CharacterHeroSpecular : 1;                  // 0x0000(0x0001) BIT_FIELD Edit, Const
	};

	/**
	 * ScriptStruct Engine.SeqAct_RangeSwitch.SwitchRange
	 * Size -> 0x0008
	 */
	struct FSwitchRange
	{
	public:
		int32_t                                                    Min;                                                     // 0x0000(0x0004) Edit
		int32_t                                                    Max;                                                     // 0x0004(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.SeqCond_SwitchClass.SwitchClassInfo
	 * Size -> 0x0009
	 */
	struct FSwitchClassInfo
	{
	public:
		class FName                                                ClassName;                                               // 0x0000(0x0008) Edit
		unsigned char                                              bFallThru;                                               // 0x0008(0x0001) Edit
	};

	/**
	 * ScriptStruct Engine.SeqCond_SwitchObject.SwitchObjectCase
	 * Size -> 0x000C
	 */
	struct FSwitchObjectCase
	{
	public:
		class UObject*                                             ObjectValue;                                             // 0x0000(0x0008) Edit
		unsigned long                                              bFallThru : 1;                                           // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bDefaultValue : 1;                                       // 0x0008(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.InterpData.AnimSetBakeAndPruneStatus
	 * Size -> 0x0014
	 */
	struct FAnimSetBakeAndPruneStatus
	{
	public:
		class FString                                              AnimSetName;                                             // 0x0000(0x0010) Edit, EditConst, NeedCtorLink
		unsigned long                                              bReferencedButUnused : 1;                                // 0x0010(0x0001) BIT_FIELD Edit, EditConst
		unsigned long                                              bSkipBakeAndPrune : 1;                                   // 0x0010(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.AmbientSoundSimpleToggleable.CheckpointRecord
	 * Size -> 0x0004
	 */
	struct AAmbientSoundSimpleToggleable_FCheckpointRecord
	{
	public:
		unsigned long                                              bCurrentlyPlaying : 1;                                   // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.SoundNodeAmbient.AmbientSoundSlot
	 * Size -> 0x0014
	 */
	struct FAmbientSoundSlot
	{
	public:
		class USoundNodeWave*                                      Wave;                                                    // 0x0000(0x0008) Edit
		float                                                      PitchScale;                                              // 0x0008(0x0004) Edit
		float                                                      VolumeScale;                                             // 0x000C(0x0004) Edit
		float                                                      Weight;                                                  // 0x0010(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.SoundNodeDistanceCrossFade.DistanceDatum
	 * Size -> 0x005C
	 */
	struct FDistanceDatum
	{
	public:
		float                                                      FadeInDistanceStart;                                     // 0x0000(0x0004) Edit
		float                                                      FadeInDistanceEnd;                                       // 0x0004(0x0004) Edit
		float                                                      FadeOutDistanceStart;                                    // 0x0008(0x0004) Edit
		float                                                      FadeOutDistanceEnd;                                      // 0x000C(0x0004) Edit
		float                                                      Volume;                                                  // 0x0010(0x0004) Edit
		struct FRawDistributionFloat                               FadeInDistance;                                          // 0x0014(0x0024) Component, NeedCtorLink, Deprecated
		struct FRawDistributionFloat                               FadeOutDistance;                                         // 0x0038(0x0024) Component, NeedCtorLink, Deprecated
	};

	/**
	 * ScriptStruct Engine.EngineTypes.LocalizedSubtitle
	 * Size -> 0x0024
	 */
	struct FLocalizedSubtitle
	{
	public:
		class FString                                              LanguageExt;                                             // 0x0000(0x0010) NeedCtorLink
		TArray<struct FSubtitleCue>                                Subtitles;                                               // 0x0010(0x0010) NeedCtorLink
		unsigned long                                              bMature : 1;                                             // 0x0020(0x0001) BIT_FIELD
		unsigned long                                              bManualWordWrap : 1;                                     // 0x0020(0x0001) BIT_FIELD
		unsigned long                                              bSingleLine : 1;                                         // 0x0020(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.SoundNodeWave.SoundMarkerInfo
	 * Size -> 0x0020
	 */
	struct FSoundMarkerInfo
	{
	public:
		class FString                                              Label;                                                   // 0x0000(0x0010) Edit, Const, EditConst, NeedCtorLink
		int32_t                                                    SampleNumber;                                            // 0x0010(0x0004) Edit, Const, EditConst
		int32_t                                                    SamplesToEndOfFile;                                      // 0x0014(0x0004) Edit, Const, EditConst
		float                                                      TimeOffset;                                              // 0x0018(0x0004) Edit, Const, EditConst
		float                                                      MarkerPreparationTime;                                   // 0x001C(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.LandscapeProxy.LandscapeLayerStruct
	 * Size -> 0x0030
	 */
	struct FLandscapeLayerStruct
	{
	public:
		class ULandscapeLayerInfoObject*                           LayerInfoObj;                                            // 0x0000(0x0008)
		class UMaterialInstanceConstant*                           ThumbnailMIC;                                            // 0x0008(0x0008) EditorOnly
		class ALandscapeProxy*                                     Owner;                                                   // 0x0010(0x0008) EditorOnly
		int32_t                                                    DebugColorChannel;                                       // 0x0018(0x0004) Transient, EditorOnly
		unsigned long                                              bSelected : 1;                                           // 0x001C(0x0001) BIT_FIELD Transient, EditorOnly
		class FString                                              SourceFilePath;                                          // 0x0020(0x0010) NeedCtorLink, EditorOnly
	};

	/**
	 * ScriptStruct Engine.Landscape.LandscapeLayerInfo
	 * Size -> 0x0038
	 */
	struct FLandscapeLayerInfo
	{
	public:
		class FName                                                LayerName;                                               // 0x0000(0x0008) Edit
		float                                                      Hardness;                                                // 0x0008(0x0004) Edit
		unsigned long                                              bNoWeightBlend : 1;                                      // 0x000C(0x0001) BIT_FIELD EditorOnly
		class UPhysicalMaterial*                                   PhysMaterial;                                            // 0x0010(0x0008) Edit
		class UMaterialInstanceConstant*                           ThumbnailMIC;                                            // 0x0018(0x0008) EditorOnly
		unsigned long                                              bSelected : 1;                                           // 0x0020(0x0001) BIT_FIELD Transient, EditorOnly
		int32_t                                                    DebugColorChannel;                                       // 0x0024(0x0004) Transient, EditorOnly
		class FString                                              LayerSourceFile;                                         // 0x0028(0x0010) Transient, NeedCtorLink, EditorOnly
	};

	/**
	 * ScriptStruct Engine.Terrain.TerrainHeight
	 * Size -> 0x0000
	 */
	struct FTerrainHeight
	{	};

	/**
	 * ScriptStruct Engine.Terrain.TerrainInfoData
	 * Size -> 0x0000
	 */
	struct FTerrainInfoData
	{	};

	/**
	 * ScriptStruct Engine.Terrain.TerrainLayer
	 * Size -> 0x0038
	 */
	struct FTerrainLayer
	{
	public:
		class FString                                              Name;                                                    // 0x0000(0x0010) Edit, NeedCtorLink
		class UTerrainLayerSetup*                                  Setup;                                                   // 0x0010(0x0008) Edit
		int32_t                                                    AlphaMapIndex;                                           // 0x0018(0x0004)
		unsigned long                                              Highlighted : 1;                                         // 0x001C(0x0001) BIT_FIELD Edit
		unsigned long                                              WireframeHighlighted : 1;                                // 0x001C(0x0001) BIT_FIELD Edit
		unsigned long                                              Hidden : 1;                                              // 0x001C(0x0001) BIT_FIELD Edit
		struct FColor                                              HighlightColor;                                          // 0x0020(0x0004) Edit
		struct FColor                                              WireframeColor;                                          // 0x0024(0x0004) Edit
		int32_t                                                    MinX;                                                    // 0x0028(0x0004)
		int32_t                                                    MinY;                                                    // 0x002C(0x0004)
		int32_t                                                    MaxX;                                                    // 0x0030(0x0004)
		int32_t                                                    MaxY;                                                    // 0x0034(0x0004)
	};

	/**
	 * ScriptStruct Engine.Terrain.TerrainDecorationInstance
	 * Size -> 0x0018
	 */
	struct FTerrainDecorationInstance
	{
	public:
		class UPrimitiveComponent*                                 Component;                                               // 0x0000(0x0008) ExportObject, Component, EditInline
		float                                                      X;                                                       // 0x0008(0x0004)
		float                                                      Y;                                                       // 0x000C(0x0004)
		float                                                      Scale;                                                   // 0x0010(0x0004)
		int32_t                                                    Yaw;                                                     // 0x0014(0x0004)
	};

	/**
	 * ScriptStruct Engine.Terrain.TerrainDecoration
	 * Size -> 0x002C
	 */
	struct FTerrainDecoration
	{
	public:
		class UPrimitiveComponentFactory*                          Factory;                                                 // 0x0000(0x0008) Edit, EditInline
		float                                                      MinScale;                                                // 0x0008(0x0004) Edit
		float                                                      MaxScale;                                                // 0x000C(0x0004) Edit
		float                                                      Density;                                                 // 0x0010(0x0004) Edit
		float                                                      SlopeRotationBlend;                                      // 0x0014(0x0004) Edit
		int32_t                                                    RandSeed;                                                // 0x0018(0x0004) Edit
		TArray<struct FTerrainDecorationInstance>                  Instances;                                               // 0x001C(0x0010) Component, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.Terrain.TerrainDecoLayer
	 * Size -> 0x0024
	 */
	struct FTerrainDecoLayer
	{
	public:
		class FString                                              Name;                                                    // 0x0000(0x0010) Edit, NeedCtorLink
		TArray<struct FTerrainDecoration>                          Decorations;                                             // 0x0010(0x0010) Edit, Component, NeedCtorLink
		int32_t                                                    AlphaMapIndex;                                           // 0x0020(0x0004)
	};

	/**
	 * ScriptStruct Engine.Terrain.AlphaMap
	 * Size -> 0x0000
	 */
	struct FAlphaMap
	{	};

	/**
	 * ScriptStruct Engine.Terrain.TerrainWeightedMaterial
	 * Size -> 0x0000
	 */
	struct ATerrain_FTerrainWeightedMaterial
	{	};

	/**
	 * ScriptStruct Engine.Terrain.CachedTerrainMaterialArray
	 * Size -> 0x0010
	 */
	struct FCachedTerrainMaterialArray
	{
	public:
		TArray<struct FPointer>                                    CachedMaterials;                                         // 0x0000(0x0010) Const, Native
	};

	/**
	 * ScriptStruct Engine.Terrain.SelectedTerrainVertex
	 * Size -> 0x000C
	 */
	struct FSelectedTerrainVertex
	{
	public:
		int32_t                                                    X;                                                       // 0x0000(0x0004)
		int32_t                                                    Y;                                                       // 0x0004(0x0004)
		int32_t                                                    Weight;                                                  // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.LandscapeComponent.WeightmapLayerAllocationInfo
	 * Size -> 0x000A
	 */
	struct FWeightmapLayerAllocationInfo
	{
	public:
		class FName                                                LayerName;                                               // 0x0000(0x0008)
		unsigned char                                              WeightmapTextureIndex;                                   // 0x0008(0x0001)
		unsigned char                                              WeightmapTextureChannel;                                 // 0x0009(0x0001)
	};

	/**
	 * ScriptStruct Engine.EngineTypes.LightMapRef
	 * Size -> 0x0008
	 */
	struct FLightMapRef
	{
	public:
		struct FPointer                                            Reference;                                               // 0x0000(0x0008) Const, Native
	};

	/**
	 * ScriptStruct Engine.TerrainComponent.TerrainPatchBounds
	 * Size -> 0x000C
	 */
	struct FTerrainPatchBounds
	{
	public:
		float                                                      MinHeight;                                               // 0x0000(0x0004)
		float                                                      MaxHeight;                                               // 0x0004(0x0004)
		float                                                      MaxDisplacement;                                         // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.TerrainComponent.TerrainMaterialMask
	 * Size -> 0x000C
	 */
	struct FTerrainMaterialMask
	{
	public:
		struct FQWord                                              BitMask;                                                 // 0x0000(0x0008)
		int32_t                                                    NumBits;                                                 // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.TerrainComponent.TerrainBVTree
	 * Size -> 0x0010
	 */
	struct FTerrainBVTree
	{
	public:
		TArray<int32_t>                                            Nodes;                                                   // 0x0000(0x0010) Const, Native
	};

	/**
	 * ScriptStruct Engine.TerrainLayerSetup.FilterLimit
	 * Size -> 0x0010
	 */
	struct FFilterLimit
	{
	public:
		unsigned long                                              Enabled : 1;                                             // 0x0000(0x0001) BIT_FIELD Edit
		float                                                      Base;                                                    // 0x0004(0x0004) Edit
		float                                                      NoiseScale;                                              // 0x0008(0x0004) Edit
		float                                                      NoiseAmount;                                             // 0x000C(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.TerrainLayerSetup.TerrainFilteredMaterial
	 * Size -> 0x0058
	 */
	struct FTerrainFilteredMaterial
	{
	public:
		unsigned long                                              UseNoise : 1;                                            // 0x0000(0x0001) BIT_FIELD Edit
		float                                                      NoiseScale;                                              // 0x0004(0x0004) Edit
		float                                                      NoisePercent;                                            // 0x0008(0x0004) Edit
		struct FFilterLimit                                        MinHeight;                                               // 0x000C(0x0010) Edit
		struct FFilterLimit                                        MaxHeight;                                               // 0x001C(0x0010) Edit
		struct FFilterLimit                                        MinSlope;                                                // 0x002C(0x0010) Edit
		struct FFilterLimit                                        MaxSlope;                                                // 0x003C(0x0010) Edit
		float                                                      Alpha;                                                   // 0x004C(0x0004) Edit
		class UTerrainMaterial*                                    Material;                                                // 0x0050(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.DataStoreClient.PlayerDataStoreGroup
	 * Size -> 0x0018
	 */
	struct FPlayerDataStoreGroup
	{
	public:
		class ULocalPlayer*                                        PlayerOwner;                                             // 0x0000(0x0008) Const, Transient, AlwaysInit
		TArray<class UUIDataStore*>                                DataStores;                                              // 0x0008(0x0010) Const, Transient, AlwaysInit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.Console.AutoCompleteCommand
	 * Size -> 0x0020
	 */
	struct FAutoCompleteCommand
	{
	public:
		class FString                                              Command;                                                 // 0x0000(0x0010) NeedCtorLink
		class FString                                              Desc;                                                    // 0x0010(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.Console.AutoCompleteNode
	 * Size -> 0x0024
	 */
	struct FAutoCompleteNode
	{
	public:
		int32_t                                                    IndexChar;                                               // 0x0000(0x0004)
		TArray<int32_t>                                            AutoCompleteListIndices;                                 // 0x0004(0x0010) AlwaysInit, NeedCtorLink
		TArray<struct FPointer>                                    ChildNodes;                                              // 0x0014(0x0010) AlwaysInit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.Input.KeyBind
	 * Size -> 0x001C
	 */
	struct FKeyBind
	{
	public:
		class FName                                                Name;                                                    // 0x0000(0x0008) Config
		class FString                                              Command;                                                 // 0x0008(0x0010) Config, NeedCtorLink
		unsigned long                                              Control : 1;                                             // 0x0018(0x0001) BIT_FIELD Config
		unsigned long                                              Shift : 1;                                               // 0x0018(0x0001) BIT_FIELD Config
		unsigned long                                              Alt : 1;                                                 // 0x0018(0x0001) BIT_FIELD Config
		unsigned long                                              bIgnoreCtrl : 1;                                         // 0x0018(0x0001) BIT_FIELD Config
		unsigned long                                              bIgnoreShift : 1;                                        // 0x0018(0x0001) BIT_FIELD Config
		unsigned long                                              bIgnoreAlt : 1;                                          // 0x0018(0x0001) BIT_FIELD Config
	};

	/**
	 * ScriptStruct Engine.Input.TouchTracker
	 * Size -> 0x0018
	 */
	struct FTouchTracker
	{
	public:
		int32_t                                                    Handle;                                                  // 0x0000(0x0004)
		int32_t                                                    TouchpadIndex;                                           // 0x0004(0x0004)
		struct FVector2D                                           Location;                                                // 0x0008(0x0008)
		EInputEvent                                                EventType;                                               // 0x0010(0x0001)
		unsigned char                                              UnknownData_F0R0[0x3];                                   // 0x0011(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		unsigned long                                              bTrapInput : 1;                                          // 0x0014(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.UISoundTheme.SoundEventMapping
	 * Size -> 0x0010
	 */
	struct FSoundEventMapping
	{
	public:
		class FName                                                SoundEventName;                                          // 0x0000(0x0008) Edit
		class USoundCue*                                           SoundToPlay;                                             // 0x0008(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.OnlineFriendMessage
	 * Size -> 0x002C
	 */
	struct FOnlineFriendMessage
	{
	public:
		struct FUniqueNetId                                        SendingPlayerId;                                         // 0x0000(0x0008)
		class FString                                              SendingPlayerNick;                                       // 0x0008(0x0010) NeedCtorLink
		unsigned long                                              bIsFriendInvite : 1;                                     // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bIsGameInvite : 1;                                       // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bWasAccepted : 1;                                        // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bWasDenied : 1;                                          // 0x0018(0x0001) BIT_FIELD
		class FString                                              Message;                                                 // 0x001C(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.OnlineFriend
	 * Size -> 0x0038
	 */
	struct FOnlineFriend
	{
	public:
		struct FUniqueNetId                                        UniqueId;                                                // 0x0000(0x0008) Const
		struct FQWord                                              SessionId;                                               // 0x0008(0x0008) Const
		class FString                                              NickName;                                                // 0x0010(0x0010) Const, NeedCtorLink
		class FString                                              PresenceInfo;                                            // 0x0020(0x0010) Const, NeedCtorLink
		EOnlineFriendState                                         FriendState;                                             // 0x0030(0x0001) Const
		unsigned char                                              UnknownData_YREU[0x3];                                   // 0x0031(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		unsigned long                                              bIsOnline : 1;                                           // 0x0034(0x0001) BIT_FIELD Const
		unsigned long                                              bIsPlaying : 1;                                          // 0x0034(0x0001) BIT_FIELD Const
		unsigned long                                              bIsPlayingThisGame : 1;                                  // 0x0034(0x0001) BIT_FIELD Const
		unsigned long                                              bIsJoinable : 1;                                         // 0x0034(0x0001) BIT_FIELD Const
		unsigned long                                              bHasVoiceSupport : 1;                                    // 0x0034(0x0001) BIT_FIELD Const
		unsigned long                                              bHaveInvited : 1;                                        // 0x0034(0x0001) BIT_FIELD
		unsigned long                                              bHasInvitedYou : 1;                                      // 0x0034(0x0001) BIT_FIELD Const
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.OnlinePartyMember
	 * Size -> 0x003C
	 */
	struct FOnlinePartyMember
	{
	public:
		struct FUniqueNetId                                        UniqueId;                                                // 0x0000(0x0008) Const
		class FString                                              NickName;                                                // 0x0008(0x0010) Const, NeedCtorLink
		unsigned char                                              LocalUserNum;                                            // 0x0018(0x0001) Const
		ENATType                                                   NatType;                                                 // 0x0019(0x0001) Const
		unsigned char                                              UnknownData_BH46[0x2];                                   // 0x001A(0x0002) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    TitleId;                                                 // 0x001C(0x0004) Const
		unsigned long                                              bIsLocal : 1;                                            // 0x0020(0x0001) BIT_FIELD Const
		unsigned long                                              bIsInPartyVoice : 1;                                     // 0x0020(0x0001) BIT_FIELD Const
		unsigned long                                              bIsTalking : 1;                                          // 0x0020(0x0001) BIT_FIELD Const
		unsigned long                                              bIsInGameSession : 1;                                    // 0x0020(0x0001) BIT_FIELD Const
		unsigned long                                              bIsPlayingThisGame : 1;                                  // 0x0020(0x0001) BIT_FIELD Const
		struct FQWord                                              SessionId;                                               // 0x0024(0x0008) Const
		int32_t                                                    Data1;                                                   // 0x002C(0x0004) Const
		int32_t                                                    Data2;                                                   // 0x0030(0x0004) Const
		int32_t                                                    Data3;                                                   // 0x0034(0x0004) Const
		int32_t                                                    Data4;                                                   // 0x0038(0x0004) Const
	};

	/**
	 * ScriptStruct Engine.UIDataProvider_OnlinePlayerStorage.PlayerStorageArrayProvider
	 * Size -> 0x000C
	 */
	struct FPlayerStorageArrayProvider
	{
	public:
		int32_t                                                    PlayerStorageId;                                         // 0x0000(0x0004)
		class UUIDataProvider_OnlinePlayerStorageArray*            Provider;                                                // 0x0004(0x0008)
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.AchievementDetails
	 * Size -> 0x0048
	 */
	struct FAchievementDetails
	{
	public:
		int32_t                                                    Id;                                                      // 0x0000(0x0004) Const
		class FString                                              AchievementName;                                         // 0x0004(0x0010) Const, NeedCtorLink
		class FString                                              Description;                                             // 0x0014(0x0010) Const, NeedCtorLink
		class FString                                              HowTo;                                                   // 0x0024(0x0010) Const, NeedCtorLink
		class USurface*                                            Image;                                                   // 0x0034(0x0008)
		unsigned char                                              MonthEarned;                                             // 0x003C(0x0001) Const
		unsigned char                                              DayEarned;                                               // 0x003D(0x0001) Const
		unsigned char                                              YearEarned;                                              // 0x003E(0x0001) Const
		unsigned char                                              DayOfWeekEarned;                                         // 0x003F(0x0001) Const
		int32_t                                                    GamerPoints;                                             // 0x0040(0x0004) Const
		unsigned long                                              bIsSecret : 1;                                           // 0x0044(0x0001) BIT_FIELD Const
		unsigned long                                              bWasAchievedOnline : 1;                                  // 0x0044(0x0001) BIT_FIELD Const
		unsigned long                                              bWasAchievedOffline : 1;                                 // 0x0044(0x0001) BIT_FIELD Const
	};

	/**
	 * ScriptStruct Engine.UIDataStore_DynamicResource.DynamicResourceProviderDefinition
	 * Size -> 0x0020
	 */
	struct FDynamicResourceProviderDefinition
	{
	public:
		class FName                                                ProviderTag;                                             // 0x0000(0x0008) Config
		class FString                                              ProviderClassName;                                       // 0x0008(0x0010) Config, NeedCtorLink
		class UClass*                                              ProviderClass;                                           // 0x0018(0x0008) Transient
	};

	/**
	 * ScriptStruct Engine.UIDataStore_GameResource.GameResourceDataProvider
	 * Size -> 0x0024
	 */
	struct FGameResourceDataProvider
	{
	public:
		class FName                                                ProviderTag;                                             // 0x0000(0x0008) Config
		class FString                                              ProviderClassName;                                       // 0x0008(0x0010) Config, NeedCtorLink
		unsigned long                                              bExpandProviders : 1;                                    // 0x0018(0x0001) BIT_FIELD Config
		class UClass*                                              ProviderClass;                                           // 0x001C(0x0008) Transient
	};

	/**
	 * ScriptStruct Engine.UIDataStore_Registry.RegistryKeyValuePair
	 * Size -> 0x0020
	 */
	struct FRegistryKeyValuePair
	{
	public:
		class FString                                              Key;                                                     // 0x0000(0x0010) NeedCtorLink
		class FString                                              Value;                                                   // 0x0010(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.UIDataStore_OnlineGameSearch.GameSearchCfg
	 * Size -> 0x0030
	 */
	struct FGameSearchCfg
	{
	public:
		class UClass*                                              GameSearchClass;                                         // 0x0000(0x0008)
		class UClass*                                              DefaultGameSettingsClass;                                // 0x0008(0x0008)
		class UClass*                                              SearchResultsProviderClass;                              // 0x0010(0x0008)
		class UUIDataProvider_Settings*                            DesiredSettingsProvider;                                 // 0x0018(0x0008)
		class UOnlineGameSearch*                                   Search;                                                  // 0x0020(0x0008)
		class FName                                                SearchName;                                              // 0x0028(0x0008)
	};

	/**
	 * ScriptStruct Engine.UIDataStore_OnlineStats.PlayerNickMetaData
	 * Size -> 0x0018
	 */
	struct FPlayerNickMetaData
	{
	public:
		class FName                                                PlayerNickName;                                          // 0x0000(0x0008) Const
		class FString                                              PlayerNickColumnName;                                    // 0x0008(0x0010) Const, Localized, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.UIDataStore_OnlineStats.RankMetaData
	 * Size -> 0x0018
	 */
	struct FRankMetaData
	{
	public:
		class FName                                                RankName;                                                // 0x0000(0x0008) Const
		class FString                                              RankColumnName;                                          // 0x0008(0x0010) Const, Localized, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.UIDataStore_OnlineGameSettings.GameSettingsCfg
	 * Size -> 0x0020
	 */
	struct FGameSettingsCfg
	{
	public:
		class UClass*                                              GameSettingsClass;                                       // 0x0000(0x0008)
		class UUIDataProvider_Settings*                            Provider;                                                // 0x0008(0x0008)
		class UOnlineGameSettings*                                 GameSettings;                                            // 0x0010(0x0008)
		class FName                                                SettingsName;                                            // 0x0018(0x0008)
	};

	/**
	 * ScriptStruct Engine.UIRoot.RawInputKeyEventData
	 * Size -> 0x0009
	 */
	struct FRawInputKeyEventData
	{
	public:
		class FName                                                InputKeyName;                                            // 0x0000(0x0008)
		unsigned char                                              ModifierKeyFlags;                                        // 0x0008(0x0001)
	};

	/**
	 * ScriptStruct Engine.UIDataStore_InputAlias.UIInputKeyData
	 * Size -> 0x001C
	 */
	struct FUIInputKeyData
	{
	public:
		struct FRawInputKeyEventData                               InputKeyData;                                            // 0x0000(0x000C) Config
		class FString                                              ButtonFontMarkupString;                                  // 0x000C(0x0010) Config, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.UIDataStore_InputAlias.UIDataStoreInputAlias
	 * Size -> 0x005C
	 */
	struct FUIDataStoreInputAlias
	{
	public:
		class FName                                                AliasName;                                               // 0x0000(0x0008) Config
		struct FUIInputKeyData                                     PlatformInputKeys[0x3];                                  // 0x0008(0x0054) Config, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.UIDataStore_StringAliasMap.UIMenuInputMap
	 * Size -> 0x0020
	 */
	struct FUIMenuInputMap
	{
	public:
		class FName                                                FieldName;                                               // 0x0000(0x0008)
		class FName                                                Set;                                                     // 0x0008(0x0008)
		class FString                                              MappedText;                                              // 0x0010(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.UIRoot.UIRangeData
	 * Size -> 0x0014
	 */
	struct FUIRangeData
	{
	public:
		float                                                      CurrentValue;                                            // 0x0000(0x0004) Edit
		float                                                      MinValue;                                                // 0x0004(0x0004) Edit
		float                                                      MaxValue;                                                // 0x0008(0x0004) Edit
		float                                                      NudgeValue;                                              // 0x000C(0x0004) Edit
		unsigned long                                              bIntRange : 1;                                           // 0x0010(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.FluidInfluenceActor.GHM_FluidInfluenceActor_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_FluidInfluenceActor_CheckpointRecord
	{
	public:
		unsigned long                                              bActive : 1;                                             // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bToggled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.SpeedTreeComponent.SpeedTreeStaticLight
	 * Size -> 0x0038
	 */
	struct FSpeedTreeStaticLight
	{
	public:
		struct FGuid                                               Guid;                                                    // 0x0000(0x0010) Const
		class UShadowMap1D*                                        BranchShadowMap;                                         // 0x0010(0x0008) Const
		class UShadowMap1D*                                        FrondShadowMap;                                          // 0x0018(0x0008) Const
		class UShadowMap1D*                                        LeafMeshShadowMap;                                       // 0x0020(0x0008) Const
		class UShadowMap1D*                                        LeafCardShadowMap;                                       // 0x0028(0x0008) Const
		class UShadowMap1D*                                        BillboardShadowMap;                                      // 0x0030(0x0008) Const
	};

	/**
	 * ScriptStruct Engine.LensFlareSource.GHM_LensFlareSource_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_LensFlareSource_CheckpointRecord
	{
	public:
		unsigned long                                              bCurrentlyActive : 1;                                    // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.LensFlareComponent.LensFlareElementMaterials
	 * Size -> 0x0010
	 */
	struct FLensFlareElementMaterials
	{
	public:
		TArray<class UMaterialInterface*>                          ElementMaterials;                                        // 0x0000(0x0010) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.LensFlare.LensFlareElement
	 * Size -> 0x0198
	 */
	struct FLensFlareElement
	{
	public:
		class FName                                                ElementName;                                             // 0x0000(0x0008) Edit
		float                                                      RayDistance;                                             // 0x0008(0x0004) Edit
		unsigned long                                              bIsEnabled : 1;                                          // 0x000C(0x0001) BIT_FIELD Edit
		unsigned long                                              bUseSourceDistance : 1;                                  // 0x000C(0x0001) BIT_FIELD Edit
		unsigned long                                              bNormalizeRadialDistance : 1;                            // 0x000C(0x0001) BIT_FIELD Edit
		unsigned long                                              bModulateColorBySource : 1;                              // 0x000C(0x0001) BIT_FIELD Edit
		struct FVector                                             Size;                                                    // 0x0010(0x000C) Edit
		TArray<class UMaterialInterface*>                          LFMaterials;                                             // 0x001C(0x0010) Edit, NeedCtorLink
		struct FRawDistributionFloat                               LFMaterialIndex;                                         // 0x002C(0x0024) Edit, Component, NeedCtorLink
		struct FRawDistributionFloat                               Scaling;                                                 // 0x0050(0x0024) Edit, Component, NeedCtorLink
		struct FRawDistributionVector                              AxisScaling;                                             // 0x0074(0x0024) Edit, Component, NeedCtorLink
		struct FRawDistributionFloat                               Rotation;                                                // 0x0098(0x0024) Edit, Component, NeedCtorLink
		unsigned long                                              bOrientTowardsSource : 1;                                // 0x00BC(0x0001) BIT_FIELD Edit
		struct FRawDistributionVector                              Color;                                                   // 0x00C0(0x0024) Edit, Component, NeedCtorLink
		struct FRawDistributionFloat                               Alpha;                                                   // 0x00E4(0x0024) Edit, Component, NeedCtorLink
		struct FRawDistributionVector                              Offset;                                                  // 0x0108(0x0024) Edit, Component, NeedCtorLink
		struct FRawDistributionVector                              DistMap_Scale;                                           // 0x012C(0x0024) Edit, Component, NeedCtorLink
		struct FRawDistributionVector                              DistMap_Color;                                           // 0x0150(0x0024) Edit, Component, NeedCtorLink
		struct FRawDistributionFloat                               DistMap_Alpha;                                           // 0x0174(0x0024) Edit, Component, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.Texture2DComposite.SourceTexture2DRegion
	 * Size -> 0x0020
	 */
	struct FSourceTexture2DRegion
	{
	public:
		int32_t                                                    OffsetX;                                                 // 0x0000(0x0004)
		int32_t                                                    OffsetY;                                                 // 0x0004(0x0004)
		int32_t                                                    SizeX;                                                   // 0x0008(0x0004)
		int32_t                                                    SizeY;                                                   // 0x000C(0x0004)
		int32_t                                                    DestOffsetX;                                             // 0x0010(0x0004)
		int32_t                                                    DestOffsetY;                                             // 0x0014(0x0004)
		class UTexture2D*                                          Texture2D;                                               // 0x0018(0x0008)
	};

	/**
	 * ScriptStruct Engine.AudioDevice.Listener
	 * Size -> 0x0044
	 */
	struct FListener
	{
	public:
		class APortalVolume*                                       PortalVolume;                                            // 0x0000(0x0008) Const
		struct FVector                                             Location;                                                // 0x0008(0x000C)
		struct FVector                                             Up;                                                      // 0x0014(0x000C)
		struct FVector                                             Right;                                                   // 0x0020(0x000C)
		struct FVector                                             Front;                                                   // 0x002C(0x000C)
		struct FVector                                             Velocity;                                                // 0x0038(0x000C)
	};

	/**
	 * ScriptStruct Engine.SoundClass.SoundClassProperties
	 * Size -> 0x0025
	 */
	struct FSoundClassProperties
	{
	public:
		float                                                      Volume;                                                  // 0x0000(0x0004) Edit
		float                                                      Pitch;                                                   // 0x0004(0x0004) Edit
		float                                                      StereoBleed;                                             // 0x0008(0x0004) Edit
		float                                                      LFEBleed;                                                // 0x000C(0x0004) Edit
		float                                                      VoiceCenterChannelVolume;                                // 0x0010(0x0004) Edit
		float                                                      RadioFilterVolume;                                       // 0x0014(0x0004) Edit
		float                                                      RadioFilterVolumeThreshold;                              // 0x0018(0x0004) Edit
		float                                                      MutingVolume;                                            // 0x001C(0x0004)
		unsigned long                                              bApplyEffects : 1;                                       // 0x0020(0x0001) BIT_FIELD Edit
		unsigned long                                              bAlwaysPlay : 1;                                         // 0x0020(0x0001) BIT_FIELD Edit
		unsigned long                                              bIsUISound : 1;                                          // 0x0020(0x0001) BIT_FIELD Edit
		unsigned long                                              bIsMusic : 1;                                            // 0x0020(0x0001) BIT_FIELD Edit
		unsigned long                                              bReverb : 1;                                             // 0x0020(0x0001) BIT_FIELD Edit
		unsigned long                                              bCenterChannelOnly : 1;                                  // 0x0020(0x0001) BIT_FIELD Edit
		unsigned long                                              bApplyAmbientVolumes : 1;                                // 0x0020(0x0001) BIT_FIELD Edit
		unsigned long                                              bPan2DSounds : 1;                                        // 0x0020(0x0001) BIT_FIELD Edit
		unsigned long                                              bDontStopMapChange : 1;                                  // 0x0020(0x0001) BIT_FIELD Edit
		unsigned char                                              SurvivalPriority;                                        // 0x0024(0x0001) Edit
	};

	/**
	 * ScriptStruct Engine.SoundMode.AudioEQEffect
	 * Size -> 0x0024
	 */
	struct FAudioEQEffect
	{
	public:
		struct FDouble                                             RootTime;                                                // 0x0000(0x0008) Native, Transient
		float                                                      HFFrequency;                                             // 0x0008(0x0004) Edit
		float                                                      HFGain;                                                  // 0x000C(0x0004) Edit
		float                                                      MFCutoffFrequency;                                       // 0x0010(0x0004) Edit
		float                                                      MFBandwidth;                                             // 0x0014(0x0004) Edit
		float                                                      MFGain;                                                  // 0x0018(0x0004) Edit
		float                                                      LFFrequency;                                             // 0x001C(0x0004) Edit
		float                                                      LFGain;                                                  // 0x0020(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.SoundMode.SoundClassAdjuster
	 * Size -> 0x001C
	 */
	struct FSoundClassAdjuster
	{
	public:
		ESoundClassName                                            SoundClassName;                                          // 0x0000(0x0001) Edit, Transient
		unsigned char                                              UnknownData_QNVK[0x3];                                   // 0x0001(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class FName                                                SoundClass;                                              // 0x0004(0x0008) Edit, EditConst
		float                                                      VolumeAdjuster;                                          // 0x000C(0x0004) Edit
		float                                                      PitchAdjuster;                                           // 0x0010(0x0004) Edit
		unsigned long                                              bApplyToChildren : 1;                                    // 0x0014(0x0001) BIT_FIELD Edit
		float                                                      VoiceCenterChannelVolumeAdjuster;                        // 0x0018(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.Scout.PathSizeInfo
	 * Size -> 0x0015
	 */
	struct FPathSizeInfo
	{
	public:
		class FName                                                Desc;                                                    // 0x0000(0x0008)
		float                                                      Radius;                                                  // 0x0008(0x0004)
		float                                                      Height;                                                  // 0x000C(0x0004)
		float                                                      CrouchHeight;                                            // 0x0010(0x0004)
		unsigned char                                              PathColor;                                               // 0x0014(0x0001)
	};

	/**
	 * ScriptStruct Engine.Light.GHM_Light_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_Light_CheckpointRecord
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.PointLightToggleable.CheckpointRecord
	 * Size -> 0x0004
	 */
	struct APointLightToggleable_FCheckpointRecord
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.SpotLightToggleable.CheckpointRecord
	 * Size -> 0x0004
	 */
	struct ASpotLightToggleable_FCheckpointRecord
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.EngineTypes.LightmassLightSettings
	 * Size -> 0x000C
	 */
	struct FLightmassLightSettings
	{
	public:
		float                                                      IndirectLightingScale;                                   // 0x0000(0x0004) Edit
		float                                                      IndirectLightingSaturation;                              // 0x0004(0x0004) Edit
		float                                                      ShadowExponent;                                          // 0x0008(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.EngineTypes.LightmassDirectionalLightSettings
	 * Size -> 0x0004 (FullSize[0x0010] - InheritedSize[0x000C])
	 */
	struct FLightmassDirectionalLightSettings : public FLightmassLightSettings
	{
	public:
		float                                                      LightSourceAngle;                                        // 0x000C(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.EngineTypes.DominantShadowInfo
	 * Size -> 0x00A4
	 */
	struct FDominantShadowInfo
	{
	public:
		struct FMatrix                                             WorldToLight;                                            // 0x0000(0x0040)
		struct FMatrix                                             LightToWorld;                                            // 0x0040(0x0040)
		struct FBox                                                LightSpaceImportanceBounds;                              // 0x0080(0x001C)
		int32_t                                                    ShadowMapSizeX;                                          // 0x009C(0x0004)
		int32_t                                                    ShadowMapSizeY;                                          // 0x00A0(0x0004)
	};

	/**
	 * ScriptStruct Engine.EngineTypes.LightmassPointLightSettings
	 * Size -> 0x0004 (FullSize[0x0010] - InheritedSize[0x000C])
	 */
	struct FLightmassPointLightSettings : public FLightmassLightSettings
	{
	public:
		float                                                      LightSourceRadius;                                       // 0x000C(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.SkeletalMeshComponent.BonePair
	 * Size -> 0x0010
	 */
	struct FBonePair
	{
	public:
		class FName                                                Bones[0x2];                                              // 0x0000(0x0010)
	};

	/**
	 * ScriptStruct Engine.SkeletalMeshComponent.ActiveMorph
	 * Size -> 0x000C
	 */
	struct FActiveMorph
	{
	public:
		class UMorphTarget*                                        Target;                                                  // 0x0000(0x0008)
		float                                                      Weight;                                                  // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.SkeletalMeshComponent.Attachment
	 * Size -> 0x0034
	 */
	struct FAttachment
	{
	public:
		class UActorComponent*                                     Component;                                               // 0x0000(0x0008) Edit, ExportObject, Component, EditInline
		class FName                                                BoneName;                                                // 0x0008(0x0008) Edit
		struct FVector                                             RelativeLocation;                                        // 0x0010(0x000C) Edit
		struct FRotator                                            RelativeRotation;                                        // 0x001C(0x000C) Edit
		struct FVector                                             RelativeScale;                                           // 0x0028(0x000C) Edit
	};

	/**
	 * ScriptStruct Engine.SkeletalMeshComponent.SkelMeshComponentLODInfo
	 * Size -> 0x001C
	 */
	struct FSkelMeshComponentLODInfo
	{
	public:
		TArray<unsigned long>                                      HiddenMaterials;                                         // 0x0000(0x0010) Const, NeedCtorLink
		unsigned long                                              bNeedsInstanceWeightUpdate : 1;                          // 0x0010(0x0001) BIT_FIELD Const
		unsigned long                                              bAlwaysUseInstanceWeights : 1;                           // 0x0010(0x0001) BIT_FIELD Const
		EInstanceWeightUsage                                       InstanceWeightUsage;                                     // 0x0014(0x0001) Const, Transient
		unsigned char                                              UnknownData_9HMS[0x3];                                   // 0x0015(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    InstanceWeightIdx;                                       // 0x0018(0x0004) Const, Transient
	};

	/**
	 * ScriptStruct Engine.SkeletalMesh.ApexClothingLodInfo
	 * Size -> 0x0010
	 */
	struct FApexClothingLodInfo
	{
	public:
		TArray<int32_t>                                            ClothingSectionInfo;                                     // 0x0000(0x0010) Edit, EditFixedSize, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.SkeletalMesh.ApexClothingAssetInfo
	 * Size -> 0x0018
	 */
	struct FApexClothingAssetInfo
	{
	public:
		TArray<struct FApexClothingLodInfo>                        ClothingLodInfo;                                         // 0x0000(0x0010) Edit, EditFixedSize, NeedCtorLink
		class FName                                                ClothingAssetName;                                       // 0x0010(0x0008)
	};

	/**
	 * ScriptStruct Engine.SkeletalMesh.BoneMirrorInfo
	 * Size -> 0x0005
	 */
	struct FBoneMirrorInfo
	{
	public:
		int32_t                                                    SourceIndex;                                             // 0x0000(0x0004) Edit
		EAxis                                                      BoneFlipAxis;                                            // 0x0004(0x0001) Edit
	};

	/**
	 * ScriptStruct Engine.SkeletalMesh.TriangleSortSettings
	 * Size -> 0x000C
	 */
	struct FTriangleSortSettings
	{
	public:
		ETriangleSortOption                                        TriangleSorting;                                         // 0x0000(0x0001) Edit
		ETriangleSortAxis                                          CustomLeftRightAxis;                                     // 0x0001(0x0001) Edit
		unsigned char                                              UnknownData_4UOQ[0x2];                                   // 0x0002(0x0002) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class FName                                                CustomLeftRightBoneName;                                 // 0x0004(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.SkeletalMesh.SkeletalMeshLODInfo
	 * Size -> 0x004C
	 */
	struct FSkeletalMeshLODInfo
	{
	public:
		float                                                      DisplayFactor;                                           // 0x0000(0x0004) Edit
		float                                                      LODHysteresis;                                           // 0x0004(0x0004) Edit
		TArray<int32_t>                                            LODMaterialMap;                                          // 0x0008(0x0010) Edit, EditFixedSize, NeedCtorLink
		TArray<unsigned long>                                      bEnableShadowCasting;                                    // 0x0018(0x0010) Edit, EditFixedSize, NeedCtorLink
		TArray<ETriangleSortOption>                                TriangleSorting;                                         // 0x0028(0x0010) NeedCtorLink, Deprecated
		TArray<struct FTriangleSortSettings>                       TriangleSortSettings;                                    // 0x0038(0x0010) Edit, EditFixedSize, NeedCtorLink
		unsigned long                                              bDisableCompressions : 1;                                // 0x0048(0x0001) BIT_FIELD Edit
		unsigned long                                              bHasBeenSimplified : 1;                                  // 0x0048(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.SkeletalMesh.SkeletalMeshOptimizationSettings
	 * Size -> 0x0009
	 */
	struct FSkeletalMeshOptimizationSettings
	{
	public:
		float                                                      MaxDeviationPercentage;                                  // 0x0000(0x0004)
		ESkeletalMeshOptimizationImportance                        SilhouetteImportance;                                    // 0x0004(0x0001)
		ESkeletalMeshOptimizationImportance                        TextureImportance;                                       // 0x0005(0x0001)
		ESkeletalMeshOptimizationImportance                        ShadingImportance;                                       // 0x0006(0x0001)
		ESkeletalMeshOptimizationImportance                        SkinningImportance;                                      // 0x0007(0x0001)
		ESkeletalMeshOptimizationNormalMode                        NormalMode;                                              // 0x0008(0x0001)
	};

	/**
	 * ScriptStruct Engine.SkeletalMesh.ClothSpecialBoneInfo
	 * Size -> 0x001C
	 */
	struct FClothSpecialBoneInfo
	{
	public:
		class FName                                                BoneName;                                                // 0x0000(0x0008) Edit
		EClothBoneType                                             BoneType;                                                // 0x0008(0x0001) Edit
		unsigned char                                              UnknownData_LZ1G[0x3];                                   // 0x0009(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		TArray<int32_t>                                            AttachedVertexIndices;                                   // 0x000C(0x0010) Const, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.SkeletalMesh.SoftBodyTetraLink
	 * Size -> 0x0010
	 */
	struct FSoftBodyTetraLink
	{
	public:
		int32_t                                                    Index;                                                   // 0x0000(0x0004)
		struct FVector                                             Bary;                                                    // 0x0004(0x000C)
	};

	/**
	 * ScriptStruct Engine.SkeletalMesh.SoftBodySpecialBoneInfo
	 * Size -> 0x001C
	 */
	struct FSoftBodySpecialBoneInfo
	{
	public:
		class FName                                                BoneName;                                                // 0x0000(0x0008) Edit
		ESoftBodyBoneType                                          BoneType;                                                // 0x0008(0x0001) Edit
		unsigned char                                              UnknownData_39TV[0x3];                                   // 0x0009(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		TArray<int32_t>                                            AttachedVertexIndices;                                   // 0x000C(0x0010) Const, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.SplineActor.GHM_SplineActor_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_SplineActor_CheckpointRecord
	{
	public:
		unsigned long                                              bDisableDestination : 1;                                 // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.SplineActor.SplineConnection
	 * Size -> 0x0010
	 */
	struct FSplineConnection
	{
	public:
		class USplineComponent*                                    SplineComponent;                                         // 0x0000(0x0008) Edit, ExportObject, Component, EditInline
		class ASplineActor*                                        ConnectTo;                                               // 0x0008(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.ProcBuilding.PBMeshCompInfo
	 * Size -> 0x000C
	 */
	struct FPBMeshCompInfo
	{
	public:
		class UStaticMeshComponent*                                MeshComp;                                                // 0x0000(0x0008) ExportObject, Component, EditInline
		int32_t                                                    TopLevelScopeIndex;                                      // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.ProcBuilding.PBFracMeshCompInfo
	 * Size -> 0x000C
	 */
	struct FPBFracMeshCompInfo
	{
	public:
		class UFracturedStaticMeshComponent*                       FracMeshComp;                                            // 0x0000(0x0008) ExportObject, Component, EditInline
		int32_t                                                    TopLevelScopeIndex;                                      // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.ProcBuilding.PBFaceUVInfo
	 * Size -> 0x0010
	 */
	struct FPBFaceUVInfo
	{
	public:
		struct FVector2D                                           Offset;                                                  // 0x0000(0x0008)
		struct FVector2D                                           Size;                                                    // 0x0008(0x0008)
	};

	/**
	 * ScriptStruct Engine.ProcBuilding.PBScope2D
	 * Size -> 0x0048
	 */
	struct FPBScope2D
	{
	public:
		struct FMatrix                                             ScopeFrame;                                              // 0x0000(0x0040)
		float                                                      DimX;                                                    // 0x0040(0x0004)
		float                                                      DimZ;                                                    // 0x0044(0x0004)
	};

	/**
	 * ScriptStruct Engine.ProcBuilding.PBScopeProcessInfo
	 * Size -> 0x001C
	 */
	struct FPBScopeProcessInfo
	{
	public:
		class AProcBuilding*                                       OwningBuilding;                                          // 0x0000(0x0008)
		class UProcBuildingRuleset*                                Ruleset;                                                 // 0x0008(0x0008)
		class FName                                                RulesetVariation;                                        // 0x0010(0x0008)
		unsigned long                                              bGenerateLODPoly : 1;                                    // 0x0018(0x0001) BIT_FIELD
		unsigned long                                              bPartOfNonRect : 1;                                      // 0x0018(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.ProcBuilding.PBEdgeInfo
	 * Size -> 0x002C
	 */
	struct FPBEdgeInfo
	{
	public:
		struct FVector                                             EdgeEnd;                                                 // 0x0000(0x000C)
		struct FVector                                             EdgeStart;                                               // 0x000C(0x000C)
		int32_t                                                    ScopeAIndex;                                             // 0x0018(0x0004)
		EScopeEdge                                                 ScopeAEdge;                                              // 0x001C(0x0001)
		unsigned char                                              UnknownData_RZUX[0x3];                                   // 0x001D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    ScopeBIndex;                                             // 0x0020(0x0004)
		EScopeEdge                                                 ScopeBEdge;                                              // 0x0024(0x0001)
		unsigned char                                              UnknownData_W790[0x3];                                   // 0x0025(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      EdgeAngle;                                               // 0x0028(0x0004)
	};

	/**
	 * ScriptStruct Engine.ProcBuilding.PBMaterialParam
	 * Size -> 0x0018
	 */
	struct FPBMaterialParam
	{
	public:
		class FName                                                ParamName;                                               // 0x0000(0x0008) Edit
		struct FLinearColor                                        Color;                                                   // 0x0008(0x0010) Edit
	};

	/**
	 * ScriptStruct Engine.PBRuleNodeBase.PBRuleLink
	 * Size -> 0x0014
	 */
	struct FPBRuleLink
	{
	public:
		class UPBRuleNodeBase*                                     NextRule;                                                // 0x0000(0x0008) Edit, ExportObject, NeedCtorLink, EditInline
		class FName                                                LinkName;                                                // 0x0008(0x0008) Edit
		int32_t                                                    DrawY;                                                   // 0x0010(0x0004) EditorOnly
	};

	/**
	 * ScriptStruct Engine.PBRuleNodeCorner.RBCornerAngleInfo
	 * Size -> 0x0008
	 */
	struct FRBCornerAngleInfo
	{
	public:
		float                                                      Angle;                                                   // 0x0000(0x0004) Edit
		float                                                      CornerSize;                                              // 0x0004(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.PBRuleNodeEdgeAngle.RBEdgeAngleInfo
	 * Size -> 0x0004
	 */
	struct FRBEdgeAngleInfo
	{
	public:
		float                                                      Angle;                                                   // 0x0000(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.PBRuleNodeMesh.BuildingMatOverrides
	 * Size -> 0x0010
	 */
	struct FBuildingMatOverrides
	{
	public:
		TArray<class UMaterialInterface*>                          MaterialOptions;                                         // 0x0000(0x0010) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.PBRuleNodeMesh.BuildingMeshInfo
	 * Size -> 0x004C
	 */
	struct FBuildingMeshInfo
	{
	public:
		class UStaticMesh*                                         Mesh;                                                    // 0x0000(0x0008) Edit
		float                                                      DimX;                                                    // 0x0008(0x0004) Edit
		float                                                      DimZ;                                                    // 0x000C(0x0004) Edit
		float                                                      Chance;                                                  // 0x0010(0x0004) Edit
		class UDistributionVector*                                 Translation;                                             // 0x0014(0x0008) Edit, ExportObject, Component, EditInline
		class UDistributionVector*                                 Rotation;                                                // 0x001C(0x0008) Edit, ExportObject, Component, EditInline
		unsigned long                                              bMeshScaleTranslation : 1;                               // 0x0024(0x0001) BIT_FIELD Edit
		unsigned long                                              bOverrideMeshLightMapRes : 1;                            // 0x0024(0x0001) BIT_FIELD Edit
		int32_t                                                    OverriddenMeshLightMapRes;                               // 0x0028(0x0004) Edit
		TArray<class UMaterialInterface*>                          MaterialOverrides;                                       // 0x002C(0x0010) NeedCtorLink
		TArray<struct FBuildingMatOverrides>                       SectionOverrides;                                        // 0x003C(0x0010) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.PBRuleNodeSplit.RBSplitInfo
	 * Size -> 0x0014
	 */
	struct FRBSplitInfo
	{
	public:
		unsigned long                                              bFixSize : 1;                                            // 0x0000(0x0001) BIT_FIELD Edit
		float                                                      FixedSize;                                               // 0x0004(0x0004) Edit
		float                                                      ExpandRatio;                                             // 0x0008(0x0004) Edit
		class FName                                                SplitName;                                               // 0x000C(0x0008) Edit
	};

	/**
	 * ScriptStruct Engine.ProcBuildingRuleset.PBVariationInfo
	 * Size -> 0x000C
	 */
	struct FPBVariationInfo
	{
	public:
		class FName                                                VariationName;                                           // 0x0000(0x0008) Edit
		unsigned long                                              bMeshOnTopOfFacePoly : 1;                                // 0x0008(0x0001) BIT_FIELD Edit
	};

	/**
	 * ScriptStruct Engine.ProcBuildingRuleset.PBParamSwatch
	 * Size -> 0x0018
	 */
	struct FPBParamSwatch
	{
	public:
		class FName                                                SwatchName;                                              // 0x0000(0x0008) Edit
		TArray<struct FPBMaterialParam>                            Params;                                                  // 0x0008(0x0010) Edit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.PlayerReplicationInfo.AutomatedTestingDatum
	 * Size -> 0x0008
	 */
	struct FAutomatedTestingDatum
	{
	public:
		int32_t                                                    NumberOfMatchesPlayed;                                   // 0x0000(0x0004)
		int32_t                                                    NumMapListCyclesDone;                                    // 0x0004(0x0004)
	};

	/**
	 * ScriptStruct Engine.CameraModifier_CameraShake.CameraShakeInstance
	 * Size -> 0x0090
	 */
	struct FCameraShakeInstance
	{
	public:
		class UCameraShake*                                        SourceShake;                                             // 0x0000(0x0008)
		class FName                                                SourceShakeName;                                         // 0x0008(0x0008)
		float                                                      OscillatorTimeRemaining;                                 // 0x0010(0x0004)
		unsigned long                                              bBlendingIn : 1;                                         // 0x0014(0x0001) BIT_FIELD
		float                                                      CurrentBlendInTime;                                      // 0x0018(0x0004)
		unsigned long                                              bBlendingOut : 1;                                        // 0x001C(0x0001) BIT_FIELD
		float                                                      CurrentBlendOutTime;                                     // 0x0020(0x0004)
		struct FVector                                             LocSinOffset;                                            // 0x0024(0x000C)
		struct FVector                                             RotSinOffset;                                            // 0x0030(0x000C)
		float                                                      FOVSinOffset;                                            // 0x003C(0x0004)
		float                                                      Scale;                                                   // 0x0040(0x0004)
		class UCameraAnimInst*                                     AnimInst;                                                // 0x0044(0x0008)
		ECameraAnimPlaySpace                                       PlaySpace;                                               // 0x004C(0x0001)
		unsigned char                                              UnknownData_B5S2[0x3];                                   // 0x004D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct FMatrix                                             UserPlaySpaceMatrix;                                     // 0x0050(0x0040)
	};

	/**
	 * ScriptStruct Engine.CameraShake.FOscillator
	 * Size -> 0x0009
	 */
	struct FFOscillator
	{
	public:
		float                                                      Amplitude;                                               // 0x0000(0x0004) Edit
		float                                                      Frequency;                                               // 0x0004(0x0004) Edit
		EInitialOscillatorOffset                                   InitialOffset;                                           // 0x0008(0x0001) Edit
	};

	/**
	 * ScriptStruct Engine.CameraShake.ROscillator
	 * Size -> 0x0024
	 */
	struct FROscillator
	{
	public:
		struct FFOscillator                                        Pitch;                                                   // 0x0000(0x000C) Edit
		struct FFOscillator                                        Yaw;                                                     // 0x000C(0x000C) Edit
		struct FFOscillator                                        Roll;                                                    // 0x0018(0x000C) Edit
	};

	/**
	 * ScriptStruct Engine.CameraShake.VOscillator
	 * Size -> 0x0024
	 */
	struct FVOscillator
	{
	public:
		struct FFOscillator                                        X;                                                       // 0x0000(0x000C) Edit
		struct FFOscillator                                        Y;                                                       // 0x000C(0x000C) Edit
		struct FFOscillator                                        Z;                                                       // 0x0018(0x000C) Edit
	};

	/**
	 * ScriptStruct Engine.AnalyticEventsBase.EventStringParam
	 * Size -> 0x0020
	 */
	struct FEventStringParam
	{
	public:
		class FString                                              ParamName;                                               // 0x0000(0x0010) NeedCtorLink
		class FString                                              ParamValue;                                              // 0x0010(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.FacebookIntegration.FacebookFriend
	 * Size -> 0x0020
	 */
	struct FFacebookFriend
	{
	public:
		class FString                                              Name;                                                    // 0x0000(0x0010) NeedCtorLink
		class FString                                              Id;                                                      // 0x0010(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.MicroTransactionBase.PurchaseInfo
	 * Size -> 0x0040
	 */
	struct FPurchaseInfo
	{
	public:
		class FString                                              Identifier;                                              // 0x0000(0x0010) NeedCtorLink
		class FString                                              DisplayName;                                             // 0x0010(0x0010) NeedCtorLink
		class FString                                              DisplayDescription;                                      // 0x0020(0x0010) NeedCtorLink
		class FString                                              DisplayPrice;                                            // 0x0030(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.Actor.AnimSlotDesc
	 * Size -> 0x000C
	 */
	struct FAnimSlotDesc
	{
	public:
		class FName                                                SlotName;                                                // 0x0000(0x0008) AlwaysInit
		int32_t                                                    NumChannels;                                             // 0x0008(0x0004) AlwaysInit
	};

	/**
	 * ScriptStruct Engine.Actor.NavReference
	 * Size -> 0x0018
	 */
	struct FNavReference
	{
	public:
		class ANavigationPoint*                                    Nav;                                                     // 0x0000(0x0008) Edit
		struct FGuid                                               Guid;                                                    // 0x0008(0x0010) Edit, Const, EditConst
	};

	/**
	 * ScriptStruct Engine.Info.KeyValuePair
	 * Size -> 0x0020
	 */
	struct FKeyValuePair
	{
	public:
		class FString                                              Key;                                                     // 0x0000(0x0010) Edit, AlwaysInit, NeedCtorLink
		class FString                                              Value;                                                   // 0x0010(0x0010) Edit, AlwaysInit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.Info.PlayerResponseLine
	 * Size -> 0x0034
	 */
	struct FPlayerResponseLine
	{
	public:
		int32_t                                                    PlayerNum;                                               // 0x0000(0x0004) Edit, AlwaysInit
		int32_t                                                    PlayerID;                                                // 0x0004(0x0004) Edit, AlwaysInit
		class FString                                              PlayerName;                                              // 0x0008(0x0010) Edit, AlwaysInit, NeedCtorLink
		int32_t                                                    Ping;                                                    // 0x0018(0x0004) Edit, AlwaysInit
		int32_t                                                    Score;                                                   // 0x001C(0x0004) Edit, AlwaysInit
		int32_t                                                    StatsID;                                                 // 0x0020(0x0004) Edit, AlwaysInit
		TArray<struct FKeyValuePair>                               PlayerInfo;                                              // 0x0024(0x0010) Edit, AlwaysInit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.Info.ServerResponseLine
	 * Size -> 0x0078
	 */
	struct FServerResponseLine
	{
	public:
		int32_t                                                    ServerID;                                                // 0x0000(0x0004) Edit, AlwaysInit
		class FString                                              IP;                                                      // 0x0004(0x0010) Edit, AlwaysInit, NeedCtorLink
		int32_t                                                    Port;                                                    // 0x0014(0x0004) Edit, AlwaysInit
		int32_t                                                    QueryPort;                                               // 0x0018(0x0004) Edit, AlwaysInit
		class FString                                              ServerName;                                              // 0x001C(0x0010) Edit, AlwaysInit, NeedCtorLink
		class FString                                              MapName;                                                 // 0x002C(0x0010) Edit, AlwaysInit, NeedCtorLink
		class FString                                              GameType;                                                // 0x003C(0x0010) Edit, AlwaysInit, NeedCtorLink
		int32_t                                                    CurrentPlayers;                                          // 0x004C(0x0004) Edit, AlwaysInit
		int32_t                                                    MaxPlayers;                                              // 0x0050(0x0004) Edit, AlwaysInit
		int32_t                                                    Ping;                                                    // 0x0054(0x0004) Edit, AlwaysInit
		TArray<struct FKeyValuePair>                               ServerInfo;                                              // 0x0058(0x0010) Edit, AlwaysInit, NeedCtorLink
		TArray<struct FPlayerResponseLine>                         PlayerInfo;                                              // 0x0068(0x0010) Edit, AlwaysInit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.SocialPostImageFlags
	 * Size -> 0x0004
	 */
	struct FSocialPostImageFlags
	{
	public:
		unsigned long                                              bIsUserGeneratedImage : 1;                               // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bIsGameGeneratedImage : 1;                               // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bIsAchievementImage : 1;                                 // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bIsMediaImage : 1;                                       // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.SocialPostImageInfo
	 * Size -> 0x0044
	 */
	struct FSocialPostImageInfo
	{
	public:
		struct FSocialPostImageFlags                               Flags;                                                   // 0x0000(0x0004)
		class FString                                              MessageText;                                             // 0x0004(0x0010) NeedCtorLink
		class FString                                              TitleText;                                               // 0x0014(0x0010) NeedCtorLink
		class FString                                              PictureCaption;                                          // 0x0024(0x0010) NeedCtorLink
		class FString                                              PictureDescription;                                      // 0x0034(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.SocialPostLinkInfo
	 * Size -> 0x0020 (FullSize[0x0064] - InheritedSize[0x0044])
	 */
	struct FSocialPostLinkInfo : public FSocialPostImageInfo
	{
	public:
		class FString                                              TitleURL;                                                // 0x0044(0x0010) NeedCtorLink
		class FString                                              PictureURL;                                              // 0x0054(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.FriendsQuery
	 * Size -> 0x000C
	 */
	struct FFriendsQuery
	{
	public:
		struct FUniqueNetId                                        UniqueId;                                                // 0x0000(0x0008)
		unsigned long                                              bIsFriend : 1;                                           // 0x0008(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.EmsFile
	 * Size -> 0x0034
	 */
	struct FEmsFile
	{
	public:
		class FString                                              Hash;                                                    // 0x0000(0x0010) NeedCtorLink
		class FString                                              DLName;                                                  // 0x0010(0x0010) NeedCtorLink
		class FString                                              Filename;                                                // 0x0020(0x0010) NeedCtorLink
		int32_t                                                    FileSize;                                                // 0x0030(0x0004)
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.SocialPostPrivileges
	 * Size -> 0x0004
	 */
	struct FSocialPostPrivileges
	{
	public:
		unsigned long                                              bCanPostImage : 1;                                       // 0x0000(0x0001) BIT_FIELD Const
		unsigned long                                              bCanPostLink : 1;                                        // 0x0000(0x0001) BIT_FIELD Const
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.SpeechRecognizedWord
	 * Size -> 0x0018
	 */
	struct FSpeechRecognizedWord
	{
	public:
		int32_t                                                    WordId;                                                  // 0x0000(0x0004)
		class FString                                              WordText;                                                // 0x0004(0x0010) NeedCtorLink
		float                                                      Confidence;                                              // 0x0014(0x0004)
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.OnlineCrossTitleContent
	 * Size -> 0x0004 (FullSize[0x0064] - InheritedSize[0x0060])
	 */
	struct FOnlineCrossTitleContent : public FOnlineContent
	{
	public:
		int32_t                                                    TitleId;                                                 // 0x0060(0x0004)
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.CommunityContentMetadata
	 * Size -> 0x0014
	 */
	struct FCommunityContentMetadata
	{
	public:
		int32_t                                                    ContentType;                                             // 0x0000(0x0004)
		TArray<struct FSettingsProperty>                           MetadataItems;                                           // 0x0004(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.CommunityContentFile
	 * Size -> 0x0038
	 */
	struct FCommunityContentFile
	{
	public:
		int32_t                                                    ContentId;                                               // 0x0000(0x0004)
		int32_t                                                    FileId;                                                  // 0x0004(0x0004)
		int32_t                                                    ContentType;                                             // 0x0008(0x0004)
		int32_t                                                    FileSize;                                                // 0x000C(0x0004)
		struct FUniqueNetId                                        Owner;                                                   // 0x0010(0x0008)
		int32_t                                                    DownloadCount;                                           // 0x0018(0x0004)
		float                                                      AverageRating;                                           // 0x001C(0x0004)
		int32_t                                                    RatingCount;                                             // 0x0020(0x0004)
		int32_t                                                    LastRatingGiven;                                         // 0x0024(0x0004)
		class FString                                              LocalFilePath;                                           // 0x0028(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.TitleFile
	 * Size -> 0x0024
	 */
	struct FTitleFile
	{
	public:
		class FString                                              Filename;                                                // 0x0000(0x0010) NeedCtorLink
		EOnlineEnumerationReadState                                AsyncState;                                              // 0x0010(0x0001)
		unsigned char                                              UnknownData_FYQV[0x3];                                   // 0x0011(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		TArray<unsigned char>                                      Data;                                                    // 0x0014(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.RemoteTalker
	 * Size -> 0x0010
	 */
	struct FRemoteTalker
	{
	public:
		struct FUniqueNetId                                        TalkerId;                                                // 0x0000(0x0008)
		float                                                      LastNotificationTime;                                    // 0x0008(0x0004)
		unsigned long                                              bWasTalking : 1;                                         // 0x000C(0x0001) BIT_FIELD
		unsigned long                                              bIsTalking : 1;                                          // 0x000C(0x0001) BIT_FIELD
		unsigned long                                              bIsRegistered : 1;                                       // 0x000C(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.OnlineSubsystem.LocalTalker
	 * Size -> 0x0004
	 */
	struct FLocalTalker
	{
	public:
		unsigned long                                              bHasVoice : 1;                                           // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bHasNetworkedVoice : 1;                                  // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bIsRecognizingSpeech : 1;                                // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bWasTalking : 1;                                         // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bIsTalking : 1;                                          // 0x0000(0x0001) BIT_FIELD
		unsigned long                                              bIsRegistered : 1;                                       // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.OnlinePartyInterface.UserProfileInfo
	 * Size -> 0x003C
	 */
	struct FUserProfileInfo
	{
	public:
		struct FUniqueNetId                                        ForId;                                                   // 0x0000(0x0008)
		class FString                                              PlayerName;                                              // 0x0008(0x0010) AlwaysInit, NeedCtorLink
		int32_t                                                    Experience;                                              // 0x0018(0x0004)
		unsigned long                                              bFemaleChar : 1;                                         // 0x001C(0x0001) BIT_FIELD
		struct FQWord                                              BadgeData;                                               // 0x0020(0x0008)
		int32_t                                                    TitleIndex;                                              // 0x0028(0x0004)
		class FString                                              LastSeenTime;                                            // 0x002C(0x0010) AlwaysInit, NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.AccessControl.PendingClientAuth
	 * Size -> 0x001C
	 */
	struct FPendingClientAuth
	{
	public:
		class UPlayer*                                             ClientConnection;                                        // 0x0000(0x0008)
		struct FUniqueNetId                                        ClientUID;                                               // 0x0008(0x0008)
		struct FDouble                                             AuthTimestamp;                                           // 0x0010(0x0008)
		int32_t                                                    AuthRetryCount;                                          // 0x0018(0x0004)
	};

	/**
	 * ScriptStruct Engine.AccessControl.ServerAuthRetry
	 * Size -> 0x000C
	 */
	struct FServerAuthRetry
	{
	public:
		struct FUniqueNetId                                        ClientUID;                                               // 0x0000(0x0008)
		int32_t                                                    AuthRetryCount;                                          // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.CoverReplicator.ManualCoverTypeInfo
	 * Size -> 0x0002
	 */
	struct FManualCoverTypeInfo
	{
	public:
		unsigned char                                              SlotIndex;                                               // 0x0000(0x0001)
		ECoverType                                                 ManualCoverType;                                         // 0x0001(0x0001)
	};

	/**
	 * ScriptStruct Engine.CoverReplicator.CoverReplicationInfo
	 * Size -> 0x0048
	 */
	struct FCoverReplicationInfo
	{
	public:
		class ACoverLink*                                          Link;                                                    // 0x0000(0x0008)
		TArray<unsigned char>                                      SlotsEnabled;                                            // 0x0008(0x0010) NeedCtorLink
		TArray<unsigned char>                                      SlotsDisabled;                                           // 0x0018(0x0010) NeedCtorLink
		TArray<unsigned char>                                      SlotsAdjusted;                                           // 0x0028(0x0010) NeedCtorLink
		TArray<struct FManualCoverTypeInfo>                        SlotsCoverTypeChanged;                                   // 0x0038(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.AudioDevice.AudioClassInfo
	 * Size -> 0x0010
	 */
	struct FAudioClassInfo
	{
	public:
		int32_t                                                    NumResident;                                             // 0x0000(0x0004) Const
		int32_t                                                    SizeResident;                                            // 0x0004(0x0004) Const
		int32_t                                                    NumRealTime;                                             // 0x0008(0x0004) Const
		int32_t                                                    SizeRealTime;                                            // 0x000C(0x0004) Const
	};

	/**
	 * ScriptStruct Engine.SoundCue.SoundNodeEditorData
	 * Size -> 0x0008
	 */
	struct FSoundNodeEditorData
	{
	public:
		int32_t                                                    NodePosX;                                                // 0x0000(0x0004) Const, Native
		int32_t                                                    NodePosY;                                                // 0x0004(0x0004) Const, Native
	};

	/**
	 * ScriptStruct Engine.AnimSequence.CompressedTrack
	 * Size -> 0x0038
	 */
	struct FCompressedTrack
	{
	public:
		TArray<unsigned char>                                      ByteStream;                                              // 0x0000(0x0010) NeedCtorLink
		TArray<float>                                              Times;                                                   // 0x0010(0x0010) NeedCtorLink
		float                                                      Mins[0x3];                                               // 0x0020(0x000C)
		float                                                      Ranges[0x3];                                             // 0x002C(0x000C)
	};

	/**
	 * ScriptStruct Engine.EngineTypes.LightmassDebugOptions
	 * Size -> 0x0014
	 */
	struct FLightmassDebugOptions
	{
	public:
		unsigned long                                              bDebugMode : 1;                                          // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bStatsEnabled : 1;                                       // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bGatherBSPSurfacesAcrossComponents : 1;                  // 0x0000(0x0001) BIT_FIELD Edit
		float                                                      CoplanarTolerance;                                       // 0x0004(0x0004) Edit
		unsigned long                                              bUseDeterministicLighting : 1;                           // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bUseImmediateImport : 1;                                 // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bImmediateProcessMappings : 1;                           // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bSortMappings : 1;                                       // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bDumpBinaryFiles : 1;                                    // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bDebugMaterials : 1;                                     // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bPadMappings : 1;                                        // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bDebugPaddings : 1;                                      // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bOnlyCalcDebugTexelMappings : 1;                         // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bUseRandomColors : 1;                                    // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bColorBordersGreen : 1;                                  // 0x0008(0x0001) BIT_FIELD Edit
		unsigned long                                              bColorByExecutionTime : 1;                               // 0x0008(0x0001) BIT_FIELD Edit
		float                                                      ExecutionTimeDivisor;                                    // 0x000C(0x0004) Edit
		unsigned long                                              bInitialized : 1;                                        // 0x0010(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.EngineTypes.SwarmDebugOptions
	 * Size -> 0x0004
	 */
	struct FSwarmDebugOptions
	{
	public:
		unsigned long                                              bDistributionEnabled : 1;                                // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bForceContentExport : 1;                                 // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bInitialized : 1;                                        // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.Texture2D.Texture2DMipMap
	 * Size -> 0x0058
	 */
	struct FTexture2DMipMap
	{
	public:
		struct FUntypedBulkData_Mirror                             Data;                                                    // 0x0000(0x0050) Native
		int32_t                                                    SizeX;                                                   // 0x0050(0x0004) Native
		int32_t                                                    SizeY;                                                   // 0x0054(0x0004) Native
	};

	/**
	 * ScriptStruct Engine.Canvas.MobileDistanceFieldParams
	 * Size -> 0x0054
	 */
	struct FMobileDistanceFieldParams
	{
	public:
		float                                                      Gamma;                                                   // 0x0000(0x0004)
		float                                                      AlphaRefVal;                                             // 0x0004(0x0004)
		float                                                      SmoothWidth;                                             // 0x0008(0x0004)
		unsigned long                                              EnableShadow : 1;                                        // 0x000C(0x0001) BIT_FIELD
		struct FVector2D                                           ShadowDirection;                                         // 0x0010(0x0008)
		struct FLinearColor                                        ShadowColor;                                             // 0x0018(0x0010)
		float                                                      ShadowSmoothWidth;                                       // 0x0028(0x0004)
		struct FDepthFieldGlowInfo                                 GlowInfo;                                                // 0x002C(0x0024) Native
		int32_t                                                    BlendMode;                                               // 0x0050(0x0004)
	};

	/**
	 * ScriptStruct Engine.Canvas.TextSizingParameters
	 * Size -> 0x002C
	 */
	struct FTextSizingParameters
	{
	public:
		float                                                      DrawX;                                                   // 0x0000(0x0004) AlwaysInit
		float                                                      DrawY;                                                   // 0x0004(0x0004) AlwaysInit
		float                                                      DrawXL;                                                  // 0x0008(0x0004) AlwaysInit
		float                                                      DrawYL;                                                  // 0x000C(0x0004) AlwaysInit
		struct FVector2D                                           Scaling;                                                 // 0x0010(0x0008) AlwaysInit
		class UFont*                                               DrawFont;                                                // 0x0018(0x0008) AlwaysInit
		struct FVector2D                                           SpacingAdjust;                                           // 0x0020(0x0008) AlwaysInit
		float                                                      ViewportHeight;                                          // 0x0028(0x0004) AlwaysInit
	};

	/**
	 * ScriptStruct Engine.Canvas.WrappedStringElement
	 * Size -> 0x0018
	 */
	struct FWrappedStringElement
	{
	public:
		class FString                                              Value;                                                   // 0x0000(0x0010) AlwaysInit, NeedCtorLink
		struct FVector2D                                           LineExtent;                                              // 0x0010(0x0008) AlwaysInit
	};

	/**
	 * ScriptStruct Engine.UIRoot.TextureCoordinates
	 * Size -> 0x0010
	 */
	struct FTextureCoordinates
	{
	public:
		float                                                      U;                                                       // 0x0000(0x0004) Edit
		float                                                      V;                                                       // 0x0004(0x0004) Edit
		float                                                      UL;                                                      // 0x0008(0x0004) Edit
		float                                                      VL;                                                      // 0x000C(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.UIRoot.InputKeyAction
	 * Size -> 0x002C
	 */
	struct FInputKeyAction
	{
	public:
		class FName                                                InputKeyName;                                            // 0x0000(0x0008) Edit
		EInputEvent                                                InputKeyState;                                           // 0x0008(0x0001) Edit
		unsigned char                                              UnknownData_UVP9[0x3];                                   // 0x0009(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		TArray<struct FSeqOpOutputInputLink>                       TriggeredOps;                                            // 0x000C(0x0010) NeedCtorLink
		TArray<class USequenceOp*>                                 ActionsToExecute;                                        // 0x001C(0x0010) NeedCtorLink, Deprecated
	};

	/**
	 * ScriptStruct Engine.UIRoot.InputEventParameters
	 * Size -> 0x0020
	 */
	struct FInputEventParameters
	{
	public:
		int32_t                                                    PlayerIndex;                                             // 0x0000(0x0004) Const, Transient, AlwaysInit
		int32_t                                                    ControllerId;                                            // 0x0004(0x0004) Const, Transient, AlwaysInit
		class FName                                                InputKeyName;                                            // 0x0008(0x0008) Const, Transient, AlwaysInit
		EInputEvent                                                EventType;                                               // 0x0010(0x0001) Const, Transient, AlwaysInit
		unsigned char                                              UnknownData_DDOX[0x3];                                   // 0x0011(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      InputDelta;                                              // 0x0014(0x0004) Const, Transient, AlwaysInit
		float                                                      DeltaTime;                                               // 0x0018(0x0004) Const, Transient, AlwaysInit
		unsigned long                                              bAltPressed : 1;                                         // 0x001C(0x0001) BIT_FIELD Const, Transient, AlwaysInit
		unsigned long                                              bCtrlPressed : 1;                                        // 0x001C(0x0001) BIT_FIELD Const, Transient, AlwaysInit
		unsigned long                                              bShiftPressed : 1;                                       // 0x001C(0x0001) BIT_FIELD Const, Transient, AlwaysInit
	};

	/**
	 * ScriptStruct Engine.UIRoot.SubscribedInputEventParameters
	 * Size -> 0x0008 (FullSize[0x0028] - InheritedSize[0x0020])
	 */
	struct FSubscribedInputEventParameters : public FInputEventParameters
	{
	public:
		class FName                                                InputAliasName;                                          // 0x0020(0x0008) Const, Transient, AlwaysInit
	};

	/**
	 * ScriptStruct Engine.CoverLink.CovPosInfo
	 * Size -> 0x0038
	 */
	struct FCovPosInfo
	{
	public:
		class ACoverLink*                                          Link;                                                    // 0x0000(0x0008)
		int32_t                                                    LtSlotIdx;                                               // 0x0008(0x0004)
		int32_t                                                    RtSlotIdx;                                               // 0x000C(0x0004)
		float                                                      LtToRtPct;                                               // 0x0010(0x0004)
		struct FVector                                             Location;                                                // 0x0014(0x000C)
		struct FVector                                             Normal;                                                  // 0x0020(0x000C)
		struct FVector                                             Tangent;                                                 // 0x002C(0x000C)
	};

	/**
	 * ScriptStruct Engine.CoverLink.FireLinkItem
	 * Size -> 0x0004
	 */
	struct FFireLinkItem
	{
	public:
		ECoverType                                                 SrcType;                                                 // 0x0000(0x0001)
		ECoverAction                                               SrcAction;                                               // 0x0001(0x0001)
		ECoverType                                                 DestType;                                                // 0x0002(0x0001)
		ECoverAction                                               DestAction;                                              // 0x0003(0x0001)
	};

	/**
	 * ScriptStruct Engine.CoverLink.CoverReference
	 * Size -> 0x0004 (FullSize[0x001C] - InheritedSize[0x0018])
	 */
	struct FCoverReference : public FActorReference
	{
	public:
		int32_t                                                    SlotIdx;                                                 // 0x0018(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.CoverLink.ExposedLink
	 * Size -> 0x001D
	 */
	struct FExposedLink
	{
	public:
		struct FCoverReference                                     TargetActor;                                             // 0x0000(0x001C) Edit, Const, EditConst
		unsigned char                                              ExposedScale;                                            // 0x001C(0x0001) Edit
	};

	/**
	 * ScriptStruct Engine.ExponentialHeightFog.GHM_ExponentialHeightFog_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_ExponentialHeightFog_CheckpointRecord
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.ParticleSystemComponent.ParticleEmitterInstanceMotionBlurInfo
	 * Size -> 0x0048
	 */
	struct FParticleEmitterInstanceMotionBlurInfo
	{
	public:
		struct FMap_Mirror                                         ParticleMBInfoMap;                                       // 0x0000(0x0048) Const, Native, Transient
	};

	/**
	 * ScriptStruct Engine.ParticleSystemComponent.ParticleEmitterInstance
	 * Size -> 0x0000
	 */
	struct FParticleEmitterInstance
	{	};

	/**
	 * ScriptStruct Engine.EngineTypes.VelocityObstacleStat
	 * Size -> 0x0020
	 */
	struct FVelocityObstacleStat
	{
	public:
		struct FVector                                             Position;                                                // 0x0000(0x000C)
		struct FVector                                             Velocity;                                                // 0x000C(0x000C)
		float                                                      Radius;                                                  // 0x0018(0x0004)
		int32_t                                                    Priority;                                                // 0x001C(0x0004)
	};

	/**
	 * ScriptStruct Engine.WorldInfo.NavMeshPathGoalEvaluatorCacheDatum
	 * Size -> 0x002C
	 */
	struct FNavMeshPathGoalEvaluatorCacheDatum
	{
	public:
		int32_t                                                    ListIdx;                                                 // 0x0000(0x0004)
		class UNavMeshPathGoalEvaluator*                           List[0x5];                                               // 0x0004(0x0028)
	};

	/**
	 * ScriptStruct Engine.WorldInfo.NavMeshPathConstraintCacheDatum
	 * Size -> 0x002C
	 */
	struct FNavMeshPathConstraintCacheDatum
	{
	public:
		int32_t                                                    ListIdx;                                                 // 0x0000(0x0004)
		class UNavMeshPathConstraint*                              List[0x5];                                               // 0x0004(0x0028)
	};

	/**
	 * ScriptStruct Engine.HeadTrackingComponent.ActorToLookAt
	 * Size -> 0x0024
	 */
	struct FActorToLookAt
	{
	public:
		class AActor*                                              Actor;                                                   // 0x0000(0x0008)
		float                                                      Rating;                                                  // 0x0008(0x0004)
		struct FDouble                                             EnteredTime;                                             // 0x000C(0x0008)
		float                                                      LastKnownDistance;                                       // 0x0014(0x0004)
		struct FDouble                                             StartTimeBeingLookedAt;                                  // 0x0018(0x0008)
		unsigned long                                              CurrentlyBeingLookedAt : 1;                              // 0x0020(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.HeightFog.GHM_HeightFog_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_HeightFog_CheckpointRecord
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.InterpGroup.InterpEdSelKey
	 * Size -> 0x0018
	 */
	struct FInterpEdSelKey
	{
	public:
		class UInterpGroup*                                        Group;                                                   // 0x0000(0x0008)
		class UInterpTrack*                                        Track;                                                   // 0x0008(0x0008)
		int32_t                                                    KeyIndex;                                                // 0x0010(0x0004)
		float                                                      UnsnappedPosition;                                       // 0x0014(0x0004)
	};

	/**
	 * ScriptStruct Engine.LandscapeProxy.LandscapeWeightmapUsage
	 * Size -> 0x0020
	 */
	struct FLandscapeWeightmapUsage
	{
	public:
		class ULandscapeComponent*                                 ChannelUsage[0x4];                                       // 0x0000(0x0020) ExportObject, Component, EditInline
	};

	/**
	 * ScriptStruct Engine.LandscapeGizmoActiveActor.GizmoSelectData
	 * Size -> 0x0050
	 */
	struct FGizmoSelectData
	{
	public:
		float                                                      Ratio;                                                   // 0x0000(0x0004) EditorOnly
		float                                                      HeightData;                                              // 0x0004(0x0004) EditorOnly
		unsigned char                                              WeightDataMap[0x48];                                     // 0x0008(0x0048) UNKNOWN PROPERTY: MapProperty Engine.LandscapeGizmoActiveActor.GizmoSelectData.WeightDataMap
	};

	/**
	 * ScriptStruct Engine.LandscapeInfo.LandscapeAddCollision
	 * Size -> 0x0030
	 */
	struct FLandscapeAddCollision
	{
	public:
		struct FVector                                             Corners[0x4];                                            // 0x0000(0x0030) EditorOnly
	};

	/**
	 * ScriptStruct Engine.LensFlare.LensFlareElementCurvePair
	 * Size -> 0x0018
	 */
	struct FLensFlareElementCurvePair
	{
	public:
		class FString                                              CurveName;                                               // 0x0000(0x0010) AlwaysInit, NeedCtorLink
		class UObject*                                             CurveObject;                                             // 0x0010(0x0008) AlwaysInit
	};

	/**
	 * ScriptStruct Engine.LensFlareComponent.LensFlareElementInstance
	 * Size -> 0x0000
	 */
	struct FLensFlareElementInstance
	{	};

	/**
	 * ScriptStruct Engine.LevelGridVolume.LevelGridCellCoordinate
	 * Size -> 0x000C
	 */
	struct FLevelGridCellCoordinate
	{
	public:
		int32_t                                                    X;                                                       // 0x0000(0x0004)
		int32_t                                                    Y;                                                       // 0x0004(0x0004)
		int32_t                                                    Z;                                                       // 0x0008(0x0004)
	};

	/**
	 * ScriptStruct Engine.NavigationHandle.PolySegmentSpan
	 * Size -> 0x0020
	 */
	struct FPolySegmentSpan
	{
	public:
		struct FPointer                                            Poly;                                                    // 0x0000(0x0008) Native
		struct FVector                                             P1;                                                      // 0x0008(0x000C)
		struct FVector                                             P2;                                                      // 0x0014(0x000C)
	};

	/**
	 * ScriptStruct Engine.OnlineRecentPlayersList.CurrentPlayerMet
	 * Size -> 0x0010
	 */
	struct FCurrentPlayerMet
	{
	public:
		int32_t                                                    TeamNum;                                                 // 0x0000(0x0004)
		int32_t                                                    Skill;                                                   // 0x0004(0x0004)
		struct FUniqueNetId                                        NetId;                                                   // 0x0008(0x0008)
	};

	/**
	 * ScriptStruct Engine.OnlineRecentPlayersList.RecentParty
	 * Size -> 0x0018
	 */
	struct FRecentParty
	{
	public:
		struct FUniqueNetId                                        PartyLeader;                                             // 0x0000(0x0008)
		TArray<struct FUniqueNetId>                                PartyMembers;                                            // 0x0008(0x0010) NeedCtorLink
	};

	/**
	 * ScriptStruct Engine.ParticleModule.ParticleCurvePair
	 * Size -> 0x0018
	 */
	struct FParticleCurvePair
	{
	public:
		class FString                                              CurveName;                                               // 0x0000(0x0010) AlwaysInit, NeedCtorLink
		class UObject*                                             CurveObject;                                             // 0x0010(0x0008) AlwaysInit
	};

	/**
	 * ScriptStruct Engine.ParticleModuleTypeDataBeam2.BeamTargetData
	 * Size -> 0x000C
	 */
	struct FBeamTargetData
	{
	public:
		class FName                                                TargetName;                                              // 0x0000(0x0008) Edit
		float                                                      TargetPercentage;                                        // 0x0008(0x0004) Edit
	};

	/**
	 * ScriptStruct Engine.ProcBuilding.PBMemUsageInfo
	 * Size -> 0x002C
	 */
	struct FPBMemUsageInfo
	{
	public:
		class AProcBuilding*                                       Building;                                                // 0x0000(0x0008)
		class UProcBuildingRuleset*                                Ruleset;                                                 // 0x0008(0x0008)
		int32_t                                                    NumStaticMeshComponent;                                  // 0x0010(0x0004)
		int32_t                                                    NumInstancedStaticMeshComponents;                        // 0x0014(0x0004)
		int32_t                                                    NumInstancedTris;                                        // 0x0018(0x0004)
		int32_t                                                    LightmapMemBytes;                                        // 0x001C(0x0004)
		int32_t                                                    ShadowmapMemBytes;                                       // 0x0020(0x0004)
		int32_t                                                    LODDiffuseMemBytes;                                      // 0x0024(0x0004)
		int32_t                                                    LODLightingMemBytes;                                     // 0x0028(0x0004)
	};

	/**
	 * ScriptStruct Engine.ReverbVolumeToggleable.GHM_ReverbVolumeToggleable_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_ReverbVolumeToggleable_CheckpointRecord
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.SeqAct_Interp.SavedTransform
	 * Size -> 0x0018
	 */
	struct FSavedTransform
	{
	public:
		struct FVector                                             Location;                                                // 0x0000(0x000C)
		struct FRotator                                            Rotation;                                                // 0x000C(0x000C)
	};

	/**
	 * ScriptStruct Engine.WorldAttractor.WorldAttractorData
	 * Size -> 0x0020
	 */
	struct FWorldAttractorData
	{
	public:
		unsigned long                                              bEnabled : 1;                                            // 0x0000(0x0001) BIT_FIELD
		struct FVector                                             Location;                                                // 0x0004(0x000C)
		EWorldAttractorFalloffType                                 FalloffType;                                             // 0x0010(0x0001)
		unsigned char                                              UnknownData_CPHL[0x3];                                   // 0x0011(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      FalloffExponent;                                         // 0x0014(0x0004)
		float                                                      Range;                                                   // 0x0018(0x0004)
		float                                                      Strength;                                                // 0x001C(0x0004)
	};

	/**
	 * ScriptStruct Engine.SkeletalMesh.BoneMirrorExport
	 * Size -> 0x0011
	 */
	struct FBoneMirrorExport
	{
	public:
		class FName                                                BoneName;                                                // 0x0000(0x0008) Edit
		class FName                                                SourceBoneName;                                          // 0x0008(0x0008) Edit
		EAxis                                                      BoneFlipAxis;                                            // 0x0010(0x0001) Edit
	};

	/**
	 * ScriptStruct Engine.SoundClass.SoundClassEditorData
	 * Size -> 0x0008
	 */
	struct FSoundClassEditorData
	{
	public:
		int32_t                                                    NodePosX;                                                // 0x0000(0x0004) Const, Native
		int32_t                                                    NodePosY;                                                // 0x0004(0x0004) Const, Native
	};

	/**
	 * ScriptStruct Engine.Terrain.TerrainMaterialResource
	 * Size -> 0x0000
	 */
	struct FTerrainMaterialResource
	{	};

	/**
	 * ScriptStruct Engine.TerrainWeightMapTexture.TerrainWeightedMaterial
	 * Size -> 0x0000
	 */
	struct UTerrainWeightMapTexture_FTerrainWeightedMaterial
	{	};

	/**
	 * ScriptStruct Engine.TriggeredPath.GHM_TriggeredPath_CheckpointRecord
	 * Size -> 0x0004
	 */
	struct FGHM_TriggeredPath_CheckpointRecord
	{
	public:
		unsigned long                                              bOpen : 1;                                               // 0x0000(0x0001) BIT_FIELD
	};

	/**
	 * ScriptStruct Engine.TriggerStreamingLevel.LevelStreamingData
	 * Size -> 0x000C
	 */
	struct FLevelStreamingData
	{
	public:
		unsigned long                                              bShouldBeLoaded : 1;                                     // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bShouldBeVisible : 1;                                    // 0x0000(0x0001) BIT_FIELD Edit
		unsigned long                                              bShouldBlockOnLoad : 1;                                  // 0x0000(0x0001) BIT_FIELD Edit
		class ULevelStreaming*                                     Level;                                                   // 0x0004(0x0008) Edit
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
