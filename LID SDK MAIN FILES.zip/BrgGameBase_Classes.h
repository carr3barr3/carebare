﻿#pragma once

/**
 * Name: LetItDie
 * Version: 15585480
 */

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
	// --------------------------------------------------
	// # Classes
	// --------------------------------------------------
	/**
	 * Class BrgGameBase.BrgEmitterPool
	 * Size -> 0x0008 (FullSize[0x02F4] - InheritedSize[0x02EC])
	 */
	class ABrgEmitterPool : public AEmitterPool
	{
	public:
		float                                                      mDefaultMaxDrawDistance;                                 // 0x02EC(0x0004) Edit
		float                                                      mDefaultSecondsBeforeInactive;                           // 0x02F0(0x0004) Edit

	public:
		class UParticleSystemComponent* SpawnEmitterMeshAttachment(class UParticleSystem* EmitterTemplate, class USkeletalMeshComponent* Mesh, const class FName& AttachPointName, bool bAttachToSocket, const struct FVector& RelativeLoc, const struct FRotator& RelativeRot);
		class UParticleSystemComponent* SpawnEmitter(class UParticleSystem* EmitterTemplate, const struct FVector& SpawnLocation, const struct FRotator& SpawnRotation, class AActor* AttachToActor, class AActor* InInstigator, int32_t MaxDLEPooledReuses, bool bInheritScaleFromBase);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgFloat64Utility
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgFloat64Utility : public UObject
	{
	public:
		struct FBrgFloat64 SubEq(struct FBrgFloat64* A, const struct FBrgFloat64& B);
		struct FBrgFloat64 AddEq(struct FBrgFloat64* A, const struct FBrgFloat64& B);
		struct FBrgFloat64 DivEq(struct FBrgFloat64* A, const struct FBrgFloat64& B);
		struct FBrgFloat64 MulEq(struct FBrgFloat64* A, const struct FBrgFloat64& B);
		bool NotEq(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		bool EqEq(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		bool GreaterEq(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		bool LessEq(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		bool Greater(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		bool Less(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		struct FBrgFloat64 Sub(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		struct FBrgFloat64 Add(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		struct FBrgFloat64 Mod(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		struct FBrgFloat64 Div(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		struct FBrgFloat64 Mul(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		struct FBrgFloat64 Minus_Pre(const struct FBrgFloat64& A);
		float F64toF(const struct FBrgFloat64& Float64Num);
		int32_t F64toI(const struct FBrgFloat64& Float64Num, float MulNum);
		class FString F64toA(const struct FBrgFloat64& Float64Num);
		struct FBrgFloat64 AtoF64(const class FString& Float64String);
		struct FBrgFloat64 FtoF64(float Num);
		struct FBrgFloat64 ItoF64(int32_t Num);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgGameBaseDummy
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgGameBaseDummy : public UObject
	{
	public:
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgGameDefine
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgGameDefine : public UObject
	{
	public:
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgGameEngineBase
	 * Size -> 0x0000 (FullSize[0x0AB4] - InheritedSize[0x0AB4])
	 */
	class UBrgGameEngineBase : public UGHM_GameEngine
	{
	public:
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgGameInfoNativeBase
	 * Size -> 0x024C (FullSize[0x083C] - InheritedSize[0x05F0])
	 */
	class ABrgGameInfoNativeBase : public AGHM_GameInfo
	{
	public:
		EBrgGameMode                                               mGameMode;                                               // 0x05F0(0x0001)
		EBrgHubStartMode                                           mHubStartMode;                                           // 0x05F1(0x0001)
		EMsgpackManagerErrorBehavior                               MsgpackErrorBehaviour;                                   // 0x05F2(0x0001) Config
		unsigned char                                              UnknownData_KCRJ[0x1];                                   // 0x05F3(0x0001) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class FString                                              mReturnToHubEitemid;                                     // 0x05F4(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mSkillSetupPointLocations;                               // 0x0604(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mCoinLockerLocations;                                    // 0x0614(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mDailyRewardBoxLocations;                                // 0x0624(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mEscalatorLocations;                                     // 0x0634(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mGameCenterLocations;                                    // 0x0644(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mStampTableLocations;                                    // 0x0654(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mBalloonLocations;                                       // 0x0664(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mButtonLocations;                                        // 0x0674(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mSecuritySwitchLocations;                                // 0x0684(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mBossButtonLocations;                                    // 0x0694(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mMaterialLocations;                                      // 0x06A4(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mRMapLocations;                                          // 0x06B4(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mMagazineLocations;                                      // 0x06C4(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mVendingMachineLocations;                                // 0x06D4(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mReceptionLocations;                                     // 0x06E4(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mBreakableObjectLocations;                               // 0x06F4(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mPartShopLocations;                                      // 0x0704(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mSisterPartShopLocations;                                // 0x0714(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mDrinkMachineLocations;                                  // 0x0724(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mBodyFreezerLocations;                                   // 0x0734(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mFortAssaultLocations;                                   // 0x0744(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mSkillExchangeLocations;                                 // 0x0754(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mSkillVendingMachineLocations;                           // 0x0764(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mSafeLocations;                                          // 0x0774(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mPresentBoxLocations;                                    // 0x0784(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mElevator2Locations;                                     // 0x0794(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mElevator2_SwitchLocations;                              // 0x07A4(0x0010) NeedCtorLink
		TArray<struct FVector>                                     mShowTentLocations;                                      // 0x07B4(0x0010) NeedCtorLink
		class UBrgResourceLoadManager*                             mResourceLoadManager;                                    // 0x07C4(0x0008)
		class UBrgLocalizedResourceManager*                        mLocalizedResourceManager;                               // 0x07CC(0x0008)
		class ABrgHUDBase*                                         mBrgHUDBase;                                             // 0x07D4(0x0008)
		class UBrgUIManagerBase*                                   mUIManagerBase;                                          // 0x07DC(0x0008)
		float                                                      mDemoSkipUITime;                                         // 0x07E4(0x0004) Edit, Config
		unsigned char                                              mNetworkManager[0x10];                                   // 0x07E8(0x0010) UNKNOWN PROPERTY: InterfaceProperty BrgGameBase.BrgGameInfoNativeBase.mNetworkManager
		class FString                                              mLangText;                                               // 0x07F8(0x0010) Config, NeedCtorLink
		class FString                                              mLangSound;                                              // 0x0808(0x0010) Config, NeedCtorLink
		float                                                      mItemOutlineMinWidth;                                    // 0x0818(0x0004) Edit, Config
		float                                                      mItemOutlineMaxWidth;                                    // 0x081C(0x0004) Edit, Config
		float                                                      mItemOutlineMinDistance;                                 // 0x0820(0x0004) Edit, Config
		float                                                      mItemOutlineMaxDistance;                                 // 0x0824(0x0004) Edit, Config
		float                                                      mDefaultMaxDrawDistance;                                 // 0x0828(0x0004) Edit
		TArray<struct FBrgGoreMeshDamageSetting>                   mGoreMeshDamageSettings;                                 // 0x082C(0x0010) Edit, Config, NeedCtorLink

	public:
		bool GetEmergencyMaintenance();
		void SetEmergencyMaintenance(bool flag);
		bool GetUnderMaintenance();
		void SetUnderMaintenance(bool flag);
		bool IsVITAController();
		bool CheckResumeFromSuspend(int32_t statusExcpetionCode);
		class UBrgNetworkManagerBase* GetNetworkManagerBase();
		bool IsInfinityMushroom(const class FString& emsrid);
		bool IsDebugEntityId(const class FString& entityId);
		class FString GetServerEnvName();
		class FString GetClientTitleVersion();
		int32_t GetDataVersion();
		int32_t GetApiVersion();
		void SetDefaultPerformanceSetting(class UPrimitiveComponent* PC);
		class AGamePlayerController* GetGamePlayerCtrl();
		void SetLangSound(const class FString& lang);
		class FString GetLangSound();
		void SetLangText(const class FString& lang);
		class FString GetLangText();
		EBrgPlatform GetPlatform();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgGlobalPartInfo
	 * Size -> 0x0014 (FullSize[0x0074] - InheritedSize[0x0060])
	 */
	class UBrgGlobalPartInfo : public UObject
	{
	public:
		unsigned long                                              mUsePart2 : 1;                                           // 0x0060(0x0001) BIT_FIELD Config
		unsigned long                                              mGlobalPartInfosEditMode : 1;                            // 0x0060(0x0001) BIT_FIELD
		TArray<struct FBrgGlobalPartInfoUnit>                      mGlobalPartInfos;                                        // 0x0064(0x0010) Config, NeedCtorLink

	public:
		bool GetGlobalPartInfo(const class FName& inPtid, struct FBrgGlobalPartInfoUnit* inGlobalPartInfo);
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageBase
	 * Size -> 0x0518 (FullSize[0x0578] - InheritedSize[0x0060])
	 */
	class UBrgUIImageBase : public UObject
	{
	public:
		class UMaterialInstanceConstant*                           mNormalMIC[0x80];                                        // 0x0060(0x0400)
		class UMaterialInstanceConstant*                           mEffectMIC[0x1D];                                        // 0x0460(0x00E8)
		class UTexture*                                            mMaskScreenTexture;                                      // 0x0548(0x0008)
		int32_t                                                    mMaskScreenTextureSizeX;                                 // 0x0550(0x0004)
		int32_t                                                    mMaskScreenTextureSizeY;                                 // 0x0554(0x0004)
		float                                                      mMaskScreenTextureInvSizeX;                              // 0x0558(0x0004)
		float                                                      mMaskScreenTextureInvSizeY;                              // 0x055C(0x0004)
		float                                                      mMaskScreenTextureScreenPositionX;                       // 0x0560(0x0004)
		float                                                      mMaskScreenTextureScreenPositionY;                       // 0x0564(0x0004)
		class UTexture*                                            mTexture;                                                // 0x0568(0x0008)
		int32_t                                                    mTextureSizeX;                                           // 0x0570(0x0004)
		int32_t                                                    mTextureSizeY;                                           // 0x0574(0x0004)

	public:
		void SetMaskScreenTexture(class UTexture* inMaskScreenTexture, float inScreenPositionX, float inScreenPositionY);
		bool SetupBaseMIC(int32_t inMaterialIndex, EMaterialEffect inMaterialEffect);
		int32_t GetMaterialIndex(struct FBrgUIMaterialAttr* inMaterialAttr);
		class UBrgUIImageBase* Create(class UTexture* UseTexture, int32_t PixelScale);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIMath
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgUIMath : public UObject
	{
	public:
		void RectClip(float* inTargetLeftUpX, float* inTargetLeftUpY, float* inTargetRightDownX, float* inTargetRightDownY, float inClipLeftUpX, float inClipLeftUpY, float inClipRightDownX, float inClipRightDownY, float* inTargetLinkLeftUpX, float* inTargetLinkLeftUpY, float* inTargetLinkRightDownX, float* inTargetLinkRightDownY);
		void Segment_Point_Analyse(const struct FVector& SegmentPos1, const struct FVector& SegmentPos2, const struct FVector& PointPos, struct FSegment_Point_Result* ResultParam);
		void Segment_Segment_Analyse(const struct FVector& SegmentAPos1, const struct FVector& SegmentAPos2, const struct FVector& SegmentBPos1, const struct FVector& SegmentBPos2, struct FSegment_Segment_Result* ResultParam);
		float GetFlashClassicTweenParam(float T, bool Reverse);
		struct FVector GetBezierParam(const struct FVector& Pos1, const struct FVector& SubPos1, const struct FVector& SubPos2, const struct FVector& Pos2, float T);
		bool CheckHit2DRect(float Area1_X1, float Area1_Y1, float Area1_X2, float Area1_Y2, float Area2_X1, float Area2_Y1, float Area2_X2, float Area2_Y2);
		int32_t GetDistMinPixelScaleNum(int32_t inNum);
		int32_t GetDistMinDiv2And3Num(int32_t inNum);
		int32_t GetPrevDiv2And3Num(int32_t inNum);
		int32_t GetNextDiv2And3Num(int32_t inNum);
		int32_t GetNextDiv2Num(int32_t inNum);
		void Initialize();
		float GetMinMaxF(float InMin, float InMax);
		struct FVector VTransform(const struct FVector& SrcPos, struct FMatrix3x3CT* InMat);
		struct FMatrix3x3CT MTranslate2(float TransX, float TransY);
		struct FMatrix3x3CT MRot2(float Angle);
		struct FMatrix3x3CT MScale2(float ScaleX, float ScaleY);
		struct FMatrix3x3CT MIdent2();
		struct FMatrix3x3CT MAdd2(struct FMatrix3x3CT* InMat1, struct FMatrix3x3CT* InMat2);
		struct FMatrix3x3CT MMult2(struct FMatrix3x3CT* InMat1, struct FMatrix3x3CT* InMat2);
		void MTranslate(struct FMatrix3x3CT* DestMat, float TransX, float TransY);
		void MRot_(struct FMatrix3x3CT* DestMat, float Angle);
		void MScale_(struct FMatrix3x3CT* DestMat, float ScaleX, float ScaleY);
		void MIdent(struct FMatrix3x3CT* DestMat);
		void MAdd(struct FMatrix3x3CT* InMat1, struct FMatrix3x3CT* InMat2, struct FMatrix3x3CT* DestMat);
		void MMult(struct FMatrix3x3CT* InMat1, struct FMatrix3x3CT* InMat2, struct FMatrix3x3CT* DestMat);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgHUDBase
	 * Size -> 0x0F80 (FullSize[0x1548] - InheritedSize[0x05C8])
	 */
	class ABrgHUDBase : public AGHM_HUD
	{
	public:
		EScreenMode                                                mScreenMode;                                             // 0x05C8(0x0001)
		EMaterialEffect                                            mUseMaterialEffect;                                      // 0x05C9(0x0001)
		EDrawXBasePos                                              mDrawBasePosX;                                           // 0x05CA(0x0001)
		EDrawYBasePos                                              mDrawBasePosY;                                           // 0x05CB(0x0001)
		class UBrgUIManagerBase*                                   mUIManagerBase;                                          // 0x05CC(0x0008)
		unsigned char                                              UnknownData_T1GH[0xC];                                   // 0x05D4(0x000C) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct FMatrix                                             mViewMatrix;                                             // 0x05E0(0x0040)
		struct FMatrix                                             mProjectionMatrix;                                       // 0x0620(0x0040)
		int32_t                                                    mDrawWaitFrame;                                          // 0x0660(0x0004)
		class UBrgUIImage*                                         mWhiteImage;                                             // 0x0664(0x0008)
		class UBrgUIImage*                                         mLineImage;                                              // 0x066C(0x0008)
		class UBrgUIImage*                                         mLine2Image;                                             // 0x0674(0x0008)
		class UBrgUIImage*                                         mLine3Image;                                             // 0x067C(0x0008)
		class UBrgUIImage*                                         mAlphaClearImage;                                        // 0x0684(0x0008)
		unsigned long                                              mStrIconSetup : 1;                                       // 0x068C(0x0001) BIT_FIELD
		unsigned long                                              mEnableDrawTransformMatrix : 1;                          // 0x068C(0x0001) BIT_FIELD
		unsigned long                                              mSetDrawArea : 1;                                        // 0x068C(0x0001) BIT_FIELD
		struct FBrgUIDrawCharIconInfo                              mStrIconInfo[0x4C];                                      // 0x0690(0x0BE0)
		class UBrgUIFont*                                          mSubUIFont;                                              // 0x1270(0x0008)
		float                                                      mSubUIFontScale;                                         // 0x1278(0x0004)
		int32_t                                                    mSubUIFontOffsetX;                                       // 0x127C(0x0004)
		int32_t                                                    mSubUIFontOffsetY;                                       // 0x1280(0x0004)
		class UBrgRenderPrimitive2DSet*                            mTargetRenderPrimitive2DSet;                             // 0x1284(0x0008)
		class UTextureRenderTarget2D*                              mSetDrawTarget;                                          // 0x128C(0x0008)
		class UTextureRenderTarget2D*                              mSetDrawBaseTarget;                                      // 0x1294(0x0008)
		float                                                      mRenderScalingX;                                         // 0x129C(0x0004)
		float                                                      mRenderScalingY;                                         // 0x12A0(0x0004)
		int32_t                                                    mRenderTargetSizeX;                                      // 0x12A4(0x0004)
		int32_t                                                    mRenderTargetSizeY;                                      // 0x12A8(0x0004)
		class UBrgUIImageBase*                                     mUseImageBase;                                           // 0x12AC(0x0008)
		int32_t                                                    mUseMaterialIndex;                                       // 0x12B4(0x0004)
		class UMaterialInstanceConstant*                           mUseFreeMIC;                                             // 0x12B8(0x0008)
		struct FColor                                              mDrawColor[0x4];                                         // 0x12C0(0x0010)
		struct FLinearColor                                        mDrawLinearColor[0x4];                                   // 0x12D0(0x0040)
		float                                                      mGlobalBright;                                           // 0x1310(0x0004)
		struct FMatrix3x3CT                                        mDrawTransformMatrix;                                    // 0x1314(0x0018)
		int32_t                                                    mUseMaskScreenNo;                                        // 0x132C(0x0004)
		class UTexture*                                            mMaskScreenTexture;                                      // 0x1330(0x0008)
		float                                                      mMaskScreenTextureScreenPositionX;                       // 0x1338(0x0004)
		float                                                      mMaskScreenTextureScreenPositionY;                       // 0x133C(0x0004)
		float                                                      mDrawAreaX1;                                             // 0x1340(0x0004)
		float                                                      mDrawAreaY1;                                             // 0x1344(0x0004)
		float                                                      mDrawAreaX2;                                             // 0x1348(0x0004)
		float                                                      mDrawAreaY2;                                             // 0x134C(0x0004)
		float                                                      mEffectFadeAreaX1;                                       // 0x1350(0x0004)
		float                                                      mEffectFadeAreaY1;                                       // 0x1354(0x0004)
		float                                                      mEffectFadeAreaX2;                                       // 0x1358(0x0004)
		float                                                      mEffectFadeAreaY2;                                       // 0x135C(0x0004)
		float                                                      mEffectFadeAreaXSizeInvert;                              // 0x1360(0x0004)
		float                                                      mEffectFadeAreaYSizeInvert;                              // 0x1364(0x0004)
		int32_t                                                    mPixelScaleI[0x2];                                       // 0x1368(0x0008)
		float                                                      mPixelScaleF[0x2];                                       // 0x1370(0x0008)
		float                                                      mPixelScaleInvF[0x2];                                    // 0x1378(0x0008)
		float                                                      mScreenScaleX;                                           // 0x1380(0x0004)
		float                                                      mScreenScaleY;                                           // 0x1384(0x0004)
		class UMaterial*                                           mCommonMaterial_MT_UI_NormalTex;                         // 0x1388(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NormalTex_Mask;                    // 0x1390(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NormalTex_Mask_OneMinus;           // 0x1398(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NormalTex_Add;                     // 0x13A0(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NormalTex_Add_Mask;                // 0x13A8(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NormalTex_Add_Mask_OneMinus;       // 0x13B0(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_PreAlphaTex;                       // 0x13B8(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_PreAlphaTex_Mask;                  // 0x13C0(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_PreAlphaTex_Mask_OneMinus;         // 0x13C8(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_PreAlphaTex_Add;                   // 0x13D0(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_PreAlphaTex_Add_Mask;              // 0x13D8(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_PreAlphaTex_Add_Mask_OneMinus;     // 0x13E0(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreColorTex;                    // 0x13E8(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreColorTex_Mask;               // 0x13F0(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreColorTex_Mask_OneMinus;      // 0x13F8(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreColorTex_Add;                // 0x1400(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreColorTex_Add_Mask;           // 0x1408(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreColorTex_Add_Mask_OneMinus;  // 0x1410(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NormalTex_3D;                      // 0x1418(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NormalTex_Add_3D;                  // 0x1420(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_PreAlphaTex_3D;                    // 0x1428(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_PreAlphaTex_Add_3D;                // 0x1430(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreColorTex_3D;                 // 0x1438(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreColorTex_Add_3D;             // 0x1440(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_AlphaClear;                        // 0x1448(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NormalTex_GrBlend_Lerp;            // 0x1450(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_PreAlphaTex_GrBlend_Lerp;          // 0x1458(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_TexG_CmnRenderBlend;               // 0x1460(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_TexR_VtxColorBlend;                // 0x1468(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreAlphaTex;                    // 0x1470(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreAlphaTex_Add;                // 0x1478(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreAlphaTex_Mask;               // 0x1480(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreAlphaTex_Mask_OneMinus;      // 0x1488(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreAlphaTex_Add_Mask;           // 0x1490(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_IgnoreAlphaTex_Add_Mask_OneMinus;  // 0x1498(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NormalTex_Modulate;                // 0x14A0(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NormalTex_Modulate_Mask;           // 0x14A8(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NormalTex_Modulate_Mask_OneMinus;  // 0x14B0(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NoTex_Modulate;                    // 0x14B8(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NoTex_Modulate_Mask;               // 0x14C0(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_NoTex_Modulate_Mask_OneMinus;      // 0x14C8(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_MiniMapImage;                      // 0x14D0(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_MiniMapSpray;                      // 0x14D8(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_MiniMapMask;                       // 0x14E0(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_MiniMapCover;                      // 0x14E8(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_HUD;                               // 0x14F0(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_HUD_3D;                            // 0x14F8(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_GameOverDesaturate;                // 0x1500(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_SceneCaptureTexture;               // 0x1508(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_Sticker_Standard;                  // 0x1510(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_Sticker_Kira;                      // 0x1518(0x0008)
		class UMaterial*                                           mCommonMaterial_MT_UI_CommonTopIconSpecial;              // 0x1520(0x0008)
		TArray<class FString>                                      mCharColor;                                              // 0x1528(0x0010) Config, NeedCtorLink
		TArray<struct FColor>                                      mCharColorData;                                          // 0x1538(0x0010) NeedCtorLink

	public:
		void Draw_Box_Rel(float X1, float Y1, float X2, float Y2);
		void UseRenderInfoRedner();
		void EndRender();
		void PostRenderInitialize();
		void RenderPrimitive();
		void DrawShadowedText(float X, float Y, const class FString& Str, unsigned char R, unsigned char G, unsigned char B, float Scale, bool IsRight);
		void SetDisplayGamma(float Gamma);
		struct FColor ColorLerp(const struct FColor& inA, const struct FColor& inB, float inAlpha);
		struct FColor AnalyseColorString(const class FString& inColorString);
		void BrgFormatStringToBrgUIDrawCharInfo(const class FString& inSrc, TArray<struct FBrgUIDrawCharInfo>* inDest);
		void AnalyseDoubleAtMarkString(const class FString& inSrc, TArray<class FString>* inDest);
		void AnalyseLFString(const class FString& inSrc, TArray<class FString>* inDest);
		class FString AddSpaceCharString(const class FString& SrcString, int32_t CharNum);
		class FString Number64bitString(int32_t HighNumber, int32_t LowNumber);
		class FString NumberString(int32_t Number);
		class FString GetWithSpaceNumberStr(int32_t Number, int32_t Keta);
		class FString GetWithZeroNumberStr(int32_t Number, int32_t Keta);
		void TimeString3(int32_t SecTime, class FString* Day, class FString* Hour, class FString* Min, class FString* Sec);
		void TimeString2(float SecTime, class FString* Day, class FString* Hour, class FString* Min, class FString* Sec, class FString* Milli);
		class FString TimeString(int32_t SecTime);
		class FString ItoA_Plus(int32_t Num);
		struct FVector ScreenPixelScaleProject(class UCanvas* inCanvas, const struct FVector& InLocation);
		struct FVector Project(class UCanvas* inCanvas, const struct FVector& InLocation);
		float GetScreenPixelSizeToWorldSize(class UCanvas* inCanvas, const struct FVector& inWorldLocation, float inPixelSize);
		int32_t GetScreenPixelScale();
		void SetupWhiteTexMIC(struct FBrgUIMaterialAttr* inMaterialAttr);
		void GetScreenImageSize(int32_t* InX, int32_t* InY);
		void GetScreenImage(class UTextureRenderTarget2D* inDestTexture);
		float Get_Font_DrawHeight(class UBrgUIFont* DrawFont, float ScaleY);
		float Get_Chara_NextAddX(class UBrgUIFont* DrawFont, const class FString& Chara, float ScaleX);
		float Draw_NumberEasy(float X, float Y, int32_t DrawNum, class UBrgUIFont* DrawFont, bool PosConvInt, bool IsDraw);
		float Draw_StrEasy(float X, float Y, const class FString& DrawStr, class UBrgUIFont* DrawFont, bool PosConvInt, bool IsDraw);
		float Draw_Number(float X, float Y, EDrawXBasePos xposBase, EDrawYBasePos yposBase, float rot_cx, float rot_cy, float Rot, float ScaleX, float ScaleY, int32_t DrawNum, class UBrgUIFont* DrawFont, bool PosConvInt, bool IsDraw, float* DrawWidth, float* DrawHeight, float UseDrawWidth);
		float Draw_BrgStr(float X, float Y, EDrawXBasePos xposBase, EDrawYBasePos yposBase, float rot_cx, float rot_cy, float Rot, float ScaleX, float ScaleY, TArray<struct FBrgUIDrawCharInfo> DrawStr, class UBrgUIFont* DrawFont, bool PosConvInt, bool IsDraw, float* DrawWidth, float* DrawHeight, float UseDrawWidth);
		float Draw_Str(float X, float Y, EDrawXBasePos xposBase, EDrawYBasePos yposBase, float rot_cx, float rot_cy, float Rot, float ScaleX, float ScaleY, const class FString& DrawStr, class UBrgUIFont* DrawFont, bool PosConvInt, bool IsDraw, float* DrawWidth, float* DrawHeight, float UseDrawWidth);
		void Draw_GradTB(float X1, float Y1, float X2, float Y2);
		void Draw_GradLR(float X1, float Y1, float X2, float Y2);
		void Draw_NAA_Triangle(float X1, float Y1, float X2, float Y2, float X3, float Y3);
		void Draw_Triangle(float X1, float Y1, float X2, float Y2, float X3, float Y3);
		void Draw_CircleGaugeMask(float X, float Y, float R, float angle_start, float angle_end);
		void Draw_GradCircle(float X, float Y, float r1, float r2, float r3, float r4, int32_t posnum);
		void Draw_Circle(float X, float Y, float R, int32_t posnum);
		void Draw_CircleLine(float X, float Y, float R, float Width, int32_t posnum, EDrawYBasePos widthBase);
		void Draw_BezierLine(float p1_x, float p1_y, float s1_x, float s1_y, float s2_x, float s2_y, float p2_x, float p2_y, int32_t pos_num, float Width, EDrawXBasePos widthBase);
		void Draw_Line(float X1, float Y1, float X2, float Y2, float Width, EDrawXBasePos posBase);
		void Draw_LineBox(float X1, float Y1, float X2, float Y2, float Width, EDrawXBasePos posBase);
		void Draw_Box(float X1, float Y1, float X2, float Y2);
		void Draw_NAA_Box(float X1, float Y1, float X2, float Y2);
		void Draw_GaugeBTImageWithStartEnd(float X, float Y, float StartRate, float EndRate, class UBrgUIImage* DrawImage);
		void Draw_GaugeTBImage(float X, float Y, float Rate, class UBrgUIImage* DrawImage);
		void Draw_GaugeBTImage(float X, float Y, float Rate, class UBrgUIImage* DrawImage);
		void Draw_GaugeLRImageWithStartEnd(float X, float Y, float StartRate, float EndRate, class UBrgUIImage* DrawImage);
		void Draw_GaugeRLImage(float X, float Y, float Rate, class UBrgUIImage* DrawImage);
		void Draw_GaugeLRImage(float X, float Y, float Rate, class UBrgUIImage* DrawImage);
		void Draw_Vertex2D_TriangleList(TArray<struct FBrgUIDrawVertex2D> vertex2D, class UBrgUIImage* DrawImage);
		void Draw_TransformImageRect(float X, float Y, const struct FMatrix3x3CT& Mat, float ix, float iy, float iw, float ih, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void Draw_RotImageRectSimple(float screenRotCenterX, float screenRotCenterY, float imageRotCenterX, float imageRotCenterY, float Rot, float ScaleX, float ScaleY, float ix, float iy, float iw, float ih, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void Draw_RotImageRect(EDrawXBasePos xBase, EDrawYBasePos yBase, float X, float Y, EDrawXBasePos cxBase, EDrawYBasePos cyBase, float CX, float CY, float Rot, float ScaleX, float ScaleY, float ix, float iy, float iw, float ih, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void Draw_TriangleImageRect(float X1, float Y1, float X2, float Y2, float X3, float Y3, float ix, float iy, float iw, float ih, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void Draw_ModiImageRect(float X1, float Y1, float X2, float Y2, float X3, float Y3, float x4, float y4, float ix, float iy, float iw, float ih, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void Draw_ExtImageRect(float X1, float Y1, float X2, float Y2, float ix, float iy, float iw, float ih, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void Draw_ImageRect(float X, float Y, float ix, float iy, float iw, float ih, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void Draw_TransformImage(float X, float Y, const struct FMatrix3x3CT& Mat, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void Draw_RotImageSimple(float screenRotCenterX, float screenRotCenterY, float imageRotCenterX, float imageRotCenterY, float Rot, float ScaleX, float ScaleY, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void Draw_RotImage(EDrawXBasePos xBase, EDrawYBasePos yBase, float X, float Y, EDrawXBasePos cxBase, EDrawYBasePos cyBase, float CX, float CY, float Rot, float ScaleX, float ScaleY, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void Draw_TriangleImage(float X1, float Y1, float X2, float Y2, float X3, float Y3, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void Draw_ModiImage(float X1, float Y1, float X2, float Y2, float X3, float Y3, float x4, float y4, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void Draw_ExtImage(float X1, float Y1, float X2, float Y2, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void Draw_Image(float X, float Y, class UBrgUIImage* DrawImage, bool Hreverse, bool Vreverse);
		void ResetDrawTransformMatrix();
		void SetDrawTransformMatrix(const struct FMatrix3x3CT& Mat);
		void SetEffectFadeArea(float X1, float Y1, float X2, float Y2);
		void ResetDrawArea();
		void SetDrawArea(float X1, float Y1, float X2, float Y2);
		void SetDrawBasePos(EDrawXBasePos XBasePos, EDrawYBasePos YBasePos);
		void SetDrawColor(unsigned char R, unsigned char G, unsigned char B, unsigned char A, int32_t ColorIndex);
		void SetGlobalBright(float inBright);
		void Clear(unsigned char R, unsigned char G, unsigned char B, unsigned char A);
		void SetUseMaskScreen(int32_t inUseMaskScreenNo, class UTexture* inMaskScreenTexture, float inMaskScreenTextureScreenPositionX, float inMaskScreenTextureScreenPositionY);
		void ResetDrawTarget();
		void SetDrawTargetToMask(int32_t inTargetMaskScreen);
		void SetDrawTarget(class UTextureRenderTarget2D* RenderTarget);
		void ResetDrawBaseTarget();
		void SetDrawBaseTarget(class UTextureRenderTarget2D* RenderTarget);
		void DrawRenderPrimitive2DSet(class UBrgRenderPrimitive2DSet* inRenderPrimitive2DSet);
		void RecordRenderPrimitive2DSet_End();
		void RecordRenderPrimitive2DSet_Begin(class UBrgRenderPrimitive2DSet* inRenderPrimitive2DSet);
		void InitializeNative();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgInt64Utility
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgInt64Utility : public UObject
	{
	public:
		struct FBrgUInt64 Dec_U(struct FBrgUInt64* A);
		struct FBrgUInt64 Inc_U(struct FBrgUInt64* A);
		struct FBrgUInt64 Dec_Pre_U(struct FBrgUInt64* A);
		struct FBrgUInt64 Inc_Pre_U(struct FBrgUInt64* A);
		struct FBrgUInt64 SubEq_U(struct FBrgUInt64* A, const struct FBrgUInt64& B);
		struct FBrgUInt64 AddEq_U(struct FBrgUInt64* A, const struct FBrgUInt64& B);
		struct FBrgUInt64 DivEq_U(struct FBrgUInt64* A, const struct FBrgUInt64& B);
		struct FBrgUInt64 MulEq_U(struct FBrgUInt64* A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Or_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Xor_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 And_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		bool NotEq_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		bool EqEq_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		bool GreaterEq_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		bool LessEq_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		bool Greater_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		bool Less_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 R_Shift_Unsigned_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 R_Shift_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 L_Shift_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Sub_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Add_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Mod_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Div_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Mul_U(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Complement_Pre_U(const struct FBrgUInt64& A);
		float UI64toF(const struct FBrgUInt64& A);
		int32_t UI64toI(const struct FBrgUInt64& A);
		class FString UI64toA(const struct FBrgUInt64& UInt64Num, bool Comma, bool PlusChara, int32_t SpaceCharaNum, int32_t ZeroDigitNum);
		struct FBrgUInt64 AtoUI64(const class FString& UInt64String);
		struct FBrgUInt64 FtoUI64(float Num);
		struct FBrgUInt64 ItoUI64(int32_t Num);
		struct FBrgInt64 Dec(struct FBrgInt64* A);
		struct FBrgInt64 InC(struct FBrgInt64* A);
		struct FBrgInt64 Dec_Pre(struct FBrgInt64* A);
		struct FBrgInt64 Inc_Pre(struct FBrgInt64* A);
		struct FBrgInt64 SubEq(struct FBrgInt64* A, const struct FBrgInt64& B);
		struct FBrgInt64 AddEq(struct FBrgInt64* A, const struct FBrgInt64& B);
		struct FBrgInt64 DivEq(struct FBrgInt64* A, const struct FBrgInt64& B);
		struct FBrgInt64 MulEq(struct FBrgInt64* A, const struct FBrgInt64& B);
		struct FBrgInt64 Or(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Xor(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 And(const struct FBrgInt64& A, const struct FBrgInt64& B);
		bool NotEq(const struct FBrgInt64& A, const struct FBrgInt64& B);
		bool EqEq(const struct FBrgInt64& A, const struct FBrgInt64& B);
		bool GreaterEq(const struct FBrgInt64& A, const struct FBrgInt64& B);
		bool LessEq(const struct FBrgInt64& A, const struct FBrgInt64& B);
		bool Greater(const struct FBrgInt64& A, const struct FBrgInt64& B);
		bool Less(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 R_Shift_Unsigned(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 R_Shift(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 L_Shift(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Sub(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Add(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Mod(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Div(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Mul(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Minus_Pre(const struct FBrgInt64& A);
		struct FBrgInt64 Complement_Pre(const struct FBrgInt64& A);
		float I64toF(const struct FBrgInt64& A);
		int32_t I64toI(const struct FBrgInt64& A);
		class FString I64toA(const struct FBrgInt64& Int64Num, bool Comma, bool PlusChara, int32_t SpaceCharaNum, int32_t ZeroDigitNum);
		struct FBrgInt64 AtoI64(const class FString& Int64String);
		struct FBrgInt64 FtoI64(float Num);
		struct FBrgInt64 ItoI64(int32_t Num);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgInterpActorSpawnable
	 * Size -> 0x0000 (FullSize[0x0318] - InheritedSize[0x0318])
	 */
	class ABrgInterpActorSpawnable : public AInterpActor
	{
	public:
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgJsonObjectFactory
	 * Size -> 0x0000 (FullSize[0x0070] - InheritedSize[0x0070])
	 */
	class UBrgJsonObjectFactory : public UJsonObjectFactory
	{
	public:
		class UJsonObject* CreateJsonObject();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgJsonObjectManager
	 * Size -> 0x0074 (FullSize[0x00D4] - InheritedSize[0x0060])
	 */
	class UBrgJsonObjectManager : public UObject
	{
	public:
		int32_t                                                    InitBulkCreateJsonObjectNum;                             // 0x0060(0x0004) Config
		int32_t                                                    AddBulkCreateJsonObjectNum;                              // 0x0064(0x0004)
		struct FMap_Mirror                                         mObjectMap;                                              // 0x0068(0x0048) Native
		TArray<class UJsonObject*>                                 mObjects;                                                // 0x00B0(0x0010) NeedCtorLink
		TArray<int32_t>                                            mFreeObjectIndices;                                      // 0x00C0(0x0010) NeedCtorLink
		int32_t                                                    mAssignedObjectMax;                                      // 0x00D0(0x0004)

	public:
		int32_t GetAssignedJsonObjectMax();
		int32_t GetAssignedJsonObjectNum();
		int32_t GetAllJsonObjectNum();
		bool FreeJsonObject(class UJsonObject* Obj);
		class UJsonObject* AssignJsonObject();
		class UBrgJsonObjectManager* CreateInstance();
		bool BulkCreateJsonObjects(int32_t Num);
		int32_t FindAssignJsonObjectIndex();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgLocalizedResourceManager
	 * Size -> 0x0054 (FullSize[0x00B4] - InheritedSize[0x0060])
	 */
	class UBrgLocalizedResourceManager : public UObject
	{
	public:
		class FString                                              mLangSound;                                              // 0x0060(0x0010) NeedCtorLink
		TArray<class USoundCue*>                                   mSoundCues;                                              // 0x0070(0x0010) NeedCtorLink
		TArray<class UAnimSet*>                                    mAnimSets;                                               // 0x0080(0x0010) NeedCtorLink
		int32_t                                                    mLoadCount;                                              // 0x0090(0x0004)
		TArray<class FString>                                      mSoundCueNames;                                          // 0x0094(0x0010) Config, NeedCtorLink
		TArray<class FString>                                      mAnimSetNames;                                           // 0x00A4(0x0010) Config, NeedCtorLink

	public:
		bool CheckLoadedLocalizedResource();
		int32_t GetLoadCount();
		void UpdateLoadCount();
		class UAnimSet* GetAnimSet(const class FString& AnimSetName);
		class USoundCue* GetSoundCue(const class FString& cueName);
		class USoundCue* PlaySoundCue(const class FString& cueName, class AActor* owningActor);
		bool UnregisterResources();
		bool UnregisterResourcesNT();
		bool RegisterResources(TArray<class USoundCue*> cues, TArray<class UAnimSet*> AnimSets);
		void RegisterLoadedResources();
		void UnloadResources(bool Immediate);
		bool IsResourcesLoaded();
		void LoadResources(bool isLoc);
		bool IsDone();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgMaterialConstManager
	 * Size -> 0x0030 (FullSize[0x0090] - InheritedSize[0x0060])
	 */
	class UBrgMaterialConstManager : public UObject
	{
	public:
		TArray<class UMaterialInstanceConstant*>                   mMtlInstConstArray;                                      // 0x0060(0x0010) NeedCtorLink
		TArray<struct FBrgMaterialParamEffect>                     mMtlParamEffectArray;                                    // 0x0070(0x0010) NeedCtorLink
		TArray<struct FBrgMaterialVectorParamEffect>               mMtlVectorParamEffectArray;                              // 0x0080(0x0010) NeedCtorLink

	public:
		void Dump();
		bool VectorParamEffectTick(float DeltaTime, int32_t Index);
		bool ScalarParamEffectTick(float DeltaTime, int32_t Index);
		void Tick(float DeltaTime);
		void EndVectorParamEffectByName(class UMaterialInstanceConstant* MtlInstConst, const class FName& ParamName, bool ParamReset);
		void EndVectorParamEffect(class UMaterialInstanceConstant* MtlInstConst);
		void BeginVectorParamEffect(class UMaterialInstanceConstant* MtlInstConst, const class FName& ParamName, const struct FLinearColor& StartParam, const struct FLinearColor& TargetParam, float Duration, float BlendInTime, float BlendOutTime, bool bEndKeep, bool bBlendPlayerTimeScale);
		void EndParamEffectByName(class UMaterialInstanceConstant* MtlInstConst, const class FName& ParamName, bool ParamReset);
		void EndParamEffect(class UMaterialInstanceConstant* MtlInstConst);
		void BeginParamEffect(class UMaterialInstanceConstant* MtlInstConst, const class FName& ParamName, float StartParam, float TargetParam, float Duration, float BlendInTime, float BlendOutTime, bool bEndKeep, bool bBlendPlayerTimeScale);
		void RemoveMaterialInstConst(class UMaterialInstanceConstant* MtlInstConst);
		class UMaterialInstanceConstant* AddMaterialInstConst(class USkeletalMeshComponent* Mesh, const class FName& MaterialName);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgMaterialInstanceActor
	 * Size -> 0x0030 (FullSize[0x02AC] - InheritedSize[0x027C])
	 */
	class ABrgMaterialInstanceActor : public AActor
	{
	public:
		class UMaterialInstance*                                   mMaterialInstance;                                       // 0x027C(0x0008)
		TArray<struct FBrgMaterialParam>                           mMaterialParamArray;                                     // 0x0284(0x0010) NeedCtorLink
		float                                                      mDuration;                                               // 0x0294(0x0004)
		float                                                      mBlendInTime;                                            // 0x0298(0x0004)
		float                                                      mBlendOutTime;                                           // 0x029C(0x0004)
		float                                                      mTimeCnt;                                                // 0x02A0(0x0004)
		float                                                      mCurrentRate;                                            // 0x02A4(0x0004)
		unsigned long                                              mbNotCreateInstance : 1;                                 // 0x02A8(0x0001) BIT_FIELD

	public:
		void ReqOutBlend();
		void SetParamValue(float Rate);
		bool OverrideVectorEndParam(const class FName& ParamName, const struct FLinearColor& VectorTargetValue);
		bool OverrideVectorStartParam(const class FName& ParamName, const struct FLinearColor& VectorTargetValue);
		bool OverrideScalarEndParam(const class FName& ParamName, float TargetValue);
		bool OverrideScalarStartParam(const class FName& ParamName, float TargetValue);
		bool IsHaveParam(const class FName& ParamName);
		void Finish();
		void Initialize(class UMaterialInterface* BaseMaterial, float Duration, float BlendInTime, float BlendOutTime, bool bNotCreateInstance);
		void Tick(float DeltaTime);
		void TickNative(float DeltaTime);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgPostEffectMaterialInstanceActor
	 * Size -> 0x001C (FullSize[0x02C8] - InheritedSize[0x02AC])
	 */
	class ABrgPostEffectMaterialInstanceActor : public ABrgMaterialInstanceActor
	{
	public:
		class UMaterialEffect*                                     mOriginMaterialEffect;                                   // 0x02AC(0x0008)
		class UMaterialInterface*                                  mOriginMaterialInterface;                                // 0x02B4(0x0008)
		class UMaterialInterface*                                  mBaseMaterialInterface;                                  // 0x02BC(0x0008)
		unsigned long                                              mbFinishDisable : 1;                                     // 0x02C4(0x0001) BIT_FIELD

	public:
		void Finish();
		void SetMaterialParam(class UMaterialInstanceConstant* TargetMatInst);
		class UMaterialEffect* GetPlayerPostEffectMaterialEffect(const class FName& EffectName);
		class ABrgPostEffectMaterialInstanceActor* CreatePostEffectMaterialInstanceActor(class AActor* InOwner, class UMaterialEffect* OriginMatEffect, class UMaterialInterface* BaseMat, float Duration, float BlendInTime, float BlendOutTime, bool bNoCreateInstance);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgMath
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgMath : public UObject
	{
	public:
		struct FVector ClosestPoint_PointPlane(const struct FVector& Point, const struct FVector& PlanePos, const struct FVector& PlaneNormal);
		float ClosestDist_PointPlane(const struct FVector& Point, const struct FVector& PlanePos, const struct FVector& PlaneNormal);
		struct FRotator RotatorClampTwoPI(const struct FRotator& InRot);
		struct FRotator RotatorSub(const struct FRotator& SrcRot, const struct FRotator& DstRot);
		struct FRotator RotatorBlend(const struct FRotator& SrcRot, const struct FRotator& DstRot, float Rate);
		void VectorRotationYaw(struct FVector* OutPos, const struct FVector& InVec, int32_t Yaw);
		void VectorRotation(struct FVector* OutPos, const struct FVector& InVec, int32_t Pitch, int32_t Yaw, int32_t Roll);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgParamMove
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgParamMove : public UObject
	{
	public:
		void VisibleAlphaProcess(bool Visible, float DeltaTime, float InAlphaSpeed, float OutAlphaSpeed, float* Alpha);
		void ProcessD(struct FParamMoveDataD* Data, float DeltaTime);
		void Process(struct FParamMoveData* Data, float DeltaTime);
		void InitializeLoopOneParamD(struct FParamMoveDataD* Data, EParamLoopMoveType Type, const struct FBrgFloat64& MinParam, const struct FBrgFloat64& MaxParam, const struct FBrgFloat64& StartRate, const struct FBrgFloat64& ParamMoveSpeed, const struct FBrgFloat64& Param);
		void InitializeLoopOneParam(struct FParamMoveData* Data, EParamLoopMoveType Type, float MinParam, float MaxParam, float StartRate, float ParamMoveSpeed, float Param);
		void InitializeLoop(struct FParamMoveData* Data, EParamLoopMoveType Type, const struct FVector& MinParam, const struct FVector& MaxParam, float StartRate, float ParamMoveSpeed, float Param);
		void InitializeOneParamD(struct FParamMoveDataD* Data, EParamMoveType Type, const struct FBrgFloat64& StartParam, const struct FBrgFloat64& TargetParam, bool EndStart, const struct FBrgFloat64& Param);
		void InitializeOneParam(struct FParamMoveData* Data, EParamMoveType Type, float StartParam, float TargetParam, bool EndStart, float Param);
		void Initialize(struct FParamMoveData* Data, EParamMoveType Type, const struct FVector& StartParam, const struct FVector& TargetParam, bool EndStart, float Param);
		void GlobalInitialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgMeshOutlineManager
	 * Size -> 0x2D018 (FullSize[0x2D078] - InheritedSize[0x0060])
	 */
	class UBrgMeshOutlineManager : public UObject
	{
	public:
		unsigned long                                              mGlobalVisible : 1;                                      // 0x0060(0x0001) BIT_FIELD
		int32_t                                                    mMeshNum;                                                // 0x0064(0x0004)
		struct FBrgMeshOutlineInfo                                 mMeshs[0x400];                                           // 0x0068(0x2D000) Component, NeedCtorLink
		class ABrgGameInfoNativeBase*                              mGameInfoNativeBase;                                     // 0x2D068(0x0008)
		class UMaterialInstanceConstant*                           mOutlineMIC;                                             // 0x2D070(0x0008)

	public:
		void TickProcess(float inDeltaTime);
		void SetGlobalVisible(bool Invisible);
		class UStaticMeshComponent* GetOutlineStaticMeshComponent(int32_t InIndex);
		bool CheckValid(int32_t InIndex);
		bool GetVisible(int32_t InIndex);
		bool SetVisible(int32_t InIndex, bool Invisible, bool inAlwaysProcess);
		bool DelOutlineMesh(int32_t InIndex);
		int32_t SearchOutlineMesh(class AActor* inTargetActor, class UStaticMeshComponent* inStaticMC, class USkeletalMeshComponent* inSkeletalMC);
		int32_t AddOutlineMesh(class AActor* inTargetActor, class UStaticMeshComponent* inStaticMC, class USkeletalMeshComponent* inSkeletalMC);
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkCacheRequest
	 * Size -> 0x005C (FullSize[0x00BC] - InheritedSize[0x0060])
	 */
	class UBrgNetworkCacheRequest : public UObject
	{
	public:
		struct FMap_Mirror                                         RequestMap;                                              // 0x0060(0x0048) Native
		TArray<class UJsonObject*>                                 Requests;                                                // 0x00A8(0x0010) NeedCtorLink
		unsigned long                                              CacheEnable : 1;                                         // 0x00B8(0x0001) BIT_FIELD Config

	public:
		class UJsonObject* FindCacheRequest(const class FString& cacheApiName, class UJsonObject* jsonObj);
		bool RemoveCacheRequest(const class FString& cacheApiName);
		bool AddCacheRequest(const class FString& cacheApiName, class UJsonObject* jsonObj);
		void Update(float DeltaTime);
		bool GetCacheEnable();
		void SetCacheEnable(bool flag);
		void Terminate();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkDeclEnum
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgNetworkDeclEnum : public UObject
	{
	public:
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkDeclStruct
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgNetworkDeclStruct : public UObject
	{
	public:
		void SetBrgDbMasterLastfloorValue(const struct FBrgDbMasterLastfloor& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterLastfloorValue(class UJsonObject* jsonObj, struct FBrgDbMasterLastfloor* outObj);
		void SetBrgDbSaveDiePointParamValue(const struct FBrgDbSaveDiePointParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSaveDiePointParamValue(class UJsonObject* jsonObj, struct FBrgDbSaveDiePointParam* outObj);
		void SetBrgDbFortBreakBonusValue(const struct FBrgDbFortBreakBonus& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFortBreakBonusValue(class UJsonObject* jsonObj, struct FBrgDbFortBreakBonus* outObj);
		void SetBrgDbTargetPointAllValue(const struct FBrgDbTargetPointAll& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTargetPointAllValue(class UJsonObject* jsonObj, struct FBrgDbTargetPointAll* outObj);
		void SetBrgDbBreakableObjTargetPointValue(const struct FBrgDbBreakableObjTargetPoint& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBreakableObjTargetPointValue(class UJsonObject* jsonObj, struct FBrgDbBreakableObjTargetPoint* outObj);
		void SetBrgDbTrboxTargetPointValue(const struct FBrgDbTrboxTargetPoint& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTrboxTargetPointValue(class UJsonObject* jsonObj, struct FBrgDbTrboxTargetPoint* outObj);
		void SetBrgDbItemTargetPointValue(const struct FBrgDbItemTargetPoint& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbItemTargetPointValue(class UJsonObject* jsonObj, struct FBrgDbItemTargetPoint* outObj);
		void SetBrgDbBeastTargetPointValue(const struct FBrgDbBeastTargetPoint& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBeastTargetPointValue(class UJsonObject* jsonObj, struct FBrgDbBeastTargetPoint* outObj);
		void SetBrgDbMushroomTargetPointValue(const struct FBrgDbMushroomTargetPoint& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMushroomTargetPointValue(class UJsonObject* jsonObj, struct FBrgDbMushroomTargetPoint* outObj);
		void SetBrgDbMbossTargetPointValue(const struct FBrgDbMbossTargetPoint& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMbossTargetPointValue(class UJsonObject* jsonObj, struct FBrgDbMbossTargetPoint* outObj);
		void SetBrgDbZakoTargetPointValue(const struct FBrgDbZakoTargetPoint& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbZakoTargetPointValue(class UJsonObject* jsonObj, struct FBrgDbZakoTargetPoint* outObj);
		void SetBrgDbZombieTargetPointValue(const struct FBrgDbZombieTargetPoint& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbZombieTargetPointValue(class UJsonObject* jsonObj, struct FBrgDbZombieTargetPoint* outObj);
		void SetBrgDbMasterZakoGenValue(const struct FBrgDbMasterZakoGen& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterZakoGenValue(class UJsonObject* jsonObj, struct FBrgDbMasterZakoGen* outObj);
		void SetBrgDbMasterBeastGenValue(const struct FBrgDbMasterBeastGen& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterBeastGenValue(class UJsonObject* jsonObj, struct FBrgDbMasterBeastGen* outObj);
		void SetBrgDbServerEnvListValue(const struct FBrgDbServerEnvList& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbServerEnvListValue(class UJsonObject* jsonObj, struct FBrgDbServerEnvList* outObj);
		void SetBrgDbServerEnvValue(const struct FBrgDbServerEnv& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbServerEnvValue(class UJsonObject* jsonObj, struct FBrgDbServerEnv* outObj);
		void SetBrgDbServerEnvUrlValue(const struct FBrgDbServerEnvUrl& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbServerEnvUrlValue(class UJsonObject* jsonObj, struct FBrgDbServerEnvUrl* outObj);
		void SetBrgDbLogoutParamValue(const struct FBrgDbLogoutParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbLogoutParamValue(class UJsonObject* jsonObj, struct FBrgDbLogoutParam* outObj);
		void SetBrgFrameRateSkipLogParamValue(const struct FBrgFrameRateSkipLogParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgFrameRateSkipLogParamValue(class UJsonObject* jsonObj, struct FBrgFrameRateSkipLogParam* outObj);
		void SetBrgFrameRateSkipInfoValue(const struct FBrgFrameRateSkipInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgFrameRateSkipInfoValue(class UJsonObject* jsonObj, struct FBrgFrameRateSkipInfo* outObj);
		void SetBrgFrameRateSkipObjectValue(const struct FBrgFrameRateSkipObject& Arg, class UJsonObject** outJsonObj);
		void GetBrgFrameRateSkipObjectValue(class UJsonObject* jsonObj, struct FBrgFrameRateSkipObject* outObj);
		void SetBrgRecoverErrorParamValue(const struct FBrgRecoverErrorParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgRecoverErrorParamValue(class UJsonObject* jsonObj, struct FBrgRecoverErrorParam* outObj);
		void SetBrgDbUpdateUserInfoParamValue(const struct FBrgDbUpdateUserInfoParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUpdateUserInfoParamValue(class UJsonObject* jsonObj, struct FBrgDbUpdateUserInfoParam* outObj);
		void SetBrgDbInputUserNameParamValue(const struct FBrgDbInputUserNameParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbInputUserNameParamValue(class UJsonObject* jsonObj, struct FBrgDbInputUserNameParam* outObj);
		void SetBrgDbUpdateCharaNameParamValue(const struct FBrgDbUpdateCharaNameParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUpdateCharaNameParamValue(class UJsonObject* jsonObj, struct FBrgDbUpdateCharaNameParam* outObj);
		void SetBrgDbUserSpecAndSettingValue(const struct FBrgDbUserSpecAndSetting& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserSpecAndSettingValue(class UJsonObject* jsonObj, struct FBrgDbUserSpecAndSetting* outObj);
		void SetBrgDbSkillGroupValue(const struct FBrgDbSkillGroup& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSkillGroupValue(class UJsonObject* jsonObj, struct FBrgDbSkillGroup* outObj);
		void SetBrgDbSkillCategoryValue(const struct FBrgDbSkillCategory& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSkillCategoryValue(class UJsonObject* jsonObj, struct FBrgDbSkillCategory* outObj);
		void SetBrgDbTmpMsgValue(const struct FBrgDbTmpMsg& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTmpMsgValue(class UJsonObject* jsonObj, struct FBrgDbTmpMsg* outObj);
		void SetBrgDbScreenshotValue(const struct FBrgDbScreenshot& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbScreenshotValue(class UJsonObject* jsonObj, struct FBrgDbScreenshot* outObj);
		void SetBrgDbEndSpParamValue(const struct FBrgDbEndSpParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbEndSpParamValue(class UJsonObject* jsonObj, struct FBrgDbEndSpParam* outObj);
		void SetBrgDbRadioJingleValue(const struct FBrgDbRadioJingle& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRadioJingleValue(class UJsonObject* jsonObj, struct FBrgDbRadioJingle* outObj);
		void SetBrgDbRadioYotsuyamaValue(const struct FBrgDbRadioYotsuyama& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRadioYotsuyamaValue(class UJsonObject* jsonObj, struct FBrgDbRadioYotsuyama* outObj);
		void SetBrgDbRadioChannelValue(const struct FBrgDbRadioChannel& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRadioChannelValue(class UJsonObject* jsonObj, struct FBrgDbRadioChannel* outObj);
		void SetBrgDbRadioMusicValue(const struct FBrgDbRadioMusic& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRadioMusicValue(class UJsonObject* jsonObj, struct FBrgDbRadioMusic* outObj);
		void SetBrgDbMasterWhistleGenValue(const struct FBrgDbMasterWhistleGen& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterWhistleGenValue(class UJsonObject* jsonObj, struct FBrgDbMasterWhistleGen* outObj);
		void SetBrgDbMasterWhistleValue(const struct FBrgDbMasterWhistle& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterWhistleValue(class UJsonObject* jsonObj, struct FBrgDbMasterWhistle* outObj);
		void SetBrgDbPlaylogValue(const struct FBrgDbPlaylog& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPlaylogValue(class UJsonObject* jsonObj, struct FBrgDbPlaylog* outObj);
		void SetBrgDbPlaylogFortValue(const struct FBrgDbPlaylogFort& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPlaylogFortValue(class UJsonObject* jsonObj, struct FBrgDbPlaylogFort* outObj);
		void SetBrgDbPlaylogFighterValue(const struct FBrgDbPlaylogFighter& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPlaylogFighterValue(class UJsonObject* jsonObj, struct FBrgDbPlaylogFighter* outObj);
		void SetBrgDbPlaylogMoneyValue(const struct FBrgDbPlaylogMoney& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPlaylogMoneyValue(class UJsonObject* jsonObj, struct FBrgDbPlaylogMoney* outObj);
		void SetBrgDbPlaylogFamousValue(const struct FBrgDbPlaylogFamous& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPlaylogFamousValue(class UJsonObject* jsonObj, struct FBrgDbPlaylogFamous* outObj);
		void SetBrgDbPlaylogKillValue(const struct FBrgDbPlaylogKill& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPlaylogKillValue(class UJsonObject* jsonObj, struct FBrgDbPlaylogKill* outObj);
		void SetBrgDbPlaylogDiedValue(const struct FBrgDbPlaylogDied& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPlaylogDiedValue(class UJsonObject* jsonObj, struct FBrgDbPlaylogDied* outObj);
		void SetBrgDbPlaylogCharaValue(const struct FBrgDbPlaylogChara& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPlaylogCharaValue(class UJsonObject* jsonObj, struct FBrgDbPlaylogChara* outObj);
		void SetBrgDbPlaylogUserValue(const struct FBrgDbPlaylogUser& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPlaylogUserValue(class UJsonObject* jsonObj, struct FBrgDbPlaylogUser* outObj);
		void SetBrgDbUpdateRevengeParamValue(const struct FBrgDbUpdateRevengeParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUpdateRevengeParamValue(class UJsonObject* jsonObj, struct FBrgDbUpdateRevengeParam* outObj);
		void SetBrgDbRevengeValue(const struct FBrgDbRevenge& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRevengeValue(class UJsonObject* jsonObj, struct FBrgDbRevenge* outObj);
		void SetBrgDbUpdateFriendParamValue(const struct FBrgDbUpdateFriendParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUpdateFriendParamValue(class UJsonObject* jsonObj, struct FBrgDbUpdateFriendParam* outObj);
		void SetBrgDbPSNFriendDiffValue(const struct FBrgDbPSNFriendDiff& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPSNFriendDiffValue(class UJsonObject* jsonObj, struct FBrgDbPSNFriendDiff* outObj);
		void SetBrgDbHunterResultValue(const struct FBrgDbHunterResult& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbHunterResultValue(class UJsonObject* jsonObj, struct FBrgDbHunterResult* outObj);
		void SetBrgDbHunterRewardValue(const struct FBrgDbHunterReward& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbHunterRewardValue(class UJsonObject* jsonObj, struct FBrgDbHunterReward* outObj);
		void SetBrgDbHunterResultTargetValue(const struct FBrgDbHunterResultTarget& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbHunterResultTargetValue(class UJsonObject* jsonObj, struct FBrgDbHunterResultTarget* outObj);
		void SetBrgDbHunterResultBaseValue(const struct FBrgDbHunterResultBase& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbHunterResultBaseValue(class UJsonObject* jsonObj, struct FBrgDbHunterResultBase* outObj);
		void SetBrgDbShowHunterResultParamValue(const struct FBrgDbShowHunterResultParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbShowHunterResultParamValue(class UJsonObject* jsonObj, struct FBrgDbShowHunterResultParam* outObj);
		void SetBrgDbRoastMushroomParamValue(const struct FBrgDbRoastMushroomParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRoastMushroomParamValue(class UJsonObject* jsonObj, struct FBrgDbRoastMushroomParam* outObj);
		void SetBrgDbFortterminalParamValue(const struct FBrgDbFortterminalParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFortterminalParamValue(class UJsonObject* jsonObj, struct FBrgDbFortterminalParam* outObj);
		void SetBrgDbUpdateFortSettingParamValue(const struct FBrgDbUpdateFortSettingParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUpdateFortSettingParamValue(class UJsonObject* jsonObj, struct FBrgDbUpdateFortSettingParam* outObj);
		void SetBrgDbGetAssaultFortResultParamValue(const struct FBrgDbGetAssaultFortResultParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbGetAssaultFortResultParamValue(class UJsonObject* jsonObj, struct FBrgDbGetAssaultFortResultParam* outObj);
		void SetBrgDbAssaultFortResultParamValue(const struct FBrgDbAssaultFortResultParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAssaultFortResultParamValue(class UJsonObject* jsonObj, struct FBrgDbAssaultFortResultParam* outObj);
		void SetBrgDbAssaultFortParamValue(const struct FBrgDbAssaultFortParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAssaultFortParamValue(class UJsonObject* jsonObj, struct FBrgDbAssaultFortParam* outObj);
		void SetBrgDbSendHunterParamValue(const struct FBrgDbSendHunterParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSendHunterParamValue(class UJsonObject* jsonObj, struct FBrgDbSendHunterParam* outObj);
		void SetBrgDbSkillGachaResultValue(const struct FBrgDbSkillGachaResult& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSkillGachaResultValue(class UJsonObject* jsonObj, struct FBrgDbSkillGachaResult* outObj);
		void SetBrgDbGachaValue(const struct FBrgDbGacha& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbGachaValue(class UJsonObject* jsonObj, struct FBrgDbGacha* outObj);
		void SetBrgDbGachaContentValue(const struct FBrgDbGachaContent& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbGachaContentValue(class UJsonObject* jsonObj, struct FBrgDbGachaContent* outObj);
		void SetBrgDbUserBoxGachaValue(const struct FBrgDbUserBoxGacha& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserBoxGachaValue(class UJsonObject* jsonObj, struct FBrgDbUserBoxGacha* outObj);
		void SetBrgDbUserBoxGachaContentValue(const struct FBrgDbUserBoxGachaContent& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserBoxGachaContentValue(class UJsonObject* jsonObj, struct FBrgDbUserBoxGachaContent* outObj);
		void SetBrgDbResetBoxGachaParamValue(const struct FBrgDbResetBoxGachaParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbResetBoxGachaParamValue(class UJsonObject* jsonObj, struct FBrgDbResetBoxGachaParam* outObj);
		void SetBrgDbSkillGachaParamValue(const struct FBrgDbSkillGachaParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSkillGachaParamValue(class UJsonObject* jsonObj, struct FBrgDbSkillGachaParam* outObj);
		void SetBrgDbUseSafeParamValue(const struct FBrgDbUseSafeParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUseSafeParamValue(class UJsonObject* jsonObj, struct FBrgDbUseSafeParam* outObj);
		void SetBrgDbReduceWaitingParamValue(const struct FBrgDbReduceWaitingParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbReduceWaitingParamValue(class UJsonObject* jsonObj, struct FBrgDbReduceWaitingParam* outObj);
		void SetBrgDbOrderQuestsParamValue(const struct FBrgDbOrderQuestsParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbOrderQuestsParamValue(class UJsonObject* jsonObj, struct FBrgDbOrderQuestsParam* outObj);
		void SetBrgDbGetQuestsParamValue(const struct FBrgDbGetQuestsParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbGetQuestsParamValue(class UJsonObject* jsonObj, struct FBrgDbGetQuestsParam* outObj);
		void SetBrgDbQuestValue(const struct FBrgDbQuest& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbQuestValue(class UJsonObject* jsonObj, struct FBrgDbQuest* outObj);
		void SetBrgDbMasterQuestCategoryValue(const struct FBrgDbMasterQuestCategory& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterQuestCategoryValue(class UJsonObject* jsonObj, struct FBrgDbMasterQuestCategory* outObj);
		void SetBrgDbMasterQuestValue(const struct FBrgDbMasterQuest& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterQuestValue(class UJsonObject* jsonObj, struct FBrgDbMasterQuest* outObj);
		void SetBrgDbMasterZombieParamValue(const struct FBrgDbMasterZombieParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterZombieParamValue(class UJsonObject* jsonObj, struct FBrgDbMasterZombieParam* outObj);
		void SetBrgDbUpdateHubCustomizeParamValue(const struct FBrgDbUpdateHubCustomizeParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUpdateHubCustomizeParamValue(class UJsonObject* jsonObj, struct FBrgDbUpdateHubCustomizeParam* outObj);
		void SetBrgDbChangeTeamParamValue(const struct FBrgDbChangeTeamParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbChangeTeamParamValue(class UJsonObject* jsonObj, struct FBrgDbChangeTeamParam* outObj);
		void SetBrgDbAssaultFortResultValue(const struct FBrgDbAssaultFortResult& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAssaultFortResultValue(class UJsonObject* jsonObj, struct FBrgDbAssaultFortResult* outObj);
		void SetBrgDbAssaultFortResultDetailValue(const struct FBrgDbAssaultFortResultDetail& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAssaultFortResultDetailValue(class UJsonObject* jsonObj, struct FBrgDbAssaultFortResultDetail* outObj);
		void SetBrgDbFortTakeoutCharaValue(const struct FBrgDbFortTakeoutChara& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFortTakeoutCharaValue(class UJsonObject* jsonObj, struct FBrgDbFortTakeoutChara* outObj);
		void SetBrgDbAssaultFortResultOldValue(const struct FBrgDbAssaultFortResultOld& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAssaultFortResultOldValue(class UJsonObject* jsonObj, struct FBrgDbAssaultFortResultOld* outObj);
		void SetBrgDbFortValue(const struct FBrgDbFort& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFortValue(class UJsonObject* jsonObj, struct FBrgDbFort* outObj);
		void SetBrgDbFortWaveValue(const struct FBrgDbFortWave& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFortWaveValue(class UJsonObject* jsonObj, struct FBrgDbFortWave* outObj);
		void SetBrgDbZombieOrderValue(const struct FBrgDbZombieOrder& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbZombieOrderValue(class UJsonObject* jsonObj, struct FBrgDbZombieOrder* outObj);
		void SetBrgDbAssaultFeeAllValue(const struct FBrgDbAssaultFeeAll& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAssaultFeeAllValue(class UJsonObject* jsonObj, struct FBrgDbAssaultFeeAll* outObj);
		void SetBrgDbAssaultFortCountAllValue(const struct FBrgDbAssaultFortCountAll& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAssaultFortCountAllValue(class UJsonObject* jsonObj, struct FBrgDbAssaultFortCountAll* outObj);
		void SetBrgDbFortDestAllValue(const struct FBrgDbFortDestAll& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFortDestAllValue(class UJsonObject* jsonObj, struct FBrgDbFortDestAll* outObj);
		void SetBrgDbFortDestAllOldValue(const struct FBrgDbFortDestAllOld& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFortDestAllOldValue(class UJsonObject* jsonObj, struct FBrgDbFortDestAllOld* outObj);
		void SetBrgDbAssaultFortCountValue(const struct FBrgDbAssaultFortCount& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAssaultFortCountValue(class UJsonObject* jsonObj, struct FBrgDbAssaultFortCount* outObj);
		void SetBrgDbDeffenceFortHubStateValue(const struct FBrgDbDeffenceFortHubState& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDeffenceFortHubStateValue(class UJsonObject* jsonObj, struct FBrgDbDeffenceFortHubState* outObj);
		void SetBrgDbRescueDestValue(const struct FBrgDbRescueDest& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRescueDestValue(class UJsonObject* jsonObj, struct FBrgDbRescueDest* outObj);
		void SetBrgDbRescueLogValue(const struct FBrgDbRescueLog& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRescueLogValue(class UJsonObject* jsonObj, struct FBrgDbRescueLog* outObj);
		void SetBrgDbFortDestValue(const struct FBrgDbFortDest& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFortDestValue(class UJsonObject* jsonObj, struct FBrgDbFortDest* outObj);
		void SetBrgDbFortDestOldValue(const struct FBrgDbFortDestOld& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFortDestOldValue(class UJsonObject* jsonObj, struct FBrgDbFortDestOld* outObj);
		void SetBrgDbHunterDestAllValue(const struct FBrgDbHunterDestAll& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbHunterDestAllValue(class UJsonObject* jsonObj, struct FBrgDbHunterDestAll* outObj);
		void SetBrgDbHunterDestValue(const struct FBrgDbHunterDest& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbHunterDestValue(class UJsonObject* jsonObj, struct FBrgDbHunterDest* outObj);
		void SetBrgDbReceiveDeathboxParamValue(const struct FBrgDbReceiveDeathboxParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbReceiveDeathboxParamValue(class UJsonObject* jsonObj, struct FBrgDbReceiveDeathboxParam* outObj);
		void SetBrgDbOperatePresentParamValue(const struct FBrgDbOperatePresentParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbOperatePresentParamValue(class UJsonObject* jsonObj, struct FBrgDbOperatePresentParam* outObj);
		void SetBrgDbOperatePresentHistoryValue(const struct FBrgDbOperatePresentHistory& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbOperatePresentHistoryValue(class UJsonObject* jsonObj, struct FBrgDbOperatePresentHistory* outObj);
		void SetBrgDbReceivePresentParamValue(const struct FBrgDbReceivePresentParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbReceivePresentParamValue(class UJsonObject* jsonObj, struct FBrgDbReceivePresentParam* outObj);
		void SetBrgDbUserConfigMenuValue(const struct FBrgDbUserConfigMenu& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserConfigMenuValue(class UJsonObject* jsonObj, struct FBrgDbUserConfigMenu* outObj);
		void SetBrgDbUserConfigValue(const struct FBrgDbUserConfig& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserConfigValue(class UJsonObject* jsonObj, struct FBrgDbUserConfig* outObj);
		void SetBrgDbGetLocdatParamValue(const struct FBrgDbGetLocdatParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbGetLocdatParamValue(class UJsonObject* jsonObj, struct FBrgDbGetLocdatParam* outObj);
		void SetBrgDbVipPurchaseParamValue(const struct FBrgDbVipPurchaseParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbVipPurchaseParamValue(class UJsonObject* jsonObj, struct FBrgDbVipPurchaseParam* outObj);
		void SetBrgDbUserVipConfigParamValue(const struct FBrgDbUserVipConfigParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserVipConfigParamValue(class UJsonObject* jsonObj, struct FBrgDbUserVipConfigParam* outObj);
		void SetBrgDbUserVipUseParamValue(const struct FBrgDbUserVipUseParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserVipUseParamValue(class UJsonObject* jsonObj, struct FBrgDbUserVipUseParam* outObj);
		void SetBrgDbOpenDialogParamValue(const struct FBrgDbOpenDialogParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbOpenDialogParamValue(class UJsonObject* jsonObj, struct FBrgDbOpenDialogParam* outObj);
		void SetBrgDbUpdateMedalParamValue(const struct FBrgDbUpdateMedalParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUpdateMedalParamValue(class UJsonObject* jsonObj, struct FBrgDbUpdateMedalParam* outObj);
		void SetBrgDbDistributeBodyLvlParamValue(const struct FBrgDbDistributeBodyLvlParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDistributeBodyLvlParamValue(class UJsonObject* jsonObj, struct FBrgDbDistributeBodyLvlParam* outObj);
		void SetBrgDbAccessPrisonParamValue(const struct FBrgDbAccessPrisonParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAccessPrisonParamValue(class UJsonObject* jsonObj, struct FBrgDbAccessPrisonParam* outObj);
		void SetBrgDbFreezeAbducteeParamValue(const struct FBrgDbFreezeAbducteeParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFreezeAbducteeParamValue(class UJsonObject* jsonObj, struct FBrgDbFreezeAbducteeParam* outObj);
		void SetBrgDbReleaseAbducteeParamValue(const struct FBrgDbReleaseAbducteeParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbReleaseAbducteeParamValue(class UJsonObject* jsonObj, struct FBrgDbReleaseAbducteeParam* outObj);
		void SetBrgDbPurchaseBodyParamValue(const struct FBrgDbPurchaseBodyParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPurchaseBodyParamValue(class UJsonObject* jsonObj, struct FBrgDbPurchaseBodyParam* outObj);
		void SetBrgDbSelectBodyParamValue(const struct FBrgDbSelectBodyParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSelectBodyParamValue(class UJsonObject* jsonObj, struct FBrgDbSelectBodyParam* outObj);
		void SetBrgDbPayRansomParamValue(const struct FBrgDbPayRansomParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPayRansomParamValue(class UJsonObject* jsonObj, struct FBrgDbPayRansomParam* outObj);
		void SetBrgDbDestroyCharaParamValue(const struct FBrgDbDestroyCharaParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDestroyCharaParamValue(class UJsonObject* jsonObj, struct FBrgDbDestroyCharaParam* outObj);
		void SetBrgDbSelectCharaParamValue(const struct FBrgDbSelectCharaParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSelectCharaParamValue(class UJsonObject* jsonObj, struct FBrgDbSelectCharaParam* outObj);
		void SetBrgDbForsakeAbducteeParamValue(const struct FBrgDbForsakeAbducteeParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbForsakeAbducteeParamValue(class UJsonObject* jsonObj, struct FBrgDbForsakeAbducteeParam* outObj);
		void SetBrgDbForsakeParamValue(const struct FBrgDbForsakeParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbForsakeParamValue(class UJsonObject* jsonObj, struct FBrgDbForsakeParam* outObj);
		void SetBrgDbRecoveryParamValue(const struct FBrgDbRecoveryParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRecoveryParamValue(class UJsonObject* jsonObj, struct FBrgDbRecoveryParam* outObj);
		void SetBrgDbCancelHunterParamValue(const struct FBrgDbCancelHunterParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbCancelHunterParamValue(class UJsonObject* jsonObj, struct FBrgDbCancelHunterParam* outObj);
		void SetBrgDbSalvageParamValue(const struct FBrgDbSalvageParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSalvageParamValue(class UJsonObject* jsonObj, struct FBrgDbSalvageParam* outObj);
		void SetBrgDbDbgStartHubParamValue(const struct FBrgDbDbgStartHubParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDbgStartHubParamValue(class UJsonObject* jsonObj, struct FBrgDbDbgStartHubParam* outObj);
		void SetBrgDbStartHubParamValue(const struct FBrgDbStartHubParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbStartHubParamValue(class UJsonObject* jsonObj, struct FBrgDbStartHubParam* outObj);
		void SetBrgDbMasterHubCustomizeValue(const struct FBrgDbMasterHubCustomize& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterHubCustomizeValue(class UJsonObject* jsonObj, struct FBrgDbMasterHubCustomize* outObj);
		void SetBrgDbBloodniumValue(const struct FBrgDbBloodnium& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBloodniumValue(class UJsonObject* jsonObj, struct FBrgDbBloodnium* outObj);
		void SetBrgDbUserHubCustomizeValue(const struct FBrgDbUserHubCustomize& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserHubCustomizeValue(class UJsonObject* jsonObj, struct FBrgDbUserHubCustomize* outObj);
		void SetBrgDbHubCustomizeLogValue(const struct FBrgDbHubCustomizeLog& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbHubCustomizeLogValue(class UJsonObject* jsonObj, struct FBrgDbHubCustomizeLog* outObj);
		void SetBrgDbAreaTemplateInfoValue(const struct FBrgDbAreaTemplateInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAreaTemplateInfoValue(class UJsonObject* jsonObj, struct FBrgDbAreaTemplateInfo* outObj);
		void SetBrgDbAreaInfoValue(const struct FBrgDbAreaInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAreaInfoValue(class UJsonObject* jsonObj, struct FBrgDbAreaInfo* outObj);
		void SetBrgDbAreaSettingValue(const struct FBrgDbAreaSetting& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAreaSettingValue(class UJsonObject* jsonObj, struct FBrgDbAreaSetting* outObj);
		void SetBrgDbAreaSettingReplaceUnitValue(const struct FBrgDbAreaSettingReplaceUnit& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAreaSettingReplaceUnitValue(class UJsonObject* jsonObj, struct FBrgDbAreaSettingReplaceUnit* outObj);
		void SetBrgDbAreaSettingConditionValue(const struct FBrgDbAreaSettingCondition& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAreaSettingConditionValue(class UJsonObject* jsonObj, struct FBrgDbAreaSettingCondition* outObj);
		void SetBrgDbAreaUnitValue(const struct FBrgDbAreaUnit& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAreaUnitValue(class UJsonObject* jsonObj, struct FBrgDbAreaUnit* outObj);
		void SetBrgDbAreaCandidateValue(const struct FBrgDbAreaCandidate& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAreaCandidateValue(class UJsonObject* jsonObj, struct FBrgDbAreaCandidate* outObj);
		void SetBrgDbAreaTemplateValue(const struct FBrgDbAreaTemplate& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAreaTemplateValue(class UJsonObject* jsonObj, struct FBrgDbAreaTemplate* outObj);
		void SetBrgDbAreaConnectRepeatStraightValue(const struct FBrgDbAreaConnectRepeatStraight& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAreaConnectRepeatStraightValue(class UJsonObject* jsonObj, struct FBrgDbAreaConnectRepeatStraight* outObj);
		void SetBrgDbAreaConnectValue(const struct FBrgDbAreaConnect& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAreaConnectValue(class UJsonObject* jsonObj, struct FBrgDbAreaConnect* outObj);
		void SetBrgDbAreaConnectFlagOffsetValue(const struct FBrgDbAreaConnectFlagOffset& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAreaConnectFlagOffsetValue(class UJsonObject* jsonObj, struct FBrgDbAreaConnectFlagOffset* outObj);
		void SetBrgDbAreaConnectEscalatorValue(const struct FBrgDbAreaConnectEscalator& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAreaConnectEscalatorValue(class UJsonObject* jsonObj, struct FBrgDbAreaConnectEscalator* outObj);
		void SetBrgDbScentenceInfoValue(const struct FBrgDbScentenceInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbScentenceInfoValue(class UJsonObject* jsonObj, struct FBrgDbScentenceInfo* outObj);
		void SetBrgDbSentenceValue(const struct FBrgDbSentence& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSentenceValue(class UJsonObject* jsonObj, struct FBrgDbSentence* outObj);
		void SetTest_structValue(const struct Ftest_struct& Arg, class UJsonObject** outJsonObj);
		void GetTest_structValue(class UJsonObject* jsonObj, struct Ftest_struct* outObj);
		void SetTest_struct2Value(const struct Ftest_struct2& Arg, class UJsonObject** outJsonObj);
		void GetTest_struct2Value(class UJsonObject* jsonObj, struct Ftest_struct2* outObj);
		void SetBrgDbMsglogValue(const struct FBrgDbMsglog& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMsglogValue(class UJsonObject* jsonObj, struct FBrgDbMsglog* outObj);
		void SetBrgDbMsgValue(const struct FBrgDbMsg& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMsgValue(class UJsonObject* jsonObj, struct FBrgDbMsg* outObj);
		void SetBrgDbPresentValue(const struct FBrgDbPresent& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPresentValue(class UJsonObject* jsonObj, struct FBrgDbPresent* outObj);
		void SetBrgDbPresentItemValue(const struct FBrgDbPresentItem& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPresentItemValue(class UJsonObject* jsonObj, struct FBrgDbPresentItem* outObj);
		void SetBrgDbLogElementValue(const struct FBrgDbLogElement& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbLogElementValue(class UJsonObject* jsonObj, struct FBrgDbLogElement* outObj);
		void SetBrgDbGrimPeaperMenuValue(const struct FBrgDbGrimPeaperMenu& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbGrimPeaperMenuValue(class UJsonObject* jsonObj, struct FBrgDbGrimPeaperMenu* outObj);
		void SetBrgDbPlayLogMenuValue(const struct FBrgDbPlayLogMenu& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPlayLogMenuValue(class UJsonObject* jsonObj, struct FBrgDbPlayLogMenu* outObj);
		void SetBrgDbSubtitleInfoValue(const struct FBrgDbSubtitleInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSubtitleInfoValue(class UJsonObject* jsonObj, struct FBrgDbSubtitleInfo* outObj);
		void SetBrgDbSubtitlePkgValue(const struct FBrgDbSubtitlePkg& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSubtitlePkgValue(class UJsonObject* jsonObj, struct FBrgDbSubtitlePkg* outObj);
		void SetBrgDbSubtitleWavValue(const struct FBrgDbSubtitleWav& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSubtitleWavValue(class UJsonObject* jsonObj, struct FBrgDbSubtitleWav* outObj);
		void SetBrgDbSubtitleValue(const struct FBrgDbSubtitle& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSubtitleValue(class UJsonObject* jsonObj, struct FBrgDbSubtitle* outObj);
		void SetBrgDbLocInfoValue(const struct FBrgDbLocInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbLocInfoValue(class UJsonObject* jsonObj, struct FBrgDbLocInfo* outObj);
		void SetBrgDbLocSectionValue(const struct FBrgDbLocSection& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbLocSectionValue(class UJsonObject* jsonObj, struct FBrgDbLocSection* outObj);
		void SetBrgDbLocTextValue(const struct FBrgDbLocText& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbLocTextValue(class UJsonObject* jsonObj, struct FBrgDbLocText* outObj);
		void SetBrgDbDbgMoveFloorParamValue(const struct FBrgDbDbgMoveFloorParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDbgMoveFloorParamValue(class UJsonObject* jsonObj, struct FBrgDbDbgMoveFloorParam* outObj);
		void SetBrgDbMoveFloorParamValue(const struct FBrgDbMoveFloorParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMoveFloorParamValue(class UJsonObject* jsonObj, struct FBrgDbMoveFloorParam* outObj);
		void SetBrgDbDbgTakeElevatorParamValue(const struct FBrgDbDbgTakeElevatorParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDbgTakeElevatorParamValue(class UJsonObject* jsonObj, struct FBrgDbDbgTakeElevatorParam* outObj);
		void SetBrgDbTakeElevatorParamValue(const struct FBrgDbTakeElevatorParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTakeElevatorParamValue(class UJsonObject* jsonObj, struct FBrgDbTakeElevatorParam* outObj);
		void SetBrgDbEndBetParamValue(const struct FBrgDbEndBetParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbEndBetParamValue(class UJsonObject* jsonObj, struct FBrgDbEndBetParam* outObj);
		void SetBrgDbStartBetParamValue(const struct FBrgDbStartBetParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbStartBetParamValue(class UJsonObject* jsonObj, struct FBrgDbStartBetParam* outObj);
		void SetBrgDbEnterGateParamValue(const struct FBrgDbEnterGateParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbEnterGateParamValue(class UJsonObject* jsonObj, struct FBrgDbEnterGateParam* outObj);
		void SetBrgDbChangeCashParamValue(const struct FBrgDbChangeCashParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbChangeCashParamValue(class UJsonObject* jsonObj, struct FBrgDbChangeCashParam* outObj);
		void SetBrgDbContinueParamValue(const struct FBrgDbContinueParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbContinueParamValue(class UJsonObject* jsonObj, struct FBrgDbContinueParam* outObj);
		void SetBrgDbBlendMushroomSoupParamValue(const struct FBrgDbBlendMushroomSoupParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBlendMushroomSoupParamValue(class UJsonObject* jsonObj, struct FBrgDbBlendMushroomSoupParam* outObj);
		void SetBrgDbExpandDeathBagParamValue(const struct FBrgDbExpandDeathBagParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbExpandDeathBagParamValue(class UJsonObject* jsonObj, struct FBrgDbExpandDeathBagParam* outObj);
		void SetBrgDbUseDustshooterParamValue(const struct FBrgDbUseDustshooterParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUseDustshooterParamValue(class UJsonObject* jsonObj, struct FBrgDbUseDustshooterParam* outObj);
		void SetBrgDbExpandCoinLockerParamValue(const struct FBrgDbExpandCoinLockerParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbExpandCoinLockerParamValue(class UJsonObject* jsonObj, struct FBrgDbExpandCoinLockerParam* outObj);
		void SetBrgDbDrawCoinLockerParamValue(const struct FBrgDbDrawCoinLockerParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDrawCoinLockerParamValue(class UJsonObject* jsonObj, struct FBrgDbDrawCoinLockerParam* outObj);
		void SetBrgDbSortCoinLockerParamValue(const struct FBrgDbSortCoinLockerParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSortCoinLockerParamValue(class UJsonObject* jsonObj, struct FBrgDbSortCoinLockerParam* outObj);
		void SetBrgDbDeposCoinLockerParamValue(const struct FBrgDbDeposCoinLockerParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDeposCoinLockerParamValue(class UJsonObject* jsonObj, struct FBrgDbDeposCoinLockerParam* outObj);
		void SetBrgDbEqSkillParamValue(const struct FBrgDbEqSkillParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbEqSkillParamValue(class UJsonObject* jsonObj, struct FBrgDbEqSkillParam* outObj);
		void SetBrgDbOpSkillParamValue(const struct FBrgDbOpSkillParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbOpSkillParamValue(class UJsonObject* jsonObj, struct FBrgDbOpSkillParam* outObj);
		void SetBrgDbEnhancePartInfoValue(const struct FBrgDbEnhancePartInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbEnhancePartInfoValue(class UJsonObject* jsonObj, struct FBrgDbEnhancePartInfo* outObj);
		void SetBrgDbEnhancePartValue(const struct FBrgDbEnhancePart& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbEnhancePartValue(class UJsonObject* jsonObj, struct FBrgDbEnhancePart* outObj);
		void SetBrgDbEnhancePartParamValue(const struct FBrgDbEnhancePartParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbEnhancePartParamValue(class UJsonObject* jsonObj, struct FBrgDbEnhancePartParam* outObj);
		void SetBrgDbRepairPartInfoValue(const struct FBrgDbRepairPartInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRepairPartInfoValue(class UJsonObject* jsonObj, struct FBrgDbRepairPartInfo* outObj);
		void SetBrgDbRepairPartValue(const struct FBrgDbRepairPart& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRepairPartValue(class UJsonObject* jsonObj, struct FBrgDbRepairPart* outObj);
		void SetBrgDbRepairPartParamValue(const struct FBrgDbRepairPartParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRepairPartParamValue(class UJsonObject* jsonObj, struct FBrgDbRepairPartParam* outObj);
		void SetBrgDbSellMushroomValue(const struct FBrgDbSellMushroom& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSellMushroomValue(class UJsonObject* jsonObj, struct FBrgDbSellMushroom* outObj);
		void SetBrgDbMushroomShopValue(const struct FBrgDbMushroomShop& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMushroomShopValue(class UJsonObject* jsonObj, struct FBrgDbMushroomShop* outObj);
		void SetBrgDbSellMushroomParamValue(const struct FBrgDbSellMushroomParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSellMushroomParamValue(class UJsonObject* jsonObj, struct FBrgDbSellMushroomParam* outObj);
		void SetBrgDbSellPartValue(const struct FBrgDbSellPart& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSellPartValue(class UJsonObject* jsonObj, struct FBrgDbSellPart* outObj);
		void SetBrgDbSellPartParamValue(const struct FBrgDbSellPartParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSellPartParamValue(class UJsonObject* jsonObj, struct FBrgDbSellPartParam* outObj);
		void SetBrgDbPurchaseParamValue(const struct FBrgDbPurchaseParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPurchaseParamValue(class UJsonObject* jsonObj, struct FBrgDbPurchaseParam* outObj);
		void SetBrgDbShopPriceInfoValue(const struct FBrgDbShopPriceInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbShopPriceInfoValue(class UJsonObject* jsonObj, struct FBrgDbShopPriceInfo* outObj);
		void SetBrgDbShopPsMushroomPriceValue(const struct FBrgDbShopPsMushroomPrice& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbShopPsMushroomPriceValue(class UJsonObject* jsonObj, struct FBrgDbShopPsMushroomPrice* outObj);
		void SetBrgDbShopPsPartPriceValue(const struct FBrgDbShopPsPartPrice& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbShopPsPartPriceValue(class UJsonObject* jsonObj, struct FBrgDbShopPsPartPrice* outObj);
		void SetBrgDbShopPriceInfoParamValue(const struct FBrgDbShopPriceInfoParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbShopPriceInfoParamValue(class UJsonObject* jsonObj, struct FBrgDbShopPriceInfoParam* outObj);
		void SetBrgDbPauseGameParamValue(const struct FBrgDbPauseGameParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPauseGameParamValue(class UJsonObject* jsonObj, struct FBrgDbPauseGameParam* outObj);
		void SetBrgDbAreaMapFlagValue(const struct FBrgDbAreaMapFlag& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAreaMapFlagValue(class UJsonObject* jsonObj, struct FBrgDbAreaMapFlag* outObj);
		void SetBrgDbSaveGameParamValue(const struct FBrgDbSaveGameParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSaveGameParamValue(class UJsonObject* jsonObj, struct FBrgDbSaveGameParam* outObj);
		void SetBrgDbGetListValue(const struct FBrgDbGetList& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbGetListValue(class UJsonObject* jsonObj, struct FBrgDbGetList* outObj);
		void SetBrgDbSaveDataValue(const struct FBrgDbSaveData& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSaveDataValue(class UJsonObject* jsonObj, struct FBrgDbSaveData* outObj);
		void SetBrgDbClearFloorValue(const struct FBrgDbClearFloor& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbClearFloorValue(class UJsonObject* jsonObj, struct FBrgDbClearFloor* outObj);
		void SetBrgDbDbgStartFloorValue(const struct FBrgDbDbgStartFloor& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDbgStartFloorValue(class UJsonObject* jsonObj, struct FBrgDbDbgStartFloor* outObj);
		void SetBrgDbStartFloorValue(const struct FBrgDbStartFloor& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbStartFloorValue(class UJsonObject* jsonObj, struct FBrgDbStartFloor* outObj);
		void SetBrgDbFloorAreaValue(const struct FBrgDbFloorArea& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorAreaValue(class UJsonObject* jsonObj, struct FBrgDbFloorArea* outObj);
		void SetBrgDbFloorValue(const struct FBrgDbFloor& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorValue(class UJsonObject* jsonObj, struct FBrgDbFloor* outObj);
		void SetBrgDbFloorRefEscalatorInfoValue(const struct FBrgDbFloorRefEscalatorInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorRefEscalatorInfoValue(class UJsonObject* jsonObj, struct FBrgDbFloorRefEscalatorInfo* outObj);
		void SetBrgDbFloorRefEscalatorValue(const struct FBrgDbFloorRefEscalator& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorRefEscalatorValue(class UJsonObject* jsonObj, struct FBrgDbFloorRefEscalator* outObj);
		void SetBrgDbDebugFloorParamValue(const struct FBrgDbDebugFloorParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDebugFloorParamValue(class UJsonObject* jsonObj, struct FBrgDbDebugFloorParam* outObj);
		void SetBrgDbFloorVendingMachineValue(const struct FBrgDbFloorVendingMachine& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorVendingMachineValue(class UJsonObject* jsonObj, struct FBrgDbFloorVendingMachine* outObj);
		void SetBrgDbVendingMachineEntityValue(const struct FBrgDbVendingMachineEntity& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbVendingMachineEntityValue(class UJsonObject* jsonObj, struct FBrgDbVendingMachineEntity* outObj);
		void SetBrgDbFloorDustshooterValue(const struct FBrgDbFloorDustshooter& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorDustshooterValue(class UJsonObject* jsonObj, struct FBrgDbFloorDustshooter* outObj);
		void SetBrgDbFloorGateValue(const struct FBrgDbFloorGate& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorGateValue(class UJsonObject* jsonObj, struct FBrgDbFloorGate* outObj);
		void SetBrgDbFloorBreakableObjValue(const struct FBrgDbFloorBreakableObj& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorBreakableObjValue(class UJsonObject* jsonObj, struct FBrgDbFloorBreakableObj* outObj);
		void SetBrgDbBreakableObjEntityValue(const struct FBrgDbBreakableObjEntity& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBreakableObjEntityValue(class UJsonObject* jsonObj, struct FBrgDbBreakableObjEntity* outObj);
		void SetBrgDbFloorSkillBenchValue(const struct FBrgDbFloorSkillBench& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorSkillBenchValue(class UJsonObject* jsonObj, struct FBrgDbFloorSkillBench* outObj);
		void SetBrgDbFloorCoinLockerValue(const struct FBrgDbFloorCoinLocker& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorCoinLockerValue(class UJsonObject* jsonObj, struct FBrgDbFloorCoinLocker* outObj);
		void SetBrgDbFloorItemValue(const struct FBrgDbFloorItem& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorItemValue(class UJsonObject* jsonObj, struct FBrgDbFloorItem* outObj);
		void SetBrgDbFloorBeastValue(const struct FBrgDbFloorBeast& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorBeastValue(class UJsonObject* jsonObj, struct FBrgDbFloorBeast* outObj);
		void SetBrgDbBeastValue(const struct FBrgDbBeast& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBeastValue(class UJsonObject* jsonObj, struct FBrgDbBeast* outObj);
		void SetBrgDbBeastLevelValue(const struct FBrgDbBeastLevel& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBeastLevelValue(class UJsonObject* jsonObj, struct FBrgDbBeastLevel* outObj);
		void SetBrgDbBeastEfcValue(const struct FBrgDbBeastEfc& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBeastEfcValue(class UJsonObject* jsonObj, struct FBrgDbBeastEfc* outObj);
		void SetBrgDbFloorMushroomValue(const struct FBrgDbFloorMushroom& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorMushroomValue(class UJsonObject* jsonObj, struct FBrgDbFloorMushroom* outObj);
		void SetBrgDbMushroomValue(const struct FBrgDbMushroom& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMushroomValue(class UJsonObject* jsonObj, struct FBrgDbMushroom* outObj);
		void SetBrgDbMushroomEfcValue(const struct FBrgDbMushroomEfc& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMushroomEfcValue(class UJsonObject* jsonObj, struct FBrgDbMushroomEfc* outObj);
		void SetBrgDbMushroomEfcTypeValue(const struct FBrgDbMushroomEfcType& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMushroomEfcTypeValue(class UJsonObject* jsonObj, struct FBrgDbMushroomEfcType* outObj);
		void SetBrgDbMasterZakoValue(const struct FBrgDbMasterZako& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterZakoValue(class UJsonObject* jsonObj, struct FBrgDbMasterZako* outObj);
		void SetBrgDbFourforcemenValue(const struct FBrgDbFourforcemen& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFourforcemenValue(class UJsonObject* jsonObj, struct FBrgDbFourforcemen* outObj);
		void SetBrgDbMasterFourforcemenValue(const struct FBrgDbMasterFourforcemen& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterFourforcemenValue(class UJsonObject* jsonObj, struct FBrgDbMasterFourforcemen* outObj);
		void SetBrgDbMasterFourforcemenLevelValue(const struct FBrgDbMasterFourforcemenLevel& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterFourforcemenLevelValue(class UJsonObject* jsonObj, struct FBrgDbMasterFourforcemenLevel* outObj);
		void SetBrgDbMasterZakoLevelValue(const struct FBrgDbMasterZakoLevel& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterZakoLevelValue(class UJsonObject* jsonObj, struct FBrgDbMasterZakoLevel* outObj);
		void SetBrgDbZakoValue(const struct FBrgDbZako& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbZakoValue(class UJsonObject* jsonObj, struct FBrgDbZako* outObj);
		void SetBrgDbMasterMbossValue(const struct FBrgDbMasterMboss& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterMbossValue(class UJsonObject* jsonObj, struct FBrgDbMasterMboss* outObj);
		void SetBrgDbMasterMbossLevelValue(const struct FBrgDbMasterMbossLevel& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterMbossLevelValue(class UJsonObject* jsonObj, struct FBrgDbMasterMbossLevel* outObj);
		void SetBrgDbMbossValue(const struct FBrgDbMboss& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMbossValue(class UJsonObject* jsonObj, struct FBrgDbMboss* outObj);
		void SetBrgDbAIInfoValue(const struct FBrgDbAIInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAIInfoValue(class UJsonObject* jsonObj, struct FBrgDbAIInfo* outObj);
		void SetBrgDbZakoTrboxValue(const struct FBrgDbZakoTrbox& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbZakoTrboxValue(class UJsonObject* jsonObj, struct FBrgDbZakoTrbox* outObj);
		void SetBrgDbMbossRewardValue(const struct FBrgDbMbossReward& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMbossRewardValue(class UJsonObject* jsonObj, struct FBrgDbMbossReward* outObj);
		void SetBrgDbPurchaseValue(const struct FBrgDbPurchase& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPurchaseValue(class UJsonObject* jsonObj, struct FBrgDbPurchase* outObj);
		void SetBrgDbShopValue(const struct FBrgDbShop& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbShopValue(class UJsonObject* jsonObj, struct FBrgDbShop* outObj);
		void SetBrgDbProductValue(const struct FBrgDbProduct& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbProductValue(class UJsonObject* jsonObj, struct FBrgDbProduct* outObj);
		void SetBrgDbProductPriceValue(const struct FBrgDbProductPrice& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbProductPriceValue(class UJsonObject* jsonObj, struct FBrgDbProductPrice* outObj);
		void SetBrgDbProductPartValue(const struct FBrgDbProductPart& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbProductPartValue(class UJsonObject* jsonObj, struct FBrgDbProductPart* outObj);
		void SetBrgDbItemValue(const struct FBrgDbItem& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbItemValue(class UJsonObject* jsonObj, struct FBrgDbItem* outObj);
		void SetBrgDbDieValue(const struct FBrgDbDie& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDieValue(class UJsonObject* jsonObj, struct FBrgDbDie* outObj);
		void SetBrgDbTrBoxRewardItemValue(const struct FBrgDbTrBoxRewardItem& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTrBoxRewardItemValue(class UJsonObject* jsonObj, struct FBrgDbTrBoxRewardItem* outObj);
		void SetBrgDbTrBoxRewardPartValue(const struct FBrgDbTrBoxRewardPart& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTrBoxRewardPartValue(class UJsonObject* jsonObj, struct FBrgDbTrBoxRewardPart* outObj);
		void SetBrgDbTrBoxRewardMoneyValue(const struct FBrgDbTrBoxRewardMoney& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTrBoxRewardMoneyValue(class UJsonObject* jsonObj, struct FBrgDbTrBoxRewardMoney* outObj);
		void SetBrgDbFloorTrboxUpdateInfoValue(const struct FBrgDbFloorTrboxUpdateInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorTrboxUpdateInfoValue(class UJsonObject* jsonObj, struct FBrgDbFloorTrboxUpdateInfo* outObj);
		void SetBrgDbFloorMushroomUpdateInfoValue(const struct FBrgDbFloorMushroomUpdateInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorMushroomUpdateInfoValue(class UJsonObject* jsonObj, struct FBrgDbFloorMushroomUpdateInfo* outObj);
		void SetBrgDbBeastUpdateInfoValue(const struct FBrgDbBeastUpdateInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBeastUpdateInfoValue(class UJsonObject* jsonObj, struct FBrgDbBeastUpdateInfo* outObj);
		void SetBrgDbMbossUpdateInfoValue(const struct FBrgDbMbossUpdateInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMbossUpdateInfoValue(class UJsonObject* jsonObj, struct FBrgDbMbossUpdateInfo* outObj);
		void SetBrgDbJackalDiffValue(const struct FBrgDbJackalDiff& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbJackalDiffValue(class UJsonObject* jsonObj, struct FBrgDbJackalDiff* outObj);
		void SetBrgDbJackalValue(const struct FBrgDbJackal& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbJackalValue(class UJsonObject* jsonObj, struct FBrgDbJackal* outObj);
		void SetBrgDbZombieUpdateInfoValue(const struct FBrgDbZombieUpdateInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbZombieUpdateInfoValue(class UJsonObject* jsonObj, struct FBrgDbZombieUpdateInfo* outObj);
		void SetBrgDbZombieValue(const struct FBrgDbZombie& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbZombieValue(class UJsonObject* jsonObj, struct FBrgDbZombie* outObj);
		void SetBrgDbZombieMasterLvlValue(const struct FBrgDbZombieMasterLvl& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbZombieMasterLvlValue(class UJsonObject* jsonObj, struct FBrgDbZombieMasterLvl* outObj);
		void SetBrgDbZombieRewardValue(const struct FBrgDbZombieReward& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbZombieRewardValue(class UJsonObject* jsonObj, struct FBrgDbZombieReward* outObj);
		void SetBrgDbZombieRewardPartValue(const struct FBrgDbZombieRewardPart& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbZombieRewardPartValue(class UJsonObject* jsonObj, struct FBrgDbZombieRewardPart* outObj);
		void SetBrgDbUserValue(const struct FBrgDbUser& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserValue(class UJsonObject* jsonObj, struct FBrgDbUser* outObj);
		void SetBrgDbUserAutomaticshopWeeklyBuyableGoodsValue(const struct FBrgDbUserAutomaticshopWeeklyBuyableGoods& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserAutomaticshopWeeklyBuyableGoodsValue(class UJsonObject* jsonObj, struct FBrgDbUserAutomaticshopWeeklyBuyableGoods* outObj);
		void SetBrgDbUserSoulValue(const struct FBrgDbUserSoul& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserSoulValue(class UJsonObject* jsonObj, struct FBrgDbUserSoul* outObj);
		void SetBrgDbUserArmorSkinValue(const struct FBrgDbUserArmorSkin& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserArmorSkinValue(class UJsonObject* jsonObj, struct FBrgDbUserArmorSkin* outObj);
		void SetBrgDbUserQuickConfigValue(const struct FBrgDbUserQuickConfig& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserQuickConfigValue(class UJsonObject* jsonObj, struct FBrgDbUserQuickConfig* outObj);
		void SetBrgDbMedalValue(const struct FBrgDbMedal& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMedalValue(class UJsonObject* jsonObj, struct FBrgDbMedal* outObj);
		void SetBrgDbMedalExpireValue(const struct FBrgDbMedalExpire& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMedalExpireValue(class UJsonObject* jsonObj, struct FBrgDbMedalExpire* outObj);
		void SetBrgDbRadioValue(const struct FBrgDbRadio& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRadioValue(class UJsonObject* jsonObj, struct FBrgDbRadio* outObj);
		void SetBrgDbUserFlagValue(const struct FBrgDbUserFlag& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserFlagValue(class UJsonObject* jsonObj, struct FBrgDbUserFlag* outObj);
		void SetBrgDbFortTerminalAnnounceValue(const struct FBrgDbFortTerminalAnnounce& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFortTerminalAnnounceValue(class UJsonObject* jsonObj, struct FBrgDbFortTerminalAnnounce* outObj);
		void SetBrgDbWarRewardsValue(const struct FBrgDbWarRewards& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbWarRewardsValue(class UJsonObject* jsonObj, struct FBrgDbWarRewards* outObj);
		void SetBrgDbRankingAllValue(const struct FBrgDbRankingAll& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRankingAllValue(class UJsonObject* jsonObj, struct FBrgDbRankingAll* outObj);
		void SetBrgDbMyTeamValue(const struct FBrgDbMyTeam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMyTeamValue(class UJsonObject* jsonObj, struct FBrgDbMyTeam* outObj);
		void SetBrgDbTdmSituationValue(const struct FBrgDbTdmSituation& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTdmSituationValue(class UJsonObject* jsonObj, struct FBrgDbTdmSituation* outObj);
		void SetBrgDbTeamAssaultCountValue(const struct FBrgDbTeamAssaultCount& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTeamAssaultCountValue(class UJsonObject* jsonObj, struct FBrgDbTeamAssaultCount* outObj);
		void SetBrgDbTerminalTeamValue(const struct FBrgDbTerminalTeam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTerminalTeamValue(class UJsonObject* jsonObj, struct FBrgDbTerminalTeam* outObj);
		void SetBrgDbTeamHateValue(const struct FBrgDbTeamHate& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTeamHateValue(class UJsonObject* jsonObj, struct FBrgDbTeamHate* outObj);
		void SetBrgDbTeamValue(const struct FBrgDbTeam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTeamValue(class UJsonObject* jsonObj, struct FBrgDbTeam* outObj);
		void SetBrgDbTeamOldValue(const struct FBrgDbTeamOld& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTeamOldValue(class UJsonObject* jsonObj, struct FBrgDbTeamOld* outObj);
		void SetBrgDbTeamMemberOldValue(const struct FBrgDbTeamMemberOld& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTeamMemberOldValue(class UJsonObject* jsonObj, struct FBrgDbTeamMemberOld* outObj);
		void SetBrgDbWarValue(const struct FBrgDbWar& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbWarValue(class UJsonObject* jsonObj, struct FBrgDbWar* outObj);
		void SetBrgDbWarPersonalLogValue(const struct FBrgDbWarPersonalLog& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbWarPersonalLogValue(class UJsonObject* jsonObj, struct FBrgDbWarPersonalLog* outObj);
		void SetBrgDbWarTeamValue(const struct FBrgDbWarTeam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbWarTeamValue(class UJsonObject* jsonObj, struct FBrgDbWarTeam* outObj);
		void SetBrgDbWarTeamMemberValue(const struct FBrgDbWarTeamMember& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbWarTeamMemberValue(class UJsonObject* jsonObj, struct FBrgDbWarTeamMember* outObj);
		void SetBrgDbTeamRankingValue(const struct FBrgDbTeamRanking& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTeamRankingValue(class UJsonObject* jsonObj, struct FBrgDbTeamRanking* outObj);
		void SetBrgDbRankingValue(const struct FBrgDbRanking& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbRankingValue(class UJsonObject* jsonObj, struct FBrgDbRanking* outObj);
		void SetBrgDbFortZombieSettingValue(const struct FBrgDbFortZombieSetting& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFortZombieSettingValue(class UJsonObject* jsonObj, struct FBrgDbFortZombieSetting* outObj);
		void SetBrgDbUserPrisonValue(const struct FBrgDbUserPrison& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserPrisonValue(class UJsonObject* jsonObj, struct FBrgDbUserPrison* outObj);
		void SetBrgDbPrisonMessageValue(const struct FBrgDbPrisonMessage& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPrisonMessageValue(class UJsonObject* jsonObj, struct FBrgDbPrisonMessage* outObj);
		void SetBrgDbCharaSlotValue(const struct FBrgDbCharaSlot& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbCharaSlotValue(class UJsonObject* jsonObj, struct FBrgDbCharaSlot* outObj);
		void SetBrgDbHunterValue(const struct FBrgDbHunter& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbHunterValue(class UJsonObject* jsonObj, struct FBrgDbHunter* outObj);
		void SetBrgDbOtherUserValue(const struct FBrgDbOtherUser& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbOtherUserValue(class UJsonObject* jsonObj, struct FBrgDbOtherUser* outObj);
		void SetBrgDbUserKnownAreaValue(const struct FBrgDbUserKnownArea& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserKnownAreaValue(class UJsonObject* jsonObj, struct FBrgDbUserKnownArea* outObj);
		void SetBrgDbUserSkillRecoverValue(const struct FBrgDbUserSkillRecover& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserSkillRecoverValue(class UJsonObject* jsonObj, struct FBrgDbUserSkillRecover* outObj);
		void SetBrgDbUserMushroomShopHistoryValue(const struct FBrgDbUserMushroomShopHistory& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserMushroomShopHistoryValue(class UJsonObject* jsonObj, struct FBrgDbUserMushroomShopHistory* outObj);
		void SetBrgDbWhistleShopHistoryValue(const struct FBrgDbWhistleShopHistory& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbWhistleShopHistoryValue(class UJsonObject* jsonObj, struct FBrgDbWhistleShopHistory* outObj);
		void SetBrgDbFortShopHistoryValue(const struct FBrgDbFortShopHistory& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFortShopHistoryValue(class UJsonObject* jsonObj, struct FBrgDbFortShopHistory* outObj);
		void SetBrgDbUserBaseShopResultValue(const struct FBrgDbUserBaseShopResult& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserBaseShopResultValue(class UJsonObject* jsonObj, struct FBrgDbUserBaseShopResult* outObj);
		void SetBrgDbBaseShopProductValue(const struct FBrgDbBaseShopProduct& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBaseShopProductValue(class UJsonObject* jsonObj, struct FBrgDbBaseShopProduct* outObj);
		void SetBrgDbUserPartResearchValue(const struct FBrgDbUserPartResearch& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserPartResearchValue(class UJsonObject* jsonObj, struct FBrgDbUserPartResearch* outObj);
		void SetBrgDbMasterPartResearchValue(const struct FBrgDbMasterPartResearch& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterPartResearchValue(class UJsonObject* jsonObj, struct FBrgDbMasterPartResearch* outObj);
		void SetBrgDbUserShopHistoryValue(const struct FBrgDbUserShopHistory& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserShopHistoryValue(class UJsonObject* jsonObj, struct FBrgDbUserShopHistory* outObj);
		void SetBrgDbUserWaitingValue(const struct FBrgDbUserWaiting& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserWaitingValue(class UJsonObject* jsonObj, struct FBrgDbUserWaiting* outObj);
		void SetBrgDbResearchValue(const struct FBrgDbResearch& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbResearchValue(class UJsonObject* jsonObj, struct FBrgDbResearch* outObj);
		void SetBrgDbUserQuestValue(const struct FBrgDbUserQuest& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserQuestValue(class UJsonObject* jsonObj, struct FBrgDbUserQuest* outObj);
		void SetBrgDbQuestRewardValue(const struct FBrgDbQuestReward& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbQuestRewardValue(class UJsonObject* jsonObj, struct FBrgDbQuestReward* outObj);
		void SetBrgDbQuestRewardPartValue(const struct FBrgDbQuestRewardPart& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbQuestRewardPartValue(class UJsonObject* jsonObj, struct FBrgDbQuestRewardPart* outObj);
		void SetBrgDbConstStrValue(const struct FBrgDbConstStr& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbConstStrValue(class UJsonObject* jsonObj, struct FBrgDbConstStr* outObj);
		void SetBrgDbConstFloatValue(const struct FBrgDbConstFloat& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbConstFloatValue(class UJsonObject* jsonObj, struct FBrgDbConstFloat* outObj);
		void SetBrgDbConstIntValue(const struct FBrgDbConstInt& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbConstIntValue(class UJsonObject* jsonObj, struct FBrgDbConstInt* outObj);
		void SetBrgDbCharaDmgValue(const struct FBrgDbCharaDmg& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbCharaDmgValue(class UJsonObject* jsonObj, struct FBrgDbCharaDmg* outObj);
		void SetBrgDbInsurePtValue(const struct FBrgDbInsurePt& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbInsurePtValue(class UJsonObject* jsonObj, struct FBrgDbInsurePt* outObj);
		void SetBrgDbPsPartInsuredValue(const struct FBrgDbPsPartInsured& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPsPartInsuredValue(class UJsonObject* jsonObj, struct FBrgDbPsPartInsured* outObj);
		void SetBrgDbEqPartParamValue(const struct FBrgDbEqPartParam& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbEqPartParamValue(class UJsonObject* jsonObj, struct FBrgDbEqPartParam* outObj);
		void SetBrgDbDiedCharaValue(const struct FBrgDbDiedChara& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDiedCharaValue(class UJsonObject* jsonObj, struct FBrgDbDiedChara* outObj);
		void SetBrgDbCharaValue(const struct FBrgDbChara& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbCharaValue(class UJsonObject* jsonObj, struct FBrgDbChara* outObj);
		void SetBrgDbHunterRecordValue(const struct FBrgDbHunterRecord& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbHunterRecordValue(class UJsonObject* jsonObj, struct FBrgDbHunterRecord* outObj);
		void SetBrgDbHunterBattleSummaryValue(const struct FBrgDbHunterBattleSummary& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbHunterBattleSummaryValue(class UJsonObject* jsonObj, struct FBrgDbHunterBattleSummary* outObj);
		void SetBrgDbBodyBonusValue(const struct FBrgDbBodyBonus& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBodyBonusValue(class UJsonObject* jsonObj, struct FBrgDbBodyBonus* outObj);
		void SetBrgDbBodyLvlValue(const struct FBrgDbBodyLvl& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBodyLvlValue(class UJsonObject* jsonObj, struct FBrgDbBodyLvl* outObj);
		void SetBrgDbPosterValue(const struct FBrgDbPoster& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPosterValue(class UJsonObject* jsonObj, struct FBrgDbPoster* outObj);
		void SetBrgDbElevatorValue(const struct FBrgDbElevator& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbElevatorValue(class UJsonObject* jsonObj, struct FBrgDbElevator* outObj);
		void SetBrgDbElevatorStopFloorValue(const struct FBrgDbElevatorStopFloor& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbElevatorStopFloorValue(class UJsonObject* jsonObj, struct FBrgDbElevatorStopFloor* outObj);
		void SetBrgDbUserOpenElevatorStopFloorValue(const struct FBrgDbUserOpenElevatorStopFloor& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserOpenElevatorStopFloorValue(class UJsonObject* jsonObj, struct FBrgDbUserOpenElevatorStopFloor* outObj);
		void SetBrgDbSkillStickerValue(const struct FBrgDbSkillSticker& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSkillStickerValue(class UJsonObject* jsonObj, struct FBrgDbSkillSticker* outObj);
		void SetBrgDbPayMushroomValue(const struct FBrgDbPayMushroom& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPayMushroomValue(class UJsonObject* jsonObj, struct FBrgDbPayMushroom* outObj);
		void SetBrgDbPsPaidSkillMushroomValue(const struct FBrgDbPsPaidSkillMushroom& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPsPaidSkillMushroomValue(class UJsonObject* jsonObj, struct FBrgDbPsPaidSkillMushroom* outObj);
		void SetBrgDbSkillStickerInfoValue(const struct FBrgDbSkillStickerInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSkillStickerInfoValue(class UJsonObject* jsonObj, struct FBrgDbSkillStickerInfo* outObj);
		void SetBrgDbMushroomExChangeStikcerValue(const struct FBrgDbMushroomExChangeStikcer& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMushroomExChangeStikcerValue(class UJsonObject* jsonObj, struct FBrgDbMushroomExChangeStikcer* outObj);
		void SetBrgOnetimeAnnounceValue(const struct FBrgOnetimeAnnounce& Arg, class UJsonObject** outJsonObj);
		void GetBrgOnetimeAnnounceValue(class UJsonObject* jsonObj, struct FBrgOnetimeAnnounce* outObj);
		void SetBrgLoadingAnnounceValue(const struct FBrgLoadingAnnounce& Arg, class UJsonObject** outJsonObj);
		void GetBrgLoadingAnnounceValue(class UJsonObject* jsonObj, struct FBrgLoadingAnnounce* outObj);
		void SetBrgDbUserMailValue(const struct FBrgDbUserMail& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserMailValue(class UJsonObject* jsonObj, struct FBrgDbUserMail* outObj);
		void SetBrgDbUserVipValue(const struct FBrgDbUserVip& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserVipValue(class UJsonObject* jsonObj, struct FBrgDbUserVip* outObj);
		void SetBrgDbUserMagazineValue(const struct FBrgDbUserMagazine& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserMagazineValue(class UJsonObject* jsonObj, struct FBrgDbUserMagazine* outObj);
		void SetBrgDbFloorMagazineValue(const struct FBrgDbFloorMagazine& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorMagazineValue(class UJsonObject* jsonObj, struct FBrgDbFloorMagazine* outObj);
		void SetBrgDbUserStampRallyValue(const struct FBrgDbUserStampRally& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserStampRallyValue(class UJsonObject* jsonObj, struct FBrgDbUserStampRally* outObj);
		void SetBrgDbFloorStampRallyValue(const struct FBrgDbFloorStampRally& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorStampRallyValue(class UJsonObject* jsonObj, struct FBrgDbFloorStampRally* outObj);
		void SetBrgDbMushroomSoupEfcValue(const struct FBrgDbMushroomSoupEfc& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMushroomSoupEfcValue(class UJsonObject* jsonObj, struct FBrgDbMushroomSoupEfc* outObj);
		void SetBrgDbBeastBookValue(const struct FBrgDbBeastBook& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBeastBookValue(class UJsonObject* jsonObj, struct FBrgDbBeastBook* outObj);
		void SetBrgDbMushroomBookValue(const struct FBrgDbMushroomBook& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMushroomBookValue(class UJsonObject* jsonObj, struct FBrgDbMushroomBook* outObj);
		void SetBrgDbStatMushroomValue(const struct FBrgDbStatMushroom& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbStatMushroomValue(class UJsonObject* jsonObj, struct FBrgDbStatMushroom* outObj);
		void SetBrgDbStatMushroomEfcValue(const struct FBrgDbStatMushroomEfc& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbStatMushroomEfcValue(class UJsonObject* jsonObj, struct FBrgDbStatMushroomEfc* outObj);
		void SetBrgDbQuickUseArmValue(const struct FBrgDbQuickUseArm& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbQuickUseArmValue(class UJsonObject* jsonObj, struct FBrgDbQuickUseArm* outObj);
		void SetBrgDbQuickUseValue(const struct FBrgDbQuickUse& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbQuickUseValue(class UJsonObject* jsonObj, struct FBrgDbQuickUse* outObj);
		void SetBrgDbDeathBagValue(const struct FBrgDbDeathBag& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDeathBagValue(class UJsonObject* jsonObj, struct FBrgDbDeathBag* outObj);
		void SetBrgDbCoinLockerValue(const struct FBrgDbCoinLocker& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbCoinLockerValue(class UJsonObject* jsonObj, struct FBrgDbCoinLocker* outObj);
		void SetBrgDbAutomaticShopDiscountTermValue(const struct FBrgDbAutomaticShopDiscountTerm& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAutomaticShopDiscountTermValue(class UJsonObject* jsonObj, struct FBrgDbAutomaticShopDiscountTerm* outObj);
		void SetBrgDbMasterAutomaticshopLineupValue(const struct FBrgDbMasterAutomaticshopLineup& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterAutomaticshopLineupValue(class UJsonObject* jsonObj, struct FBrgDbMasterAutomaticshopLineup* outObj);
		void SetBrgDbUserPresentReceiveValue(const struct FBrgDbUserPresentReceive& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserPresentReceiveValue(class UJsonObject* jsonObj, struct FBrgDbUserPresentReceive* outObj);
		void SetBrgDbUserDeathboxValue(const struct FBrgDbUserDeathbox& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserDeathboxValue(class UJsonObject* jsonObj, struct FBrgDbUserDeathbox* outObj);
		void SetBrgDbUserPresentValue(const struct FBrgDbUserPresent& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserPresentValue(class UJsonObject* jsonObj, struct FBrgDbUserPresent* outObj);
		void SetBrgDbStorageSlotValue(const struct FBrgDbStorageSlot& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbStorageSlotValue(class UJsonObject* jsonObj, struct FBrgDbStorageSlot* outObj);
		void SetBrgDbUnlockedFighterValue(const struct FBrgDbUnlockedFighter& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUnlockedFighterValue(class UJsonObject* jsonObj, struct FBrgDbUnlockedFighter* outObj);
		void SetBrgDbGasmaskValue(const struct FBrgDbGasmask& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbGasmaskValue(class UJsonObject* jsonObj, struct FBrgDbGasmask* outObj);
		void SetBrgDbBodyDetailValue(const struct FBrgDbBodyDetail& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBodyDetailValue(class UJsonObject* jsonObj, struct FBrgDbBodyDetail* outObj);
		void SetBrgDbBodyValue(const struct FBrgDbBody& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBodyValue(class UJsonObject* jsonObj, struct FBrgDbBody* outObj);
		void SetBrgDbItemEntityValue(const struct FBrgDbItemEntity& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbItemEntityValue(class UJsonObject* jsonObj, struct FBrgDbItemEntity* outObj);
		void SetBrgDbBeastEntityValue(const struct FBrgDbBeastEntity& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBeastEntityValue(class UJsonObject* jsonObj, struct FBrgDbBeastEntity* outObj);
		void SetBrgDbMushroomEntityValue(const struct FBrgDbMushroomEntity& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMushroomEntityValue(class UJsonObject* jsonObj, struct FBrgDbMushroomEntity* outObj);
		void SetBrgDbStatValue(const struct FBrgDbStat& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbStatValue(class UJsonObject* jsonObj, struct FBrgDbStat* outObj);
		void SetBrgDbStatElementValue(const struct FBrgDbStatElement& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbStatElementValue(class UJsonObject* jsonObj, struct FBrgDbStatElement* outObj);
		void SetBrgDbActionLogValue(const struct FBrgDbActionLog& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbActionLogValue(class UJsonObject* jsonObj, struct FBrgDbActionLog* outObj);
		void SetBrgDbGameIntervalValue(const struct FBrgDbGameInterval& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbGameIntervalValue(class UJsonObject* jsonObj, struct FBrgDbGameInterval* outObj);
		void SetBrgDbGetZombieRewardValue(const struct FBrgDbGetZombieReward& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbGetZombieRewardValue(class UJsonObject* jsonObj, struct FBrgDbGetZombieReward* outObj);
		void SetBrgDbKilledZombieValue(const struct FBrgDbKilledZombie& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbKilledZombieValue(class UJsonObject* jsonObj, struct FBrgDbKilledZombie* outObj);
		void SetBrgDbTrBoxRewardValue(const struct FBrgDbTrBoxReward& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbTrBoxRewardValue(class UJsonObject* jsonObj, struct FBrgDbTrBoxReward* outObj);
		void SetBrgDbUserScreenshotValue(const struct FBrgDbUserScreenshot& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserScreenshotValue(class UJsonObject* jsonObj, struct FBrgDbUserScreenshot* outObj);
		void SetBrgDbEqSkillValue(const struct FBrgDbEqSkill& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbEqSkillValue(class UJsonObject* jsonObj, struct FBrgDbEqSkill* outObj);
		void SetBrgDbPsSkillValue(const struct FBrgDbPsSkill& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPsSkillValue(class UJsonObject* jsonObj, struct FBrgDbPsSkill* outObj);
		void SetBrgDbPsPartValue(const struct FBrgDbPsPart& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPsPartValue(class UJsonObject* jsonObj, struct FBrgDbPsPart* outObj);
		void SetBrgDbEqPartValue(const struct FBrgDbEqPart& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbEqPartValue(class UJsonObject* jsonObj, struct FBrgDbEqPart* outObj);
		void SetBrgDbMasterGateValue(const struct FBrgDbMasterGate& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterGateValue(class UJsonObject* jsonObj, struct FBrgDbMasterGate* outObj);
		void SetBrgDbBrObjValue(const struct FBrgDbBrObj& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBrObjValue(class UJsonObject* jsonObj, struct FBrgDbBrObj* outObj);
		void SetBrgDbPartArmTypeValue(const struct FBrgDbPartArmType& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPartArmTypeValue(class UJsonObject* jsonObj, struct FBrgDbPartArmType* outObj);
		void SetBrgDbPartAddEfcValue(const struct FBrgDbPartAddEfc& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPartAddEfcValue(class UJsonObject* jsonObj, struct FBrgDbPartAddEfc* outObj);
		void SetBrgDbPartArmValue(const struct FBrgDbPartArm& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPartArmValue(class UJsonObject* jsonObj, struct FBrgDbPartArm* outObj);
		void SetBrgDbPartValue(const struct FBrgDbPart& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPartValue(class UJsonObject* jsonObj, struct FBrgDbPart* outObj);
		void SetBrgDbAtkScaleValue(const struct FBrgDbAtkScale& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAtkScaleValue(class UJsonObject* jsonObj, struct FBrgDbAtkScale* outObj);
		void SetBrgDbParamOffsetValue(const struct FBrgDbParamOffset& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbParamOffsetValue(class UJsonObject* jsonObj, struct FBrgDbParamOffset* outObj);
		void SetBrgDbAtkAttrValue(const struct FBrgDbAtkAttr& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAtkAttrValue(class UJsonObject* jsonObj, struct FBrgDbAtkAttr* outObj);
		void SetBrgDbDefAttrValue(const struct FBrgDbDefAttr& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbDefAttrValue(class UJsonObject* jsonObj, struct FBrgDbDefAttr* outObj);
		void SetBrgDbAssetValue(const struct FBrgDbAsset& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbAssetValue(class UJsonObject* jsonObj, struct FBrgDbAsset* outObj);
		void SetBrgDbSkillMoveValue(const struct FBrgDbSkillMove& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSkillMoveValue(class UJsonObject* jsonObj, struct FBrgDbSkillMove* outObj);
		void SetBrgDbMasterSkillGachaCautionsValue(const struct FBrgDbMasterSkillGachaCautions& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterSkillGachaCautionsValue(class UJsonObject* jsonObj, struct FBrgDbMasterSkillGachaCautions* outObj);
		void SetBrgDbMasterTermsValue(const struct FBrgDbMasterTerms& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterTermsValue(class UJsonObject* jsonObj, struct FBrgDbMasterTerms* outObj);
		void SetBrgDbMasterEventScheduleValue(const struct FBrgDbMasterEventSchedule& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterEventScheduleValue(class UJsonObject* jsonObj, struct FBrgDbMasterEventSchedule* outObj);
		void SetBrgDbMasterCreditValue(const struct FBrgDbMasterCredit& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterCreditValue(class UJsonObject* jsonObj, struct FBrgDbMasterCredit* outObj);
		void SetBrgDbMasterMysterybagContentValue(const struct FBrgDbMasterMysterybagContent& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterMysterybagContentValue(class UJsonObject* jsonObj, struct FBrgDbMasterMysterybagContent* outObj);
		void SetBrgDbMasterWarRewardValue(const struct FBrgDbMasterWarReward& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterWarRewardValue(class UJsonObject* jsonObj, struct FBrgDbMasterWarReward* outObj);
		void SetBrgDbMasterTdmRankValue(const struct FBrgDbMasterTdmRank& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterTdmRankValue(class UJsonObject* jsonObj, struct FBrgDbMasterTdmRank* outObj);
		void SetBrgDbMasterFreezerValue(const struct FBrgDbMasterFreezer& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterFreezerValue(class UJsonObject* jsonObj, struct FBrgDbMasterFreezer* outObj);
		void SetBrgDbMasterPrisonValue(const struct FBrgDbMasterPrison& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterPrisonValue(class UJsonObject* jsonObj, struct FBrgDbMasterPrison* outObj);
		void SetBrgDbMasterSpiritTankLevelValue(const struct FBrgDbMasterSpiritTankLevel& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterSpiritTankLevelValue(class UJsonObject* jsonObj, struct FBrgDbMasterSpiritTankLevel* outObj);
		void SetBrgDbMasterSafeLevelValue(const struct FBrgDbMasterSafeLevel& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterSafeLevelValue(class UJsonObject* jsonObj, struct FBrgDbMasterSafeLevel* outObj);
		void SetBrgDbMasterPartEquipmentValue(const struct FBrgDbMasterPartEquipment& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterPartEquipmentValue(class UJsonObject* jsonObj, struct FBrgDbMasterPartEquipment* outObj);
		void SetBrgDbMasterHairDisplayValue(const struct FBrgDbMasterHairDisplay& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterHairDisplayValue(class UJsonObject* jsonObj, struct FBrgDbMasterHairDisplay* outObj);
		void SetBrgDbMasterWaitingReduceValue(const struct FBrgDbMasterWaitingReduce& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterWaitingReduceValue(class UJsonObject* jsonObj, struct FBrgDbMasterWaitingReduce* outObj);
		void SetBrgDbMasterSkillGachaValue(const struct FBrgDbMasterSkillGacha& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterSkillGachaValue(class UJsonObject* jsonObj, struct FBrgDbMasterSkillGacha* outObj);
		void SetBrgDbMasterMagazineValue(const struct FBrgDbMasterMagazine& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterMagazineValue(class UJsonObject* jsonObj, struct FBrgDbMasterMagazine* outObj);
		void SetBrgResearchStampInfoValue(const struct FBrgResearchStampInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgResearchStampInfoValue(class UJsonObject* jsonObj, struct FBrgResearchStampInfo* outObj);
		void SetBrgDbUserHvnTresureInfoValue(const struct FBrgDbUserHvnTresureInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserHvnTresureInfoValue(class UJsonObject* jsonObj, struct FBrgDbUserHvnTresureInfo* outObj);
		void SetBrgDbUserResearchStampValue(const struct FBrgDbUserResearchStamp& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUserResearchStampValue(class UJsonObject* jsonObj, struct FBrgDbUserResearchStamp* outObj);
		void SetBrgDbMasterLvlValue(const struct FBrgDbMasterLvl& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterLvlValue(class UJsonObject* jsonObj, struct FBrgDbMasterLvl* outObj);
		void SetBrgDbMasterAbpValue(const struct FBrgDbMasterAbp& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterAbpValue(class UJsonObject* jsonObj, struct FBrgDbMasterAbp* outObj);
		void SetBrgDbMasterLvlRewardTypeValue(const struct FBrgDbMasterLvlRewardType& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterLvlRewardTypeValue(class UJsonObject* jsonObj, struct FBrgDbMasterLvlRewardType* outObj);
		void SetBrgDbMasterLvlRewardValue(const struct FBrgDbMasterLvlReward& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterLvlRewardValue(class UJsonObject* jsonObj, struct FBrgDbMasterLvlReward* outObj);
		void SetBrgDbMasterEquipRankPointValue(const struct FBrgDbMasterEquipRankPoint& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterEquipRankPointValue(class UJsonObject* jsonObj, struct FBrgDbMasterEquipRankPoint* outObj);
		void SetBrgDbMasterPointRewardTypeValue(const struct FBrgDbMasterPointRewardType& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterPointRewardTypeValue(class UJsonObject* jsonObj, struct FBrgDbMasterPointRewardType* outObj);
		void SetBrgDbMasterPointRewardValue(const struct FBrgDbMasterPointReward& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbMasterPointRewardValue(class UJsonObject* jsonObj, struct FBrgDbMasterPointReward* outObj);
		void SetBrgDbSkillTypeValue(const struct FBrgDbSkillType& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSkillTypeValue(class UJsonObject* jsonObj, struct FBrgDbSkillType* outObj);
		void SetBrgDbSkillValue(const struct FBrgDbSkill& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSkillValue(class UJsonObject* jsonObj, struct FBrgDbSkill* outObj);
		void SetBrgDbOpenSkillMushroomValue(const struct FBrgDbOpenSkillMushroom& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbOpenSkillMushroomValue(class UJsonObject* jsonObj, struct FBrgDbOpenSkillMushroom* outObj);
		void SetBrgDbParamListTypeValue(const struct FBrgDbParamListType& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbParamListTypeValue(class UJsonObject* jsonObj, struct FBrgDbParamListType* outObj);
		void SetBrgDbParamListValue(const struct FBrgDbParamList& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbParamListValue(class UJsonObject* jsonObj, struct FBrgDbParamList* outObj);
		void SetBrgDbParamFloatValue(const struct FBrgDbParamFloat& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbParamFloatValue(class UJsonObject* jsonObj, struct FBrgDbParamFloat* outObj);
		void SetBrgDbParamIntValue(const struct FBrgDbParamInt& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbParamIntValue(class UJsonObject* jsonObj, struct FBrgDbParamInt* outObj);
		void SetBrgDbParamStrValue(const struct FBrgDbParamStr& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbParamStrValue(class UJsonObject* jsonObj, struct FBrgDbParamStr* outObj);
		void SetBrgDbBodyNameValue(const struct FBrgDbBodyName& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBodyNameValue(class UJsonObject* jsonObj, struct FBrgDbBodyName* outObj);
		void SetBrgDbBodyLimitBreakItemValue(const struct FBrgDbBodyLimitBreakItem& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBodyLimitBreakItemValue(class UJsonObject* jsonObj, struct FBrgDbBodyLimitBreakItem* outObj);
		void SetBrgDbBodyLvlStatusValue(const struct FBrgDbBodyLvlStatus& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBodyLvlStatusValue(class UJsonObject* jsonObj, struct FBrgDbBodyLvlStatus* outObj);
		void SetBrgDbBodyLvlExpGradeValue(const struct FBrgDbBodyLvlExpGrade& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBodyLvlExpGradeValue(class UJsonObject* jsonObj, struct FBrgDbBodyLvlExpGrade* outObj);
		void SetBrgDbBodyLvlExpValue(const struct FBrgDbBodyLvlExp& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBodyLvlExpValue(class UJsonObject* jsonObj, struct FBrgDbBodyLvlExp* outObj);
		void SetBrgDbPlayerStatusValue(const struct FBrgDbPlayerStatus& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbPlayerStatusValue(class UJsonObject* jsonObj, struct FBrgDbPlayerStatus* outObj);
		void SetBrgDbFloorStageUnitValue(const struct FBrgDbFloorStageUnit& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbFloorStageUnitValue(class UJsonObject* jsonObj, struct FBrgDbFloorStageUnit* outObj);
		void SetBrgDbUnitTargetPointListValue(const struct FBrgDbUnitTargetPointList& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbUnitTargetPointListValue(class UJsonObject* jsonObj, struct FBrgDbUnitTargetPointList* outObj);
		void SetBrgDbStageValue(const struct FBrgDbStage& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbStageValue(class UJsonObject* jsonObj, struct FBrgDbStage* outObj);
		void SetBrgDbStageUnitValue(const struct FBrgDbStageUnit& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbStageUnitValue(class UJsonObject* jsonObj, struct FBrgDbStageUnit* outObj);
		void SetBrgDbBuildInfoValue(const struct FBrgDbBuildInfo& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbBuildInfoValue(class UJsonObject* jsonObj, struct FBrgDbBuildInfo* outObj);
		void SetBrgDbSessionValue(const struct FBrgDbSession& Arg, class UJsonObject** outJsonObj);
		void GetBrgDbSessionValue(class UJsonObject* jsonObj, struct FBrgDbSession* outObj);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkManagerBase
	 * Size -> 0x00F0 (FullSize[0x0150] - InheritedSize[0x0060])
	 */
	class UBrgNetworkManagerBase : public UObject
	{
	public:
		class FString                                              CustomServerHostName;                                    // 0x0060(0x0010) Config, NeedCtorLink
		class FString                                              CustomServerHostName_Steam;                              // 0x0070(0x0010) Config, NeedCtorLink
		class FString                                              ServerHostName;                                          // 0x0080(0x0010) NeedCtorLink
		class FString                                              AdditionalUrl;                                           // 0x0090(0x0010) NeedCtorLink
		unsigned long                                              ConnectsToLocalServer : 1;                               // 0x00A0(0x0001) BIT_FIELD Config
		unsigned long                                              IsGhmNetwrokServer : 1;                                  // 0x00A0(0x0001) BIT_FIELD Config
		unsigned long                                              DisableNetwork : 1;                                      // 0x00A0(0x0001) BIT_FIELD Config
		unsigned long                                              mRequesting : 1;                                         // 0x00A0(0x0001) BIT_FIELD
		int32_t                                                    LogOutputRequestSizeLimit;                               // 0x00A4(0x0004) Config
		TArray<class UBrgNetworkResponseInterface*>                mForceErrorResponses;                                    // 0x00A8(0x0010) NeedCtorLink
		TArray<class UBrgNetworkPendingRequest*>                   mPendingRequests;                                        // 0x00B8(0x0010) NeedCtorLink
		float                                                      mRequestTimer;                                           // 0x00C8(0x0004)
		TArray<class UBrgNetworkResponseInterface*>                mWaitingResponses;                                       // 0x00CC(0x0010) NeedCtorLink
		class UBrgNetworkCacheRequest*                             mCacheRequest;                                           // 0x00DC(0x0008)
		class FString                                              mRequestIdBase;                                          // 0x00E4(0x0010) NeedCtorLink
		int32_t                                                    mRequestIndex;                                           // 0x00F4(0x0004)
		int32_t                                                    mLastResponseTime;                                       // 0x00F8(0x0004)
		int32_t                                                    mLastResponseClientTimeSec;                              // 0x00FC(0x0004)
		int32_t                                                    mLastResponseClientTimeMsec;                             // 0x0100(0x0004)
		int32_t                                                    mLastResponseServerTimeSec;                              // 0x0104(0x0004)
		int32_t                                                    mLastResponseServerTimeMsec;                             // 0x0108(0x0004)
		class FString                                              mLastResponseApiName;                                    // 0x010C(0x0010) NeedCtorLink
		class FString                                              mLastResponseReqid;                                      // 0x011C(0x0010) NeedCtorLink
		int32_t                                                    mLastResponseServerNo;                                   // 0x012C(0x0004)
		int32_t                                                    mLastRequestStartTimeSec;                                // 0x0130(0x0004)
		int32_t                                                    mLastRequestStartTimeMsec;                               // 0x0134(0x0004)
		int32_t                                                    LocalHttpsPort;                                          // 0x0138(0x0004) Config
		int32_t                                                    LocalHttpPort;                                           // 0x013C(0x0004) Config
		class FString                                              LocalServerHostName;                                     // 0x0140(0x0010) Config, NeedCtorLink

	public:
		void TestCommand(const class FString& Cmd, const class FString& param1, const class FString& param2);
		bool SetCookie(const class FString& URL, const class FString& cookieName, const class FString& cookieData);
		void FindApiInfo(const class FString& reqid, class FString* ApiName, float* Time, class FString* ErrorCode);
		void Render(class ABrgHUDBase* HUD);
		void Update(float DeltaTime);
		void UpdateWaitingResponse(float DeltaTime);
		bool AddWaitingResponse(class UBrgNetworkResponseInterface* res);
		void UpdateForceErrorResponse(float DeltaTime);
		int32_t GetForceErrorCodeNo(class UBrgNetworkResponseInterface* res);
		class FString GetForceErrorCodeCategory(class UBrgNetworkResponseInterface* res);
		bool AddForceErrorResponse(class UBrgNetworkResponseInterface* res);
		bool UpdatePendingRequests(float DeltaTime);
		bool CallPendingRequest(class UBrgNetworkPendingRequest* pendReq);
		bool StartRequestCallback(class UBrgNetworkPendingRequest* pendReq);
		bool SetRequestTime(class UJsonObject* reqContent);
		bool ResetLastResponseTime();
		bool SetLastResponseTime(int32_t clientTimeSec, int32_t clientTimeMsec, int32_t serverTimeSec, int32_t serverTimeMsec, const class FString& ApiName, const class FString& reqid, int32_t serverNo);
		bool RemovePendingRequest(class UHttpRequestInterface* req, bool cacheExist);
		class FString CreateResponseHash(TArray<unsigned char>* Content);
		class FString CreateRequestHash(TArray<unsigned char>* Content);
		bool CreateRequest(const class FString& URL, class UBrgNetworkRequestContent* Content, class UBrgNetworkResponseInterface* res);
		class UBrgNetworkResponseInterface* Request(class UClass* responseClass, class UBrgNetworkRequestContent* Content);
		bool ResetRequestIdBase();
		bool SetRequestIdBase(const class FString& reqidbase);
		bool GenerateRequestId(class FString* reqid);
		class FString GetAdditionalUrl();
		void SetAdditionalUrl(const class FString& URL);
		bool ForceResponseError();
		int32_t GetLocalHttpPort();
		int32_t GetLocalHttpsPort();
		class FString GetServerHostName();
		int32_t GetLastResponseTime();
		void Terminate();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkManager
	 * Size -> 0x0008 (FullSize[0x0158] - InheritedSize[0x0150])
	 */
	class UBrgNetworkManager : public UBrgNetworkManagerBase
	{
	public:
		struct FPointer                                            VfTable_IBrgNetworkManagerInterface;                     // 0x0150(0x0008) Const, Native, NoExport

	public:
		class UBrgNetworkResponseUpdaterevenge* RequestUpdaterevenge(const struct FBrgDbUpdateRevengeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseTest* RequestTest(bool bid, int32_t iid, float fid, const class FString& sid, const struct Ftest_struct2& oid, TArray<unsigned long> bids, TArray<int32_t> iids, TArray<float> fids, TArray<class FString> sids, TArray<struct Ftest_struct2> oids);
		class UBrgNetworkResponseFramerateskiplog* RequestFramerateskiplog(const struct FBrgFrameRateSkipLogParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseEndsp* RequestEndsp(const struct FBrgDbEndSpParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseOrderquests* RequestOrderquests(const struct FBrgDbOrderQuestsParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetquests* RequestGetquests(const struct FBrgDbGetQuestsParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseBodies* RequestBodies(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseEndbet* RequestEndbet(const struct FBrgDbEndBetParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseStartbet* RequestStartbet(const struct FBrgDbStartBetParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseChangecash* RequestChangecash(const struct FBrgDbChangeCashParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseVipconfig* RequestVipconfig(const struct FBrgDbUserVipConfigParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseVipuse* RequestVipuse(const struct FBrgDbUserVipUseParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseVippurchase* RequestVippurchase(const struct FBrgDbVipPurchaseParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSaveitemlog* RequestSaveitemlog(const struct FBrgDbSession& ssn, TArray<struct FBrgDbMsglog> items, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponsePlaylog* RequestPlaylog(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGimreaper* RequestGimreaper(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetmsg* RequestGetmsg(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseArrival* RequestArrival(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRelievegame* RequestRelievegame(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseContinue* RequestContinue(const struct FBrgDbContinueParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSavegame* RequestSavegame(const struct FBrgDbSaveGameParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseResumegame* RequestResumegame(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponsePausegame* RequestPausegame(const struct FBrgDbPauseGameParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseLoadgame* RequestLoadgame(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSavelasthubtime* RequestSavelasthubtime(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseReceivedeathbox* RequestReceivedeathbox(const struct FBrgDbReceiveDeathboxParam& rec, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseFreeze_abductee* RequestFreeze_abductee(const struct FBrgDbFreezeAbducteeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRelease_abductee* RequestRelease_abductee(const struct FBrgDbReleaseAbducteeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseAccess_prison* RequestAccess_prison(const struct FBrgDbAccessPrisonParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRadio* RequestRadio(const struct FBrgDbUserSoul& soul, const struct FBrgDbSession& ssn);
		class UBrgNetworkResponseResetboxgacha* RequestResetboxgacha(const struct FBrgDbResetBoxGachaParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSkillgacha* RequestSkillgacha(const struct FBrgDbSkillGachaParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUsesafe* RequestUsesafe(const struct FBrgDbUseSafeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseOperatepresent* RequestOperatepresent(const struct FBrgDbOperatePresentParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseReceivepresent* RequestReceivepresent(const struct FBrgDbReceivePresentParam& rec, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponsePresents* RequestPresents(const struct FBrgDbSession& ssn, const struct FBrgDbUserSoul& soul, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDbg_starthub* RequestDbg_starthub(const struct FBrgDbDbgStartHubParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseStarthub* RequestStarthub(const struct FBrgDbStartHubParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDbg_tgtpntlist* RequestDbg_tgtpntlist();
		class UBrgNetworkResponseDbg_takeelv* RequestDbg_takeelv(const struct FBrgDbDbgTakeElevatorParam& elv, const struct FBrgDbDebugFloorParam& dbg, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDbg_movefloor* RequestDbg_movefloor(const struct FBrgDbDbgMoveFloorParam& mv, const struct FBrgDbDebugFloorParam& dbg, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDbg_clearfloor* RequestDbg_clearfloor(const struct FBrgDbClearFloor& clr, const struct FBrgDbDebugFloorParam& dbg, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDbg_startfloor* RequestDbg_startfloor(const struct FBrgDbDbgStartFloor& Param, const struct FBrgDbDebugFloorParam& dbg, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRecovererror* RequestRecovererror(const struct FBrgRecoverErrorParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUsedustshooter* RequestUsedustshooter(const struct FBrgDbUseDustshooterParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseEntergate* RequestEntergate(const struct FBrgDbEnterGateParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseTakeelv* RequestTakeelv(const struct FBrgDbTakeElevatorParam& elv, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseMovefloor* RequestMovefloor(const struct FBrgDbMoveFloorParam& mv, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseClearfloor* RequestClearfloor(const struct FBrgDbClearFloor& clr, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseStartfloor* RequestStartfloor(const struct FBrgDbStartFloor& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseExpandcl* RequestExpandcl(const struct FBrgDbExpandCoinLockerParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSortcl* RequestSortcl(const struct FBrgDbSortCoinLockerParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDrawcl* RequestDrawcl(const struct FBrgDbDrawCoinLockerParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDeposcl* RequestDeposcl(const struct FBrgDbDeposCoinLockerParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseMushroomshop* RequestMushroomshop(TArray<struct FBrgDbUserMushroomShopHistory> shophistory, TArray<struct FBrgDbUserSkillRecover> skillrecover, const struct FBrgDbMushroomShop& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetmushroomshop* RequestGetmushroomshop(const struct FBrgDbUserSoul& soul, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDbg_resetskl* RequestDbg_resetskl(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseOpenskl* RequestOpenskl(const struct FBrgDbOpSkillParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseEquipskl* RequestEquipskl(const struct FBrgDbEqSkillParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetassaultfortresult* RequestGetassaultfortresult(const struct FBrgDbGetAssaultFortResultParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUpdatehubcustomize* RequestUpdatehubcustomize(const struct FBrgDbUpdateHubCustomizeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUpdatefortsetting* RequestUpdatefortsetting(const struct FBrgDbUpdateFortSettingParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseChangeteam* RequestChangeteam(const struct FBrgDbChangeTeamParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetteaminfo* RequestGetteaminfo(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetranking* RequestGetranking(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseWhistleshop* RequestWhistleshop(TArray<struct FBrgDbWhistleShopHistory> whistlehistory, const struct FBrgDbUserSoul& soul, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseFacilityshop* RequestFacilityshop(TArray<struct FBrgDbFortShopHistory> shophistory, const struct FBrgDbUserSoul& soul, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetfortdestall* RequestGetfortdestall(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseFortterminal* RequestFortterminal(const struct FBrgDbFortterminalParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseImagetraining* RequestImagetraining(int32_t blow_num, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponsePayransom* RequestPayransom(const struct FBrgDbPayRansomParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetfortdests* RequestGetfortdests(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseAssaultfortresult* RequestAssaultfortresult(const struct FBrgDbAssaultFortResultParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseAssaultfort* RequestAssaultfort(const struct FBrgDbAssaultFortParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseShowhunterresult* RequestShowhunterresult(const struct FBrgDbShowHunterResultParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGethunterdests* RequestGethunterdests(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseCancelhunter* RequestCancelhunter(const struct FBrgDbCancelHunterParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSendhunter* RequestSendhunter(const struct FBrgDbSendHunterParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSavescreenshot* RequestSavescreenshot(const struct FBrgDbScreenshot& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseTutorial* RequestTutorial(int32_t flag, const struct FBrgDbUserSoul& soul, const struct FBrgDbSession& ssn);
		class UBrgNetworkResponseUpdatefriend* RequestUpdatefriend(const struct FBrgDbUpdateFriendParam& Param, const struct FBrgDbSession& ssn);
		class UBrgNetworkResponsePurchasebody* RequestPurchasebody(const struct FBrgDbPurchaseBodyParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSelectbody* RequestSelectbody(const struct FBrgDbSelectBodyParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseConfigmenu* RequestConfigmenu(const struct FBrgDbUserConfigMenu& Param, const struct FBrgDbUserSpecAndSetting& specandsetting, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseConfig* RequestConfig(const struct FBrgDbUserConfig& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUpdatemedal* RequestUpdatemedal(const struct FBrgDbUpdateMedalParam& Param, const class FString& Code, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseOpendialog* RequestOpendialog(const struct FBrgDbOpenDialogParam& Param, const class FString& Code, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDistributebodylvl* RequestDistributebodylvl(const struct FBrgDbDistributeBodyLvlParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDestroychara* RequestDestroychara(const struct FBrgDbDestroyCharaParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseForsake_abductee* RequestForsake_abductee(const struct FBrgDbForsakeAbducteeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseForsake* RequestForsake(const struct FBrgDbForsakeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSelectchara* RequestSelectchara(const struct FBrgDbSelectCharaParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRecovery* RequestRecovery(const struct FBrgDbRecoveryParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSalvage* RequestSalvage(const struct FBrgDbSalvageParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseExpanddb* RequestExpanddb(const struct FBrgDbExpandDeathBagParam& Param, const class FString& Code, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSavediepoint* RequestSavediepoint(const struct FBrgDbSaveDiePointParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDie* RequestDie(const struct FBrgDbDie& die, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseInputusername* RequestInputusername(const struct FBrgDbInputUserNameParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUpdatecharaname* RequestUpdatecharaname(const struct FBrgDbUpdateCharaNameParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUpdateuserinfo* RequestUpdateuserinfo(const struct FBrgDbUpdateUserInfoParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetuserinfo* RequestGetuserinfo(const class FString& Code, const struct FBrgDbUserSpecAndSetting& specandsetting, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetparams* RequestGetparams(int32_t is_encrypted, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetlocdat* RequestGetlocdat(const struct FBrgDbGetLocdatParam& Param, int32_t is_encrypted, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseConversation* RequestConversation(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseReduce_waiting* RequestReduce_waiting(const struct FBrgDbReduceWaitingParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRoastmushroom* RequestRoastmushroom(const struct FBrgDbRoastMushroomParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetskillsticker* RequestGetskillsticker(const struct FBrgDbUserSoul& soul, TArray<struct FBrgDbSkillSticker> skills, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponsePaymushroom* RequestPaymushroom(const struct FBrgDbUserSoul& soul, TArray<struct FBrgDbPayMushroom> mushrooms, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUpdate_research* RequestUpdate_research(const struct FBrgDbUserSoul& soul, TArray<struct FBrgDbUserShopHistory> shophistory, TArray<struct FBrgDbUserBaseShopResult> shoppurchase, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetpartresearch* RequestGetpartresearch(const struct FBrgDbUserSoul& soul, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseBlendmsrsoup* RequestBlendmsrsoup(const struct FBrgDbBlendMushroomSoupParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSellpt* RequestSellpt(const struct FBrgDbSellPartParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSellmsr* RequestSellmsr(const struct FBrgDbSellMushroomParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRepairpt* RequestRepairpt(const struct FBrgDbRepairPartParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseInsurept* RequestInsurept(const struct FBrgDbInsurePt& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetshopprice* RequestGetshopprice(const struct FBrgDbShopPriceInfoParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseEnhancept* RequestEnhancept(const struct FBrgDbEnhancePartParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseCharge* RequestCharge(const struct FBrgDbPurchaseParam& Param, const class FString& Code, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseTermsagree* RequestTermsagree(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRegusr* RequestRegusr(const class FString& uuid, const class FString& sid);
		class UBrgNetworkResponseLogout* RequestLogout(const struct FBrgDbLogoutParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseLogins* RequestLogins(const class FString& Code, int32_t Size, const class FString& sid, int32_t consent);
		class UBrgNetworkResponseLoginp* RequestLoginp(const class FString& Code, int32_t Size, const class FString& sid, int32_t consent);
		class UBrgNetworkResponseLogin* RequestLogin(const class FString& Uid, const class FString& sid, const class FString& nm, int32_t consent);
		class UBrgNetworkResponseStart* RequestStart(int32_t Type, int32_t ver, const class FString& rg, const class FString& lang, const class FString& tsid, const class FString& Uid, const struct FBrgDbBuildInfo& bi);
		int32_t GetApiVersion();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkManagerInterface
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgNetworkManagerInterface : public UInterface
	{
	public:
		class UBrgNetworkResponseUpdaterevenge* RequestUpdaterevenge(const struct FBrgDbUpdateRevengeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseTest* RequestTest(bool bid, int32_t iid, float fid, const class FString& sid, const struct Ftest_struct2& oid, TArray<unsigned long> bids, TArray<int32_t> iids, TArray<float> fids, TArray<class FString> sids, TArray<struct Ftest_struct2> oids);
		class UBrgNetworkResponseFramerateskiplog* RequestFramerateskiplog(const struct FBrgFrameRateSkipLogParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseEndsp* RequestEndsp(const struct FBrgDbEndSpParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseOrderquests* RequestOrderquests(const struct FBrgDbOrderQuestsParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetquests* RequestGetquests(const struct FBrgDbGetQuestsParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseBodies* RequestBodies(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseEndbet* RequestEndbet(const struct FBrgDbEndBetParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseStartbet* RequestStartbet(const struct FBrgDbStartBetParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseChangecash* RequestChangecash(const struct FBrgDbChangeCashParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseVipconfig* RequestVipconfig(const struct FBrgDbUserVipConfigParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseVipuse* RequestVipuse(const struct FBrgDbUserVipUseParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseVippurchase* RequestVippurchase(const struct FBrgDbVipPurchaseParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSaveitemlog* RequestSaveitemlog(const struct FBrgDbSession& ssn, TArray<struct FBrgDbMsglog> items, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponsePlaylog* RequestPlaylog(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGimreaper* RequestGimreaper(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetmsg* RequestGetmsg(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseArrival* RequestArrival(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRelievegame* RequestRelievegame(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseContinue* RequestContinue(const struct FBrgDbContinueParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSavegame* RequestSavegame(const struct FBrgDbSaveGameParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseResumegame* RequestResumegame(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponsePausegame* RequestPausegame(const struct FBrgDbPauseGameParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseLoadgame* RequestLoadgame(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSavelasthubtime* RequestSavelasthubtime(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseReceivedeathbox* RequestReceivedeathbox(const struct FBrgDbReceiveDeathboxParam& rec, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseFreeze_abductee* RequestFreeze_abductee(const struct FBrgDbFreezeAbducteeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRelease_abductee* RequestRelease_abductee(const struct FBrgDbReleaseAbducteeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseAccess_prison* RequestAccess_prison(const struct FBrgDbAccessPrisonParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRadio* RequestRadio(const struct FBrgDbUserSoul& soul, const struct FBrgDbSession& ssn);
		class UBrgNetworkResponseResetboxgacha* RequestResetboxgacha(const struct FBrgDbResetBoxGachaParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSkillgacha* RequestSkillgacha(const struct FBrgDbSkillGachaParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUsesafe* RequestUsesafe(const struct FBrgDbUseSafeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseOperatepresent* RequestOperatepresent(const struct FBrgDbOperatePresentParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseReceivepresent* RequestReceivepresent(const struct FBrgDbReceivePresentParam& rec, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponsePresents* RequestPresents(const struct FBrgDbSession& ssn, const struct FBrgDbUserSoul& soul, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDbg_starthub* RequestDbg_starthub(const struct FBrgDbDbgStartHubParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseStarthub* RequestStarthub(const struct FBrgDbStartHubParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDbg_tgtpntlist* RequestDbg_tgtpntlist();
		class UBrgNetworkResponseDbg_takeelv* RequestDbg_takeelv(const struct FBrgDbDbgTakeElevatorParam& elv, const struct FBrgDbDebugFloorParam& dbg, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDbg_movefloor* RequestDbg_movefloor(const struct FBrgDbDbgMoveFloorParam& mv, const struct FBrgDbDebugFloorParam& dbg, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDbg_clearfloor* RequestDbg_clearfloor(const struct FBrgDbClearFloor& clr, const struct FBrgDbDebugFloorParam& dbg, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDbg_startfloor* RequestDbg_startfloor(const struct FBrgDbDbgStartFloor& Param, const struct FBrgDbDebugFloorParam& dbg, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRecovererror* RequestRecovererror(const struct FBrgRecoverErrorParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUsedustshooter* RequestUsedustshooter(const struct FBrgDbUseDustshooterParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseEntergate* RequestEntergate(const struct FBrgDbEnterGateParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseTakeelv* RequestTakeelv(const struct FBrgDbTakeElevatorParam& elv, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseMovefloor* RequestMovefloor(const struct FBrgDbMoveFloorParam& mv, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseClearfloor* RequestClearfloor(const struct FBrgDbClearFloor& clr, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseStartfloor* RequestStartfloor(const struct FBrgDbStartFloor& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseExpandcl* RequestExpandcl(const struct FBrgDbExpandCoinLockerParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSortcl* RequestSortcl(const struct FBrgDbSortCoinLockerParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDrawcl* RequestDrawcl(const struct FBrgDbDrawCoinLockerParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDeposcl* RequestDeposcl(const struct FBrgDbDeposCoinLockerParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseMushroomshop* RequestMushroomshop(TArray<struct FBrgDbUserMushroomShopHistory> shophistory, TArray<struct FBrgDbUserSkillRecover> skillrecover, const struct FBrgDbMushroomShop& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetmushroomshop* RequestGetmushroomshop(const struct FBrgDbUserSoul& soul, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDbg_resetskl* RequestDbg_resetskl(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseOpenskl* RequestOpenskl(const struct FBrgDbOpSkillParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseEquipskl* RequestEquipskl(const struct FBrgDbEqSkillParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetassaultfortresult* RequestGetassaultfortresult(const struct FBrgDbGetAssaultFortResultParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUpdatehubcustomize* RequestUpdatehubcustomize(const struct FBrgDbUpdateHubCustomizeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUpdatefortsetting* RequestUpdatefortsetting(const struct FBrgDbUpdateFortSettingParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseChangeteam* RequestChangeteam(const struct FBrgDbChangeTeamParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetteaminfo* RequestGetteaminfo(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetranking* RequestGetranking(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseWhistleshop* RequestWhistleshop(TArray<struct FBrgDbWhistleShopHistory> whistlehistory, const struct FBrgDbUserSoul& soul, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseFacilityshop* RequestFacilityshop(TArray<struct FBrgDbFortShopHistory> shophistory, const struct FBrgDbUserSoul& soul, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetfortdestall* RequestGetfortdestall(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseFortterminal* RequestFortterminal(const struct FBrgDbFortterminalParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseImagetraining* RequestImagetraining(int32_t blow_num, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponsePayransom* RequestPayransom(const struct FBrgDbPayRansomParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetfortdests* RequestGetfortdests(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseAssaultfortresult* RequestAssaultfortresult(const struct FBrgDbAssaultFortResultParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseAssaultfort* RequestAssaultfort(const struct FBrgDbAssaultFortParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseShowhunterresult* RequestShowhunterresult(const struct FBrgDbShowHunterResultParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGethunterdests* RequestGethunterdests(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseCancelhunter* RequestCancelhunter(const struct FBrgDbCancelHunterParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSendhunter* RequestSendhunter(const struct FBrgDbSendHunterParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSavescreenshot* RequestSavescreenshot(const struct FBrgDbScreenshot& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseTutorial* RequestTutorial(int32_t flag, const struct FBrgDbUserSoul& soul, const struct FBrgDbSession& ssn);
		class UBrgNetworkResponseUpdatefriend* RequestUpdatefriend(const struct FBrgDbUpdateFriendParam& Param, const struct FBrgDbSession& ssn);
		class UBrgNetworkResponsePurchasebody* RequestPurchasebody(const struct FBrgDbPurchaseBodyParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSelectbody* RequestSelectbody(const struct FBrgDbSelectBodyParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseConfigmenu* RequestConfigmenu(const struct FBrgDbUserConfigMenu& Param, const struct FBrgDbUserSpecAndSetting& specandsetting, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseConfig* RequestConfig(const struct FBrgDbUserConfig& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUpdatemedal* RequestUpdatemedal(const struct FBrgDbUpdateMedalParam& Param, const class FString& Code, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseOpendialog* RequestOpendialog(const struct FBrgDbOpenDialogParam& Param, const class FString& Code, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDistributebodylvl* RequestDistributebodylvl(const struct FBrgDbDistributeBodyLvlParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDestroychara* RequestDestroychara(const struct FBrgDbDestroyCharaParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseForsake_abductee* RequestForsake_abductee(const struct FBrgDbForsakeAbducteeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseForsake* RequestForsake(const struct FBrgDbForsakeParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSelectchara* RequestSelectchara(const struct FBrgDbSelectCharaParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRecovery* RequestRecovery(const struct FBrgDbRecoveryParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSalvage* RequestSalvage(const struct FBrgDbSalvageParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseExpanddb* RequestExpanddb(const struct FBrgDbExpandDeathBagParam& Param, const class FString& Code, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSavediepoint* RequestSavediepoint(const struct FBrgDbSaveDiePointParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseDie* RequestDie(const struct FBrgDbDie& die, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseInputusername* RequestInputusername(const struct FBrgDbInputUserNameParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUpdatecharaname* RequestUpdatecharaname(const struct FBrgDbUpdateCharaNameParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUpdateuserinfo* RequestUpdateuserinfo(const struct FBrgDbUpdateUserInfoParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetuserinfo* RequestGetuserinfo(const class FString& Code, const struct FBrgDbUserSpecAndSetting& specandsetting, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetparams* RequestGetparams(int32_t is_encrypted, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetlocdat* RequestGetlocdat(const struct FBrgDbGetLocdatParam& Param, int32_t is_encrypted, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseConversation* RequestConversation(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseReduce_waiting* RequestReduce_waiting(const struct FBrgDbReduceWaitingParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRoastmushroom* RequestRoastmushroom(const struct FBrgDbRoastMushroomParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetskillsticker* RequestGetskillsticker(const struct FBrgDbUserSoul& soul, TArray<struct FBrgDbSkillSticker> skills, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponsePaymushroom* RequestPaymushroom(const struct FBrgDbUserSoul& soul, TArray<struct FBrgDbPayMushroom> mushrooms, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseUpdate_research* RequestUpdate_research(const struct FBrgDbUserSoul& soul, TArray<struct FBrgDbUserShopHistory> shophistory, TArray<struct FBrgDbUserBaseShopResult> shoppurchase, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetpartresearch* RequestGetpartresearch(const struct FBrgDbUserSoul& soul, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseBlendmsrsoup* RequestBlendmsrsoup(const struct FBrgDbBlendMushroomSoupParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSellpt* RequestSellpt(const struct FBrgDbSellPartParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseSellmsr* RequestSellmsr(const struct FBrgDbSellMushroomParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRepairpt* RequestRepairpt(const struct FBrgDbRepairPartParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseInsurept* RequestInsurept(const struct FBrgDbInsurePt& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseGetshopprice* RequestGetshopprice(const struct FBrgDbShopPriceInfoParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseEnhancept* RequestEnhancept(const struct FBrgDbEnhancePartParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseCharge* RequestCharge(const struct FBrgDbPurchaseParam& Param, const class FString& Code, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseTermsagree* RequestTermsagree(const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseRegusr* RequestRegusr(const class FString& uuid, const class FString& sid);
		class UBrgNetworkResponseLogout* RequestLogout(const struct FBrgDbLogoutParam& Param, const struct FBrgDbSession& ssn, TArray<struct FBrgDbPlaylog> playlog);
		class UBrgNetworkResponseLogins* RequestLogins(const class FString& Code, int32_t Size, const class FString& sid, int32_t consent);
		class UBrgNetworkResponseLoginp* RequestLoginp(const class FString& Code, int32_t Size, const class FString& sid, int32_t consent);
		class UBrgNetworkResponseLogin* RequestLogin(const class FString& Uid, const class FString& sid, const class FString& nm, int32_t consent);
		class UBrgNetworkResponseStart* RequestStart(int32_t Type, int32_t ver, const class FString& rg, const class FString& lang, const class FString& tsid, const class FString& Uid, const struct FBrgDbBuildInfo& bi);
		int32_t GetLocalHttpPort();
		int32_t GetLocalHttpsPort();
		class FString GetServerHostName();
		int32_t GetApiVersion();
		void Terminate();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkRequestContent
	 * Size -> 0x0000 (FullSize[0x0120] - InheritedSize[0x0120])
	 */
	class UBrgNetworkRequestContent : public UJsonObject
	{
	public:
		class FString ToString();
		bool SetParamInt(const class FString& Key, int32_t Value);
		bool SetParam(const class FString& Key, const class FString& Value);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseInterface
	 * Size -> 0x00FC (FullSize[0x015C] - InheritedSize[0x0060])
	 */
	class UBrgNetworkResponseInterface : public UObject
	{
	public:
		class FString                                              ApiName;                                                 // 0x0060(0x0010) NeedCtorLink
		class FString                                              ApiPath;                                                 // 0x0070(0x0010) NeedCtorLink
		class FString                                              SchemeType;                                              // 0x0080(0x0010) NeedCtorLink
		unsigned long                                              bIsDone : 1;                                             // 0x0090(0x0001) BIT_FIELD
		unsigned long                                              bIsError : 1;                                            // 0x0090(0x0001) BIT_FIELD
		unsigned long                                              bCanParseContent : 1;                                    // 0x0090(0x0001) BIT_FIELD
		unsigned long                                              bStartDecryptContent : 1;                                // 0x0090(0x0001) BIT_FIELD
		unsigned long                                              bContentDecrypted : 1;                                   // 0x0090(0x0001) BIT_FIELD
		unsigned long                                              bContentDecryptFailed : 1;                               // 0x0090(0x0001) BIT_FIELD
		int32_t                                                    StatusCode;                                              // 0x0094(0x0004)
		int32_t                                                    ApiVersion;                                              // 0x0098(0x0004)
		int32_t                                                    DataVersion;                                             // 0x009C(0x0004)
		class FString                                              ErrorCode;                                               // 0x00A0(0x0010) NeedCtorLink
		class FString                                              ErrorMessage;                                            // 0x00B0(0x0010) NeedCtorLink
		class FString                                              ErrorParam;                                              // 0x00C0(0x0010) NeedCtorLink
		int32_t                                                    StatusExceptionCode;                                     // 0x00D0(0x0004)
		class FString                                              AccountId;                                               // 0x00D4(0x0010) NeedCtorLink
		class FString                                              RequestID;                                               // 0x00E4(0x0010) NeedCtorLink
		EBrgNetworkErrorType                                       ErrorType;                                               // 0x00F4(0x0001)
		unsigned char                                              UnknownData_9AP7[0x3];                                   // 0x00F5(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    LibraryErrorCode;                                        // 0x00F8(0x0004)
		class UJsonObject*                                         jsonObj;                                                 // 0x00FC(0x0008)
		TArray<class FScriptDelegate>                              GetResponseDelegates;                                    // 0x0104(0x0010) NeedCtorLink
		TArray<class FScriptDelegate>                              PreRequestDelegates;                                     // 0x0114(0x0010) NeedCtorLink
		TArray<unsigned char>                                      DecryptContent;                                          // 0x0124(0x0010) NeedCtorLink
		class UHttpRequestInterface*                               RequestInterface;                                        // 0x0134(0x0008)
		class UHttpResponseInterface*                              ResponseInterface;                                       // 0x013C(0x0008)
		float                                                      ForceErrorTimer;                                         // 0x0144(0x0004)
		int32_t                                                    LogOutputResponseSizeLimit;                              // 0x0148(0x0004) Config
		class FScriptDelegate                                      __OnGetResponse__Delegate;                               // 0x014C(0x000C) ELEMENT_SIZE_MISMATCH NeedCtorLink
		unsigned char                                              UnknownData_GD54[0x4];                                   // 0x0158(0x0004) FIX WRONG TYPE SIZE OF PREVIOUS PROPERTY

	public:
		void SetForceError();
		float GetForceErrorTimer();
		void SetForceErrorTimer(float Timer);
		bool CallPreRequestDelegate(class UHttpRequestInterface* OriginalRequest, int32_t* errCode);
		void ClearPreRequestDelegate();
		void AddPreRequestDelegate(const class FScriptDelegate& preReq);
		void CallGetResponseDelegate();
		void ClearGetResponseDelegate();
		void AddGetResponseDelegate(const class FScriptDelegate& getres);
		class FString GetRequestURL(bool isGhmlocalserver);
		class FString GetRequestURLNative(bool isGhmlocalserver);
		void ClearDecodedContent();
		void CleanParam();
		class FString GetErrorParam();
		class FString GetRequestId();
		void SetRequestId(const class FString& reqid);
		class FString GetAccountId();
		int32_t GetDataVersion();
		int32_t GetApiVersion();
		int32_t GetLibraryErrorCode();
		void SetLibraryErrorCode(int32_t Code);
		void SetErrorType(EBrgNetworkErrorType Type);
		EBrgNetworkErrorType GetErrorType();
		class UJsonObject* GetDecodedContent();
		int32_t GetStatusCode();
		int32_t GetStatusExceptionCode();
		void SetErrorMessage(const class FString& msg);
		void SetErrorCodeByCategoryAndNumber(const class FString& Category, int32_t No);
		void SetErrorCode(const class FString& Code);
		class FString GetErrorCodeAndMessage();
		class FString GetErrorMessage();
		class FString GetShortErrorCode();
		class FString GetErrorCode();
		class FString GetApiName();
		bool IsSuccess();
		bool IsError();
		bool IsDone();
		bool GetContentDecryptFailed();
		void SetContentDecryptFailed(bool flag);
		bool GetContentDecrypted();
		void SetContentDecrypted(bool flag);
		class FString GetDecryptContentAsString();
		bool GetStartDecryptContent();
		bool StartDecryptContent();
		int32_t GetContentSize();
		bool GetContent(TArray<unsigned char>* cntnt);
		void SetCanParseContent(bool flag);
		bool CanParseContent();
		bool NeedsParseContent();
		bool HasResponse();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		bool OnPreRequest(class UHttpRequestInterface* OriginalRequest, int32_t* errCode);
		void OnGetResponse(class UBrgNetworkResponseInterface* res);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseAccess_prison
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseAccess_prison : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserPrison>                            mPrison;                                                 // 0x05C0(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseArrival
	 * Size -> 0x0010 (FullSize[0x016C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseArrival : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x015C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseAssaultfort
	 * Size -> 0x0658 (FullSize[0x07B4] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseAssaultfort : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		struct FBrgDbFort                                          mFort;                                                   // 0x05C0(0x01D4) NeedCtorLink
		class FString                                              mDeathbox;                                               // 0x0794(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x07A4(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseAssaultfortresult
	 * Size -> 0x0584 (FullSize[0x06E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseAssaultfortresult : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		struct FBrgDbAssaultFortResultDetail                       mRes;                                                    // 0x05C0(0x0110) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x06D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseBlendmsrsoup
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseBlendmsrsoup : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbMushroomSoupEfc>                       mEfcs;                                                   // 0x015C(0x0010) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x016C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseBodies
	 * Size -> 0x0030 (FullSize[0x018C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseBodies : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbBody>                                  mBodies;                                                 // 0x015C(0x0010) NeedCtorLink
		TArray<struct FBrgDbGasmask>                               mGasmasks;                                               // 0x016C(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x017C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseCancelhunter
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseCancelhunter : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseChangecash
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseChangecash : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseChangeteam
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseChangeteam : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserPrison>                            mPrison;                                                 // 0x05C0(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseCharge
	 * Size -> 0x048C (FullSize[0x05E8] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseCharge : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbPurchase                                      mPurchase;                                               // 0x015C(0x0018) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0174(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D8(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseClearfloor
	 * Size -> 0x06A8 (FullSize[0x0804] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseClearfloor : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbFloor                                         mFlr;                                                    // 0x015C(0x0234) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0390(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x07F4(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseConfig
	 * Size -> 0x0020 (FullSize[0x017C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseConfig : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUserConfig                                    mConfig;                                                 // 0x015C(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x016C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseConfigmenu
	 * Size -> 0x0000 (FullSize[0x015C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseConfigmenu : public UBrgNetworkResponseInterface
	{
	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseContinue
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseContinue : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseConversation
	 * Size -> 0x0020 (FullSize[0x017C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseConversation : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbScentenceInfo>                         mSinarios;                                               // 0x015C(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x016C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseDbg_clearfloor
	 * Size -> 0x06A8 (FullSize[0x0804] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseDbg_clearfloor : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbFloor                                         mFlr;                                                    // 0x015C(0x0234) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0390(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x07F4(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseDbg_movefloor
	 * Size -> 0x06C8 (FullSize[0x0824] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseDbg_movefloor : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbFloor                                         mFlr;                                                    // 0x015C(0x0234) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0390(0x0464) NeedCtorLink
		TArray<struct FBrgDbTmpMsg>                                mMsgs;                                                   // 0x07F4(0x0010) NeedCtorLink
		class FString                                              mDeathbox;                                               // 0x0804(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0814(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseDbg_resetskl
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseDbg_resetskl : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseDbg_startfloor
	 * Size -> 0x06C8 (FullSize[0x0824] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseDbg_startfloor : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbFloor                                         mFlr;                                                    // 0x015C(0x0234) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0390(0x0464) NeedCtorLink
		TArray<struct FBrgDbTmpMsg>                                mMsgs;                                                   // 0x07F4(0x0010) NeedCtorLink
		class FString                                              mDeathbox;                                               // 0x0804(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0814(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseDbg_starthub
	 * Size -> 0x0524 (FullSize[0x0680] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseDbg_starthub : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		struct FBrgDbAreaTemplateInfo                              mTmplinfo;                                               // 0x05C0(0x0050) NeedCtorLink
		TArray<struct FBrgDbTmpMsg>                                mMsgs;                                                   // 0x0610(0x0010) NeedCtorLink
		TArray<struct FBrgDbAssaultFortResultOld>                  mDeffrtres;                                              // 0x0620(0x0010) NeedCtorLink
		TArray<struct FBrgDbRescueLog>                             mRescuelog;                                              // 0x0630(0x0010) NeedCtorLink
		TArray<struct FBrgDbWar>                                   mWarres;                                                 // 0x0640(0x0010) NeedCtorLink
		TArray<class FString>                                      mHitchart;                                               // 0x0650(0x0010) NeedCtorLink
		TArray<struct FBrgDbUserDeathbox>                          mDeathbox;                                               // 0x0660(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0670(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseDbg_takeelv
	 * Size -> 0x06B8 (FullSize[0x0814] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseDbg_takeelv : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbFloor                                         mFlr;                                                    // 0x015C(0x0234) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0390(0x0464) NeedCtorLink
		class FString                                              mDeathbox;                                               // 0x07F4(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0804(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseDbg_tgtpntlist
	 * Size -> 0x02A0 (FullSize[0x03FC] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseDbg_tgtpntlist : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbMasterBeastGen>                        mBstgen;                                                 // 0x015C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterZakoGen>                         mZakogen;                                                // 0x016C(0x0010) NeedCtorLink
		struct FBrgDbTargetPointAll                                mMet;                                                    // 0x017C(0x0080) NeedCtorLink
		struct FBrgDbTargetPointAll                                mAms;                                                    // 0x01FC(0x0080) NeedCtorLink
		struct FBrgDbTargetPointAll                                mRft;                                                    // 0x027C(0x0080) NeedCtorLink
		struct FBrgDbTargetPointAll                                mArc;                                                    // 0x02FC(0x0080) NeedCtorLink
		struct FBrgDbTargetPointAll                                mHzm;                                                    // 0x037C(0x0080) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseDeposcl
	 * Size -> 0x04C4 (FullSize[0x0620] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseDeposcl : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink
		struct FBrgDbCoinLocker                                    mCl;                                                     // 0x05D0(0x0050) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseDestroychara
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseDestroychara : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseDie
	 * Size -> 0x04BC (FullSize[0x0618] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseDie : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		struct FBrgDbBloodnium                                     mBld_result;                                             // 0x05C0(0x0048) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0608(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseDistributebodylvl
	 * Size -> 0x04C4 (FullSize[0x0620] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseDistributebodylvl : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		struct FBrgDbCoinLocker                                    mCl;                                                     // 0x05C0(0x0050) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0610(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseDrawcl
	 * Size -> 0x04C4 (FullSize[0x0620] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseDrawcl : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink
		struct FBrgDbCoinLocker                                    mCl;                                                     // 0x05D0(0x0050) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseEndbet
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseEndbet : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseEndsp
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseEndsp : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseEnhancept
	 * Size -> 0x0488 (FullSize[0x05E4] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseEnhancept : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbEnhancePartInfo                               mEnhance;                                                // 0x015C(0x0014) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0170(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D4(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseEntergate
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseEntergate : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseEquipskl
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseEquipskl : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseExpandcl
	 * Size -> 0x04C4 (FullSize[0x0620] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseExpandcl : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink
		struct FBrgDbCoinLocker                                    mCl;                                                     // 0x05D0(0x0050) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseExpanddb
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseExpanddb : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseFacilityshop
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseFacilityshop : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserPrison>                            mPrison;                                                 // 0x05C0(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseForsake
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseForsake : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseForsake_abductee
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseForsake_abductee : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseFortterminal
	 * Size -> 0x0588 (FullSize[0x06E4] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseFortterminal : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbTdmSituation>                          mSituation;                                              // 0x015C(0x0010) NeedCtorLink
		TArray<struct FBrgDbTerminalTeam>                          mTeams;                                                  // 0x016C(0x0010) NeedCtorLink
		struct FBrgDbMyTeam                                        mMyteam;                                                 // 0x017C(0x0040) NeedCtorLink
		TArray<struct FBrgDbFortZombieSetting>                     mFortsetting;                                            // 0x01BC(0x0010) NeedCtorLink
		TArray<struct FBrgDbAssaultFortResult>                     mDeffortres;                                             // 0x01CC(0x0010) NeedCtorLink
		TArray<struct FBrgDbAssaultFortResult>                     mAsltfortres;                                            // 0x01DC(0x0010) NeedCtorLink
		TArray<struct FBrgDbWar>                                   mWarlogs;                                                // 0x01EC(0x0010) NeedCtorLink
		struct FBrgDbFortTerminalAnnounce                          mAnnounce;                                               // 0x01FC(0x0058) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0254(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserPrison>                            mPrison;                                                 // 0x06B8(0x0010) NeedCtorLink
		int32_t                                                    mNextresettime;                                          // 0x06C8(0x0004)
		int32_t                                                    mPeriod;                                                 // 0x06CC(0x0004)
		int32_t                                                    mPeriodlen;                                              // 0x06D0(0x0004)
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x06D4(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseFramerateskiplog
	 * Size -> 0x0010 (FullSize[0x016C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseFramerateskiplog : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x015C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseFreeze_abductee
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseFreeze_abductee : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserPrison>                            mPrison;                                                 // 0x05C0(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetassaultfortresult
	 * Size -> 0x052C (FullSize[0x0688] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetassaultfortresult : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		struct FBrgDbAssaultFortResult                             mFortresult;                                             // 0x05C0(0x00B8) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0678(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetfortdestall
	 * Size -> 0x0074 (FullSize[0x01D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetfortdestall : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbFortDestAll                                   mDests;                                                  // 0x015C(0x0064) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x01C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetfortdests
	 * Size -> 0x0114 (FullSize[0x0270] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetfortdests : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbFortDestAllOld                                mDests;                                                  // 0x015C(0x0040) NeedCtorLink
		struct FBrgDbWar                                           mWar;                                                    // 0x019C(0x002C) NeedCtorLink
		struct FBrgDbTeamOld                                       mTeam;                                                   // 0x01C8(0x0048) NeedCtorLink
		TArray<struct FBrgDbTeamHate>                              mHates;                                                  // 0x0210(0x0010) NeedCtorLink
		TArray<struct FBrgDbAssaultFortResultOld>                  mDeffrtres;                                              // 0x0220(0x0010) NeedCtorLink
		struct FBrgDbAssaultFortCountAll                           mAvcnts;                                                 // 0x0230(0x0020)
		struct FBrgDbAssaultFeeAll                                 mFees;                                                   // 0x0250(0x0010)
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0260(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGethunterdests
	 * Size -> 0x0050 (FullSize[0x01AC] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGethunterdests : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbHunterDestAll                                 mDests;                                                  // 0x015C(0x0040) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x019C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetlocdat
	 * Size -> 0x0030 (FullSize[0x018C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetlocdat : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbLocInfo                                       mLoc;                                                    // 0x015C(0x0010) NeedCtorLink
		struct FBrgDbSubtitleInfo                                  mSbt;                                                    // 0x016C(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x017C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetmsg
	 * Size -> 0x0020 (FullSize[0x017C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetmsg : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbMsg>                                   mMsgs;                                                   // 0x015C(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x016C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetmushroomshop
	 * Size -> 0x04C4 (FullSize[0x0620] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetmushroomshop : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbSkillSticker>                          mShop;                                                   // 0x05C0(0x0010) NeedCtorLink
		TArray<struct FBrgDbSkillSticker>                          mShop_exchange;                                          // 0x05D0(0x0010) NeedCtorLink
		TArray<struct FBrgDbUserBoxGacha>                          mBoxgachas;                                              // 0x05E0(0x0010) NeedCtorLink
		TArray<struct FBrgDbGacha>                                 mGachas;                                                 // 0x05F0(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterSkillGachaCautions>              mCautions;                                               // 0x0600(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0610(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetparams
	 * Size -> 0x04F0 (FullSize[0x064C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetparams : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbStage>                                 mStgs;                                                   // 0x015C(0x0010) NeedCtorLink
		TArray<struct FBrgDbFloorArea>                             mFlrareas;                                               // 0x016C(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlayerStatus>                          mPlsts;                                                  // 0x017C(0x0010) NeedCtorLink
		TArray<struct FBrgDbBody>                                  mBodies;                                                 // 0x018C(0x0010) NeedCtorLink
		TArray<struct FBrgDbBodyDetail>                            mBody_detail;                                            // 0x019C(0x0010) NeedCtorLink
		TArray<struct FBrgDbBodyName>                              mBody_names;                                             // 0x01AC(0x0010) NeedCtorLink
		TArray<struct FBrgDbGasmask>                               mGasmask;                                                // 0x01BC(0x0010) NeedCtorLink
		TArray<struct FBrgDbBodyLvlStatus>                         mBodylvlsts;                                             // 0x01CC(0x0010) NeedCtorLink
		TArray<struct FBrgDbBodyLvlExpGrade>                       mBodylvlexpgrade;                                        // 0x01DC(0x0010) NeedCtorLink
		TArray<struct FBrgDbBodyLimitBreakItem>                    mBodylimitbreakitem;                                     // 0x01EC(0x0010) NeedCtorLink
		TArray<struct FBrgDbSkillMove>                             mSklmvs;                                                 // 0x01FC(0x0010) NeedCtorLink
		TArray<struct FBrgDbSkill>                                 mSkls;                                                   // 0x020C(0x0010) NeedCtorLink
		TArray<struct FBrgDbSkillType>                             mSkltps;                                                 // 0x021C(0x0010) NeedCtorLink
		TArray<struct FBrgDbConstInt>                              mConst_ints;                                             // 0x022C(0x0010) NeedCtorLink
		TArray<struct FBrgDbConstFloat>                            mConst_floats;                                           // 0x023C(0x0010) NeedCtorLink
		TArray<struct FBrgDbConstStr>                              mConst_strs;                                             // 0x024C(0x0010) NeedCtorLink
		TArray<struct FBrgDbAsset>                                 mAssets;                                                 // 0x025C(0x0010) NeedCtorLink
		TArray<struct FBrgDbPart>                                  mPts;                                                    // 0x026C(0x0010) NeedCtorLink
		TArray<struct FBrgDbPartArm>                               mPtarms;                                                 // 0x027C(0x0010) NeedCtorLink
		TArray<struct FBrgDbPartArmType>                           mPtarmtps;                                               // 0x028C(0x0010) NeedCtorLink
		TArray<struct FBrgDbAtkScale>                              mAtkscls;                                                // 0x029C(0x0010) NeedCtorLink
		TArray<struct FBrgDbBrObj>                                 mBos;                                                    // 0x02AC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterGate>                            mGates;                                                  // 0x02BC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMushroom>                              mMsrs;                                                   // 0x02CC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMushroomEfc>                           mMsrefcs;                                                // 0x02DC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMushroomEfcType>                       mMsrefctps;                                              // 0x02EC(0x0010) NeedCtorLink
		TArray<struct FBrgDbBeast>                                 mBsts;                                                   // 0x02FC(0x0010) NeedCtorLink
		TArray<struct FBrgDbBeastEfc>                              mBstefcs;                                                // 0x030C(0x0010) NeedCtorLink
		TArray<struct FBrgDbItem>                                  mItems;                                                  // 0x031C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterMboss>                           mMbss;                                                   // 0x032C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterFourforcemen>                    mFourforcemen;                                           // 0x033C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterZako>                            mZako;                                                   // 0x034C(0x0010) NeedCtorLink
		TArray<struct FBrgDbParamListType>                         mPtls;                                                   // 0x035C(0x0010) NeedCtorLink
		TArray<struct FBrgDbProductPrice>                          mPrdprcs;                                                // 0x036C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterAutomaticshopLineup>             mAutomaticShopLineup;                                    // 0x037C(0x0010) NeedCtorLink
		TArray<struct FBrgDbAutomaticShopDiscountTerm>             mAutomaticShopDiscountTerm;                              // 0x038C(0x0010) NeedCtorLink
		TArray<class FString>                                      mFlrstamps;                                              // 0x039C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterMagazine>                        mMagazines;                                              // 0x03AC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterPointReward>                     mMstpntrwd;                                              // 0x03BC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterPointRewardType>                 mMstpntrwdtp;                                            // 0x03CC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterEquipRankPoint>                  mPartsrankp;                                             // 0x03DC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterLvlReward>                       mMstlvlrwd;                                              // 0x03EC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterLvlRewardType>                   mMstlvlrwdtp;                                            // 0x03FC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterAbp>                             mEnmyabp;                                                // 0x040C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterAbp>                             mStgabp;                                                 // 0x041C(0x0010) NeedCtorLink
		TArray<struct FBrgDbResearch>                              mResearch;                                               // 0x042C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterPartResearch>                    mPartresearch;                                           // 0x043C(0x0010) NeedCtorLink
		TArray<struct FBrgDbElevator>                              mElvs;                                                   // 0x044C(0x0010) NeedCtorLink
		TArray<struct FBrgDbJackal>                                mJkls;                                                   // 0x045C(0x0010) NeedCtorLink
		TArray<struct FBrgDbBodyLvlStatus>                         mJklbodylvlsts;                                          // 0x046C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterQuest>                           mQuests;                                                 // 0x047C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterQuestCategory>                   mQuestcategory;                                          // 0x048C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterZombieParam>                     mZmbparams;                                              // 0x049C(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x04AC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterWhistle>                         mWhistles;                                               // 0x04BC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterWhistleGen>                      mWhistle_gens;                                           // 0x04CC(0x0010) NeedCtorLink
		TArray<struct FBrgDbRadioMusic>                            mRadio_music;                                            // 0x04DC(0x0010) NeedCtorLink
		TArray<struct FBrgDbRadioChannel>                          mRadio_channel;                                          // 0x04EC(0x0010) NeedCtorLink
		TArray<struct FBrgDbRadioYotsuyama>                        mRadio_yotsuyama;                                        // 0x04FC(0x0010) NeedCtorLink
		TArray<struct FBrgDbRadioJingle>                           mRadio_jingle;                                           // 0x050C(0x0010) NeedCtorLink
		TArray<struct FBrgDbSkillCategory>                         mSkill_category;                                         // 0x051C(0x0010) NeedCtorLink
		TArray<struct FBrgDbSkillGroup>                            mSkill_group;                                            // 0x052C(0x0010) NeedCtorLink
		TArray<class FString>                                      mGameflg;                                                // 0x053C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterSkillGacha>                      mSkill_gachas;                                           // 0x054C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterWaitingReduce>                   mWaiting_reduce;                                         // 0x055C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterHairDisplay>                     mHair_display;                                           // 0x056C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterPartEquipment>                   mPart_equipment;                                         // 0x057C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterSafeLevel>                       mSafe;                                                   // 0x058C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterSpiritTankLevel>                 mSpirit_tank;                                            // 0x059C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterPrison>                          mPrison;                                                 // 0x05AC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterFreezer>                         mFreezer;                                                // 0x05BC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterHubCustomize>                    mHubcustomize;                                           // 0x05CC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterTdmRank>                         mTdmrank;                                                // 0x05DC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterWarReward>                       mWarrwd;                                                 // 0x05EC(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterMysterybagContent>               mMysterybagcontents;                                     // 0x05FC(0x0010) NeedCtorLink
		TArray<struct FBrgDbFortBreakBonus>                        mFortbreakbonus;                                         // 0x060C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterCredit>                          mCredit;                                                 // 0x061C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterEventSchedule>                   mEventschedule;                                          // 0x062C(0x0010) NeedCtorLink
		TArray<struct FBrgDbMasterLastfloor>                       mLastfloor;                                              // 0x063C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetpartresearch
	 * Size -> 0x049C (FullSize[0x05F8] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetpartresearch : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserPartResearch>                      mUser_research;                                          // 0x05C0(0x0010) NeedCtorLink
		int32_t                                                    mBuyable_count;                                          // 0x05D0(0x0004)
		int32_t                                                    mBuyable_count_limit;                                    // 0x05D4(0x0004)
		TArray<struct FBrgResearchStampInfo>                       mResearch_stamp_info;                                    // 0x05D8(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05E8(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetquests
	 * Size -> 0x04B4 (FullSize[0x0610] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetquests : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserQuest>                             mAll_quests;                                             // 0x05C0(0x0010) NeedCtorLink
		TArray<struct FBrgDbQuest>                                 mQuests;                                                 // 0x05D0(0x0010) NeedCtorLink
		TArray<class FString>                                      mCleared_qids;                                           // 0x05E0(0x0010) NeedCtorLink
		TArray<class FString>                                      mCanceled_qids;                                          // 0x05F0(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0600(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetranking
	 * Size -> 0x00D0 (FullSize[0x022C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetranking : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbRankingAll                                    mRankingall;                                             // 0x015C(0x00C0) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x021C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetshopprice
	 * Size -> 0x0498 (FullSize[0x05F4] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetshopprice : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbShopPriceInfo                                 mInfo;                                                   // 0x015C(0x0024) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0180(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05E4(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetskillsticker
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetskillsticker : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetteaminfo
	 * Size -> 0x0050 (FullSize[0x01AC] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetteaminfo : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbMyTeam                                        mMyteam;                                                 // 0x015C(0x0040) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x019C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGetuserinfo
	 * Size -> 0x0524 (FullSize[0x0680] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGetuserinfo : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserPartResearch>                      mUser_research;                                          // 0x05C0(0x0010) NeedCtorLink
		struct FBrgDbUserConfigMenu                                mUser_config_menu;                                       // 0x05D0(0x0020) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05F0(0x0010) NeedCtorLink
		TArray<class FString>                                      mHitchart;                                               // 0x0600(0x0010) NeedCtorLink
		TArray<struct FBrgLoadingAnnounce>                         mLoading_announces;                                      // 0x0610(0x0010) NeedCtorLink
		struct FBrgDbCoinLocker                                    mCl;                                                     // 0x0620(0x0050) NeedCtorLink
		TArray<struct FBrgDbUserQuest>                             mAll_quests;                                             // 0x0670(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseGimreaper
	 * Size -> 0x0020 (FullSize[0x017C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseGimreaper : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbGrimPeaperMenu>                        mMenu;                                                   // 0x015C(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x016C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseImagetraining
	 * Size -> 0x0478 (FullSize[0x05D4] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseImagetraining : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		int32_t                                                    mIs_defending;                                           // 0x05C0(0x0004)
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C4(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseInputusername
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseInputusername : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseInsurept
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseInsurept : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseLoadgame
	 * Size -> 0x06A8 (FullSize[0x0804] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseLoadgame : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbFloor                                         mFlr;                                                    // 0x015C(0x0234) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0390(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x07F4(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseLogin
	 * Size -> 0x0004 (FullSize[0x0160] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseLogin : public UBrgNetworkResponseInterface
	{
	public:
		int32_t                                                    mIs_normal_end;                                          // 0x015C(0x0004)

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseLoginp
	 * Size -> 0x0024 (FullSize[0x0180] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseLoginp : public UBrgNetworkResponseInterface
	{
	public:
		class FString                                              mUid;                                                    // 0x015C(0x0010) NeedCtorLink
		class FString                                              mPsid;                                                   // 0x016C(0x0010) NeedCtorLink
		int32_t                                                    mIs_normal_end;                                          // 0x017C(0x0004)

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseLogins
	 * Size -> 0x0034 (FullSize[0x0190] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseLogins : public UBrgNetworkResponseInterface
	{
	public:
		class FString                                              mUid;                                                    // 0x015C(0x0010) NeedCtorLink
		class FString                                              mPsid;                                                   // 0x016C(0x0010) NeedCtorLink
		int32_t                                                    mIs_normal_end;                                          // 0x017C(0x0004)
		class FString                                              mRegion;                                                 // 0x0180(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseLogout
	 * Size -> 0x0000 (FullSize[0x015C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseLogout : public UBrgNetworkResponseInterface
	{
	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseMovefloor
	 * Size -> 0x06C8 (FullSize[0x0824] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseMovefloor : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbFloor                                         mFlr;                                                    // 0x015C(0x0234) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0390(0x0464) NeedCtorLink
		TArray<struct FBrgDbTmpMsg>                                mMsgs;                                                   // 0x07F4(0x0010) NeedCtorLink
		TArray<struct FBrgDbRescueLog>                             mRescuelog;                                              // 0x0804(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0814(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseMushroomshop
	 * Size -> 0x04C4 (FullSize[0x0620] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseMushroomshop : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink
		struct FBrgDbCoinLocker                                    mCl;                                                     // 0x05D0(0x0050) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseOpendialog
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseOpendialog : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseOpenskl
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseOpenskl : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseOperatepresent
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseOperatepresent : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbUserPresent>                           mPresents;                                               // 0x015C(0x0010) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x016C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseOrderquests
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseOrderquests : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserQuest>                             mAll_quests;                                             // 0x05C0(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponsePausegame
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponsePausegame : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponsePaymushroom
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponsePaymushroom : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponsePayransom
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponsePayransom : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponsePlaylog
	 * Size -> 0x0030 (FullSize[0x018C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponsePlaylog : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbPlayLogMenu>                           mMenu;                                                   // 0x015C(0x0010) NeedCtorLink
		TArray<struct FBrgDbLogElement>                            mElements;                                               // 0x016C(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x017C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponsePresents
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponsePresents : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserPresent>                           mPresents;                                               // 0x05C0(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponsePurchasebody
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponsePurchasebody : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseRadio
	 * Size -> 0x0464 (FullSize[0x05C0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseRadio : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseReceivedeathbox
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseReceivedeathbox : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbUserDeathbox>                          mDeathbox;                                               // 0x015C(0x0010) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x016C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseReceivepresent
	 * Size -> 0x04A4 (FullSize[0x0600] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseReceivepresent : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbUserPresent>                           mPresents;                                               // 0x015C(0x0010) NeedCtorLink
		struct FBrgDbUserPresentReceive                            mReceive;                                                // 0x016C(0x0020) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x018C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05F0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseRecovererror
	 * Size -> 0x0000 (FullSize[0x015C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseRecovererror : public UBrgNetworkResponseInterface
	{
	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseRecovery
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseRecovery : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseReduce_waiting
	 * Size -> 0x0488 (FullSize[0x05E4] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseReduce_waiting : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserPrison>                            mPrison;                                                 // 0x05C0(0x0010) NeedCtorLink
		int32_t                                                    mUsed_medal;                                             // 0x05D0(0x0004)
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D4(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseRegusr
	 * Size -> 0x0030 (FullSize[0x018C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseRegusr : public UBrgNetworkResponseInterface
	{
	public:
		class FString                                              mUid;                                                    // 0x015C(0x0010) NeedCtorLink
		class FString                                              mKey;                                                    // 0x016C(0x0010) NeedCtorLink
		class FString                                              mPsid;                                                   // 0x017C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseRelease_abductee
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseRelease_abductee : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserPrison>                            mPrison;                                                 // 0x05C0(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseRelievegame
	 * Size -> 0x0708 (FullSize[0x0864] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseRelievegame : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbFloor                                         mFlr;                                                    // 0x015C(0x0234) NeedCtorLink
		struct FBrgDbAreaTemplateInfo                              mTmplinfo;                                               // 0x0390(0x0050) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x03E0(0x0464) NeedCtorLink
		class FString                                              mRelief_point;                                           // 0x0844(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0854(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseRepairpt
	 * Size -> 0x0488 (FullSize[0x05E4] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseRepairpt : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbRepairPartInfo                                mRepair;                                                 // 0x015C(0x0014) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0170(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D4(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseResetboxgacha
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseResetboxgacha : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserBoxGacha>                          mBoxgachas;                                              // 0x05C0(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseResumegame
	 * Size -> 0x0738 (FullSize[0x0894] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseResumegame : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbFloor                                         mFlr;                                                    // 0x015C(0x0234) NeedCtorLink
		struct FBrgDbAreaTemplateInfo                              mTmplinfo;                                               // 0x0390(0x0050) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x03E0(0x0464) NeedCtorLink
		TArray<float>                                              mPos;                                                    // 0x0844(0x0010) NeedCtorLink
		TArray<struct FBrgDbAreaMapFlag>                           mAreamapflags;                                           // 0x0854(0x0010) NeedCtorLink
		TArray<struct FBrgDbSaveData>                              mSavedata;                                               // 0x0864(0x0010) NeedCtorLink
		TArray<struct FBrgDbGetList>                               mGetlist;                                                // 0x0874(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0884(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseRoastmushroom
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseRoastmushroom : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseSalvage
	 * Size -> 0x0234 (FullSize[0x0390] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseSalvage : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbChara                                         mChr;                                                    // 0x015C(0x0214) NeedCtorLink
		TArray<struct FBrgDbDiedChara>                             mDchrs;                                                  // 0x0370(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0380(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseSavediepoint
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseSavediepoint : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseSavegame
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseSavegame : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseSaveitemlog
	 * Size -> 0x0010 (FullSize[0x016C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseSaveitemlog : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x015C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseSavelasthubtime
	 * Size -> 0x0010 (FullSize[0x016C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseSavelasthubtime : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x015C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseSavescreenshot
	 * Size -> 0x0010 (FullSize[0x016C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseSavescreenshot : public UBrgNetworkResponseInterface
	{
	public:
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x015C(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseSelectbody
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseSelectbody : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseSelectchara
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseSelectchara : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseSellmsr
	 * Size -> 0x0478 (FullSize[0x05D4] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseSellmsr : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbSellMushroom                                  mSell;                                                   // 0x015C(0x0004)
		struct FBrgDbUser                                          mUser;                                                   // 0x0160(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C4(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseSellpt
	 * Size -> 0x0478 (FullSize[0x05D4] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseSellpt : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbSellPart                                      mSell;                                                   // 0x015C(0x0004)
		struct FBrgDbUser                                          mUser;                                                   // 0x0160(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C4(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseSendhunter
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseSendhunter : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseShowhunterresult
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseShowhunterresult : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbHunterResult>                          mResults;                                                // 0x05C0(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseSkillgacha
	 * Size -> 0x0494 (FullSize[0x05F0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseSkillgacha : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserBoxGacha>                          mBoxgachas;                                              // 0x05C0(0x0010) NeedCtorLink
		struct FBrgDbSkillGachaResult                              mResult;                                                 // 0x05D0(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05E0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseSortcl
	 * Size -> 0x04C4 (FullSize[0x0620] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseSortcl : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink
		struct FBrgDbCoinLocker                                    mCl;                                                     // 0x05D0(0x0050) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseStart
	 * Size -> 0x0080 (FullSize[0x01DC] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseStart : public UBrgNetworkResponseInterface
	{
	public:
		class FString                                              mCnt;                                                    // 0x015C(0x0010) NeedCtorLink
		class FString                                              mApi;                                                    // 0x016C(0x0010) NeedCtorLink
		class FString                                              mPsid;                                                   // 0x017C(0x0010) NeedCtorLink
		struct FBrgDbMasterTerms                                   mTerms;                                                  // 0x018C(0x0040) NeedCtorLink
		TArray<struct FBrgDbMasterTerms>                           mTermslist;                                              // 0x01CC(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseStartbet
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseStartbet : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseStartfloor
	 * Size -> 0x06D8 (FullSize[0x0834] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseStartfloor : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbFloor                                         mFlr;                                                    // 0x015C(0x0234) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0390(0x0464) NeedCtorLink
		TArray<struct FBrgDbRescueLog>                             mRescuelog;                                              // 0x07F4(0x0010) NeedCtorLink
		TArray<struct FBrgDbTmpMsg>                                mMsgs;                                                   // 0x0804(0x0010) NeedCtorLink
		class FString                                              mDeathbox;                                               // 0x0814(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0824(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseStarthub
	 * Size -> 0x061C (FullSize[0x0778] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseStarthub : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		int32_t                                                    mIs_imagetraining;                                       // 0x05C0(0x0004)
		int32_t                                                    mIs_defending;                                           // 0x05C4(0x0004)
		int32_t                                                    mIs_new_quest;                                           // 0x05C8(0x0004)
		int32_t                                                    mReplica_money;                                          // 0x05CC(0x0004)
		int32_t                                                    mReplica_spirit;                                         // 0x05D0(0x0004)
		int32_t                                                    mReplica_bloodnium_point;                                // 0x05D4(0x0004)
		TArray<struct FBrgDbUserPrison>                            mPrison;                                                 // 0x05D8(0x0010) NeedCtorLink
		struct FBrgDbAreaTemplateInfo                              mTmplinfo;                                               // 0x05E8(0x0050) NeedCtorLink
		TArray<struct FBrgDbTmpMsg>                                mMsgs;                                                   // 0x0638(0x0010) NeedCtorLink
		struct FBrgDbDeffenceFortHubState                          mDefstate;                                               // 0x0648(0x0060) NeedCtorLink
		int32_t                                                    mFortkun;                                                // 0x06A8(0x0004)
		TArray<struct FBrgDbWar>                                   mWars;                                                   // 0x06AC(0x0010) NeedCtorLink
		TArray<struct FBrgDbTeam>                                  mTeams;                                                  // 0x06BC(0x0010) NeedCtorLink
		TArray<struct FBrgDbUserDeathbox>                          mDeathbox;                                               // 0x06CC(0x0010) NeedCtorLink
		TArray<class FString>                                      mHitchart;                                               // 0x06DC(0x0010) NeedCtorLink
		TArray<struct FBrgLoadingAnnounce>                         mLoading_announces;                                      // 0x06EC(0x0010) NeedCtorLink
		TArray<struct FBrgOnetimeAnnounce>                         mOnetime_announces;                                      // 0x06FC(0x0010) NeedCtorLink
		TArray<struct FBrgDbUserHubCustomize>                      mHubcustomize;                                           // 0x070C(0x0010) NeedCtorLink
		struct FBrgDbBloodnium                                     mBld_result;                                             // 0x071C(0x0048) NeedCtorLink
		int32_t                                                    mDel_old_quest;                                          // 0x0764(0x0004)
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0768(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseTakeelv
	 * Size -> 0x06D8 (FullSize[0x0834] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseTakeelv : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbFloor                                         mFlr;                                                    // 0x015C(0x0234) NeedCtorLink
		struct FBrgDbUser                                          mUser;                                                   // 0x0390(0x0464) NeedCtorLink
		TArray<struct FBrgDbTmpMsg>                                mMsgs;                                                   // 0x07F4(0x0010) NeedCtorLink
		TArray<struct FBrgDbRescueLog>                             mRescuelog;                                              // 0x0804(0x0010) NeedCtorLink
		class FString                                              mDeathbox;                                               // 0x0814(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x0824(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseTermsagree
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseTermsagree : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseTest
	 * Size -> 0x0084 (FullSize[0x01E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseTest : public UBrgNetworkResponseInterface
	{
	public:
		unsigned long                                              mBresult : 1;                                            // 0x015C(0x0001) BIT_FIELD
		int32_t                                                    mIresult;                                                // 0x0160(0x0004)
		float                                                      mFresult;                                                // 0x0164(0x0004)
		class FString                                              mSresult;                                                // 0x0168(0x0010) NeedCtorLink
		struct Ftest_struct2                                       mOresult;                                                // 0x0178(0x0018) NeedCtorLink
		TArray<unsigned long>                                      mBresults;                                               // 0x0190(0x0010) NeedCtorLink
		TArray<int32_t>                                            mIresults;                                               // 0x01A0(0x0010) NeedCtorLink
		TArray<float>                                              mFresults;                                               // 0x01B0(0x0010) NeedCtorLink
		TArray<class FString>                                      mSresults;                                               // 0x01C0(0x0010) NeedCtorLink
		TArray<struct Ftest_struct2>                               mOresults;                                               // 0x01D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseTutorial
	 * Size -> 0x0000 (FullSize[0x015C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseTutorial : public UBrgNetworkResponseInterface
	{
	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseUpdate_research
	 * Size -> 0x04C4 (FullSize[0x0620] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseUpdate_research : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink
		struct FBrgDbCoinLocker                                    mCl;                                                     // 0x05D0(0x0050) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseUpdatecharaname
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseUpdatecharaname : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseUpdatefortsetting
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseUpdatefortsetting : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbFortZombieSetting>                     mFortsetting;                                            // 0x05C0(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseUpdatefriend
	 * Size -> 0x0004 (FullSize[0x0160] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseUpdatefriend : public UBrgNetworkResponseInterface
	{
	public:
		int32_t                                                    mResult;                                                 // 0x015C(0x0004)

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseUpdatehubcustomize
	 * Size -> 0x0484 (FullSize[0x05E0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseUpdatehubcustomize : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbUserHubCustomize>                      mHubcustomize;                                           // 0x05C0(0x0010) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05D0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseUpdatemedal
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseUpdatemedal : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseUpdaterevenge
	 * Size -> 0x0000 (FullSize[0x015C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseUpdaterevenge : public UBrgNetworkResponseInterface
	{
	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseUpdateuserinfo
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseUpdateuserinfo : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseUsedustshooter
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseUsedustshooter : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseUsesafe
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseUsesafe : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseVipconfig
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseVipconfig : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseVippurchase
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseVippurchase : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseVipuse
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseVipuse : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseWhistleshop
	 * Size -> 0x0474 (FullSize[0x05D0] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseWhistleshop : public UBrgNetworkResponseInterface
	{
	public:
		struct FBrgDbUser                                          mUser;                                                   // 0x015C(0x0464) NeedCtorLink
		TArray<struct FBrgDbPlaylog>                               mPlaylog;                                                // 0x05C0(0x0010) NeedCtorLink

	public:
		void CleanParam();
		void OnProcessRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* InHttpResponse, bool bDidSucceed);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgPartMesh
	 * Size -> 0x0844 (FullSize[0x08A4] - InheritedSize[0x0060])
	 */
	class UBrgPartMesh : public UObject
	{
	public:
		unsigned long                                              mVisible : 1;                                            // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mHiddenType2 : 1;                                        // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mCastShadow : 1;                                         // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mDropItemVisible : 1;                                    // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mbHideHood : 1;                                          // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mChangeAttachTarget : 1;                                 // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mNewAttachTargetActorLightChannelValid : 1;              // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mbNewAttachSocket : 1;                                   // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mDirectMaterialParameterChange : 1;                      // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mChangeAttachSocket : 1;                                 // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mDisableMaterialFadeIn : 1;                              // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mbBlockPawnMovement : 1;                                 // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mbCheckSkipPhysicsAnimEquip : 1;                         // 0x0060(0x0001) BIT_FIELD
		class FString                                              mName;                                                   // 0x0064(0x0010) NeedCtorLink
		EBrgPartMeshComponentState                                 mState;                                                  // 0x0074(0x0001)
		ERBCollisionChannel                                        mCollisionChannel;                                       // 0x0075(0x0001)
		unsigned char                                              mSubDeathOpacityVisible[0x2];                            // 0x0076(0x0002)
		ESceneDepthPriorityGroup                                   mSceneDepthPriorityGroup;                                // 0x0078(0x0001)
		ERBCollisionChannel                                        mNewCollisionChannel;                                    // 0x0079(0x0001)
		unsigned char                                              UnknownData_0S4R[0x2];                                   // 0x007A(0x0002) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class APawn*                                               mAttachTargetPawn;                                       // 0x007C(0x0008)
		class AActor*                                              mAttachTargetActor;                                      // 0x0084(0x0008)
		class USkeletalMeshComponent*                              mAttachTargetSkeletalMeshComponent;                      // 0x008C(0x0008) ExportObject, Component, EditInline
		class UDynamicLightEnvironmentComponent*                   mAttachTargetActorLightEnvironment;                      // 0x0094(0x0008) ExportObject, Component, EditInline
		struct FLightingChannelContainer                           mAttachTargetActorLightChannel;                          // 0x009C(0x0004)
		struct FBrgPartMeshData                                    mData[0x2];                                              // 0x00A0(0x05D8) Component, NeedCtorLink
		int32_t                                                    mNowIndex;                                               // 0x0678(0x0004)
		int32_t                                                    mDeathOpacityTarget;                                     // 0x067C(0x0004)
		struct FParamMoveData                                      mDropItemVisibleAlpha;                                   // 0x0680(0x006C)
		struct FParamMoveData                                      mSubDeathOpacityVisibleAlpha[0x2];                       // 0x06EC(0x00D8)
		struct FParamMoveData                                      mHoodVisibleAlpha;                                       // 0x07C4(0x006C)
		class ABrgGameInfoNativeBase*                              mGameInfoNativeBase;                                     // 0x0830(0x0008)
		class UBrgUIParamEditMenuParam*                            mConstParam;                                             // 0x0838(0x0008)
		class UBrgResourceLoadManager*                             mResourceLoadManager;                                    // 0x0840(0x0008)
		struct FVector                                             mCameraLocation;                                         // 0x0848(0x000C)
		class APawn*                                               mNewAttachTargetPawn;                                    // 0x0854(0x0008)
		class AActor*                                              mNewAttachTargetActor;                                   // 0x085C(0x0008)
		class USkeletalMeshComponent*                              mNewAttachTargetSkeletalMeshComponent;                   // 0x0864(0x0008) ExportObject, Component, EditInline
		class UDynamicLightEnvironmentComponent*                   mNewAttachTargetActorLightEnvironment;                   // 0x086C(0x0008) ExportObject, Component, EditInline
		struct FLightingChannelContainer                           mNewAttachTargetActorLightChannel;                       // 0x0874(0x0004)
		class FName                                                mNewAttachSocketName;                                    // 0x0878(0x0008)
		int32_t                                                    mAlwaysMaterialParamSetCount;                            // 0x0880(0x0004)
		class UMaterialInstanceConstant*                           mOutlineMIC;                                             // 0x0884(0x0008)
		class UParticleSystem*                                     mCrashBottlePS;                                          // 0x088C(0x0008)
		struct FVector                                             mBackLocation;                                           // 0x0894(0x000C)
		float                                                      mSkipPhysicsAnimSpeedEquip;                              // 0x08A0(0x0004)

	public:
		void RefreshMaterialInstanceRef();
		bool SetMaterial(int32_t MaterialIndex, class UMaterialInstanceConstant* MIC);
		bool GetSkipUpdatePhysicsAnim();
		void SetSkipUpdatePhysicsAnim(bool InFlg);
		float GetSkipPhysicsAnimSpeedEquip();
		bool GetCheckSkipPhysicsAnimEquipFlg();
		void SetSkipPhysicsAnim(bool InFlg, float InSkipSpeed);
		void SetSkipPhysicsAnimSpeedEquip(float InSkipSpeed);
		void SetSkipPhysicsAnimFlg(bool InFlg);
		void SetBlockPawnMovement(bool NewFlag);
		void CreateMyceliumCoveredMeshComponent(class USkeletalMesh* OverriedSkeletalMesh, class UPhysicsAsset* OverriedPhysicsAsset, class USkeletalMeshComponent* OverriedSkeletalMeshComponent);
		void TickMyceliumCovered(float inDeltaTime);
		void TickOutline(float inDeltaTime);
		void TickProcess_DuringAsyncWork(float inDeltaTime);
		void TickProcess_PreAsyncWork(float inDeltaTime);
		void TickProcess(float inDeltaTime);
		void SetMeshMaterialInstanceVectorParameterValue(int32_t InIndex, const class FName& ParameterName, struct FLinearColor* Value);
		void SetMeshMaterialInstanceTextureParameterValue(int32_t InIndex, const class FName& ParameterName, class UTexture* Value);
		void SetMeshMaterialInstanceScalarParameterValue(int32_t InIndex, const class FName& ParameterName, float Value);
		void SetMeshCastShadow(int32_t InIndex, bool inCastShadow);
		void SetMeshVisible(int32_t InIndex, bool Invisible);
		void SetDamagedMeshState(int32_t InIndex, bool inDamaged);
		void SetPartialEmissiveColorIntensityOffMesh(int32_t InIndex);
		bool SetUseMeshDropItemEffect(int32_t InIndex, bool inUseFlag);
		void StartDeathOpacityMesh(int32_t InIndex, float inFadeTime, bool inAfterDetach, bool inIsFadeIn);
		void StartDeathColorMesh(int32_t InIndex);
		void StartZScaleMesh(int32_t InIndex);
		void SetUseRoastMaterialMesh(int32_t InIndex);
		void AllUnFixed(class USkeletalMeshComponent* InMesh);
		void UnfixBones(class USkeletalMeshComponent* inDestMesh, class USkeletalMeshComponent* inSrcMesh);
		void StartFracturedStaticMeshActorMesh(int32_t InIndex, const struct FVector& InLocation, const struct FRotator& InRotation, const struct FVector& inBreakDir);
		void AllPhysicsMesh(int32_t InIndex);
		void PhysicsReSetupMesh(int32_t InIndex);
		void AttachMesh(int32_t InIndex);
		void ChangeAttachTargetSocketMesh(int32_t InIndex);
		void ChangeAttachTargetMesh(int32_t InIndex);
		void DetachMesh(int32_t InIndex);
		class USkeletalMeshComponent* GetMyceliumCoveredMeshComponent();
		class USkeletalMeshComponent* GetMeshComponent();
		class UPhysicsAsset* GetPhysicsAsset();
		class UMaterialInstanceConstant* GetRoastMaterialInstanceConstant(int32_t matIndex);
		class UStaticMesh* GetStaticMesh();
		class USkeletalMesh* GetMesh();
		bool CheckIdle();
		EBrgPartMeshComponentState GetState();
		void SetPartialEmissiveColorIntensityOff();
		bool SetUseDropItemEffect(bool inUseFlag);
		void ResetAttachMesh();
		void SetSceneDepthPriorityGroup(ESceneDepthPriorityGroup inGroup);
		void SetMaterialInstanceVectorParameterValue(const class FName& ParameterName, struct FLinearColor* Value);
		void SetMaterialInstanceTextureParameterValue(const class FName& ParameterName, class UTexture* Value);
		void SetMaterialInstanceScalarParameterValue(const class FName& ParameterName, float Value);
		void SetCastShadow(bool inCastShadow);
		bool GetVisible();
		void SetVisible(bool Invisible);
		void SetDamagedState(bool inDamaged);
		void PhysicsReSetup();
		void SetDropItemVisible(bool Invisible);
		void SetHideHood(bool inHide, float inFadeTime, float inStartParam);
		void SetSubDeathOpacity(bool Invisible, float inFadeTime, int32_t InIndex, float inStartParam);
		void StartDeathOpacity(float inFadeTime, bool inAfterDetach, bool inIsFadeIn);
		void StartDeathColor();
		void StartZScale();
		void SetUseRoastMaterial();
		void StartFracturedStaticMeshActor(const struct FVector& InLocation, const struct FRotator& InRotation, const struct FVector& inBreakDir);
		void PhysicsDrop();
		void UnloadMesh();
		bool LoadMesh(const class FString& inMeshPath, const class FString& inPhysicsAssetPath, const class FString& inAnimSetPath, const class FString& inAnimTreePath, bool inIsAttachSocket, const class FName& inAttachSocketName, const class FString& inFracturedStaticMeshPath, const class FString& inStaticMeshPath, bool inUseSkeletalMeshComponent, bool inAlwaysLoad, bool inPostAsyncTickGroupOverride, const class FString& inOutlineMeshPath, TArray<class FString> inRoastMaterialInstanceConstantPath, float inFadeInDeathOpacityStartParam, float inFadeInDeathOpacityTime, bool inImmediate);
		void ChangeAttachSocket(const class FName& inAttachSocketName);
		void ChangeAttachTarget(class APawn* inAttachTargetPawn, class AActor* inAttachTargetActor, class USkeletalMeshComponent* inAttachTargetSkeletalMeshComponent, class UDynamicLightEnvironmentComponent* inAttachTargetActorLightEnvironment, ERBCollisionChannel inCollisionChannel);
		void SetChangeAttachTargetLightChannel(const struct FLightingChannelContainer& inAttachTargetActorLightChannel);
		void SetDeathOpacityTarget(int32_t TargetNumber);
		void CancelMaterialFadeIn();
		void SetEnableMaterialFadeIn(bool inEnable);
		void SetInitializeLightChannel(const struct FLightingChannelContainer& inAttachTargetActorLightChannel);
		void SetName(const class FString& InName);
		void Initialize(class APawn* inAttachTargetPawn, class AActor* inAttachTargetActor, class USkeletalMeshComponent* inAttachTargetSkeletalMeshComponent, class UDynamicLightEnvironmentComponent* inAttachTargetActorLightEnvironment, ERBCollisionChannel inCollisionChannel, bool inHiddenType2);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgPerformanceManager
	 * Size -> 0x0030 (FullSize[0x0090] - InheritedSize[0x0060])
	 */
	class UBrgPerformanceManager : public UObject
	{
	public:
		unsigned long                                              mbActive : 1;                                            // 0x0060(0x0001) BIT_FIELD Edit
		unsigned long                                              mbManageEnemiesShadow : 1;                               // 0x0060(0x0001) BIT_FIELD Edit
		unsigned long                                              mbManageObjects : 1;                                     // 0x0060(0x0001) BIT_FIELD Edit
		int32_t                                                    mEnemyShadowLimitNum;                                    // 0x0064(0x0004) Edit
		float                                                      mRandomGenerateObjectActiveRange;                        // 0x0068(0x0004) Edit
		int32_t                                                    mFOVMarginAngle;                                         // 0x006C(0x0004) Edit
		float                                                      mAlwaysActiveDist;                                       // 0x0070(0x0004) Edit
		struct FVector                                             mPlayerLocation;                                         // 0x0074(0x000C) Edit, Transient
		TArray<struct FImportantActorInfo>                         mImportantActors;                                        // 0x0080(0x0010) Edit, NeedCtorLink

	public:
		bool IsInImportantActorZone(struct FVector* TestLocation, float TestRadius);
		void RemoveImportantActor(class AActor* ImportantActor);
		void AddImportantActor(class AActor* ImportantActor, float ZoneRadius);
		void SetObjects(bool bNewActive);
		void SetEnemiesShadow(bool bNewActive);
		void ResetObjects();
		void ResetEnemiesShadow();
		void SetActive(bool bNewActive);
		void TickDuringAsyncWork(float DeltaTime, class ABrgGameInfoNativeBase* GameInfo);
		void TickMushroomShop(float DeltaTime, class ABrgGameInfoNativeBase* GameInfo);
		void TickRandomGenerateObjects(float DeltaTime, class ABrgGameInfoNativeBase* GameInfo);
		void TickEnemiesShadow(float DeltaTime, class ABrgGameInfoNativeBase* GameInfo);
		void TickEnemies(float DeltaTime, class ABrgGameInfoNativeBase* GameInfo);
		void Tick(float DeltaTime, class ABrgGameInfoNativeBase* GameInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgRenderPrimitive2DSet
	 * Size -> 0x0030 (FullSize[0x0090] - InheritedSize[0x0060])
	 */
	class UBrgRenderPrimitive2DSet : public UObject
	{
	public:
		int32_t                                                    mRenderPrimitiveCount;                                   // 0x0060(0x0004)
		TArray<struct FBrgOneRenderPrimitiveInfo>                  mRenderPrimitiveInfos;                                   // 0x0064(0x0010) NeedCtorLink
		TArray<struct FBrgRenderPrimitive2DSetVertexBuffer>        mVertexBuffers;                                          // 0x0074(0x0010) NeedCtorLink
		int32_t                                                    mUseVertexBufferIndex;                                   // 0x0084(0x0004)
		int32_t                                                    mUseStartVertexCount;                                    // 0x0088(0x0004)
		int32_t                                                    mUseNowVertexCount;                                      // 0x008C(0x0004)

	public:
		class UBrgRenderPrimitive2DSet* Create(int32_t inMaxDrawNum, int32_t inMaxVertexNum);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgResourceLoadManager
	 * Size -> 0x02F0 (FullSize[0x0350] - InheritedSize[0x0060])
	 */
	class UBrgResourceLoadManager : public UObject
	{
	public:
		class UClass*                                              mFontClass;                                              // 0x0060(0x0008)
		class UClass*                                              mTexture2DClass;                                         // 0x0068(0x0008)
		class UClass*                                              mMaterialClass;                                          // 0x0070(0x0008)
		class UClass*                                              mMaterialInstanceConstantClass;                          // 0x0078(0x0008)
		class UClass*                                              mSkeletalMeshClass;                                      // 0x0080(0x0008)
		class UClass*                                              mStaticMeshClass;                                        // 0x0088(0x0008)
		class UClass*                                              mPhysicsAssetClass;                                      // 0x0090(0x0008)
		class UClass*                                              mAnimTreeClass;                                          // 0x0098(0x0008)
		class UClass*                                              mAnimSetClass;                                           // 0x00A0(0x0008)
		class UClass*                                              mParticleSystemClass;                                    // 0x00A8(0x0008)
		class UClass*                                              mSoundCueClass;                                          // 0x00B0(0x0008)
		class UClass*                                              mFracturedStaticMeshClass;                               // 0x00B8(0x0008)
		class UClass*                                              mTextureMovieClass;                                      // 0x00C0(0x0008)
		TArray<class UBrgResourceLoadManager_PackageData*>         mPackageDataArray;                                       // 0x00C8(0x0010) NeedCtorLink
		TArray<class UBrgResourceLoadManager_PackageData*>         mPackageDataArray_Loading;                               // 0x00D8(0x0010) NeedCtorLink
		TArray<class UBrgResourceLoadManager_PackageData*>         mPackageDataArray_LoadAfterDelete;                       // 0x00E8(0x0010) NeedCtorLink
		TArray<class FString>                                      mFileNotFound_FilePaths;                                 // 0x00F8(0x0010) NeedCtorLink
		TArray<class FString>                                      mNotFound_ObjectPaths;                                   // 0x0108(0x0010) NeedCtorLink
		float                                                      mPackageDataLoadDelay;                                   // 0x0118(0x0004)
		float                                                      mPackageDataLoadDelayCounter;                            // 0x011C(0x0004)
		float                                                      mPackageDataLoadUseTime;                                 // 0x0120(0x0004)
		int32_t                                                    mFrameCount;                                             // 0x0124(0x0004)
		int32_t                                                    mStaticLoadObjectCount;                                  // 0x0128(0x0004)
		struct FBrgObjectDataSet                                   mFontDataSet;                                            // 0x012C(0x0028) NeedCtorLink
		struct FBrgObjectDataSet                                   mTexture2DDataSet;                                       // 0x0154(0x0028) NeedCtorLink
		struct FBrgObjectDataSet                                   mMaterialDataSet;                                        // 0x017C(0x0028) NeedCtorLink
		struct FBrgObjectDataSet                                   mMaterialInstanceConstantDataSet;                        // 0x01A4(0x0028) NeedCtorLink
		struct FBrgObjectDataSet                                   mSkeletalMeshDataSet;                                    // 0x01CC(0x0028) NeedCtorLink
		struct FBrgObjectDataSet                                   mStaticMeshDataSet;                                      // 0x01F4(0x0028) NeedCtorLink
		struct FBrgObjectDataSet                                   mPhysicsAssetDataSet;                                    // 0x021C(0x0028) NeedCtorLink
		struct FBrgObjectDataSet                                   mAnimTreeDataSet;                                        // 0x0244(0x0028) NeedCtorLink
		struct FBrgObjectDataSet                                   mAnimSetDataSet;                                         // 0x026C(0x0028) NeedCtorLink
		struct FBrgObjectDataSet                                   mParticleSystemDataSet;                                  // 0x0294(0x0028) NeedCtorLink
		struct FBrgObjectDataSet                                   mSoundCueDataSet;                                        // 0x02BC(0x0028) NeedCtorLink
		struct FBrgObjectDataSet                                   mFracturedStaticMeshDataSet;                             // 0x02E4(0x0028) NeedCtorLink
		struct FBrgObjectDataSet                                   mTextureMovieDataSet;                                    // 0x030C(0x0028) NeedCtorLink
		EBrgResourceLoadManager_LoadMode                           mLoadMode;                                               // 0x0334(0x0001)
		unsigned char                                              UnknownData_H0MT[0x3];                                   // 0x0335(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct FBrgResourceLoadManager_LoadModeProperty            mLoadModeProperty[0x3];                                  // 0x0338(0x0018)

	public:
		void DebugRender(class ABrgHUDBase* inHUD);
		void DebugRenderParam(class ABrgHUDBase* inHUD, int32_t inDrawX, int32_t InDrawY, const class FString& inParamName, int32_t inLoadCount, int32_t inLoadingCount);
		class FString DebugGetLoadModeName(EBrgResourceLoadManager_LoadMode loadMode);
		void DumpState();
		void DumpResources();
		void DumpResources_Mesh();
		void DumpInvalidResources();
		void Tick(float DeltaTime);
		void TextureMovieDataTick(float DeltaTime);
		class UTextureMovie* GetTextureMovie(const class FString& TextureMoviePath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void TextureMovieUnloadRequest(class UObject* OwnerObject, const class FString& TextureMoviePath, bool isLoc);
		void TextureMovieLoadRequest(class UObject* OwnerObject, const class FString& TextureMoviePath, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		int32_t TextureMovieRequest(class UObject* OwnerObject, const class FString& TextureMoviePath, bool IsLoad, bool IsLoadCompCheckOnly, bool IsImmediate);
		void FracturedStaticMeshDataTick(float DeltaTime);
		class UFracturedStaticMesh* GetFracturedStaticMesh(const class FString& FracturedStaticMeshPath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void FracturedStaticMeshUnloadRequest(class UObject* OwnerObject, const class FString& FracturedStaticMeshPath, bool isLoc);
		void FracturedStaticMeshLoadRequest(class UObject* OwnerObject, const class FString& FracturedStaticMeshPath, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		int32_t FracturedStaticMeshRequest(class UObject* OwnerObject, const class FString& FracturedStaticMeshPath, bool IsLoad, bool IsLoadCompCheckOnly, bool IsImmediate);
		bool AllSoundCueIsLoaded();
		void SoundCueDataTick(float DeltaTime);
		class USoundCue* GetSoundCue(const class FString& SoundCuePath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void SoundCueUnloadRequest(class UObject* OwnerObject, const class FString& SoundCuePath, bool isLoc, bool Immediate);
		void SoundCueLoadRequest(class UObject* OwnerObject, const class FString& SoundCuePath, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		int32_t SoundCueRequest(class UObject* OwnerObject, const class FString& SoundCuePath, bool IsLoad, bool IsLoadCompCheckOnly, bool IsImmediate);
		void ParticleSystemDataTick(float DeltaTime);
		class UParticleSystem* GetParticleSystem(const class FString& ParticleSystemPath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void ParticleSystemUnloadRequest(class UObject* OwnerObject, const class FString& ParticleSystemPath, bool isLoc);
		void ParticleSystemLoadRequest(class UObject* OwnerObject, const class FString& ParticleSystemPath, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		int32_t ParticleSystemRequest(class UObject* OwnerObject, const class FString& ParticleSystemPath, bool IsLoad, bool IsLoadCompCheckOnly, bool IsImmediate);
		bool AllAnimSetIsLoaded();
		void AnimSetDataTick(float DeltaTime);
		class UAnimSet* GetAnimSet(const class FString& AnimSetPath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void AnimSetUnloadRequest(class UObject* OwnerObject, const class FString& AnimSetPath, bool isLoc, bool Immediate);
		void AnimSetLoadRequest(class UObject* OwnerObject, const class FString& AnimSetPath, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		int32_t AnimSetRequest(class UObject* OwnerObject, const class FString& AnimSetPath, bool IsLoad, bool IsLoadCompCheckOnly, bool IsImmediate);
		void AnimTreeDataTick(float DeltaTime);
		class UAnimTree* GetAnimTree(const class FString& AnimTreePath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void AnimTreeUnloadRequest(class UObject* OwnerObject, const class FString& AnimTreePath, bool isLoc);
		void AnimTreeLoadRequest(class UObject* OwnerObject, const class FString& AnimTreePath, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		int32_t AnimTreeRequest(class UObject* OwnerObject, const class FString& AnimTreePath, bool IsLoad, bool IsLoadCompCheckOnly, bool IsImmediate);
		void PhysicsAssetDataTick(float DeltaTime);
		class UPhysicsAsset* GetPhysicsAsset(const class FString& PhysicsAssetPath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void PhysicsAssetUnloadRequest(class UObject* OwnerObject, const class FString& PhysicsAssetPath, bool isLoc);
		void PhysicsAssetLoadRequest(class UObject* OwnerObject, const class FString& PhysicsAssetPath, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		int32_t PhysicsAssetRequest(class UObject* OwnerObject, const class FString& PhysicsAssetPath, bool IsLoad, bool IsLoadCompCheckOnly, bool IsImmediate);
		void StaticMeshDataTick(float DeltaTime);
		class UStaticMesh* GetStaticMesh(const class FString& StaticMeshPath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void StaticMeshUnloadRequest(class UObject* OwnerObject, const class FString& StaticMeshPath, bool isLoc);
		void StaticMeshLoadRequest(class UObject* OwnerObject, const class FString& StaticMeshPath, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		int32_t StaticMeshRequest(class UObject* OwnerObject, const class FString& StaticMeshPath, bool IsLoad, bool IsLoadCompCheckOnly, bool IsImmediate);
		void SkeletalMeshDataTick(float DeltaTime);
		class USkeletalMesh* GetSkeletalMesh(const class FString& SkeletalMeshPath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void SkeletalMeshUnloadRequest(class UObject* OwnerObject, const class FString& SkeletalMeshPath, bool isLoc);
		void SkeletalMeshLoadRequest(class UObject* OwnerObject, const class FString& SkeletalMeshPath, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		int32_t SkeletalMeshRequest(class UObject* OwnerObject, const class FString& SkeletalMeshPath, bool IsLoad, bool IsLoadCompCheckOnly, bool IsImmediate);
		void MaterialInstanceConstantDataTick(float DeltaTime);
		class UMaterialInstanceConstant* GetMaterialInstanceConstant(const class FString& MaterialInstanceConstantPath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void MaterialInstanceConstantUnloadRequest(class UObject* OwnerObject, const class FString& MaterialInstanceConstantPath, bool isLoc);
		void MaterialInstanceConstantLoadRequest(class UObject* OwnerObject, const class FString& MaterialInstanceConstantPath, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		int32_t MaterialInstanceConstantRequest(class UObject* OwnerObject, const class FString& MaterialInstanceConstantPath, bool IsLoad, bool IsLoadCompCheckOnly, bool IsImmediate);
		void MaterialDataTick(float DeltaTime);
		class UMaterial* GetMaterial(const class FString& MaterialPath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void MaterialUnloadRequest(class UObject* OwnerObject, const class FString& MaterialPath, bool isLoc);
		void MaterialLoadRequest(class UObject* OwnerObject, const class FString& MaterialPath, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		int32_t MaterialRequest(class UObject* OwnerObject, const class FString& MaterialPath, bool IsLoad, bool IsLoadCompCheckOnly, bool IsImmediate);
		void Texture2DDataTick(float DeltaTime);
		class UTexture2D* GetTexture2D(const class FString& Texture2DPath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void Texture2DUnloadRequest(class UObject* OwnerObject, const class FString& Texture2DPath, bool isLoc);
		void Texture2DLoadRequest(class UObject* OwnerObject, const class FString& Texture2DPath, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		int32_t Texture2DRequest(class UObject* OwnerObject, const class FString& Texture2DPath, bool IsLoad, bool IsLoadCompCheckOnly, bool IsImmediate);
		void FontDataTick(float DeltaTime);
		class UFont* GetFont(const class FString& FontPath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void FontUnloadRequest(class UObject* OwnerObject, const class FString& FontPath, bool isLoc);
		void FontLoadRequest(class UObject* OwnerObject, const class FString& FontPath, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		int32_t FontRequest(class UObject* OwnerObject, const class FString& FontPath, bool IsLoad, bool IsLoadCompCheckOnly, bool IsImmediate);
		bool AllObjectIsLoaded(struct FBrgObjectDataSet* ObjectDataSet);
		void ObjectDataTick(struct FBrgObjectDataSet* ObjectDataSet, float DeltaTime);
		class UObject* GetObject(struct FBrgObjectDataSet* ObjectDataSet, const class FName& ObjectPath, int32_t* IsFileNotFound, bool Immediate, bool isLoc);
		void ResetNotFoundObjectInfo(struct FBrgObjectDataSet* ObjectDataSet);
		void ObjectUnloadRequest_NoneReference(struct FBrgObjectDataSet* ObjectDataSet);
		void ObjectUnloadRequest_Always(struct FBrgObjectDataSet* ObjectDataSet);
		void ObjectUnloadRequest_PackateName(struct FBrgObjectDataSet* ObjectDataSet, const class FName& PackageName, bool IgnoreReferenceCount);
		void ObjectUnloadRequest(struct FBrgObjectDataSet* ObjectDataSet, const class FName& ObjectPath, class UObject* OwnerObject, bool isLoc, bool Immediate);
		void ObjectLoadRequest(struct FBrgObjectDataSet* ObjectDataSet, class UClass* ObjectClass, const class FName& ObjectPath, class UObject* OwnerObject, bool Immediate, bool isLoc, bool NoNotFoundLogOut);
		void PackageDataTick(float DeltaTime);
		void ResetNotFoundPackageInfo();
		void PackageAddToRoot();
		void PackageUnloadRequest_All();
		void PackageUnloadRequest_NoneReference();
		void PackageForceUnloadRequest(const class FName& PackageName, bool isLoc);
		void PackageUnlodeRequest(const class FName& PackageName, bool isLoc, bool Immediate);
		int32_t GetLoadingPackageCount();
		bool CheckPackageLoad(const class FName& PackageName, bool isLoc, int32_t* IsFileNotFound);
		bool PackageLoadRequest(const class FName& PackageName, bool isLoc, bool Immediate);
		void ResetFrameSkipReport();
		bool LoadPackageASyncNative_LOC(class UBrgResourceLoadManager_PackageData* inPackageData, const class FName& PackageName);
		bool LoadPackageASyncNative(class UBrgResourceLoadManager_PackageData* inPackageData, const class FName& PackageName);
		class UPackage* LoadPackageSyncNative_LOC(const class FName& PackageName);
		class UPackage* LoadPackageSyncNative(const class FName& PackageName);
		struct FBrgResourceLoadManager_LoadModeProperty GetCurrentLoadModeProperty();
		struct FBrgResourceLoadManager_LoadModeProperty GetLoadModeProperty(EBrgResourceLoadManager_LoadMode loadMode);
		EBrgResourceLoadManager_LoadMode GetLoadMode();
		void SetLoadMode(EBrgResourceLoadManager_LoadMode loadMode);
		bool IsAllLoadFinished();
		void Terminate();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgResourceLoadManager_PackageData
	 * Size -> 0x0018 (FullSize[0x0078] - InheritedSize[0x0060])
	 */
	class UBrgResourceLoadManager_PackageData : public UObject
	{
	public:
		int32_t                                                    mReferenceCount;                                         // 0x0060(0x0004)
		unsigned long                                              mASyncLoading : 1;                                       // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mASyncLoaded : 1;                                        // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mASyncLoadAfterDeleteRequest : 1;                        // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mIsLoc : 1;                                              // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mFileNotFound : 1;                                       // 0x0064(0x0001) BIT_FIELD
		class FName                                                mPackageName;                                            // 0x0068(0x0008)
		class UPackage*                                            mPackage;                                                // 0x0070(0x0008)

	public:
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgTextureRenderTarget2D_UI
	 * Size -> 0x0000 (FullSize[0x0164] - InheritedSize[0x0164])
	 */
	class UBrgTextureRenderTarget2D_UI : public UTextureRenderTarget2D
	{
	public:
		class UBrgTextureRenderTarget2D_UI* CreateForSceneCapture(int32_t InSizeX, int32_t InSizeY);
		class UTextureRenderTarget2D* Create_(int32_t InSizeX, int32_t InSizeY, EPixelFormat InFormat, const struct FColor& InClearColor, bool bOnlyRenderOnce);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgTextureRenderTarget2D_UI_3D
	 * Size -> 0x0000 (FullSize[0x0164] - InheritedSize[0x0164])
	 */
	class UBrgTextureRenderTarget2D_UI_3D : public UTextureRenderTarget2D
	{
	public:
		class UTextureRenderTarget2D* Create_(int32_t InSizeX, int32_t InSizeY, EPixelFormat InFormat, const struct FColor& InClearColor, bool bOnlyRenderOnce);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIAnim
	 * Size -> 0x0030 (FullSize[0x0090] - InheritedSize[0x0060])
	 */
	class UBrgUIAnim : public UObject
	{
	public:
		EUIAnimType                                                mAnimType;                                               // 0x0060(0x0001)
		unsigned char                                              UnknownData_PVRC[0x3];                                   // 0x0061(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class UBrgUIImage*                                         mAnimImage;                                              // 0x0064(0x0008)
		int32_t                                                    mXNum;                                                   // 0x006C(0x0004)
		int32_t                                                    mYNum;                                                   // 0x0070(0x0004)
		int32_t                                                    mTotalNum;                                               // 0x0074(0x0004)
		float                                                      mAnimWait;                                               // 0x0078(0x0004)
		unsigned long                                              mAnimRun : 1;                                            // 0x007C(0x0001) BIT_FIELD
		unsigned long                                              mAnimStopRequest : 1;                                    // 0x007C(0x0001) BIT_FIELD
		int32_t                                                    mAnimStopNo;                                             // 0x0080(0x0004)
		int32_t                                                    mAnimNo;                                                 // 0x0084(0x0004)
		int32_t                                                    mAnimNoDir;                                              // 0x0088(0x0004)
		float                                                      mAnimWaitCounter;                                        // 0x008C(0x0004)

	public:
		void Draw_RotImage(class ABrgHUDBase* inHUDBase, EDrawXBasePos xBase, EDrawYBasePos yBase, float X, float Y, EDrawXBasePos cxBase, EDrawYBasePos cyBase, float CX, float CY, float Rot, float ScaleX, float ScaleY, bool Reverse);
		void Process(float DeltaTime);
		void SetAnimNo(int32_t AnimNo);
		void StopAnim(int32_t EndAnimNo);
		void StartAnim(bool ResetAnimNo);
		void Initialize(class UBrgUIImage* inAnimImage, int32_t inXNum, int32_t inYNum, int32_t inTotalNum, float inAnimWait, EUIAnimType inAnimType);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIBaseBase
	 * Size -> 0x0008 (FullSize[0x0068] - InheritedSize[0x0060])
	 */
	class UBrgUIBaseBase : public UObject
	{
	public:
		class UBrgUIManagerBase*                                   mUIManagerBase;                                          // 0x0060(0x0008)

	public:
		void Draw_ExtImage_UseGuide(class UBrgUIImage* DrawImage, class UBrgUIImage* SrcGuideImage, class UBrgUIImage* DestGuideImage, float Scale, float X, float Y, bool Hreverse, bool Vreverse);
		void DrawEmblemIcon_UseImage(class UBrgUIImage* DrawImage, class UBrgUIImage* GuideImage, float OffsetX, float OffsetY);
		void DrawEmblemIcon_UseGuide(const class FString& EmblemID, class UBrgUIImage* GuideImage, float OffsetX, float OffsetY);
		void Draw_GaugeLRImageWithStartEnd_UseGuide(float StartRate, float EndRate, class UBrgUIImage* DrawImage, class UBrgUIImage* SrcGuideImage, class UBrgUIImage* DestGuideImage, float X, float Y, bool inReverse);
		void Draw_GaugeLRImageWithStartEnd_UsePos(float StartRate, float EndRate, class UBrgUIImage* DrawImage, float X, float Y, bool inReverse);
		void Draw_GaugeLRImage_UseGuide(float Rate, class UBrgUIImage* DrawImage, class UBrgUIImage* SrcGuideImage, class UBrgUIImage* DestGuideImage, float X, float Y, bool inReverse);
		void Draw_GaugeLRImage_UsePos(float Rate, class UBrgUIImage* DrawImage, float X, float Y, bool inReverse);
		void Draw_Image_UseGuide(class UBrgUIImage* DrawImage, class UBrgUIImage* SrcGuideImage, class UBrgUIImage* DestGuideImage, float X, float Y, bool Hreverse, bool Vreverse);
		void Draw_Image_UsePos(class UBrgUIImage* DrawImage, float X, float Y, bool Hreverse, bool Vreverse);
		class FString ItoA_Plus(int32_t Num);
		class FString GetLocalizeText(struct FBrgUILocalizeText* inLocalizeText, const class FString& SectionPlusTextID, const class FString& AddString0, const class FString& AddString1, const class FString& AddString2, const class FString& AddString3);
		void Initialize_Event();
		void Initialize();
		struct FBrgFloat64 SubtractEqual_BrgFloat64BrgFloat64(struct FBrgFloat64* A, const struct FBrgFloat64& B);
		struct FBrgFloat64 AddEqual_BrgFloat64BrgFloat64(struct FBrgFloat64* A, const struct FBrgFloat64& B);
		struct FBrgFloat64 DivideEqual_BrgFloat64BrgFloat64(struct FBrgFloat64* A, const struct FBrgFloat64& B);
		struct FBrgFloat64 MultiplyEqual_BrgFloat64BrgFloat64(struct FBrgFloat64* A, const struct FBrgFloat64& B);
		bool NotEqual_BrgFloat64BrgFloat64(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		bool EqualEqual_BrgFloat64BrgFloat64(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		bool GreaterEqual_BrgFloat64BrgFloat64(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		bool LessEqual_BrgFloat64BrgFloat64(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		bool Greater_BrgFloat64BrgFloat64(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		bool Less_BrgFloat64BrgFloat64(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		struct FBrgFloat64 Subtract_BrgFloat64BrgFloat64(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		struct FBrgFloat64 Add_BrgFloat64BrgFloat64(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		struct FBrgFloat64 Percent_BrgFloat64BrgFloat64(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		struct FBrgFloat64 Divide_BrgFloat64BrgFloat64(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		struct FBrgFloat64 Multiply_BrgFloat64BrgFloat64(const struct FBrgFloat64& A, const struct FBrgFloat64& B);
		struct FBrgFloat64 Subtract_PreBrgFloat64(const struct FBrgFloat64& A);
		struct FBrgUInt64 SubtractSubtract_BrgUInt64(struct FBrgUInt64* A);
		struct FBrgUInt64 AddAdd_BrgUInt64(struct FBrgUInt64* A);
		struct FBrgUInt64 SubtractSubtract_PreBrgUInt64(struct FBrgUInt64* A);
		struct FBrgUInt64 AddAdd_PreBrgUInt64(struct FBrgUInt64* A);
		struct FBrgUInt64 SubtractEqual_BrgUInt64BrgUInt64(struct FBrgUInt64* A, const struct FBrgUInt64& B);
		struct FBrgUInt64 AddEqual_BrgUInt64BrgUInt64(struct FBrgUInt64* A, const struct FBrgUInt64& B);
		struct FBrgUInt64 DivideEqual_BrgUInt64BrgUInt64(struct FBrgUInt64* A, const struct FBrgUInt64& B);
		struct FBrgUInt64 MultiplyEqual_BrgUInt64BrgUInt64(struct FBrgUInt64* A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Or_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Xor_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 And_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		bool NotEqual_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		bool EqualEqual_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		bool GreaterEqual_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		bool LessEqual_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		bool Greater_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		bool Less_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 GreaterGreaterGreater_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 GreaterGreater_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 LessLess_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Subtract_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Add_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Percent_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Divide_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Multiply_BrgUInt64BrgUInt64(const struct FBrgUInt64& A, const struct FBrgUInt64& B);
		struct FBrgUInt64 Complement_PreBrgUInt64(const struct FBrgUInt64& A);
		struct FBrgInt64 SubtractSubtract_BrgInt64(struct FBrgInt64* A);
		struct FBrgInt64 AddAdd_BrgInt64(struct FBrgInt64* A);
		struct FBrgInt64 SubtractSubtract_PreBrgInt64(struct FBrgInt64* A);
		struct FBrgInt64 AddAdd_PreBrgInt64(struct FBrgInt64* A);
		struct FBrgInt64 SubtractEqual_BrgInt64BrgInt64(struct FBrgInt64* A, const struct FBrgInt64& B);
		struct FBrgInt64 AddEqual_BrgInt64BrgInt64(struct FBrgInt64* A, const struct FBrgInt64& B);
		struct FBrgInt64 DivideEqual_BrgInt64BrgInt64(struct FBrgInt64* A, const struct FBrgInt64& B);
		struct FBrgInt64 MultiplyEqual_BrgInt64BrgInt64(struct FBrgInt64* A, const struct FBrgInt64& B);
		struct FBrgInt64 Or_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Xor_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 And_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		bool NotEqual_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		bool EqualEqual_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		bool GreaterEqual_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		bool LessEqual_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		bool Greater_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		bool Less_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 GreaterGreaterGreater_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 GreaterGreater_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 LessLess_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Subtract_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Add_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Percent_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Divide_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Multiply_BrgInt64BrgInt64(const struct FBrgInt64& A, const struct FBrgInt64& B);
		struct FBrgInt64 Subtract_PreBrgInt64(const struct FBrgInt64& A);
		struct FBrgInt64 Complement_PreBrgInt64(const struct FBrgInt64& A);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIParticleManager
	 * Size -> 0x0014 (FullSize[0x007C] - InheritedSize[0x0068])
	 */
	class UBrgUIParticleManager : public UBrgUIBaseBase
	{
	public:
		unsigned long                                              mConstParamEdit_Enable : 1;                              // 0x0068(0x0001) BIT_FIELD
		EUIParamEditMode                                           mConstParamEdit_Mode;                                    // 0x006C(0x0001)
		unsigned char                                              UnknownData_HDHL[0x3];                                   // 0x006D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    mConstParamEdit_TargetEffectIndex;                       // 0x0070(0x0004)
		int32_t                                                    mConstParamEdit_TargetParamIndex;                        // 0x0074(0x0004)
		int32_t                                                    mConstParamEdit_TargetMaxMin;                            // 0x0078(0x0004)

	public:
		void Initialize_NT();
		void EditRenderProcess(class ABrgHUDBase* inHUDBase);
		void RenderProcess_Type(class ABrgHUDBase* inHUDBase, EUIParticle inParticleType);
		void RenderProcess(class ABrgHUDBase* inHUDBase);
		void TickProcess(float DeltaTime);
		void SetParticleRenderDisableFlag(int32_t inParticleIndex, bool inDisableFlag);
		int32_t AddParticle(EUIParticle inType, float InX, float InY, int32_t inParamI1, int32_t inParamI2, int32_t inParamI3, float inParamF1, float inParamF2, float inParamF3);
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIBlackSelectWindow
	 * Size -> 0x281C4 (FullSize[0x28224] - InheritedSize[0x0060])
	 */
	class UBrgUIBlackSelectWindow : public UObject
	{
	public:
		class UBrgUIManagerBase*                                   mUIManagerBase;                                          // 0x0060(0x0008)
		EBrgUIBlackSelectWindowState                               mState;                                                  // 0x0068(0x0001)
		unsigned char                                              UnknownData_CL8W[0x3];                                   // 0x0069(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      mCounter;                                                // 0x006C(0x0004)
		int32_t                                                    mCounterI;                                               // 0x0070(0x0004)
		float                                                      mScale;                                                  // 0x0074(0x0004)
		float                                                      mScalingBaseX;                                           // 0x0078(0x0004)
		float                                                      mScalingBaseY;                                           // 0x007C(0x0004)
		float                                                      mWindowX;                                                // 0x0080(0x0004)
		float                                                      mWindowY;                                                // 0x0084(0x0004)
		float                                                      mWindowSizeX;                                            // 0x0088(0x0004)
		float                                                      mWindowSizeY;                                            // 0x008C(0x0004)
		struct FParamMoveData                                      mWindowSize;                                             // 0x0090(0x006C)
		int32_t                                                    mItemMaxNum;                                             // 0x00FC(0x0004)
		int32_t                                                    mItemNum;                                                // 0x0100(0x0004)
		struct FSUIBlackSelectItemInfo                             mItem[0x400];                                            // 0x0104(0x28000) NeedCtorLink
		struct FParamMoveData                                      mItemAlpha;                                              // 0x28104(0x006C)
		TArray<struct FSUIBlackSelectItemSubString>                mSubStringInfos;                                         // 0x28170(0x0010) NeedCtorLink
		class FString                                              mTitle;                                                  // 0x28180(0x0010) NeedCtorLink
		class FString                                              mOutTitle;                                               // 0x28190(0x0010) NeedCtorLink
		int32_t                                                    mStartSelectItem;                                        // 0x281A0(0x0004)
		int32_t                                                    mSelectItem;                                             // 0x281A4(0x0004)
		int32_t                                                    mOldSelectItem;                                          // 0x281A8(0x0004)
		int32_t                                                    mTargetDispFirstItemIndex;                               // 0x281AC(0x0004)
		struct FParamMoveData                                      mDispFirstItemIndex;                                     // 0x281B0(0x006C)
		unsigned long                                              mSelectEnable : 1;                                       // 0x2821C(0x0001) BIT_FIELD
		unsigned long                                              mSelectButtonDisable : 1;                                // 0x2821C(0x0001) BIT_FIELD
		unsigned long                                              mCursorDisable : 1;                                      // 0x2821C(0x0001) BIT_FIELD
		unsigned long                                              mCancelDisable : 1;                                      // 0x2821C(0x0001) BIT_FIELD
		unsigned long                                              mCenterDraw : 1;                                         // 0x2821C(0x0001) BIT_FIELD
		unsigned long                                              mDrawSubLine : 1;                                        // 0x2821C(0x0001) BIT_FIELD
		unsigned long                                              mDrawInfoName : 1;                                       // 0x2821C(0x0001) BIT_FIELD
		unsigned long                                              mCancelRequest : 1;                                      // 0x2821C(0x0001) BIT_FIELD
		unsigned long                                              mSelectChange : 1;                                       // 0x2821C(0x0001) BIT_FIELD
		unsigned long                                              mCancel : 1;                                             // 0x2821C(0x0001) BIT_FIELD
		unsigned long                                              mEnd : 1;                                                // 0x2821C(0x0001) BIT_FIELD
		float                                                      mDrawBright;                                             // 0x28220(0x0004)

	public:
		void TickProcess(float inDeltaTime);
		void RenderProcess(class ABrgHUDBase* inHUDBase);
		int32_t GetSelectIndex();
		bool CheckSelectDisable(int32_t InIndex);
		bool CheckEndStart();
		bool CheckEnd();
		bool CheckCancel();
		void Close();
		void SetCancelEnable(bool inEnable);
		void SetCursorEnable(bool inEnable);
		void SetSelectButtonEnable(bool inEnable);
		void SetSelectEnable(bool inEnable);
		void SetCenterDraw(bool inCenterDraw);
		void SetDrawInfoName(bool inDrawInfoName);
		void SetDrawSubLine(bool inDrawSubLine);
		void SetSubStringInfos(TArray<struct FSUIBlackSelectItemSubString> inSubStringInfos);
		void SetOutTitle(const class FString& inOutTitle);
		void SetTitle(const class FString& inTitle);
		void SetDrawBright(float inDrawBright);
		void SetScale(float InScale);
		void SetSize(float InSizeX, float InSizeY);
		void SetPosition(float InX, float InY);
		void SetItem(TArray<struct FSUIBlackSelectItemInitInfo> inItems, int32_t inSelectIndex, TArray<struct FSUIBlackSelectItemSubString> inSubStringInfos);
		void GetItemMaxWidth(float* InSizeX, float* InSizeY);
		void Start(float inWindowX, float inWindowY, float inWindowSizeX, float inWindowSizeY, float inScalingBaseX, float inScalingBaseY, float InScale);
		void RefreshDispFirstIndex(bool inLinear);
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIBlackWindow
	 * Size -> 0x0080 (FullSize[0x00E0] - InheritedSize[0x0060])
	 */
	class UBrgUIBlackWindow : public UObject
	{
	public:
		EBrgUIBlackWindowState                                     mState;                                                  // 0x0060(0x0001)
		unsigned char                                              UnknownData_LYJW[0x3];                                   // 0x0061(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct FParamMoveData                                      mAlphaMoveData;                                          // 0x0064(0x006C)
		int32_t                                                    mCenterX;                                                // 0x00D0(0x0004)
		int32_t                                                    mCenterY;                                                // 0x00D4(0x0004)
		int32_t                                                    mSizeX;                                                  // 0x00D8(0x0004)
		int32_t                                                    mSizeY;                                                  // 0x00DC(0x0004)

	public:
		void TickProcess(float DeltaTime);
		void RenderProcess(class ABrgHUDBase* inHUDBase);
		void DrawLineBox(class ABrgHUDBase* inHUDBase, float X1, float Y1, float X2, float Y2, bool fill);
		bool CheckEnd();
		void SetVisible(bool Invisible);
		void SetSize(int32_t InSizeX, int32_t InSizeY);
		void SetPosition(int32_t inLeftUpX, int32_t inLeftUpY);
		void Initialize(int32_t inLeftUpX, int32_t inLeftUpY, int32_t InSizeX, int32_t InSizeY);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIBlackYesNoWindow
	 * Size -> 0x00C4 (FullSize[0x0124] - InheritedSize[0x0060])
	 */
	class UBrgUIBlackYesNoWindow : public UObject
	{
	public:
		EBrgUIBlackYesNoWindowState                                mState;                                                  // 0x0060(0x0001)
		unsigned char                                              UnknownData_WMRH[0x3];                                   // 0x0061(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      mCounter;                                                // 0x0064(0x0004)
		int32_t                                                    mCounterI;                                               // 0x0068(0x0004)
		class FString                                              mMessage;                                                // 0x006C(0x0010) NeedCtorLink
		float                                                      mWindowX;                                                // 0x007C(0x0004)
		float                                                      mWindowY;                                                // 0x0080(0x0004)
		float                                                      mWindowSizeX;                                            // 0x0084(0x0004)
		float                                                      mWindowSizeY;                                            // 0x0088(0x0004)
		class UBrgUIBlackWindow*                                   mBlackWindow;                                            // 0x008C(0x0008)
		class UBrgUIDebugString*                                   mStr_Message;                                            // 0x0094(0x0008)
		class UBrgUIDebugString*                                   mStr_Yes;                                                // 0x009C(0x0008)
		class UBrgUIDebugString*                                   mStr_No;                                                 // 0x00A4(0x0008)
		struct FParamMoveData                                      mButtonAlphaData;                                        // 0x00AC(0x006C)
		class UBrgUIParamEditMenuParam*                            mConstParam;                                             // 0x0118(0x0008)
		unsigned long                                              mIsYes : 1;                                              // 0x0120(0x0001) BIT_FIELD
		unsigned long                                              mEnd : 1;                                                // 0x0120(0x0001) BIT_FIELD

	public:
		void TickProcess(float inDeltaTime);
		void RenderProcess(class ABrgHUDBase* inHUDBase);
		void SetStrVisible(bool Invisible);
		void SetPosition(float InX, float InY);
		bool CheckEnd();
		void Start(const class FString& InMessage, const class FString& inYesStr, const class FString& inNoStr, float inWindowX, float inWindowY);
		void Initialize();
		void InitializeNative();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIDebugMessage
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIDebugMessage : public UObject
	{
	public:
		EBrgUIDebugMessageState                                    mState;                                                  // 0x0060(0x0001)
		unsigned char                                              UnknownData_66ZB[0x3];                                   // 0x0061(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		float                                                      mCounter;                                                // 0x0064(0x0004)
		int32_t                                                    mCounterI;                                               // 0x0068(0x0004)
		float                                                      mWindowX;                                                // 0x006C(0x0004)
		float                                                      mWindowY;                                                // 0x0070(0x0004)
		float                                                      mWindowSizeX;                                            // 0x0074(0x0004)
		float                                                      mWindowSizeY;                                            // 0x0078(0x0004)
		class UBrgUIBlackWindow*                                   mBlackWindow;                                            // 0x007C(0x0008)
		TArray<class UBrgUIDebugString*>                           mStr_Message;                                            // 0x0084(0x0010) NeedCtorLink
		TArray<class FString>                                      mMessage;                                                // 0x0094(0x0010) NeedCtorLink
		class UBrgUIParamEditMenuParam*                            mConstParam;                                             // 0x00A4(0x0008)
		unsigned long                                              mCloseRequest : 1;                                       // 0x00AC(0x0001) BIT_FIELD
		unsigned long                                              mEnd : 1;                                                // 0x00AC(0x0001) BIT_FIELD

	public:
		void TickProcess(float inDeltaTime);
		void RenderProcess(class ABrgHUDBase* inHUDBase);
		void SetStrVisible(bool Invisible);
		int32_t GetLineNum();
		void SetPosition(float InX, float InY);
		bool CheckIdle();
		bool CheckEnd();
		void Close();
		void Start(const class FString& InMessage, float inWindowX, float inWindowY);
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIDebugSelectWindow
	 * Size -> 0x0078 (FullSize[0x00D8] - InheritedSize[0x0060])
	 */
	class UBrgUIDebugSelectWindow : public UObject
	{
	public:
		EBrgUIDebugSelectWindowState                               mState;                                                  // 0x0060(0x0001)
		unsigned char                                              UnknownData_SKBR[0x3];                                   // 0x0061(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		unsigned long                                              mStateFirst : 1;                                         // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mCancel : 1;                                             // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mCancelEnable : 1;                                       // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mDisableChoiceSound : 1;                                 // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mCloseRequest : 1;                                       // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mEnd : 1;                                                // 0x0064(0x0001) BIT_FIELD
		class UBrgUIBlackWindow*                                   mBlackWindow;                                            // 0x0068(0x0008)
		class UBrgUIDebugMessage*                                  mDebugMessage;                                           // 0x0070(0x0008)
		class FString                                              mMessage;                                                // 0x0078(0x0010) NeedCtorLink
		float                                                      mWindowX;                                                // 0x0088(0x0004)
		float                                                      mWindowY;                                                // 0x008C(0x0004)
		float                                                      mWindowSizeX;                                            // 0x0090(0x0004)
		float                                                      mWindowSizeY;                                            // 0x0094(0x0004)
		float                                                      mMaxStringWidth;                                         // 0x0098(0x0004)
		int32_t                                                    mSelectIndex;                                            // 0x009C(0x0004)
		class UBrgUIParamEditMenuParam*                            mConstParam;                                             // 0x00A0(0x0008)
		class UBrgUIParamEditMenuParam*                            mDebugMessageConstParam;                                 // 0x00A8(0x0008)
		TArray<struct FBrgUIDebugSelectString>                     mSelectUnit;                                             // 0x00B0(0x0010) NeedCtorLink
		class USoundCue*                                           mChoiceSoundCue;                                         // 0x00C0(0x0008)
		class UBrgUIManagerBase*                                   mUIManagerBase;                                          // 0x00C8(0x0008)
		class UGHM_SoundManager*                                   mSoundManager;                                           // 0x00D0(0x0008)

	public:
		void TickProcess(float inDeltaTime);
		void RenderProcess(class ABrgHUDBase* inHUDBase);
		void SetStrVisible(bool Invisible);
		void SetSelectIndex(int32_t InIndex);
		void SetPosition(float InX, float InY);
		int32_t GetSelectIndex();
		int32_t CheckSelectIndexParam();
		bool CheckCancel();
		bool CheckEnd();
		bool CheckIdle();
		void Close();
		void Start(const class FString& InMessage, bool inCancelEnable, float inWindowX, float inWindowY, bool inDisableChoiceSound, class USoundCue* inChoiceSoundCue);
		void AddUnit(const class FString& InString, bool inDisableSelect, int32_t inParam, bool inCancelSE);
		void RefreshWindowSize();
		void AllDeleteUnit();
		void Initialize();
		void InitializeNative();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIDebugString
	 * Size -> 0x00F8 (FullSize[0x0158] - InheritedSize[0x0060])
	 */
	class UBrgUIDebugString : public UObject
	{
	public:
		EBrgUIDebugStringState                                     mState;                                                  // 0x0060(0x0001)
		EDrawXBasePos                                              mDrawBasePosX;                                           // 0x0061(0x0001)
		EDrawYBasePos                                              mDrawBasePosY;                                           // 0x0062(0x0001)
		unsigned char                                              UnknownData_81VV[0x1];                                   // 0x0063(0x0001) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		unsigned long                                              mVisible : 1;                                            // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mSubVisible : 1;                                         // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mIsSelect : 1;                                           // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mColorDown : 1;                                          // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mValidNextString : 1;                                    // 0x0064(0x0001) BIT_FIELD
		unsigned long                                              mNextStringAnimation : 1;                                // 0x0064(0x0001) BIT_FIELD
		struct FParamMoveData                                      mSelectAlpha;                                            // 0x0068(0x006C)
		int32_t                                                    mDrawR;                                                  // 0x00D4(0x0004)
		int32_t                                                    mDrawG;                                                  // 0x00D8(0x0004)
		int32_t                                                    mDrawB;                                                  // 0x00DC(0x0004)
		int32_t                                                    mDrawX;                                                  // 0x00E0(0x0004)
		int32_t                                                    mDrawY;                                                  // 0x00E4(0x0004)
		struct FBrgUIDebugStr                                      mString;                                                 // 0x00E8(0x0030) NeedCtorLink
		struct FBrgUIDebugStr                                      mBackString;                                             // 0x0118(0x0030) NeedCtorLink
		class FString                                              mNextString;                                             // 0x0148(0x0010) NeedCtorLink

	public:
		void Str_TickProcess(struct FBrgUIDebugStr* InStr, float inDeltaTime);
		float Str_RenderProcess(struct FBrgUIDebugStr* InStr, class ABrgHUDBase* inHUDBase, bool IsDraw);
		float GetDrawStringWidth(const class FString& InString, class ABrgHUDBase* inHUDBase);
		void Str_SetVisible(struct FBrgUIDebugStr* InStr, bool Invisible, bool inIsAnimation);
		bool Str_CheckIdle(struct FBrgUIDebugStr* InStr);
		void Str_Initialize(struct FBrgUIDebugStr* InStr, const class FString& InString);
		void TickProcess(float inDeltaTime);
		void RenderProcess(class ABrgHUDBase* inHUDBase);
		void RenderProcessWithSetPosition(class ABrgHUDBase* inHUDBase, int32_t inDrawX, int32_t InDrawY);
		void ChangeString_Number(int32_t inNumber, bool inIsAnimation);
		void ChangeString(const class FString& inNewString, bool inIsAnimation);
		void SetSelectState(bool inIsSelect, bool inAnimation);
		void RefreshVisible(bool inIsAnimation);
		void SetSubVisible(bool inIsVisible, bool inIsAnimation);
		void SetVisible(bool inIsVisible, bool inIsAnimation);
		void SetPosition(int32_t inDrawX, int32_t InDrawY, EDrawXBasePos inBasePosX, EDrawYBasePos inBasePosY);
		void SetColorDown(bool inColorDown);
		bool CheckIdle();
		void Initialize(const class FString& InString, EDrawXBasePos inBasePosX, EDrawYBasePos inBasePosY, int32_t inDrawX, int32_t InDrawY);
		class UBrgUIDebugString* Create(const class FString& InString, EDrawXBasePos inBasePosX, EDrawYBasePos inBasePosY, int32_t inDrawX, int32_t InDrawY);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIDefine
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgUIDefine : public UObject
	{
	public:
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIFont
	 * Size -> 0x00C8 (FullSize[0x0128] - InheritedSize[0x0060])
	 */
	class UBrgUIFont : public UObject
	{
	public:
		class UFont*                                               mFont;                                                   // 0x0060(0x0008)
		unsigned long                                              mDisableDataOffsetX : 1;                                 // 0x0068(0x0001) BIT_FIELD
		int32_t                                                    mNewLineAddY;                                            // 0x006C(0x0004)
		int32_t                                                    mAdjustMaxCharHeight;                                    // 0x0070(0x0004)
		TArray<class UBrgUIImage*>                                 mFontImageArray;                                         // 0x0074(0x0010) NeedCtorLink
		int32_t                                                    mPixelScale;                                             // 0x0084(0x0004)
		TArray<struct FBrgUIFontImageCharInfo>                     mImageCharInfos;                                         // 0x0088(0x0010) NeedCtorLink
		struct FBrgUIFontBaseParam                                 mBaseParam;                                              // 0x0098(0x0014)
		struct FBrgUIFontBaseParam                                 mSubBaseParam;                                           // 0x00AC(0x0014)
		struct FBrgUIFontBaseParam                                 mEngUpBaseParam;                                         // 0x00C0(0x0014)
		struct FBrgUIFontBaseParam                                 mEngLowBaseParam;                                        // 0x00D4(0x0014)
		struct FBrgUIFontBaseParam                                 mNumberBaseParam;                                        // 0x00E8(0x0014)
		EMaterialEffect                                            mUseMaterialEffect;                                      // 0x00FC(0x0001)
		unsigned char                                              UnknownData_5KF1[0x3];                                   // 0x00FD(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    mUseMaterialIndex;                                       // 0x0100(0x0004)
		class UTexture*                                            mMaskScreenTexture;                                      // 0x0104(0x0008)
		float                                                      mMaskScreenTextureScreenPositionX;                       // 0x010C(0x0004)
		float                                                      mMaskScreenTextureScreenPositionY;                       // 0x0110(0x0004)
		int32_t                                                    mIconAddOffsetX;                                         // 0x0114(0x0004)
		int32_t                                                    mIconAddOffsetY;                                         // 0x0118(0x0004)
		int32_t                                                    mIconAddNextX;                                           // 0x011C(0x0004)
		int32_t                                                    mSubUIFontAddOffsetX;                                    // 0x0120(0x0004)
		int32_t                                                    mSubUIFontAddOffsetY;                                    // 0x0124(0x0004)

	public:
		bool AddImageChara(const struct FBrgUIFontImageCharInfo& inImageCharInfo);
		bool GetCharInfo(const class FString& inChara, struct FBrgUIFontCharInfo* inCharInfo);
		class UBrgUIFont* Create(class UFont* inUseFont, int32_t inPixelScale, struct FBrgUIMaterialAttr* inMaterialAttr, class UTexture* inUseMaskScreenTexture, float inMaskScreenTexture_ScreenPositionX, float inMaskScreenTexture_ScreenPositionY);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIFontLoader
	 * Size -> 0x0038 (FullSize[0x0098] - InheritedSize[0x0060])
	 */
	class UBrgUIFontLoader : public UObject
	{
	public:
		EBrgUIFontLoaderState                                      mState;                                                  // 0x0060(0x0001)
		unsigned char                                              UnknownData_5RSK[0x3];                                   // 0x0061(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class UFont*                                               mFont;                                                   // 0x0064(0x0008)
		class UBrgUIFont*                                          mUIFont;                                                 // 0x006C(0x0008)
		class FString                                              mFontPath;                                               // 0x0074(0x0010) NeedCtorLink
		int32_t                                                    mPixelScale;                                             // 0x0084(0x0004)
		class UBrgResourceLoadManager*                             mResourceLoadManager;                                    // 0x0088(0x0008)
		unsigned long                                              mLoadRequestState : 1;                                   // 0x0090(0x0001) BIT_FIELD
		struct FBrgUIMaterialAttr                                  mMaterialAttr;                                           // 0x0094(0x0004)

	public:
		int32_t Request(bool inLoadState, bool IsLoadCompCheckOnly);
		void TickProcess();
		void Initialize(class UBrgResourceLoadManager* inResourceLoadManager, const class FString& inFontPath, int32_t inPixelScale, struct FBrgUIMaterialAttr* inMaterialAttr);
		class UBrgUIFontLoader* Create(class UBrgResourceLoadManager* inResourceLoadManager, const class FString& inFontPath, int32_t inPixelScale, struct FBrgUIMaterialAttr* inMaterialAttr);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIFontRender
	 * Size -> 0x005C (FullSize[0x00BC] - InheritedSize[0x0060])
	 */
	class UBrgUIFontRender : public UObject
	{
	public:
		struct FBrgUIFontRenderState                               mState;                                                  // 0x0060(0x003C)
		class ABrgHUDBase*                                         mHUDBase;                                                // 0x009C(0x0008)
		int32_t                                                    mPixelScale;                                             // 0x00A4(0x0004)
		unsigned char                                              mColorR;                                                 // 0x00A8(0x0001)
		unsigned char                                              mColorG;                                                 // 0x00A9(0x0001)
		unsigned char                                              mColorB;                                                 // 0x00AA(0x0001)
		unsigned char                                              mColorA;                                                 // 0x00AB(0x0001)
		unsigned char                                              mShadowColorR;                                           // 0x00AC(0x0001)
		unsigned char                                              mShadowColorG;                                           // 0x00AD(0x0001)
		unsigned char                                              mShadowColorB;                                           // 0x00AE(0x0001)
		unsigned char                                              mShadowColorA;                                           // 0x00AF(0x0001)
		unsigned long                                              mPosConvInt : 1;                                         // 0x00B0(0x0001) BIT_FIELD
		unsigned long                                              mIs3D : 1;                                               // 0x00B0(0x0001) BIT_FIELD
		class UBrgUIFont*                                          mTimeTxtFontDay;                                         // 0x00B4(0x0008)

	public:
		void SetColorByColor(const struct FColor& fontColor);
		void SetColor(unsigned char R, unsigned char G, unsigned char B, unsigned char A);
		float DrawShadowText_UseImgPos_KeepColor(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, const class FString& inDrawString, bool inCenter, float inAddX, float inAddY, bool inAutoXScaling, bool inUseFullSpace);
		float DrawShadowText_UseImgPos(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, const class FString& inDrawString, bool inCenter, float inAddX, float inAddY, bool inAutoXScaling, bool inUseFullSpace);
		void SetTimeTextDay(class UBrgUIFont* InFont);
		float GetDrawNumberWidthWithFontState(struct FBrgUIFontRenderState* inFontStateint, int32_t inDrawNumber, bool inIsZero, int32_t inFigure, bool inSigned, const class FString& inUnitString, float* DrawWidth, float* DrawHeight);
		float GetDrawTextWidthWithFontState(struct FBrgUIFontRenderState* inFontState, const class FString& Str, float* DrawWidth, float* DrawHeight);
		float GetDrawTextWidth(const class FString& Str, float* DrawWidth, float* DrawHeight);
		float DrawNumberCenter_UseGuide(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, class UBrgUIImage* inSrcGuideImage, class UBrgUIImage* inDestGuideImage, int32_t inDrawNumber, float inAddX, float inAddY, bool inIsZero, int32_t inFigure, bool inSigned, const class FString& inUnitString, bool inAutoXScaling, bool inUseFullSpace);
		float DrawNumberCenter_UseImgPos(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, int32_t inDrawNumber, float inAddX, float inAddY, bool inIsZero, int32_t inFigure, bool inSigned, const class FString& inUnitString, bool inAutoXScaling, bool inUseFullSpace);
		float DrawNumberLeft_UseGuide(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, class UBrgUIImage* inSrcGuideImage, class UBrgUIImage* inDestGuideImage, int32_t inDrawNumber, float inAddX, float inAddY, bool inIsZero, int32_t inFigure, bool inSigned, const class FString& inUnitString, bool inAutoXScaling, bool inUseFullSpace);
		float DrawNumberLeft_UseImgPos(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, int32_t inDrawNumber, float inAddX, float inAddY, bool inIsZero, int32_t inFigure, bool inSigned, const class FString& inUnitString, bool inAutoXScaling, bool inUseFullSpace);
		float DrawNumber_UseGuide(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, class UBrgUIImage* inSrcGuideImage, class UBrgUIImage* inDestGuideImage, int32_t inDrawNumber, float inAddX, float inAddY, bool inIsZero, int32_t inFigure, bool inSigned, const class FString& inUnitString, bool inAutoXScaling, bool inUseFullSpace);
		float DrawNumber_UseImgPos(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, int32_t inDrawNumber, float inAddX, float inAddY, bool inIsZero, int32_t inFigure, bool inSigned, const class FString& inUnitString, bool inAutoXScaling, bool inUseFullSpace);
		float DrawTimeTextRight_UseGuide(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, class UBrgUIImage* inSrcGuideImage, class UBrgUIImage* inDestGuideImage, const class FString& inDrawDay, const class FString& inDrawHour, const class FString& inDrawMinute, float inColonOpacity, int32_t inDayStrOffsetY, float inAddX, float inAddY, bool inAutoXScaling, bool inUseFullSpace);
		float DrawTimeTextRight_UseImgPos(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, const class FString& inDrawDay, const class FString& inDrawHour, const class FString& inDrawMinute, float inColonOpacity, int32_t inDayStrOffsetY, float inAddX, float inAddY, bool inAutoXScaling, bool inUseFullSpace);
		float DrawTimeText_UseGuide(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, class UBrgUIImage* inSrcGuideImage, class UBrgUIImage* inDestGuideImage, const class FString& inDrawDay, const class FString& inDrawHour, const class FString& inDrawMinute, float inColonOpacity, int32_t inDayStrOffsetY, bool inCenter, float inAddX, float inAddY, bool inAutoXScaling, bool inUseFullSpace);
		float DrawTimeText_UseImgPos(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, const class FString& inDrawDay, const class FString& inDrawHour, const class FString& inDrawMinute, float inColonOpacity, int32_t inDayStrOffsetY, bool inCenter, float inAddX, float inAddY, bool inAutoXScaling, bool inUseFullSpace);
		float DrawTimeText(float X, float Y, const class FString& inDrawDay, const class FString& inDrawHour, const class FString& inDrawMinute, float inColonOpacity, int32_t inDayStrOffsetY, bool IsRight, bool IsCenter, bool UseShadowColor, float ScalingWidth, bool UseFullScalingWidth);
		float DrawTextRight_UseGuide(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, class UBrgUIImage* inSrcGuideImage, class UBrgUIImage* inDestGuideImage, const class FString& inDrawString, float inAddX, float inAddY, bool inAutoXScaling, bool inUseFullSpace);
		float DrawTextRight_UseImgPos(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, const class FString& inDrawString, float inAddX, float inAddY, bool inAutoXScaling, bool inUseFullSpace);
		float DrawText_UseGuide(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, class UBrgUIImage* inSrcGuideImage, class UBrgUIImage* inDestGuideImage, const class FString& inDrawString, bool inCenter, float inAddX, float inAddY, bool inAutoXScaling, bool inUseFullSpace);
		float DrawText_UseImgPos(struct FBrgUIFontRenderState* inFontState, class UBrgUIImage* inImage, const class FString& inDrawString, bool inCenter, float inAddX, float inAddY, bool inAutoXScaling, bool inUseFullSpace);
		void DrawShadowString(float X, float Y, const class FString& Str, bool IsRight, bool IsCenter, float ScalingWidth, bool UseFullScalingWidth);
		float DrawNumber(float X, float Y, int32_t inDrawNumber, bool inIsZero, int32_t inFigure, bool inSigned, const class FString& inUnitString, bool IsRight, bool IsCenter, float ScalingWidth, bool UseFullScalingWidth);
		float DrawText(float X, float Y, const class FString& Str, bool IsRight, bool IsCenter, bool UseShadowColor, float ScalingWidth, bool UseFullScalingWidth);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImage
	 * Size -> 0x006C (FullSize[0x00CC] - InheritedSize[0x0060])
	 */
	class UBrgUIImage : public UObject
	{
	public:
		EMaterialEffect                                            mUseMaterialEffect;                                      // 0x0060(0x0001)
		unsigned char                                              UnknownData_3O5H[0x3];                                   // 0x0061(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    mUseMaterialIndex;                                       // 0x0064(0x0004)
		class UMaterialInstanceConstant*                           mUseFreeMIC;                                             // 0x0068(0x0008)
		class UTexture*                                            mMaskScreenTexture;                                      // 0x0070(0x0008)
		float                                                      mMaskScreenTextureScreenPositionX;                       // 0x0078(0x0004)
		float                                                      mMaskScreenTextureScreenPositionY;                       // 0x007C(0x0004)
		TArray<class UBrgUIImageBase*>                             mBaseData;                                               // 0x0080(0x0010) NeedCtorLink
		int32_t                                                    mUseX;                                                   // 0x0090(0x0004)
		int32_t                                                    mUseY;                                                   // 0x0094(0x0004)
		int32_t                                                    mUseSizeX;                                               // 0x0098(0x0004)
		int32_t                                                    mUseSizeY;                                               // 0x009C(0x0004)
		float                                                      mUseU;                                                   // 0x00A0(0x0004)
		float                                                      mUseV;                                                   // 0x00A4(0x0004)
		float                                                      mUseSizeU;                                               // 0x00A8(0x0004)
		float                                                      mUseSizeV;                                               // 0x00AC(0x0004)
		int32_t                                                    mImageMapInfoNo;                                         // 0x00B0(0x0004)
		int32_t                                                    mImageMapImageInfoNo;                                    // 0x00B4(0x0004)
		int32_t                                                    mImageMapScreenPosX;                                     // 0x00B8(0x0004)
		int32_t                                                    mImageMapScreenPosY;                                     // 0x00BC(0x0004)
		int32_t                                                    mImageMapOpacity;                                        // 0x00C0(0x0004)
		int32_t                                                    mPosX;                                                   // 0x00C4(0x0004)
		int32_t                                                    mPosY;                                                   // 0x00C8(0x0004)

	public:
		void Initialize(class UTexture* UseTexture, class UBrgUIImageBase* UseImageBase, int32_t UseX, int32_t UseY, int32_t UseSizeX, int32_t UseSizeY, int32_t PixelScale);
		class UBrgUIImage* Create(class UTexture* UseTexture, class UBrgUIImageBase* UseImageBase, int32_t UseX, int32_t UseY, int32_t UseSizeX, int32_t UseSizeY, int32_t PixelScale);
		class UBrgUIImage* CreateUseMapInfo(TArray<class UBrgUIImageBase*> inUseImageBase, int32_t inImageMapInfoNo, int32_t inImageMapImageInfoNo, int32_t inUseSizeX, int32_t inUseSizeY, int32_t inScreenPosX, int32_t inScreenPosY, int32_t inOpacity);
		bool SetupFreeMIC(class UMaterialInstanceConstant* inFreeMIC);
		bool SetupEffectMIC(EMaterialEffect inMaterialEffect, class UTexture* inUseMaskScreenTexture, float inMaskScreenTexture_ScreenPositionX, float inMaskScreenTexture_ScreenPositionY);
		bool SetupMIC(struct FBrgUIMaterialAttr* inMaterialAttr, class UTexture* inUseMaskScreenTexture, float inMaskScreenTexture_ScreenPositionX, float inMaskScreenTexture_ScreenPositionY);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImage_Stream
	 * Size -> 0x0058 (FullSize[0x0124] - InheritedSize[0x00CC])
	 */
	class UBrgUIImage_Stream : public UBrgUIImage
	{
	public:
		class FString                                              mImageKeyString;                                         // 0x00CC(0x0010) NeedCtorLink
		class FString                                              mTexturePath;                                            // 0x00DC(0x0010) NeedCtorLink
		int32_t                                                    mLastUseTime[0x2];                                       // 0x00EC(0x0008)
		float                                                      mLastUseTimeF;                                           // 0x00F4(0x0004)
		unsigned long                                              mLoaded : 1;                                             // 0x00F8(0x0001) BIT_FIELD
		unsigned long                                              mLoadRequest : 1;                                        // 0x00F8(0x0001) BIT_FIELD
		unsigned long                                              mValidSetupMICParam : 1;                                 // 0x00F8(0x0001) BIT_FIELD
		unsigned long                                              mValidSetupEffectMICParam : 1;                           // 0x00F8(0x0001) BIT_FIELD
		unsigned long                                              mValidSetupFreeMIC : 1;                                  // 0x00F8(0x0001) BIT_FIELD
		class UBrgUIResource_StreamImageManager*                   mOwner;                                                  // 0x00FC(0x0008)
		ESetupMICParamType                                         mMICParamType;                                           // 0x0104(0x0001)
		EMaterialEffect                                            mSetupEffectMICParam_MaterialEffect;                     // 0x0105(0x0001)
		unsigned char                                              UnknownData_6FD9[0x2];                                   // 0x0106(0x0002) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct FBrgUIMaterialAttr                                  mSetupMICParam_MaterialAttr;                             // 0x0108(0x0004)
		class UTexture*                                            mSetupMICParam_MaskScreenTexture;                        // 0x010C(0x0008)
		float                                                      mSetupMICParam_MaskScreenTexture_ScreenPositionX;        // 0x0114(0x0004)
		float                                                      mSetupMICParam_MaskScreenTexture_ScreenPositionY;        // 0x0118(0x0004)
		class UMaterialInstanceConstant*                           mSetupFreeMICParam_FreeMIC;                              // 0x011C(0x0008)

	public:
		bool IsLoaded();
		void Unload();
		void Reload();
		bool SetupFreeMIC(class UMaterialInstanceConstant* inFreeMIC);
		bool SetupEffectMIC(EMaterialEffect inMaterialEffect, class UTexture* inUseMaskScreenTexture, float inMaskScreenTexture_ScreenPositionX, float inMaskScreenTexture_ScreenPositionY);
		bool SetupMIC(struct FBrgUIMaterialAttr* inMaterialAttr, class UTexture* inUseMaskScreenTexture, float inMaskScreenTexture_ScreenPositionX, float inMaskScreenTexture_ScreenPositionY);
		class UBrgUIImage_Stream* CreateStream(const class FString& inTexturePath);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo
	 * Size -> 0x0021 (FullSize[0x0081] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo : public UObject
	{
	public:
		TArray<struct FImageMapInfo>                               mImageMapArray;                                          // 0x0060(0x0010) NeedCtorLink
		TArray<struct FImageMapInfo>                               mImageMapArray_720p;                                     // 0x0070(0x0010) NeedCtorLink
		EScreenMode                                                mScreenMode;                                             // 0x0080(0x0001)

	public:
		int32_t GetImageNo(int32_t inImageMapNo, const class FString& inImageName);
		int32_t GetImageMapNo(const class FString& inTextureUpackName, const class FString& inTexturePath);
		class UBrgUIImage* CreateImage_Index(TArray<class UBrgUIImageBase*> inBaseImage, int32_t inMapIndex, int32_t inImageIndex);
		class UBrgUIImage* CreateImage(TArray<class UBrgUIImageBase*> inBaseImage, const class FString& inTextureUpackName, const class FString& inTexturePath, const class FString& inImageName);
		bool Initialize(EScreenMode inScreenMode);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfoBase
	 * Size -> 0x0024 (FullSize[0x0084] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfoBase : public UObject
	{
	public:
		EBrgUIIMageMapInfoType                                     mType;                                                   // 0x0060(0x0001)
		unsigned char                                              UnknownData_D5AU[0x3];                                   // 0x0061(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class FString                                              mName;                                                   // 0x0064(0x0010) NeedCtorLink
		class UBrgUIImageMapInfoBase*                              mParent;                                                 // 0x0074(0x0008)
		int32_t                                                    mMapIndex;                                               // 0x007C(0x0004)
		int32_t                                                    mImageInfoIndex;                                         // 0x0080(0x0004)

	public:
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfoGroup
	 * Size -> 0x0010 (FullSize[0x0094] - InheritedSize[0x0084])
	 */
	class UBrgUIImageMapInfoGroup : public UBrgUIImageMapInfoBase
	{
	public:
		TArray<class UBrgUIImageMapInfoBase*>                      mChild;                                                  // 0x0084(0x0010) NeedCtorLink

	public:
		class UBrgUIImageMapInfoBase* GetObject(const class FString& inPath);
		class UBrgUIImageMapInfoImage* GetImage(const class FString& inPath);
		class UBrgUIImageMapInfoGroup* GetGroup(const class FString& inPath);
		class UBrgUIImage* GetUIImage(const class FString& inPath);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfoImage
	 * Size -> 0x0008 (FullSize[0x008C] - InheritedSize[0x0084])
	 */
	class UBrgUIImageMapInfoImage : public UBrgUIImageMapInfoBase
	{
	public:
		class UBrgUIImage*                                         mImage;                                                  // 0x0084(0x0008)

	public:
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfoSet
	 * Size -> 0x0034 (FullSize[0x0094] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfoSet : public UObject
	{
	public:
		class UBrgUIImageMapInfo*                                  mImageMapInfo;                                           // 0x0060(0x0008)
		TArray<class UBrgUIImageBase*>                             mBaseImage;                                              // 0x0068(0x0010) NeedCtorLink
		class UBrgUIImageMapInfoGroup*                             mTopGroup;                                               // 0x0078(0x0008)
		int32_t                                                    mMapIndex;                                               // 0x0080(0x0004)
		TArray<class UBrgUIImageMapInfoBase*>                      mInfoBaseArray;                                          // 0x0084(0x0010) NeedCtorLink

	public:
		class UBrgUIImageMapInfoBase* GetObject(const class FString& inPath);
		class UBrgUIImageMapInfoImage* GetImage(const class FString& inPath);
		class UBrgUIImageMapInfoGroup* GetGroup(const class FString& inPath);
		class UBrgUIImage* GetUIImage(const class FString& inPath);
		void SetupImageEffectMIC(TArray<class UBrgUIImageBase*> inBaseImage, EMaterialEffect inMaterialEffect, class UTexture* inUseMaskScreenTexture, float inMaskScreenTexture_ScreenPositionX, float inMaskScreenTexture_ScreenPositionY);
		void SetupImage(TArray<class UBrgUIImageBase*> inBaseImage, struct FBrgUIMaterialAttr* inMaterialAttr, class UTexture* inUseMaskScreenTexture, float inMaskScreenTexture_ScreenPositionX, float inMaskScreenTexture_ScreenPositionY);
		void Initialize(class UBrgUIImageMapInfo* inImageMapInfo, int32_t inMapIndex);
		class UBrgUIImageMapInfoSet* CreateImageMapInfoSet(class UBrgUIImageMapInfo* inImageMapInfo, const class FString& inTextureUpackName, const class FString& inTexturePath);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIManagerBase
	 * Size -> 0x2784 (FullSize[0x27E4] - InheritedSize[0x0060])
	 */
	class UBrgUIManagerBase : public UObject
	{
	public:
		EScreenMode                                                mScreenMode;                                             // 0x0060(0x0001)
		EBrgUIManager_RenderProcessType                            mRenderProcessType;                                      // 0x0061(0x0001)
		EBrgUIManager_SortType                                     mBuySortType;                                            // 0x0062(0x0001)
		EBrgUIManager_SortType                                     mCoinLockerSortType;                                     // 0x0063(0x0001)
		EBrgUIManager_SortType                                     mPossessionItemSortType;                                 // 0x0064(0x0001)
		EBrgUIManager_SortType                                     mDeathBagSortType;                                       // 0x0065(0x0001)
		EBrgUIManager_AccessType                                   mTopActiveAccessType;                                    // 0x0066(0x0001)
		unsigned char                                              mEnableAccessFlag[0x31];                                 // 0x0067(0x0031)
		EGHM_MouseDef                                              mInputMouseTemp;                                         // 0x0098(0x0001)
		unsigned char                                              UnknownData_ZMQ9[0x3];                                   // 0x0099(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class ABrgGameInfoNativeBase*                              mGameInfoNativeBase;                                     // 0x009C(0x0008)
		class ABrgHUDBase*                                         mHUDBase;                                                // 0x00A4(0x0008)
		class UTextureRenderTarget2D*                              mMaskScreenRenderTarget[0x3];                            // 0x00AC(0x0018)
		class FString                                              mStringLanguage;                                         // 0x00C4(0x0010) NeedCtorLink
		class FString                                              mFontConstParamTestString;                               // 0x00D4(0x0010) NeedCtorLink
		class FString                                              mFontConstParamTestString2;                              // 0x00E4(0x0010) NeedCtorLink
		struct FBrgUIFont_ConstParam_Set                           mFontConstParamSets[0x4];                                // 0x00F4(0x1720)
		class UBrgUIParamEditMenuParam*                            mFontConstParam;                                         // 0x1814(0x0008)
		int32_t                                                    mFontConstParamBackup[0x1F];                             // 0x181C(0x007C)
		class UBrgUIImage*                                         mImageChar[0x2];                                         // 0x1898(0x0010)
		class UBrgUIParamEditMenuParam*                            mConstParam;                                             // 0x18A8(0x0008)
		class UBrgUIImageMapInfo*                                  mImageMapInfo;                                           // 0x18B0(0x0008)
		class UBrgUIResource_ItemIconManager*                      mItemIconManager;                                        // 0x18B8(0x0008)
		class UBrgUIResource_TeamEmblemImageManager*               mTeamEmblemImageManager;                                 // 0x18C0(0x0008)
		class UBrgUIResource_TeamEmblemIconImageManager*           mTeamEmblemIconImageManager;                             // 0x18C8(0x0008)
		class UBrgUIResource_PartTypeIconManager*                  mPartTypeIconManager;                                    // 0x18D0(0x0008)
		class UBrgUIResource_QuestPictureManager*                  mQuestPictureManager;                                    // 0x18D8(0x0008)
		class UBrgUIResource_EnmaMenuImageManager*                 mEnmaMenuImageManager;                                   // 0x18E0(0x0008)
		class UBrgUIResource_FighterIcon*                          mResourceFighterIcon;                                    // 0x18E8(0x0008)
		class UBrgUIResource_FortIconImageManager*                 mFortIconImageManager;                                   // 0x18F0(0x0008)
		float                                                      mMaskScreenInvSizeX;                                     // 0x18F8(0x0004)
		float                                                      mMaskScreenInvSizeY;                                     // 0x18FC(0x0004)
		class UTextureRenderTarget2D*                              mCommonRenderTarget;                                     // 0x1900(0x0008)
		class UBrgUIImage*                                         mCommonRenderTargetImage;                                // 0x1908(0x0008)
		class UBrgUIParamEditMenu*                                 mParamEditMenu;                                          // 0x1910(0x0008)
		int32_t                                                    mDisableDrawArea;                                        // 0x1918(0x0004)
		int32_t                                                    mScreenWidth;                                            // 0x191C(0x0004)
		int32_t                                                    mScreenHeight;                                           // 0x1920(0x0004)
		int32_t                                                    mScreenWidthHalf;                                        // 0x1924(0x0004)
		int32_t                                                    mScreenHeightHalf;                                       // 0x1928(0x0004)
		int32_t                                                    mNoneDrawLeftWidth;                                      // 0x192C(0x0004)
		int32_t                                                    mNoneDrawRightWidth;                                     // 0x1930(0x0004)
		int32_t                                                    mNoneDrawTopHeight;                                      // 0x1934(0x0004)
		int32_t                                                    mNoneDrawBottomHeight;                                   // 0x1938(0x0004)
		float                                                      mNowAdjustX;                                             // 0x193C(0x0004)
		float                                                      mNowAdjustY;                                             // 0x1940(0x0004)
		class UBrgUIFont*                                          mDebugFont;                                              // 0x1944(0x0008)
		class UBrgUIFont*                                          mDebugFontJP;                                            // 0x194C(0x0008)
		class UBrgUIFont*                                          mFont[0x40];                                             // 0x1954(0x0200)
		class UBrgUIFont*                                          mFont_Add[0x40];                                         // 0x1B54(0x0200)
		class UBrgUIFont*                                          mFont_UseMask[0x40];                                     // 0x1D54(0x0200)
		class UBrgUIFont*                                          mFont_UseMask_OneMinus[0x40];                            // 0x1F54(0x0200)
		unsigned long                                              mFontLoadEnd : 1;                                        // 0x2154(0x0001) BIT_FIELD
		unsigned long                                              mSetupDbNoneId : 1;                                      // 0x2154(0x0001) BIT_FIELD
		unsigned long                                              mbTouchPadPress : 1;                                     // 0x2154(0x0001) BIT_FIELD
		unsigned long                                              mbTouchPadPressLeft : 1;                                 // 0x2154(0x0001) BIT_FIELD
		unsigned long                                              mbTouchPadPressRight : 1;                                // 0x2154(0x0001) BIT_FIELD
		unsigned long                                              mbTouchPadEdgeLeft : 1;                                  // 0x2154(0x0001) BIT_FIELD
		unsigned long                                              mbTouchPadEdgeRight : 1;                                 // 0x2154(0x0001) BIT_FIELD
		unsigned long                                              mAlwaysHUDVisible : 1;                                   // 0x2154(0x0001) BIT_FIELD
		unsigned long                                              mHideNetworkDebugInfo : 1;                               // 0x2154(0x0001) BIT_FIELD
		unsigned long                                              mBlackScreenVisible : 1;                                 // 0x2154(0x0001) BIT_FIELD
		unsigned long                                              mBackgroundVisible : 1;                                  // 0x2154(0x0001) BIT_FIELD
		unsigned long                                              mbKeyCtrol : 1;                                          // 0x2154(0x0001) BIT_FIELD
		int32_t                                                    mFontLoadState;                                          // 0x2158(0x0004)
		class FString                                              mFontPaths[0xA];                                         // 0x215C(0x00A0) NeedCtorLink
		class UFont*                                               mFonts[0xA];                                             // 0x21FC(0x0050)
		class FString                                              mDbPtNoneHeadId;                                         // 0x224C(0x0010) NeedCtorLink
		class FString                                              mDbPtNoneArmId;                                          // 0x225C(0x0010) NeedCtorLink
		class FString                                              mDbPtNoneBodyId;                                         // 0x226C(0x0010) NeedCtorLink
		class FString                                              mDbPtNoneLegsId;                                         // 0x227C(0x0010) NeedCtorLink
		class UBrgUIImageBase*                                     mGamePadIconImageBase;                                   // 0x228C(0x0008)
		class UBrgUIImage*                                         mGamePadIconSrcGuide;                                    // 0x2294(0x0008)
		class UBrgUIImage*                                         mGamePadIconImage[0x15];                                 // 0x229C(0x00A8)
		class FString                                              mGamePadIconImagePath;                                   // 0x2344(0x0010) NeedCtorLink
		int32_t                                                    mNowInput;                                               // 0x2354(0x0004)
		int32_t                                                    mEdgeInput;                                              // 0x2358(0x0004)
		int32_t                                                    mRepeatInput;                                            // 0x235C(0x0004)
		int32_t                                                    mInputPhase[0x10];                                       // 0x2360(0x0040)
		float                                                      mInputTime[0x10];                                        // 0x23A0(0x0040)
		float                                                      mInputTime2[0x10];                                       // 0x23E0(0x0040)
		int32_t                                                    mTouchPadInput;                                          // 0x2420(0x0004)
		int32_t                                                    mTouchPadEdgeInput;                                      // 0x2424(0x0004)
		struct FVector                                             mTouchOld[0x5];                                          // 0x2428(0x003C)
		struct FVector                                             mTouchOld2[0x5];                                         // 0x2464(0x003C)
		struct FVector                                             mTouchOld3[0x5];                                         // 0x24A0(0x003C)
		int32_t                                                    mNowInputIgnoreStick;                                    // 0x24DC(0x0004)
		int32_t                                                    mEdgeInputIgnoreStick;                                   // 0x24E0(0x0004)
		int32_t                                                    mRepeatInputIgnoreStick;                                 // 0x24E4(0x0004)
		int32_t                                                    mInputPhaseIgnoreStick[0x10];                            // 0x24E8(0x0040)
		float                                                      mInputTimeIgnoreStick[0x10];                             // 0x2528(0x0040)
		float                                                      mInputTime2IgnoreStick[0x10];                            // 0x2568(0x0040)
		class FString                                              mPausePointDbId;                                         // 0x25A8(0x0010) NeedCtorLink
		float                                                      mBlackScreenAlphaSpeed;                                  // 0x25B8(0x0004)
		float                                                      mBlackScreenAlpha;                                       // 0x25BC(0x0004)
		struct FColor                                              mBackgroundColor;                                        // 0x25C0(0x0004)
		struct FParamMoveData                                      mBackgroundColorPM;                                      // 0x25C4(0x006C)
		struct FParamMoveData                                      mBackgroundColorAlphaPM;                                 // 0x2630(0x006C)
		struct FParamMoveData                                      mBackgroundVisibleAlpha;                                 // 0x269C(0x006C)
		float                                                      mNetworkAnimCounter;                                     // 0x2708(0x0004)
		class USoundCue*                                           mMenuStartSC;                                            // 0x270C(0x0008)
		class USoundCue*                                           mPopUpOKSC;                                              // 0x2714(0x0008)
		class USoundCue*                                           mAccessSC;                                               // 0x271C(0x0008)
		class USoundCue*                                           mSystemWindow_Message_OpenSoundCue;                      // 0x2724(0x0008)
		class USoundCue*                                           mSystemWindow_YesNo_OpenSoundCue;                        // 0x272C(0x0008)
		class USoundCue*                                           mMenuSelectSC;                                           // 0x2734(0x0008)
		class USoundCue*                                           mMenuOKSC;                                               // 0x273C(0x0008)
		class USoundCue*                                           mMenuCancelSC;                                           // 0x2744(0x0008)
		class USoundCue*                                           mMenuNGSC;                                               // 0x274C(0x0008)
		class USoundCue*                                           mMenuOutSC;                                              // 0x2754(0x0008)
		class USoundCue*                                           mMenuTrash;                                              // 0x275C(0x0008)
		class UGHM_SoundManager*                                   mSoundManager;                                           // 0x2764(0x0008)
		TArray<struct FBrgUIManagerSoundInfo>                      mPlaySoundCueArray;                                      // 0x276C(0x0010) NeedCtorLink
		class FName                                                mFNameNone;                                              // 0x277C(0x0008)
		class FName                                                mFNameDeathOpacity;                                      // 0x2784(0x0008)
		class FName                                                mFNameOutlineWidth;                                      // 0x278C(0x0008)
		class FName                                                mFNameZ_Scale;                                           // 0x2794(0x0008)
		class FName                                                mFNameZ_Scale_Intensity;                                 // 0x279C(0x0008)
		class FName                                                mFNameDeathColor;                                        // 0x27A4(0x0008)
		class FName                                                mFNamePassiveState;                                      // 0x27AC(0x0008)
		struct FVector                                             mCameraPos;                                              // 0x27B4(0x000C)
		struct FVector                                             mCameraTargetPos;                                        // 0x27C0(0x000C)
		class UBrgNetworkResponseEndsp*                            mNetworkResponseEndsp;                                   // 0x27CC(0x0008)
		class FString                                              mInputKeyTemp;                                           // 0x27D4(0x0010) NeedCtorLink

	public:
		EGHM_MouseDef GetInputMouse();
		void SetInputMouse(EGHM_MouseDef mouse);
		class FString GetInputKey();
		bool IsKeyCtrol();
		void ResetKeyCtrol();
		void SetInputKey(const class FString& Key);
		void RefreshAdjustPos(class ABrgHUDBase* inHUD);
		void InputProcess(float DeltaTime);
		void InitializeNative();
		class FString GetResourcePath(const class FString& PackageName, const class FString& ResourcePath);
		float GetSafeAreaRate();
		void SetNoneDrawSize(class ABrgHUDBase* inHUD, int32_t LeftWidth, int32_t RightWidth, int32_t TopHeight, int32_t BottomHeight);
		float GetGamePadRightStickInputAngle(float DeadZone);
		float GetGamePadLeftStickInputAngle(float DeadZone);
		void GetGamePadRightStickInput(float* DestX, float* DestY);
		void GetGamePadLeftStickInput(float* DestX, float* DestY);
		int32_t GetGamePadRepeatInput(bool IngoreStick);
		int32_t GetGamePadEdgeInput(bool IngoreStick);
		int32_t GetGamePadInput(bool IngoreStick);
		bool IsCircleTreatedAsYes(bool isForced);
		void InitCircleTreatedAsYes(bool isForced);
		class FString GetTextSecondToModifiedTime(int32_t iInSecond, int32_t maxDay);
		class FString GetLocalizeTextST_P(const class FString& SectionPlusTextID, const class FString& AddString0, const class FString& AddString1, const class FString& AddString2, const class FString& AddString3, const class FString& AddString4, const class FString& AddString5);
		class FString GetLocalizeTextArrayST(const class FString& SectionPlusTextID, TArray<class FString> AddString);
		class FString GetLocalizeTextST(const class FString& SectionPlusTextID, const class FString& AddString0, const class FString& AddString1, const class FString& AddString2, const class FString& AddString3, const class FString& AddString4, const class FString& AddString5);
		void PlayStockSoundCue();
		void RemoveAndStopSoundCue(class USoundCue* InSoundCue, class APawn* inPawn);
		void AddPlaySoundCue(class USoundCue* InSoundCue, class APawn* inPawn);
		void AllClearEnableAccessFlag();
		void SetEnableAccessFlag(EBrgUIManager_AccessType inAccessType, bool inEnable);
		void SetAlwaysHUDVisibleState(bool Invisible);
		void SetRenderProcessType(EBrgUIManager_RenderProcessType inRenderProcessType);
		void SetBackgroundVisible(bool Invisible, float inChangeTime);
		void SetBackgroundAlpha(float inAlpha, float inChangeTime);
		void SetBackgroundColor(const struct FColor& InColor, float inChangeTime);
		void SetBlackScreenVisible(bool Visible, float StartAlpha, float AlphaSpeed);
		bool CheckNonePartId(const class FString& Id);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIParamEditMenu
	 * Size -> 0x0030 (FullSize[0x0090] - InheritedSize[0x0060])
	 */
	class UBrgUIParamEditMenu : public UObject
	{
	public:
		unsigned long                                              mParamEdit_Enable : 1;                                   // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mParamEdit_Repeat : 1;                                   // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mParamEdit_FirstRepeat : 1;                              // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mParamEdit_SecondRepeat : 1;                             // 0x0060(0x0001) BIT_FIELD
		EUIParamEditMode                                           mParamEdit_Mode;                                         // 0x0064(0x0001)
		unsigned char                                              UnknownData_CW8Z[0x3];                                   // 0x0065(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		int32_t                                                    mParamEdit_TargetTypeIndex;                              // 0x0068(0x0004)
		int32_t                                                    mParamEdit_TargetParamIndex;                             // 0x006C(0x0004)
		int32_t                                                    mParamEdit_TargetMaxMin;                                 // 0x0070(0x0004)
		float                                                      mParamEdit_RepeatCounter;                                // 0x0074(0x0004)
		float                                                      mParamEdit_RepeatCounter2;                               // 0x0078(0x0004)
		int32_t                                                    mParamEdit_Input;                                        // 0x007C(0x0004)
		TArray<class UBrgUIParamEditMenuParam*>                    mScriptParam;                                            // 0x0080(0x0010) NeedCtorLink

	public:
		void RenderProcess(class ABrgHUDBase* inHUD);
		void TickProcess(float DeltaTime);
		void SubParamInfo(class UBrgUIParamEditMenuParam* inParam);
		void AddParamInfo(class UBrgUIParamEditMenuParam* inParam);
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIParamEditMenuParam
	 * Size -> 0x0020 (FullSize[0x0080] - InheritedSize[0x0060])
	 */
	class UBrgUIParamEditMenuParam : public UObject
	{
	public:
		class FString                                              mName;                                                   // 0x0060(0x0010) NeedCtorLink
		TArray<struct FUIParamUnitInfo>                            mParam;                                                  // 0x0070(0x0010) NeedCtorLink

	public:
		float GetMinMaxF(int32_t InIndex);
		float GetMaxF(int32_t InIndex);
		int32_t GetMaxI(int32_t InIndex);
		float GetMinF(int32_t InIndex);
		int32_t GetMinI(int32_t InIndex);
		float GetF(int32_t InIndex);
		int32_t GetI(int32_t InIndex);
		void ParamInit(int32_t InIndex, const class FString& inParamName, bool inIsMinMax, int32_t inParamIntMin, int32_t inParamIntMax, float inParamScale);
		void Initialize(const class FString& InName, int32_t inParamNum);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIParticlePetal
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgUIParticlePetal : public UObject
	{
	public:
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIParticleWave
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgUIParticleWave : public UObject
	{
	public:
		void GetTestColor(int32_t No, unsigned char* R, unsigned char* G, unsigned char* B);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource__OnMemoryBase
	 * Size -> 0x0028 (FullSize[0x0088] - InheritedSize[0x0060])
	 */
	class UBrgUIResource__OnMemoryBase : public UObject
	{
	public:
		unsigned long                                              mTerminate : 1;                                          // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mLoadEnd : 1;                                            // 0x0060(0x0001) BIT_FIELD
		int32_t                                                    mLoadWaitLastPackageIndex;                               // 0x0064(0x0004)
		TArray<class FString>                                      mLoadWaitClassNames;                                     // 0x0068(0x0010) NeedCtorLink
		TArray<class UBrgUIResource_Common*>                       mResourceArray;                                          // 0x0078(0x0010) NeedCtorLink

	public:
		void Tick(float inDeltaTime);
		bool GetLoadWaitPackageName(TArray<class FString>* inClassName);
		bool CheckLoadEnd();
		void CreateResource();
		void Terminate();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_OnMemory
	 * Size -> 0x0224 (FullSize[0x02AC] - InheritedSize[0x0088])
	 */
	class UBrgUIResource_OnMemory : public UBrgUIResource__OnMemoryBase
	{
	public:
		class UBrgUIResource_Common*                               mButtonResource;                                         // 0x0088(0x0008)
		class UBrgUIResource_HUD6*                                 mHUD6Resource;                                           // 0x0090(0x0008)
		class UBrgUIResource_HUD6*                                 mHUD6Resource_UseMask;                                   // 0x0098(0x0008)
		class UBrgUIResource_HUD6*                                 mHUD6Resource_UseMask_OneMinus;                          // 0x00A0(0x0008)
		class UBrgUIResource_HUD6*                                 mHUD6Resource_AddBlend;                                  // 0x00A8(0x0008)
		class UBrgUIResource_PauseMenu_v01*                        mPauseMenu_v01_Resource;                                 // 0x00B0(0x0008)
		class UBrgUIResource_PauseMenu_v01*                        mPauseMenu_v01_Resource_AddBlend;                        // 0x00B8(0x0008)
		class UBrgUIResource_PauseMenu_v02_Shop*                   mPauseMenu_v02_Shop_Resource;                            // 0x00C0(0x0008)
		class UBrgUIResource_PauseMenu_STM_v00*                    mPauseMenu_STM_v00;                                      // 0x00C8(0x0008)
		class UBrgUIResource_AreaMap*                              mAreaMapResource;                                        // 0x00D0(0x0008)
		class UBrgUIResource_AreaMap*                              mAreaMapResource_UseMask;                                // 0x00D8(0x0008)
		class UBrgUIResource_AreaMap*                              mAreaMapResource_UseMask_OneMinus;                       // 0x00E0(0x0008)
		class UBrgUIResource_MiniGame_v00*                         mMiniGameResource_v00;                                   // 0x00E8(0x0008)
		class UBrgUIResource_MiniGame_v00*                         mMiniGameResource_v00_UseMask;                           // 0x00F0(0x0008)
		class UBrgUIResource_MiniGame_STM_v00*                     mMiniGameResource_STM_v00;                               // 0x00F8(0x0008)
		class UBrgUIResource_Title_First*                          mTitleFirstResource;                                     // 0x0100(0x0008)
		class UBrgUIResource_ElevatorMenu*                         mElevatorMenuResource;                                   // 0x0108(0x0008)
		class UBrgUIResource_StatusMenu*                           mStatusMenuResource;                                     // 0x0110(0x0008)
		class UBrgUIResource_ItemLMenu*                            mItemLMenuResource;                                      // 0x0118(0x0008)
		class UBrgUIResource_Insurance*                            mInsuranceResource;                                      // 0x0120(0x0008)
		class UBrgUIResource_InsuranceMenu*                        mInsuranceMenuResource;                                  // 0x0128(0x0008)
		class UBrgUIResource_InsuranceMenu_v00_00*                 mInsuranceMenuResource_v00_00;                           // 0x0130(0x0008)
		class UBrgUIResource_Icon_MiniMap*                         mIcon_MiniMapResource;                                   // 0x0138(0x0008)
		class UBrgUIResource_Icon_Network*                         mIcon_NetworkResource;                                   // 0x0140(0x0008)
		class UBrgUIResource_Icon_Info_v00*                        mIcon_Info_v00_Resource;                                 // 0x0148(0x0008)
		class UBrgUIResource_Icon_Info_v00*                        mIcon_Info_v00_Resource_AddBlend;                        // 0x0150(0x0008)
		class UBrgUIResource_Icon_Info_v00*                        mIcon_Info_v00_Resource_UseMask_OneMinus;                // 0x0158(0x0008)
		class UBrgUIResource_Icon_Info_v00*                        mIcon_Info_v00_Resource_UseMask_Special;                 // 0x0160(0x0008)
		class UBrgUIResource_Icon_Info_v01*                        mIcon_Info_v01_Resource;                                 // 0x0168(0x0008)
		class UBrgUIResource_Icon_Info_v01*                        mIcon_Info_v01_Resource_UseMask_OneMinus;                // 0x0170(0x0008)
		class UBrgUIResource_Icon_Info_v02*                        mIcon_Info_v02_Resource;                                 // 0x0178(0x0008)
		class UBrgUIResource_Icon_Info_v02*                        mIcon_Info_v02_Resource_UseMask_OneMinus;                // 0x0180(0x0008)
		class UBrgUIResource_Result_Floor_v02*                     mResult_Floor_v02_MenuResource;                          // 0x0188(0x0008)
		class UBrgUIResource_Result_Floor_Info_v00*                mResult_Floor_Info_v00_MenuResource;                     // 0x0190(0x0008)
		class UBrgUIResource_SystemWindow*                         mSystemWindowResource;                                   // 0x0198(0x0008)
		class UBrgUIResource_SkillSticker*                         mSkillStickerResource;                                   // 0x01A0(0x0008)
		class UBrgUIResource_UncleDeath_Anim*                      mUncleDeath_AnimResource;                                // 0x01A8(0x0008)
		class UBrgUIResource_FortMonitor*                          mFortMonitorResource;                                    // 0x01B0(0x0008)
		class UBrgUIResource_FreeContinue*                         mFreeContinueResource;                                   // 0x01B8(0x0008)
		class UBrgUIResource_Title_Notice*                         mTitleNoticeResource;                                    // 0x01C0(0x0008)
		unsigned long                                              mIsItemIconInfosInitialize : 1;                          // 0x01C8(0x0001) BIT_FIELD
		unsigned long                                              mIsPtArmTypeIconInfosInitialize : 1;                     // 0x01C8(0x0001) BIT_FIELD
		unsigned long                                              mbInitializedButtonInfo : 1;                             // 0x01C8(0x0001) BIT_FIELD
		TArray<struct FBrgUIImageWithGuide>                        mItemIconInfos;                                          // 0x01CC(0x0010) NeedCtorLink
		TArray<struct FBrgUIImageWithGuide>                        mPtArmTypeIconInfos;                                     // 0x01DC(0x0010) NeedCtorLink
		TArray<struct FBrgUIImageWithGuide>                        mPtArmTypeIconInfosSizeS;                                // 0x01EC(0x0010) NeedCtorLink
		TArray<class UBrgUIImage*>                                 mSizeLButtonArray;                                       // 0x01FC(0x0010) NeedCtorLink
		class UBrgUIImage*                                         mSizeLButtonGuide;                                       // 0x020C(0x0008)
		TArray<class UBrgUIImage*>                                 mSizeSButtonArray;                                       // 0x0214(0x0010) NeedCtorLink
		class UBrgUIImage*                                         mSizeSButtonGuide00;                                     // 0x0224(0x0008)
		class UBrgUIImage*                                         mSizeSButtonGuide01;                                     // 0x022C(0x0008)
		TArray<class UBrgUIImage*>                                 mSizeXSButtonArray;                                      // 0x0234(0x0010) NeedCtorLink
		class UBrgUIImage*                                         mSizeXSButtonGuide;                                      // 0x0244(0x0008)
		TArray<class UBrgUIImage*>                                 mSizeLKeyArray;                                          // 0x024C(0x0010) NeedCtorLink
		TArray<class UBrgUIImage*>                                 mSizeSKeyArray;                                          // 0x025C(0x0010) NeedCtorLink
		TArray<class UBrgUIImage*>                                 mSizeXSKeyArray;                                         // 0x026C(0x0010) NeedCtorLink
		TArray<class UBrgUIImage*>                                 mSizeLMouseArray;                                        // 0x027C(0x0010) NeedCtorLink
		TArray<class UBrgUIImage*>                                 mSizeSMouseArray;                                        // 0x028C(0x0010) NeedCtorLink
		TArray<class UBrgUIImage*>                                 mSizeXSMouseArray;                                       // 0x029C(0x0010) NeedCtorLink

	public:
		bool IsPadCtrl();
		class FString GetUIKeyFromButtondef(EBrgUIHUD_ButtonDef btn);
		class FString GetPlayerKeyFromButtonDef(EBrgUIHUD_ButtonDef btn);
		void CheckKeyImageArray();
		int32_t GetKeyImageIndex(const class FString& Key);
		EBrgUIHUD_ButtonDef GetButtonDefFromKeyConfig(EGHM_PadDef btn);
		EBrgUIHUD_ButtonDef ConvertKeyConfigButtonDef(EBrgUIHUD_ButtonDef btn);
		class UBrgUIImage* GetUIPlusButtonImage(EBrgUIHUD_PlusButtonImageDef btn);
		class UBrgUIImage* GetMouseImageXS(EGHM_MouseDef mouse);
		class UBrgUIImage* GetMouseImageS(EGHM_MouseDef mouse);
		class UBrgUIImage* GetMouseImageL(EGHM_MouseDef mouse);
		class UBrgUIImage* GetShiftKeyImageXSGuide();
		class UBrgUIImage* GetShiftKeyImageXS();
		class UBrgUIImage* GetKeyImageXSUI(EBrgKeyConfig_KeyLinkDef def, bool fix);
		class UBrgUIImage* GetKeyImageXSPlayer(EBrgKeyConfig_KeyLinkDef def, bool fix);
		class UBrgUIImage* GetKeyImageXS(const class FString& Key);
		class UBrgUIImage* GetKeyImageS(const class FString& Key);
		class UBrgUIImage* GetKeyImageL(const class FString& Key);
		class UBrgUIImage* GetButtonGuideXS();
		class UBrgUIImage* GetButtonImageXS(EBrgUIHUD_ButtonDef btn, bool fix);
		class UBrgUIImage* GetButtonGuideS01();
		class UBrgUIImage* GetButtonGuideS00();
		class UBrgUIImage* GetButtonImageSEx(EBrgUIHUD_ButtonDef_Ex btn);
		class UBrgUIImage* GetButtonImageS(EBrgUIHUD_ButtonDef btn, bool fix);
		class UBrgUIImage* GetButtonGuideL();
		class UBrgUIImage* GetButtonImageLEx(EBrgUIHUD_ButtonDef_Ex btn);
		class UBrgUIImage* GetButtonImageL(EBrgUIHUD_ButtonDef btn, bool fix);
		bool IsSetupButtonImage();
		bool GetPartTypeIcon(const class FString& inType, struct FBrgUIImageWithGuide* inImageWithGuide);
		void GetGradeStarIcon(struct FBrgUIImageWithGuide* inImageWithGuide);
		bool GetFighterTypeMiniIconImage_Enma(const class FString& inFighterTypeID, bool inIsOn, struct FBrgUIImageWithGuide* inImageWithGuide);
		bool GetFighterTypeMiniIconImage(const class FString& inFighterTypeID, struct FBrgUIImageWithGuide* inImageWithGuide);
		bool GetStatEfcIcon(const class FString& inStatEfcIconId, struct FBrgUIImageWithGuide* inImageWithGuide);
		bool GetBstEfcIcon(const class FString& inBstEfcId, struct FBrgUIImageWithGuide* inImageWithGuide, struct FColor* inIconColor);
		bool GetMsrEfcIcon(const class FString& inMsrEfcId, struct FBrgUIImageWithGuide* inImageWithGuide, struct FColor* inIconColor);
		bool GetPtArmTypeIconImage(const class FString& inPtArmTypeId, TArray<struct FBrgUIImageWithGuide> inPtArmTypeIconInfos, struct FBrgUIImageWithGuide* inImageWithGuide);
		bool GetPtArmTypeIconInfos(const class FString& inGroupPath, TArray<struct FBrgDbPartArmType> inPtArmTypeList, TArray<struct FBrgUIImageWithGuide>* inPtArmTypeIconInfos);
		bool GetPtArmTypeIcon(const class FString& inPtArmTypeId, struct FBrgUIImageWithGuide* inImageWithGuide, bool inSize_S);
		bool GetHvnTreasureIcon(struct FBrgUIImageWithGuide* inImageWithGuide);
		bool GetMsrIcon(struct FBrgUIImageWithGuide* inImageWithGuide);
		bool GetItemIcon(const class FString& inItemId, struct FBrgUIImageWithGuide* inImageWithGuide);
		void SetupSteamMouseImage();
		void SetupSteamKeyImage();
		void SetupSteamBtnImage();
		void SetupPS4BtnImage();
		void Terminate();
		void CreateResource();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_OnMemory_Hub
	 * Size -> 0x0180 (FullSize[0x0208] - InheritedSize[0x0088])
	 */
	class UBrgUIResource_OnMemory_Hub : public UBrgUIResource__OnMemoryBase
	{
	public:
		class UBrgUIResource_FreezerMenu_v01*                      mFreezerMenuResource_v01;                                // 0x0088(0x0008)
		class UBrgUIResource_MotherBarbs*                          mMotherBarbsResource;                                    // 0x0090(0x0008)
		class UBrgUIResource_NaomiQuests*                          mNaomiQuestsResource;                                    // 0x0098(0x0008)
		class UBrgUIResource_questmenu_STM_v00*                    mNaomiQuestsResource_STM;                                // 0x00A0(0x0008)
		class UBrgUIResource_Tips_v00*                             mTips_v00_Resource;                                      // 0x00A8(0x0008)
		class UBrgUIResource_RadioMenu*                            mRadioMenuResource;                                      // 0x00B0(0x0008)
		class UBrgUIResource_RewardBox_v00*                        mRewardBoxResource_v00;                                  // 0x00B8(0x0008)
		class UBrgUIResource_RewardBox_v00*                        mRewardBoxResource_v00_UseMask_OneMinus;                 // 0x00C0(0x0008)
		class UBrgUIResource_RewardBox_v01*                        mRewardBoxResource_v01;                                  // 0x00C8(0x0008)
		class UBrgUIResource_Fort_Defense_v00*                     mFort_Defense_v00_Resource;                              // 0x00D0(0x0008)
		class UBrgUIResource_Fort_Facility_v00*                    mFort_Facility_v00_Resource;                             // 0x00D8(0x0008)
		class UBrgUIResource_Fort_Raid_v00*                        mFort_Raid_v00_Resource;                                 // 0x00E0(0x0008)
		class UBrgUIResource_Fort_Ranking_v00*                     mFort_Ranking_v00_Resource;                              // 0x00E8(0x0008)
		class UBrgUIResource_Fort_MyTeam_v00*                      mFort_MyTeam_v00_Resource;                               // 0x00F0(0x0008)
		class UBrgUIResource_Fort_Raid_Info_v00*                   mFort_Raid_Info_v00_Resource;                            // 0x00F8(0x0008)
		class UBrgUIResource_Fort_Report_v00*                      mFort_Report_v00_Resource;                               // 0x0100(0x0008)
		class UBrgUIResource_Fort_ReportDetail_v00*                mFort_ReportDetail_v00_Resource;                         // 0x0108(0x0008)
		class UBrgUIResource_Fort_Result_v00*                      mFort_Result_v00_Resource;                               // 0x0110(0x0008)
		class UBrgUIResource_Fort_Result_v01*                      mFort_Result_v01_Resource;                               // 0x0118(0x0008)
		class UBrgUIResource_Fort_Result_v00_Lang*                 mFort_Result_v00_Lang_Resource;                          // 0x0120(0x0008)
		class UBrgUIResource_Fort_TeamChange_v00*                  mFort_TeamChange_v00_Resource;                           // 0x0128(0x0008)
		class UBrgUIResource_Fort_Top_v00*                         mFort_Top_v00_Resource;                                  // 0x0130(0x0008)
		class UBrgUIResource_Fort_RoomCustom_v00*                  mFort_RoomCustom_v00_Resource;                           // 0x0138(0x0008)
		class UBrgUIResource_Fort_Whistle_v00*                     mFort_Whistle_v00_Resource;                              // 0x0140(0x0008)
		class UBrgUIResource_Prison_v00*                           mPrison_v00_Resource;                                    // 0x0148(0x0008)
		class UBrgUIResource_StampEx_v00*                          mStampEx_v00_Resource;                                   // 0x0150(0x0008)
		class UBrgUIResource_Mushroom_v00*                         mMushroom_v00_Resource;                                  // 0x0158(0x0008)
		class UBrgUIResource_SystemWindow_v02*                     mSystemWindow_v02Resource;                               // 0x0160(0x0008)
		class UBrgUIResource_SystemWindow_v03*                     mSystemWindow_v03Resource;                               // 0x0168(0x0008)
		class UBrgUIResource_InsuranceMenu_Cover_v00*              mInsuranceMenu_Cover_v00Resource;                        // 0x0170(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_Top_Mask_v00;                        // 0x0178(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_Top_Shot_v00;                        // 0x0180(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_Top_Shot_v01;                        // 0x0188(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_Top_Effect_v00;                      // 0x0190(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_Top_Cursor_v00;                      // 0x0198(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_Top_Base_D_v00;                      // 0x01A0(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_Top_Base_D_v01;                      // 0x01A8(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_Top_Base_U_v00;                      // 0x01B0(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_Top_Base_U_v01;                      // 0x01B8(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_TeamChange_Mask_v00;                 // 0x01C0(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_Vendetta;                            // 0x01C8(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_MysteryBag_v00;                      // 0x01D0(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_MysteryBag_v01;                      // 0x01D8(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_MysteryBag_v02;                      // 0x01E0(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_MysteryBag_v03;                      // 0x01E8(0x0008)
		class UBrgUIImage_Stream*                                  mUI_Fort_TX_UI_Fort_MysteryBag_v04;                      // 0x01F0(0x0008)
		TArray<class FString>                                      mEmblemIds;                                              // 0x01F8(0x0010) NeedCtorLink

	public:
		void CreateResource();
		void CreateResourceNative();
		void UnloadFortIcon();
		void UnloadEmblem();
		void LoadEmblem();
		void Terminate();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Common
	 * Size -> 0x002C (FullSize[0x008C] - InheritedSize[0x0060])
	 */
	class UBrgUIResource_Common : public UObject
	{
	public:
		unsigned long                                              mSetupImage : 1;                                         // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mInitialize : 1;                                         // 0x0060(0x0001) BIT_FIELD
		TArray<class UBrgUITexture2DLoader*>                       mImageLoaders;                                           // 0x0064(0x0010) NeedCtorLink
		TArray<class UBrgUIImageBase*>                             mUIBaseImages;                                           // 0x0074(0x0010) NeedCtorLink
		class UBrgUIImageMapInfoSet*                               mImageMapInfoSet;                                        // 0x0084(0x0008)

	public:
		bool LoadProcess();
		void SetupImageCommon();
		void PrivateSetupImage();
		void SetupImage();
		bool SetImageLoadState(bool IsLoad, bool IsLoadCompCheckOnly);
		void Terminate();
		void SetupLoadImage(const class FString& inPackageName, const class FString& inImageName, int32_t inImageNum, const class FString& inUnrealPackageName, const class FString& inUnrealImageName);
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_AreaMap
	 * Size -> 0x0A4C (FullSize[0x0AD8] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_AreaMap : public UBrgUIResource_Common
	{
	public:
		EBrgUIResource_AreaMap_UseMaskType                         mUseMask;                                                // 0x008C(0x0001)
		unsigned char                                              UnknownData_MLU6[0x3];                                   // 0x008D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class UBrgUIImage*                                         l__bg;                                                   // 0x0090(0x0008)
		struct Fstx_ui_areamap_v00__map_floor_all                  l_map_floor_all;                                         // 0x0098(0x0188)
		struct Fstx_ui_areamap_v00__map_valve_all                  l_map_valve_all;                                         // 0x0220(0x08B8)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_ButtonGuide
	 * Size -> 0x01AC (FullSize[0x0238] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_ButtonGuide : public UBrgUIResource_Common
	{
	public:
		EBrgUIResource_ButtonGuide_UseMaskType                     mUseMask;                                                // 0x008C(0x0001)
		unsigned char                                              UnknownData_QIKY[0x3];                                   // 0x008D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class UBrgUIImage*                                         l__bg;                                                   // 0x0090(0x0008)
		struct Fstx_ui_buttonguide_v00__buttonguide_all            l_buttonguide_all;                                       // 0x0098(0x01A0)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_ButtonGuide_STM_v00
	 * Size -> 0x1264 (FullSize[0x12F0] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_ButtonGuide_STM_v00 : public UBrgUIResource_Common
	{
	public:
		EBrgUIResource_ButtonGuide_STM_UseMaskType                 mUseMask;                                                // 0x008C(0x0001)
		unsigned char                                              UnknownData_BD51[0x3];                                   // 0x008D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class UBrgUIImage*                                         l__bg;                                                   // 0x0090(0x0008)
		struct Fstx_ui_buttonguide_stm_v00__buttonguide_stm_v00_all l_buttonguide_stm_v00_all;                               // 0x0098(0x0298)
		struct Fstx_ui_buttonguide_stm_v00__buttonguide_stm_v01_all l_buttonguide_stm_v01_all;                               // 0x0330(0x0FC0)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_ElevatorMenu
	 * Size -> 0x0180 (FullSize[0x020C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_ElevatorMenu : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_elevator_v00___bg                           l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_elevator_v00___guide_01                     l__guide_01;                                             // 0x0094(0x0018)
		struct Fstx_ui_elevator_v00__deathmetal_all                l_deathmetal_all;                                        // 0x00AC(0x0020)
		struct Fstx_ui_elevator_v00__coin_all                      l_coin_all;                                              // 0x00CC(0x0020)
		struct Fstx_ui_elevator_v00__scrollbar_all                 l_scrollbar_all;                                         // 0x00EC(0x0018)
		struct Fstx_ui_elevator_v00__elevator_all                  l_elevator_all;                                          // 0x0104(0x00D8)
		struct Fstx_ui_elevator_v00__elevator_h_all                l_elevator_h_all;                                        // 0x01DC(0x0030)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Memo_v00
	 * Size -> 0x10C4 (FullSize[0x1150] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Memo_v00 : public UBrgUIResource_Common
	{
	public:
		EBrgUIResource_EnmaMenu_Memo_UseMaskType                   mUseMask;                                                // 0x008C(0x0001)
		unsigned char                                              UnknownData_6EWL[0x3];                                   // 0x008D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct Fstx_ui_enmamenu_memo_v00___bg                      l__bg;                                                   // 0x0090(0x0018)
		struct Fstx_ui_enmamenu_memo_v00__base_memo_all            l_base_memo_all;                                         // 0x00A8(0x0010)
		struct Fstx_ui_enmamenu_memo_v00__memo_help_all            l_memo_help_all;                                         // 0x00B8(0x0390)
		struct Fstx_ui_enmamenu_memo_v00__memo_quest_all           l_memo_quest_all;                                        // 0x0448(0x0280)
		struct Fstx_ui_enmamenu_memo_v00__memo_mail_all            l_memo_mail_all;                                         // 0x06C8(0x0178)
		struct Fstx_ui_enmamenu_memo_v00__memo_catalog_all         l_memo_catalog_all;                                      // 0x0840(0x0178)
		struct Fstx_ui_enmamenu_memo_v00__memo_magazine_all        l_memo_magazine_all;                                     // 0x09B8(0x0130)
		struct Fstx_ui_enmamenu_memo_v00__memo_sticker_all         l_memo_sticker_all;                                      // 0x0AE8(0x01E0)
		struct Fstx_ui_enmamenu_memo_v00__memo_beast_all           l_memo_beast_all;                                        // 0x0CC8(0x01B8)
		struct Fstx_ui_enmamenu_memo_v00__memo_mushroom_all        l_memo_mushroom_all;                                     // 0x0E80(0x0190)
		struct Fstx_ui_enmamenu_memo_v00__memo_masterlevell_all    l_memo_masterlevell_all;                                 // 0x1010(0x0108)
		struct Fstx_ui_enmamenu_memo_v00__memo_fighter_all         l_memo_fighter_all;                                      // 0x1118(0x0028)
		struct Fstx_ui_enmamenu_memo_v00__base_tape_all            l_base_tape_all;                                         // 0x1140(0x0010)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Menu_v00
	 * Size -> 0x00D0 (FullSize[0x015C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Menu_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_enmamenu_menu_v00__base_menu_all            l_base_menu_all;                                         // 0x0094(0x0018)
		struct Fstx_ui_enmamenu_menu_v00__postit_all               l_postit_all;                                            // 0x00AC(0x0070)
		struct Fstx_ui_enmamenu_menu_v00__cursol_all               l_cursol_all;                                            // 0x011C(0x0038)
		class UBrgUIImage*                                         l__guide_menu_all;                                       // 0x0154(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Menu_v01
	 * Size -> 0x0118 (FullSize[0x01A4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Menu_v01 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_enmamenu_menu_v01__menu_all                 l_menu_all;                                              // 0x0094(0x0078)
		struct Fstx_ui_enmamenu_menu_v01__menu_title_all           l_menu_title_all;                                        // 0x010C(0x0098)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_Beast_v00
	 * Size -> 0x02E8 (FullSize[0x0374] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_Beast_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__base_page;                                            // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_background;                                       // 0x0094(0x0008)
		struct Fstx_ui_enmamenu_page_beast_v00__scrollbar_all      l_scrollbar_all;                                         // 0x009C(0x0028)
		struct Fstx_ui_enmamenu_page_beast_v00__base_masking_all   l_base_masking_all;                                      // 0x00C4(0x0010)
		struct Fstx_ui_enmamenu_page_beast_v00__icon_postit_all    l_icon_postit_all;                                       // 0x00D4(0x0278)
		struct Fstx_ui_enmamenu_page_beast_v00__icon_seal_all      l_icon_seal_all;                                         // 0x034C(0x0010)
		class UBrgUIImage*                                         l_mask_postit_v00;                                       // 0x035C(0x0008)
		class UBrgUIImage*                                         l_mask_postit_v01;                                       // 0x0364(0x0008)
		class UBrgUIImage*                                         l__guide_base_page;                                      // 0x036C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_Catalog_v00
	 * Size -> 0x00C0 (FullSize[0x014C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_Catalog_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__base_page;                                            // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_background;                                       // 0x0094(0x0008)
		struct Fstx_ui_enmamenu_page_catalog_v00__base_masking_all l_base_masking_all;                                      // 0x009C(0x0010)
		struct Fstx_ui_enmamenu_page_catalog_v00__icon_page_all    l_icon_page_all;                                         // 0x00AC(0x0080)
		class UBrgUIImage*                                         l__guide_icon_page_big;                                  // 0x012C(0x0008)
		class UBrgUIImage*                                         l_mask_postit_v00;                                       // 0x0134(0x0008)
		class UBrgUIImage*                                         l_mask_postit_v01;                                       // 0x013C(0x0008)
		class UBrgUIImage*                                         l__guide_base_page;                                      // 0x0144(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_Fighter_v00
	 * Size -> 0x07C0 (FullSize[0x084C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_Fighter_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__base_page;                                            // 0x008C(0x0008)
		struct Fstx_ui_enmamenu_page_fighter_v00__scrollbar_all    l_scrollbar_all;                                         // 0x0094(0x0028)
		struct Fstx_ui_enmamenu_page_fighter_v00__base_masking_all l_base_masking_all;                                      // 0x00BC(0x0010)
		struct Fstx_ui_enmamenu_page_fighter_v00__2p_all           l_2p_all;                                                // 0x00CC(0x0190)
		struct Fstx_ui_enmamenu_page_fighter_v00__1p_all           l_1p_all;                                                // 0x025C(0x03A0)
		struct Fstx_ui_enmamenu_page_fighter_v00__icon_postit_all  l_icon_postit_all;                                       // 0x05FC(0x01D0)
		struct Fstx_ui_enmamenu_page_fighter_v00__icon_seal_all    l_icon_seal_all;                                         // 0x07CC(0x0010)
		class UBrgUIImage*                                         l_mask_v01;                                              // 0x07DC(0x0008)
		class UBrgUIImage*                                         l_mask_v00;                                              // 0x07E4(0x0008)
		struct Fstx_ui_enmamenu_page_fighter_v00__cursol_all       l_cursol_all;                                            // 0x07EC(0x0058)
		class UBrgUIImage*                                         l__guide_base_page;                                      // 0x0844(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_Help_v00
	 * Size -> 0x0230 (FullSize[0x02BC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_Help_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__base_page;                                            // 0x008C(0x0008)
		struct Fstx_ui_enmamenu_page_help_v00__scrollbar_all       l_scrollbar_all;                                         // 0x0094(0x0028)
		struct Fstx_ui_enmamenu_page_help_v00__icon_postit_all     l_icon_postit_all;                                       // 0x00BC(0x00D0)
		struct Fstx_ui_enmamenu_page_help_v00__icon_new_all        l_icon_new_all;                                          // 0x018C(0x0078)
		struct Fstx_ui_enmamenu_page_help_v00__cursol_all          l_cursol_all;                                            // 0x0204(0x0080)
		struct Fstx_ui_enmamenu_page_help_v00__base_masking_all    l_base_masking_all;                                      // 0x0284(0x0010)
		struct Fstx_ui_enmamenu_page_help_v00__icon_seal_all       l_icon_seal_all;                                         // 0x0294(0x0010)
		class UBrgUIImage*                                         l_mask_postit_v00;                                       // 0x02A4(0x0008)
		class UBrgUIImage*                                         l_mask_postit_v01;                                       // 0x02AC(0x0008)
		class UBrgUIImage*                                         l__guide_base_page;                                      // 0x02B4(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_Index_v00
	 * Size -> 0x0188 (FullSize[0x0214] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_Index_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_background;                                       // 0x0094(0x0008)
		struct Fstx_ui_enmamenu_page_index_v00__icon_postit_all    l_icon_postit_all;                                       // 0x009C(0x0120)
		struct Fstx_ui_enmamenu_page_index_v00__cursol_all         l_cursol_all;                                            // 0x01BC(0x0040)
		class UBrgUIImage*                                         l__guide_base_page_v01;                                  // 0x01FC(0x0008)
		class UBrgUIImage*                                         l__guide_base_page_v00;                                  // 0x0204(0x0008)
		class UBrgUIImage*                                         l__guide_base_tab_v00;                                   // 0x020C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_Magazine_v00
	 * Size -> 0x0170 (FullSize[0x01FC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_Magazine_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__base_page;                                            // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_background;                                       // 0x0094(0x0008)
		struct Fstx_ui_enmamenu_page_magazine_v00__base_masking_all l_base_masking_all;                                      // 0x009C(0x0010)
		struct Fstx_ui_enmamenu_page_magazine_v00__icon_page_all   l_icon_page_all;                                         // 0x00AC(0x0110)
		struct Fstx_ui_enmamenu_page_magazine_v00__text_all        l_text_all;                                              // 0x01BC(0x0020)
		class UBrgUIImage*                                         l__guide_icon_page_big;                                  // 0x01DC(0x0008)
		class UBrgUIImage*                                         l_mask_postit_v00;                                       // 0x01E4(0x0008)
		class UBrgUIImage*                                         l_mask_postit_v01;                                       // 0x01EC(0x0008)
		class UBrgUIImage*                                         l__guide_base_page;                                      // 0x01F4(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_Mail_v00
	 * Size -> 0x0240 (FullSize[0x02CC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_Mail_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__base_page;                                            // 0x008C(0x0008)
		struct Fstx_ui_enmamenu_page_mail_v00__scrollbar_all       l_scrollbar_all;                                         // 0x0094(0x0028)
		struct Fstx_ui_enmamenu_page_mail_v00__icon_postit_all     l_icon_postit_all;                                       // 0x00BC(0x00E0)
		struct Fstx_ui_enmamenu_page_mail_v00__icon_new_all        l_icon_new_all;                                          // 0x019C(0x0078)
		struct Fstx_ui_enmamenu_page_mail_v00__base_masking_all    l_base_masking_all;                                      // 0x0214(0x0010)
		struct Fstx_ui_enmamenu_page_mail_v00__cursol_all          l_cursol_all;                                            // 0x0224(0x0080)
		struct Fstx_ui_enmamenu_page_mail_v00__icon_seal_all       l_icon_seal_all;                                         // 0x02A4(0x0010)
		class UBrgUIImage*                                         l_mask_postit_v00;                                       // 0x02B4(0x0008)
		class UBrgUIImage*                                         l_mask_postit_v01;                                       // 0x02BC(0x0008)
		class UBrgUIImage*                                         l__guide_base_page;                                      // 0x02C4(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_MasterLevel_v00
	 * Size -> 0x03B8 (FullSize[0x0444] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_MasterLevel_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__base_page;                                            // 0x008C(0x0008)
		struct Fstx_ui_enmamenu_page_masterlevel_v00__scrollbar_all l_scrollbar_all;                                         // 0x0094(0x0028)
		struct Fstx_ui_enmamenu_page_masterlevel_v00__base_masking_all l_base_masking_all;                                      // 0x00BC(0x0010)
		struct Fstx_ui_enmamenu_page_masterlevel_v00__icon_postit_all l_icon_postit_all;                                       // 0x00CC(0x0350)
		struct Fstx_ui_enmamenu_page_masterlevel_v00__icon_seal_all l_icon_seal_all;                                         // 0x041C(0x0010)
		class UBrgUIImage*                                         l_mask_postit_v00;                                       // 0x042C(0x0008)
		class UBrgUIImage*                                         l_mask_postit_v01;                                       // 0x0434(0x0008)
		class UBrgUIImage*                                         l__guide_base_page;                                      // 0x043C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_Mushroom_v00
	 * Size -> 0x0320 (FullSize[0x03AC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_Mushroom_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__base_page;                                            // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_background;                                       // 0x0094(0x0008)
		struct Fstx_ui_enmamenu_page_mushroom_v00__scrollbar_all   l_scrollbar_all;                                         // 0x009C(0x0028)
		struct Fstx_ui_enmamenu_page_mushroom_v00__base_masking_all l_base_masking_all;                                      // 0x00C4(0x0010)
		struct Fstx_ui_enmamenu_page_mushroom_v00__icon_postit_all l_icon_postit_all;                                       // 0x00D4(0x02B0)
		struct Fstx_ui_enmamenu_page_mushroom_v00__icon_seal_all   l_icon_seal_all;                                         // 0x0384(0x0010)
		class UBrgUIImage*                                         l_mask_postit_v00;                                       // 0x0394(0x0008)
		class UBrgUIImage*                                         l_mask_postit_v01;                                       // 0x039C(0x0008)
		class UBrgUIImage*                                         l__guide_base_page;                                      // 0x03A4(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_Omoide_v00
	 * Size -> 0x00C8 (FullSize[0x0154] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_Omoide_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__base_page;                                            // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_corkboard;                                        // 0x0094(0x0008)
		struct Fstx_ui_enmamenu_page_omoide_v00__scrollbar_all     l_scrollbar_all;                                         // 0x009C(0x0028)
		struct Fstx_ui_enmamenu_page_omoide_v00__base_photo_all    l_base_photo_all;                                        // 0x00C4(0x0078)
		struct Fstx_ui_enmamenu_page_omoide_v00__base_masking_all  l_base_masking_all;                                      // 0x013C(0x0010)
		class UBrgUIImage*                                         l__guide_base_page;                                      // 0x014C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_Quest_v00
	 * Size -> 0x01E0 (FullSize[0x026C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_Quest_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__base_page;                                            // 0x008C(0x0008)
		struct Fstx_ui_enmamenu_page_quest_v00__scrollbar_all      l_scrollbar_all;                                         // 0x0094(0x0028)
		struct Fstx_ui_enmamenu_page_quest_v00__base_masking_all   l_base_masking_all;                                      // 0x00BC(0x0010)
		struct Fstx_ui_enmamenu_page_quest_v00__icon_postit_all    l_icon_postit_all;                                       // 0x00CC(0x0188)
		class UBrgUIImage*                                         l_mask_postit_v00;                                       // 0x0254(0x0008)
		class UBrgUIImage*                                         l_mask_postit_v01;                                       // 0x025C(0x0008)
		class UBrgUIImage*                                         l__guide_base_page;                                      // 0x0264(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_Senpai_v00
	 * Size -> 0x0208 (FullSize[0x0294] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_Senpai_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__base_page;                                            // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_page2;                                            // 0x0094(0x0008)
		struct Fstx_ui_enmamenu_page_senpai_v00__scrollbar_all     l_scrollbar_all;                                         // 0x009C(0x0028)
		struct Fstx_ui_enmamenu_page_senpai_v00__entry_all         l_entry_all;                                             // 0x00C4(0x0028)
		struct Fstx_ui_enmamenu_page_senpai_v00__icon_line_all     l_icon_line_all;                                         // 0x00EC(0x0068)
		struct Fstx_ui_enmamenu_page_senpai_v00__text_all          l_text_all;                                              // 0x0154(0x0010)
		struct Fstx_ui_enmamenu_page_senpai_v00__text_guide_all    l_text_guide_all;                                        // 0x0164(0x0108)
		struct Fstx_ui_enmamenu_page_senpai_v00__base_masking_all  l_base_masking_all;                                      // 0x026C(0x0010)
		class UBrgUIImage*                                         l_mask_postit_v00;                                       // 0x027C(0x0008)
		class UBrgUIImage*                                         l_mask_postit_v01;                                       // 0x0284(0x0008)
		class UBrgUIImage*                                         l__guide_base_page;                                      // 0x028C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_Sticker_v00
	 * Size -> 0x0328 (FullSize[0x03B4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_Sticker_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__base_page;                                            // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_background;                                       // 0x0094(0x0008)
		struct Fstx_ui_enmamenu_page_sticker_v00__scrollbar_all    l_scrollbar_all;                                         // 0x009C(0x0028)
		struct Fstx_ui_enmamenu_page_sticker_v00__base_masking_all l_base_masking_all;                                      // 0x00C4(0x0010)
		struct Fstx_ui_enmamenu_page_sticker_v00__icon_postit_all  l_icon_postit_all;                                       // 0x00D4(0x02B8)
		struct Fstx_ui_enmamenu_page_sticker_v00__icon_seal_all    l_icon_seal_all;                                         // 0x038C(0x0010)
		class UBrgUIImage*                                         l_mask_postit_v00;                                       // 0x039C(0x0008)
		class UBrgUIImage*                                         l_mask_postit_v01;                                       // 0x03A4(0x0008)
		class UBrgUIImage*                                         l__guide_base_page;                                      // 0x03AC(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Page_v00
	 * Size -> 0x0018 (FullSize[0x00A4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Page_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_page;                                             // 0x0094(0x0008)
		class UBrgUIImage*                                         l__guide_base_page;                                      // 0x009C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Paperdoll_v00
	 * Size -> 0x0098 (FullSize[0x0124] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Paperdoll_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		class UBrgUIImage*                                         l_paperdoll_v00;                                         // 0x0094(0x0008)
		class UBrgUIImage*                                         l_paperdoll_v01;                                         // 0x009C(0x0008)
		class UBrgUIImage*                                         l_glasses_v04;                                           // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_glasses_v03;                                           // 0x00AC(0x0008)
		class UBrgUIImage*                                         l_glasses_v02;                                           // 0x00B4(0x0008)
		class UBrgUIImage*                                         l_glasses_v01;                                           // 0x00BC(0x0008)
		class UBrgUIImage*                                         l_glasses_v00;                                           // 0x00C4(0x0008)
		class UBrgUIImage*                                         l_skateboard;                                            // 0x00CC(0x0008)
		class UBrgUIImage*                                         l_pc;                                                    // 0x00D4(0x0008)
		class UBrgUIImage*                                         l_book;                                                  // 0x00DC(0x0008)
		class UBrgUIImage*                                         l_deathdrive;                                            // 0x00E4(0x0008)
		class UBrgUIImage*                                         l_audio;                                                 // 0x00EC(0x0008)
		class UBrgUIImage*                                         l_balloon;                                               // 0x00F4(0x0008)
		class UBrgUIImage*                                         l_scythe;                                                // 0x00FC(0x0008)
		class UBrgUIImage*                                         l_kiwako;                                                // 0x0104(0x0008)
		class UBrgUIImage*                                         l_meijin;                                                // 0x010C(0x0008)
		class UBrgUIImage*                                         l_yotsuyama;                                             // 0x0114(0x0008)
		class UBrgUIImage*                                         l_uncledeath;                                            // 0x011C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Stamp_Arrow
	 * Size -> 0x0040 (FullSize[0x00CC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Stamp_Arrow : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_enmamenu_stamp_arrow___bg                   l__bg;                                                   // 0x008C(0x0010)
		struct Fstx_ui_enmamenu_stamp_arrow__arrow_all             l_arrow_all;                                             // 0x009C(0x0030)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Stamp_v00
	 * Size -> 0x02C8 (FullSize[0x0354] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Stamp_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_enmamenu_stamp_v00__bg                      l_bg;                                                    // 0x008C(0x0028)
		struct Fstx_ui_enmamenu_stamp_v00__icon_stamp_all          l_icon_stamp_all;                                        // 0x00B4(0x01A0)
		struct Fstx_ui_enmamenu_stamp_v00__cloud_all               l_cloud_all;                                             // 0x0254(0x0100)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Stamp_v01
	 * Size -> 0x0168 (FullSize[0x01F4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Stamp_v01 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_v00;                                              // 0x0094(0x0008)
		struct Fstx_ui_enmamenu_stamp_v01__perfect_all             l_perfect_all;                                           // 0x009C(0x0050)
		struct Fstx_ui_enmamenu_stamp_v01__good                    l_good;                                                  // 0x00EC(0x0050)
		struct Fstx_ui_enmamenu_stamp_v01__miss                    l_miss;                                                  // 0x013C(0x0050)
		struct Fstx_ui_enmamenu_stamp_v01___guide_all              l__guide_all;                                            // 0x018C(0x0068)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_STM_Tab_v00
	 * Size -> 0x004C (FullSize[0x00D8] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_STM_Tab_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_enmamenu_stm_tab_v00__button_r_all          l_button_r_all;                                          // 0x0094(0x0020)
		struct Fstx_ui_enmamenu_stm_tab_v00__button_l_all          l_button_l_all;                                          // 0x00B4(0x0020)
		unsigned long                                              mAddBlendDraw : 1;                                       // 0x00D4(0x0001) BIT_FIELD

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_Tab_v00
	 * Size -> 0x01A8 (FullSize[0x0234] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_Tab_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_enmamenu_tab_v00__base_tab_all              l_base_tab_all;                                          // 0x0094(0x0030)
		struct Fstx_ui_enmamenu_tab_v00__icon_tab_all              l_icon_tab_all;                                          // 0x00C4(0x0068)
		struct Fstx_ui_enmamenu_tab_v00__icon_new_all              l_icon_new_all;                                          // 0x012C(0x0090)
		struct Fstx_ui_enmamenu_tab_v00__text_all                  l_text_all;                                              // 0x01BC(0x0030)
		struct Fstx_ui_enmamenu_tab_v00___guide_tabtitle_all       l__guide_tabtitle_all;                                   // 0x01EC(0x0030)
		class UBrgUIImage*                                         l__guide_base_tab_v00;                                   // 0x021C(0x0008)
		struct Fstx_ui_enmamenu_tab_v00__button_stm                l_button_stm;                                            // 0x0224(0x0010)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenu_v01
	 * Size -> 0x2428 (FullSize[0x24B4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_EnmaMenu_v01 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_enmamenu_v01___bg                           l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_enmamenu_v01__mail_all                      l_mail_all;                                              // 0x0094(0x0508)
		struct Fstx_ui_enmamenu_v01__reference_mushroom_all        l_reference_mushroom_all;                                // 0x059C(0x0638)
		struct Fstx_ui_enmamenu_v01__reference_menu_all            l_reference_menu_all;                                    // 0x0BD4(0x0050)
		struct Fstx_ui_enmamenu_v01__quest_all                     l_quest_all;                                             // 0x0C24(0x07D0)
		struct Fstx_ui_enmamenu_v01__mydata_senpai_all             l_mydata_senpai_all;                                     // 0x13F4(0x01D8)
		struct Fstx_ui_enmamenu_v01__mydata_masterlevel_all        l_mydata_masterlevel_all;                                // 0x15CC(0x0E28)
		struct Fstx_ui_enmamenu_v01__mydata_menu_all               l_mydata_menu_all;                                       // 0x23F4(0x0070)
		class UBrgUIImage*                                         l_base_ring;                                             // 0x2464(0x0008)
		struct Fstx_ui_enmamenu_v01__cursol_all                    l_cursol_all;                                            // 0x246C(0x0010)
		struct Fstx_ui_enmamenu_v01__guide_01                      l_guide_01;                                              // 0x247C(0x0038)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_Defense_v00
	 * Size -> 0x0470 (FullSize[0x04FC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_Defense_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_defense_v00___bg                            l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_defense_v00__reinforce_all                  l_reinforce_all;                                         // 0x0094(0x0008)
		struct Fstx_ui_defense_v00__setting_all                    l_setting_all;                                           // 0x009C(0x01C0)
		struct Fstx_ui_defense_v00__mydata_all                     l_mydata_all;                                            // 0x025C(0x02A0)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_Facility_v00
	 * Size -> 0x0128 (FullSize[0x01B4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_Facility_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_facility_v00___bg                           l__bg;                                                   // 0x008C(0x0020)
		struct Fstx_ui_facility_v00__upgrade_all                   l_upgrade_all;                                           // 0x00AC(0x00F8)
		struct Fstx_ui_facility_v00__mydata_all                    l_mydata_all;                                            // 0x01A4(0x0010)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_MyTeam_v00
	 * Size -> 0x02E8 (FullSize[0x0374] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_MyTeam_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_fort_myteam_v00___bg                        l__bg;                                                   // 0x008C(0x0058)
		struct Fstx_ui_fort_myteam_v00__hate_all                   l_hate_all;                                              // 0x00E4(0x00D8)
		struct Fstx_ui_fort_myteam_v00__team_all                   l_team_all;                                              // 0x01BC(0x0080)
		struct Fstx_ui_fort_myteam_v00__status_all                 l_status_all;                                            // 0x023C(0x0078)
		struct Fstx_ui_fort_myteam_v00__newplayerlist_all          l_newplayerlist_all;                                     // 0x02B4(0x0098)
		struct Fstx_ui_fort_myteam_v00__setting_all                l_setting_all;                                           // 0x034C(0x0010)
		struct Fstx_ui_fort_myteam_v00__mydata_all                 l_mydata_all;                                            // 0x035C(0x0018)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_Raid_Info_v00
	 * Size -> 0x0080 (FullSize[0x010C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_Raid_Info_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_fort_raid_info_v00___bg                     l__bg;                                                   // 0x008C(0x0018)
		struct Fstx_ui_fort_raid_info_v00__fort_raid_v00           l_fort_raid_v00;                                         // 0x00A4(0x0050)
		struct Fstx_ui_fort_raid_info_v00__map_floor_all           l_map_floor_all;                                         // 0x00F4(0x0010)
		struct Fstx_ui_fort_raid_info_v00__playerlist_all          l_playerlist_all;                                        // 0x0104(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_Raid_v00
	 * Size -> 0x0410 (FullSize[0x049C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_Raid_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_raid_v00___bg                               l__bg;                                                   // 0x008C(0x0020)
		struct Fstx_ui_raid_v00__playerdata_v01                    l_playerdata_v01;                                        // 0x00AC(0x0030)
		struct Fstx_ui_raid_v00__playerdata_v00                    l_playerdata_v00;                                        // 0x00DC(0x00B8)
		struct Fstx_ui_raid_v00__cost_all                          l_cost_all;                                              // 0x0194(0x0020)
		struct Fstx_ui_raid_v00__playerlist_all                    l_playerlist_all;                                        // 0x01B4(0x01C0)
		struct Fstx_ui_raid_v00__newplayerlist_all                 l_newplayerlist_all;                                     // 0x0374(0x0128)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_Ranking_v00
	 * Size -> 0x01F8 (FullSize[0x0284] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_Ranking_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_ranking_v00___bg                            l__bg;                                                   // 0x008C(0x0020)
		struct Fstx_ui_ranking_v00__setting_all                    l_setting_all;                                           // 0x00AC(0x0010)
		struct Fstx_ui_ranking_v00__mydata_all                     l_mydata_all;                                            // 0x00BC(0x0018)
		struct Fstx_ui_ranking_v00__ranking_all                    l_ranking_all;                                           // 0x00D4(0x01B0)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_Report_v00
	 * Size -> 0x0600 (FullSize[0x068C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_Report_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_fort_report_v00___bg                        l__bg;                                                   // 0x008C(0x0058)
		struct Fstx_ui_fort_report_v00__scrollbar_all              l_scrollbar_all;                                         // 0x00E4(0x0038)
		struct Fstx_ui_fort_report_v00__report_dispute_all         l_report_dispute_all;                                    // 0x011C(0x0168)
		struct Fstx_ui_fort_report_v00__result_dispute_all         l_result_dispute_all;                                    // 0x0284(0x00F8)
		struct Fstx_ui_fort_report_v00__report_raid_all            l_report_raid_all;                                       // 0x037C(0x01F8)
		class UBrgUIImage*                                         l_mask_v00;                                              // 0x0574(0x0008)
		class UBrgUIImage*                                         l_mask_v01;                                              // 0x057C(0x0008)
		struct Fstx_ui_fort_report_v00__popup_all                  l_popup_all;                                             // 0x0584(0x0098)
		struct Fstx_ui_fort_report_v00__sort_r                     l_sort_r;                                                // 0x061C(0x0030)
		struct Fstx_ui_fort_report_v00__mark_detail_all            l_mark_detail_all;                                       // 0x064C(0x0040)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_ReportDetail_v00
	 * Size -> 0x0070 (FullSize[0x00FC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_ReportDetail_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_fort_reportdetail_v00___bg                  l__bg;                                                   // 0x008C(0x0020)
		struct Fstx_ui_fort_reportdetail_v00__map_result_all       l_map_result_all;                                        // 0x00AC(0x0008)
		struct Fstx_ui_fort_reportdetail_v00__result_all           l_result_all;                                            // 0x00B4(0x0008)
		struct Fstx_ui_fort_reportdetail_v00__log_all              l_log_all;                                               // 0x00BC(0x0028)
		struct Fstx_ui_fort_reportdetail_v00__chala_image_all      l_chala_image_all;                                       // 0x00E4(0x0008)
		struct Fstx_ui_fort_reportdetail_v00__report_raid_all      l_report_raid_all;                                       // 0x00EC(0x0010)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_Result_v00
	 * Size -> 0x0398 (FullSize[0x0424] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_Result_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_fort_result_v00___bg                        l__bg;                                                   // 0x008C(0x0010)
		class UBrgUIImage*                                         l__guide_01;                                             // 0x009C(0x0008)
		class UBrgUIImage*                                         l__menu_title;                                           // 0x00A4(0x0008)
		struct Fstx_ui_fort_result_v00__letters_all                l_letters_all;                                           // 0x00AC(0x00C8)
		struct Fstx_ui_fort_result_v00__2p_all                     l_2p_all;                                                // 0x0174(0x00E0)
		struct Fstx_ui_fort_result_v00__1p_all                     l_1p_all;                                                // 0x0254(0x01D0)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_Result_v00_Lang
	 * Size -> 0x0078 (FullSize[0x0104] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_Result_v00_Lang : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_fort_result_v00_int__image_failed_all       l_image_failed_all;                                      // 0x0094(0x0018)
		struct Fstx_ui_fort_result_v00_int__image_success_all      l_image_success_all;                                     // 0x00AC(0x0018)
		struct Fstx_ui_fort_result_v00_int__image_time_all         l_image_time_all;                                        // 0x00C4(0x0018)
		struct Fstx_ui_fort_result_v00_int__image_start_all        l_image_start_all;                                       // 0x00DC(0x0018)
		class FString                                              mLangStr;                                                // 0x00F4(0x0010) NeedCtorLink

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_Result_v01
	 * Size -> 0x0170 (FullSize[0x01FC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_Result_v01 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_fort_result_v01__reward_v00                 l_reward_v00;                                            // 0x0094(0x0030)
		class UBrgUIImage*                                         l__guide_base_v01;                                       // 0x00C4(0x0008)
		class UBrgUIImage*                                         l__guide_base_v00;                                       // 0x00CC(0x0008)
		class UBrgUIImage*                                         l_base_v00;                                              // 0x00D4(0x0008)
		struct Fstx_ui_fort_result_v01__icon_bag_all               l_icon_bag_all;                                          // 0x00DC(0x0080)
		struct Fstx_ui_fort_result_v01__text_all                   l_text_all;                                              // 0x015C(0x0080)
		struct Fstx_ui_fort_result_v01___guide_icon_all            l__guide_icon_all;                                       // 0x01DC(0x0020)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_RoomCustom_v00
	 * Size -> 0x0160 (FullSize[0x01EC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_RoomCustom_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_fort_roomcustom_v00__pattern_all            l_pattern_all;                                           // 0x0094(0x0088)
		struct Fstx_ui_fort_roomcustom_v00__set_all                l_set_all;                                               // 0x011C(0x0058)
		struct Fstx_ui_fort_roomcustom_v00__thumbnail_all          l_thumbnail_all;                                         // 0x0174(0x0068)
		class UBrgUIImage*                                         l_mask_pattern_v00;                                      // 0x01DC(0x0008)
		class UBrgUIImage*                                         l_mask_set_v00;                                          // 0x01E4(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_TeamChange_v00
	 * Size -> 0x0150 (FullSize[0x01DC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_TeamChange_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_fort_teamchange_v00___bg                    l__bg;                                                   // 0x008C(0x0058)
		struct Fstx_ui_fort_teamchange_v00__teamlist_all           l_teamlist_all;                                          // 0x00E4(0x00B8)
		struct Fstx_ui_fort_teamchange_v00__areaforce_s_all        l_areaforce_s_all;                                       // 0x019C(0x0030)
		struct Fstx_ui_fort_teamchange_v00__hate_all               l_hate_all;                                              // 0x01CC(0x0008)
		struct Fstx_ui_fort_teamchange_v00__team_all               l_team_all;                                              // 0x01D4(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_Top_v00
	 * Size -> 0x03E8 (FullSize[0x0474] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_Top_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_fort_top_v00___bg                           l__bg;                                                   // 0x008C(0x0058)
		struct Fstx_ui_fort_top_v00__areaforce_l_all               l_areaforce_l_all;                                       // 0x00E4(0x0080)
		struct Fstx_ui_fort_top_v00__teamflag_all                  l_teamflag_all;                                          // 0x0164(0x0020)
		struct Fstx_ui_fort_top_v00__hate_all                      l_hate_all;                                              // 0x0184(0x0008)
		struct Fstx_ui_fort_top_v00__team_all                      l_team_all;                                              // 0x018C(0x0008)
		struct Fstx_ui_fort_top_v00__battlerush_all                l_battlerush_all;                                        // 0x0194(0x0160)
		struct Fstx_ui_fort_top_v00__rank_all                      l_rank_all;                                              // 0x02F4(0x0178)
		class UBrgUIImage*                                         l_guide_report_raid_all;                                 // 0x046C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Fort_Whistle_v00
	 * Size -> 0x0368 (FullSize[0x03F4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Fort_Whistle_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_fort_whistle_v00___bg                       l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_fort_whistle_v00__reinforce_all             l_reinforce_all;                                         // 0x0094(0x0228)
		struct Fstx_ui_fort_whistle_v00__select_all                l_select_all;                                            // 0x02BC(0x0110)
		struct Fstx_ui_fort_whistle_v00__scrollbar                 l_scrollbar;                                             // 0x03CC(0x0028)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_FortMonitor
	 * Size -> 0x0088 (FullSize[0x0114] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_FortMonitor : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_myteam_v01;                                       // 0x0094(0x0008)
		class UBrgUIImage*                                         l_base_myteam_v00;                                       // 0x009C(0x0008)
		class UBrgUIImage*                                         l_base_others_v00;                                       // 0x00A4(0x0008)
		struct Fstx_ui_fort_monitor_v00__text_all                  l_text_all;                                              // 0x00AC(0x0058)
		struct Fstx_ui_fort_monitor_v00___guide_teamflag_all       l__guide_teamflag_all;                                   // 0x0104(0x0010)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_FreeContinue
	 * Size -> 0x0048 (FullSize[0x00D4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_FreeContinue : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_base_v00;                                              // 0x008C(0x0008)
		struct Fstx_ui_freecontinue_v00__balloon_all               l_balloon_all;                                           // 0x0094(0x0030)
		struct Fstx_ui_freecontinue_v00__title                     l_title;                                                 // 0x00C4(0x0008)
		class UBrgUIImage*                                         l__buttonguide;                                          // 0x00CC(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_FreezerMenu_STM_Name_v00
	 * Size -> 0x0034 (FullSize[0x00C0] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_FreezerMenu_STM_Name_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_freezermenu_stm_name_v00__name_all          l_name_all;                                              // 0x0094(0x0028)
		unsigned long                                              mAddBlendDraw : 1;                                       // 0x00BC(0x0001) BIT_FIELD

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_FreezerMenu_v01
	 * Size -> 0x1088 (FullSize[0x1114] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_FreezerMenu_v01 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_freezermenu_v01___bg                        l__bg;                                                   // 0x008C(0x0020)
		struct Fstx_ui_freezermenu_v01__result_all                 l_result_all;                                            // 0x00AC(0x0430)
		struct Fstx_ui_freezermenu_v01__confirm_all                l_confirm_all;                                           // 0x04DC(0x0108)
		struct Fstx_ui_freezermenu_v01__fighter_list_all           l_fighter_list_all;                                      // 0x05E4(0x0240)
		struct Fstx_ui_freezermenu_v01__top_all                    l_top_all;                                               // 0x0824(0x08E0)
		struct Fstx_ui_freezermenu_v01__psn_resource_name_all      l_psn_resource_name_all;                                 // 0x1104(0x0010)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_HUD6
	 * Size -> 0x0B60 (FullSize[0x0BEC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_HUD6 : public UBrgUIResource_Common
	{
	public:
		EBrgUIResource_HUD6_UseMaskType                            mUseMask;                                                // 0x008C(0x0001)
		unsigned char                                              UnknownData_3APN[0x3];                                   // 0x008D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		unsigned long                                              mAddBlendDraw : 1;                                       // 0x0090(0x0001) BIT_FIELD
		struct Fstx_ui_hud_base_status_v06___bg                    l__bg;                                                   // 0x0094(0x0008)
		class UBrgUIImage*                                         l_gauge_timecount_stm_v01;                               // 0x009C(0x0008)
		class UBrgUIImage*                                         l_gauge_timecount_stm_v00;                               // 0x00A4(0x0008)
		struct Fstx_ui_hud_base_status_v06__tutorial_all           l_tutorial_all;                                          // 0x00AC(0x0028)
		struct Fstx_ui_hud_base_status_v06__button_action_all      l_button_action_all;                                     // 0x00D4(0x0040)
		struct Fstx_ui_hud_base_status_v06__guide_goretical        l_guide_goretical;                                       // 0x0114(0x0030)
		struct Fstx_ui_hud_base_status_v06__bossfinish_all         l_bossfinish_all;                                        // 0x0144(0x0030)
		class UBrgUIImage*                                         l__bg_v01;                                               // 0x0174(0x0008)
		struct Fstx_ui_hud_base_status_v06__equip_armour_all       l_equip_armour_all;                                      // 0x017C(0x00C0)
		struct Fstx_ui_hud_base_status_v06__info_enemy_all         l_info_enemy_all;                                        // 0x023C(0x0028)
		struct Fstx_ui_hud_base_status_v06__health_boss_all        l_health_boss_all;                                       // 0x0264(0x0028)
		class UBrgUIImage*                                         l_icon_retile_v01;                                       // 0x028C(0x0008)
		class UBrgUIImage*                                         l_icon_retile_v00;                                       // 0x0294(0x0008)
		struct Fstx_ui_hud_base_status_v06__status_enemypc_all     l_status_enemypc_all;                                    // 0x029C(0x0060)
		struct Fstx_ui_hud_base_status_v06__status_enemy_all       l_status_enemy_all;                                      // 0x02FC(0x0020)
		struct Fstx_ui_hud_base_status_v06__lockon_quick           l_lockon_quick;                                          // 0x031C(0x0008)
		struct Fstx_ui_hud_base_status_v06__deathbox_all           l_deathbox_all;                                          // 0x0324(0x0028)
		class UBrgUIImage*                                         l__bg_v03;                                               // 0x034C(0x0008)
		struct Fstx_ui_hud_base_status_v06__subtitle_all           l_subtitle_all;                                          // 0x0354(0x0010)
		struct Fstx_ui_hud_base_status_v06__floor_info_all         l_floor_info_all;                                        // 0x0364(0x0030)
		struct Fstx_ui_hud_base_status_v06__timecount_all          l_timecount_all;                                         // 0x0394(0x0068)
		struct Fstx_ui_hud_base_status_v06__point_all              l_point_all;                                             // 0x03FC(0x00A0)
		struct Fstx_ui_hud_base_status_v06__timecount_vip_all      l_timecount_vip_all;                                     // 0x049C(0x0020)
		struct Fstx_ui_hud_base_status_v06__locater                l_locater;                                               // 0x04BC(0x0010)
		struct Fstx_ui_hud_base_status_v06__message_all            l_message_all;                                           // 0x04CC(0x0068)
		struct Fstx_ui_hud_base_status_v06__floorname_all          l_floorname_all;                                         // 0x0534(0x0008)
		struct Fstx_ui_hud_base_status_v06__info_exp               l_info_exp;                                              // 0x053C(0x0018)
		struct Fstx_ui_hud_base_status_v06__info_abp               l_info_abp;                                              // 0x0554(0x0018)
		struct Fstx_ui_hud_base_status_v06__info_critical          l_info_critical;                                         // 0x056C(0x0008)
		struct Fstx_ui_hud_base_status_v06__info_guard             l_info_guard;                                            // 0x0574(0x0008)
		class UBrgUIImage*                                         l__bg_v04;                                               // 0x057C(0x0008)
		struct Fstx_ui_hud_base_status_v06__info_all               l_info_all;                                              // 0x0584(0x01A0)
		class UBrgUIImage*                                         l__bg_v05;                                               // 0x0724(0x0008)
		struct Fstx_ui_hud_base_status_v06__skill_pc_all           l_skill_pc_all;                                          // 0x072C(0x00D8)
		struct Fstx_ui_hud_base_status_v06__statas_all             l_statas_all;                                            // 0x0804(0x00A0)
		struct Fstx_ui_hud_base_status_v06__ragegauge_all          l_ragegauge_all;                                         // 0x08A4(0x0018)
		struct Fstx_ui_hud_base_status_v06__health_all             l_health_all;                                            // 0x08BC(0x0050)
		class UBrgUIImage*                                         l__bg_v06;                                               // 0x090C(0x0008)
		struct Fstx_ui_hud_base_status_v06__item_all               l_item_all;                                              // 0x0914(0x0118)
		struct Fstx_ui_hud_base_status_v06__stm                    l_stm;                                                   // 0x0A2C(0x0098)
		class UBrgUIImage*                                         l__bg_v07;                                               // 0x0AC4(0x0008)
		struct Fstx_ui_hud_base_status_v06__equip_all              l_equip_all;                                             // 0x0ACC(0x0120)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Icon_Info_v00
	 * Size -> 0x1710 (FullSize[0x179C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Icon_Info_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg_action;                                            // 0x008C(0x0008)
		struct Fstx_ui_icon_info_v00__action_hud_item_all          l_action_hud_item_all;                                   // 0x0094(0x0250)
		class UBrgUIImage*                                         l__bg_info_item;                                         // 0x02E4(0x0008)
		struct Fstx_ui_icon_info_v00__info_item_all                l_info_item_all;                                         // 0x02EC(0x04D8)
		class UBrgUIImage*                                         l__bg_material;                                          // 0x07C4(0x0008)
		struct Fstx_ui_icon_info_v00__material_item_all            l_material_item_all;                                     // 0x07CC(0x0020)
		struct Fstx_ui_icon_info_v00__material_r_item_all          l_material_r_item_all;                                   // 0x07EC(0x03A0)
		struct Fstx_ui_icon_info_v00__material_n_item_all          l_material_n_item_all;                                   // 0x0B8C(0x0300)
		class UBrgUIImage*                                         l__bg_subtitle;                                          // 0x0E8C(0x0008)
		class UBrgUIImage*                                         l__memo_subtitle;                                        // 0x0E94(0x0008)
		struct Fstx_ui_icon_info_v00__skin_all                     l_skin_all;                                              // 0x0E9C(0x0030)
		struct Fstx_ui_icon_info_v00__fighter_all                  l_fighter_all;                                           // 0x0ECC(0x0030)
		struct Fstx_ui_icon_info_v00__prison_all                   l_prison_all;                                            // 0x0EFC(0x0030)
		struct Fstx_ui_icon_info_v00__freezer_all                  l_freezer_all;                                           // 0x0F2C(0x0220)
		struct Fstx_ui_icon_info_v00__rewardbox_item_all           l_rewardbox_item_all;                                    // 0x114C(0x0170)
		struct Fstx_ui_icon_info_v00__sort_item_all                l_sort_item_all;                                         // 0x12BC(0x0188)
		struct Fstx_ui_icon_info_v00__action_item_all              l_action_item_all;                                       // 0x1444(0x00F0)
		struct Fstx_ui_icon_info_v00__subtitle_item_all            l_subtitle_item_all;                                     // 0x1534(0x01A8)
		class UBrgUIImage*                                         l__bg;                                                   // 0x16DC(0x0008)
		struct Fstx_ui_icon_info_v00__mysterybag_all               l_mysterybag_all;                                        // 0x16E4(0x0060)
		struct Fstx_ui_icon_info_v00__hernia_all                   l_hernia_all;                                            // 0x1744(0x0050)
		EBrgUIResource_Icon_Info_v00_UseMaskType                   mUseMask;                                                // 0x1794(0x0001)
		unsigned char                                              UnknownData_93DC[0x3];                                   // 0x1795(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		unsigned long                                              mAddBlendDraw : 1;                                       // 0x1798(0x0001) BIT_FIELD

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Icon_Info_v01
	 * Size -> 0x08D1 (FullSize[0x095D] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Icon_Info_v01 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_icon_info_v01__stefcicon_all                l_stefcicon_all;                                         // 0x0094(0x0208)
		struct Fstx_ui_icon_info_v01__master_level2                l_master_level2;                                         // 0x029C(0x0360)
		struct Fstx_ui_icon_info_v01__master_level                 l_master_level;                                          // 0x05FC(0x0360)
		EBrgUIResource_Icon_Info_v01_UseMaskType                   mUseMask;                                                // 0x095C(0x0001)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Icon_Info_v02
	 * Size -> 0x0549 (FullSize[0x05D5] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Icon_Info_v02 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_icon_info_v02__reinforce_all                l_reinforce_all;                                         // 0x0094(0x0090)
		struct Fstx_ui_icon_info_v02__ftypicon_enma_all            l_ftypicon_enma_all;                                     // 0x0124(0x0108)
		struct Fstx_ui_icon_info_v02__ftypicon_all                 l_ftypicon_all;                                          // 0x022C(0x0088)
		struct Fstx_ui_icon_info_v02__tdmicon_all                  l_tdmicon_all;                                           // 0x02B4(0x0138)
		struct Fstx_ui_icon_info_v02__resourceicon_all             l_resourceicon_all;                                      // 0x03EC(0x0038)
		struct Fstx_ui_icon_info_v02__upgradeicon_all              l_upgradeicon_all;                                       // 0x0424(0x0048)
		struct Fstx_ui_icon_info_v02__tabicon_all                  l_tabicon_all;                                           // 0x046C(0x00B8)
		struct Fstx_ui_icon_info_v02__menuicon_all                 l_menuicon_all;                                          // 0x0524(0x00A8)
		class UBrgUIImage*                                         l__memo_yoshimura;                                       // 0x05CC(0x0008)
		EBrgUIResource_Icon_Info_v02_UseMaskType                   mUseMask;                                                // 0x05D4(0x0001)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Icon_MiniMap
	 * Size -> 0x0240 (FullSize[0x02CC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Icon_MiniMap : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_icon_minimap_v00__minimap_v00               l_minimap_v00;                                           // 0x0094(0x0018)
		struct Fstx_ui_icon_minimap_v00__minimap_v01               l_minimap_v01;                                           // 0x00AC(0x0010)
		struct Fstx_ui_icon_minimap_v00__minimap_v02               l_minimap_v02;                                           // 0x00BC(0x0010)
		struct Fstx_ui_icon_minimap_v00__minimap_v03               l_minimap_v03;                                           // 0x00CC(0x0010)
		struct Fstx_ui_icon_minimap_v00__minimap_v04               l_minimap_v04;                                           // 0x00DC(0x0010)
		struct Fstx_ui_icon_minimap_v00__minimap_v05               l_minimap_v05;                                           // 0x00EC(0x0010)
		struct Fstx_ui_icon_minimap_v00__minimap_v06               l_minimap_v06;                                           // 0x00FC(0x0010)
		struct Fstx_ui_icon_minimap_v00__minimap_v07               l_minimap_v07;                                           // 0x010C(0x0010)
		struct Fstx_ui_icon_minimap_v00__minimap_v08               l_minimap_v08;                                           // 0x011C(0x0010)
		struct Fstx_ui_icon_minimap_v00__minimap_v10               l_minimap_v10;                                           // 0x012C(0x0010)
		struct Fstx_ui_icon_minimap_v00__minimap_v11               l_minimap_v11;                                           // 0x013C(0x0010)
		struct Fstx_ui_icon_minimap_v00__minimap_v12               l_minimap_v12;                                           // 0x014C(0x0010)
		struct Fstx_ui_icon_minimap_v00__minimap_v13               l_minimap_v13;                                           // 0x015C(0x0010)
		struct Fstx_ui_icon_minimap_v00__minimap_v14               l_minimap_v14;                                           // 0x016C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_enemypc            l_result_enemypc;                                        // 0x017C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_kill_v00           l_result_kill_v00;                                       // 0x018C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_kill_v01           l_result_kill_v01;                                       // 0x019C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_kill_v02           l_result_kill_v02;                                       // 0x01AC(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_kill_v03           l_result_kill_v03;                                       // 0x01BC(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_kill_v04           l_result_kill_v04;                                       // 0x01CC(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_kill_v05           l_result_kill_v05;                                       // 0x01DC(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_eat_v00            l_result_eat_v00;                                        // 0x01EC(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_eat_v01            l_result_eat_v01;                                        // 0x01FC(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_getitem_v00        l_result_getitem_v00;                                    // 0x020C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_getitem_v01        l_result_getitem_v01;                                    // 0x021C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_getitem_v02        l_result_getitem_v02;                                    // 0x022C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_getitem_v03        l_result_getitem_v03;                                    // 0x023C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_getequip_v00       l_result_getequip_v00;                                   // 0x024C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_getequip_v01       l_result_getequip_v01;                                   // 0x025C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_getequip_v02       l_result_getequip_v02;                                   // 0x026C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_getequip_v03       l_result_getequip_v03;                                   // 0x027C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_killcoin           l_result_killcoin;                                       // 0x028C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_buy                l_result_buy;                                            // 0x029C(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_break_v00          l_result_break_v00;                                      // 0x02AC(0x0010)
		struct Fstx_ui_icon_minimap_v00__result_break_v01          l_result_break_v01;                                      // 0x02BC(0x0010)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Icon_Network
	 * Size -> 0x00F8 (FullSize[0x0184] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Icon_Network : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_icon_network_v00___bg                       l__bg;                                                   // 0x008C(0x0008)
		class UBrgUIImage*                                         l_icon_network_v24;                                      // 0x0094(0x0008)
		class UBrgUIImage*                                         l_icon_network_v00;                                      // 0x009C(0x0008)
		class UBrgUIImage*                                         l_icon_network_v01;                                      // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_icon_network_v02;                                      // 0x00AC(0x0008)
		class UBrgUIImage*                                         l_icon_network_v03;                                      // 0x00B4(0x0008)
		class UBrgUIImage*                                         l_icon_network_v04;                                      // 0x00BC(0x0008)
		class UBrgUIImage*                                         l_icon_network_v05;                                      // 0x00C4(0x0008)
		class UBrgUIImage*                                         l_icon_network_v06;                                      // 0x00CC(0x0008)
		class UBrgUIImage*                                         l_icon_network_v07;                                      // 0x00D4(0x0008)
		class UBrgUIImage*                                         l_icon_network_v08;                                      // 0x00DC(0x0008)
		class UBrgUIImage*                                         l_icon_network_v09;                                      // 0x00E4(0x0008)
		class UBrgUIImage*                                         l_icon_network_v10;                                      // 0x00EC(0x0008)
		class UBrgUIImage*                                         l_icon_network_v11;                                      // 0x00F4(0x0008)
		class UBrgUIImage*                                         l_icon_network_v12;                                      // 0x00FC(0x0008)
		class UBrgUIImage*                                         l_icon_network_v13;                                      // 0x0104(0x0008)
		class UBrgUIImage*                                         l_icon_network_v14;                                      // 0x010C(0x0008)
		class UBrgUIImage*                                         l_icon_network_v15;                                      // 0x0114(0x0008)
		class UBrgUIImage*                                         l_icon_network_v16;                                      // 0x011C(0x0008)
		class UBrgUIImage*                                         l_icon_network_v17;                                      // 0x0124(0x0008)
		class UBrgUIImage*                                         l_icon_network_v18;                                      // 0x012C(0x0008)
		class UBrgUIImage*                                         l_icon_network_v19;                                      // 0x0134(0x0008)
		class UBrgUIImage*                                         l_icon_network_v20;                                      // 0x013C(0x0008)
		class UBrgUIImage*                                         l_icon_network_v21;                                      // 0x0144(0x0008)
		class UBrgUIImage*                                         l_icon_network_v22;                                      // 0x014C(0x0008)
		class UBrgUIImage*                                         l_icon_network_v23;                                      // 0x0154(0x0008)
		class UBrgUIImage*                                         l__guide_icon_network2;                                  // 0x015C(0x0008)
		class UBrgUIImage*                                         l__guide_icon_network;                                   // 0x0164(0x0008)
		class UBrgUIImage*                                         l__guide_text;                                           // 0x016C(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim;                                         // 0x0174(0x0008)
		class UBrgUISpriteAnim*                                    mBlinkSpriteAnim;                                        // 0x017C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Insurance
	 * Size -> 0x0050 (FullSize[0x00DC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Insurance : public UBrgUIResource_Common
	{
	public:
		class UBrgUITexture2DLoader*                               mFlipTexture[0x5];                                       // 0x008C(0x0028)
		class UBrgUIImage*                                         mFlipImage[0x5];                                         // 0x00B4(0x0028)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		bool SetImageLoadState(bool IsLoad, bool IsLoadCompCheckOnly);
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_InsuranceMenu
	 * Size -> 0x0480 (FullSize[0x050C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_InsuranceMenu : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_insurancemenu_v00___bg                      l__bg;                                                   // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_flip_v00;                                         // 0x0094(0x0008)
		struct Fstx_ui_insurancemenu_v00__flip_all                 l_flip_all;                                              // 0x009C(0x01B8)
		struct Fstx_ui_insurancemenu_v00__timelimit_all            l_timelimit_all;                                         // 0x0254(0x0090)
		struct Fstx_ui_insurancemenu_v00__item_all                 l_item_all;                                              // 0x02E4(0x0028)
		struct Fstx_ui_insurancemenu_v00__balloon_w_all            l_balloon_w_all;                                         // 0x030C(0x0078)
		struct Fstx_ui_insurancemenu_v00__realization_all          l_realization_all;                                       // 0x0384(0x00B0)
		struct Fstx_ui_insurancemenu_v00__vip_all                  l_vip_all;                                               // 0x0434(0x0068)
		struct Fstx_ui_insurancemenu_v00__vipupdate_all            l_vipupdate_all;                                         // 0x049C(0x0048)
		struct Fstx_ui_insurancemenu_v00__locker_all               l_locker_all;                                            // 0x04E4(0x0028)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_InsuranceMenu_Cover_v00
	 * Size -> 0x0098 (FullSize[0x0124] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_InsuranceMenu_Cover_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_insurancemenu_cover_v00___bg                l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_insurancemenu_cover_v00__cover_all          l_cover_all;                                             // 0x0094(0x0090)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_InsuranceMenu_v00_00
	 * Size -> 0x01E0 (FullSize[0x026C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_InsuranceMenu_v00_00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_insurancemenu_v00_00__flip_all              l_flip_all;                                              // 0x008C(0x01B8)
		struct Fstx_ui_insurancemenu_v00_00__item_all              l_item_all;                                              // 0x0244(0x0028)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_ItemIcon
	 * Size -> 0x0808 (FullSize[0x0894] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_ItemIcon : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_icon_item_v00__image_item_all               l_image_item_all;                                        // 0x008C(0x07D8)
		class UBrgUIImage*                                         l__guide_frame_item;                                     // 0x0864(0x0008)
		class UBrgUIImageMapInfoGroup*                             mArmGroup;                                               // 0x086C(0x0008)
		class UBrgUIImageMapInfoGroup*                             mHeadGroup;                                              // 0x0874(0x0008)
		class UBrgUIImageMapInfoGroup*                             mTopsGroup;                                              // 0x087C(0x0008)
		class UBrgUIImageMapInfoGroup*                             mBottomsGroup;                                           // 0x0884(0x0008)
		class UBrgUIImageMapInfoGroup*                             mMushroomGroup;                                          // 0x088C(0x0008)

	public:
		class UBrgUIImage* GetMushroomIconImage(const class FString& inMushroomID);
		class UBrgUIImage* GetPartIconImage(const class FString& inPartID);
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_ItemIconS
	 * Size -> 0x0258 (FullSize[0x02E4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_ItemIconS : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_icon_item_s_v00__image_item_s_all           l_image_item_s_all;                                      // 0x008C(0x0248)
		class UBrgUIImage*                                         l__guide_frame_items;                                    // 0x02D4(0x0008)
		class UBrgUIImageMapInfoGroup*                             mArmGroup;                                               // 0x02DC(0x0008)

	public:
		class UBrgUIImage* GetPartIconImage(const class FString& inPartID);
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_ItemLMenu
	 * Size -> 0x0218 (FullSize[0x02A4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_ItemLMenu : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_itemlmenu_v00__menu_all                     l_menu_all;                                              // 0x0094(0x0210)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Loading_v00
	 * Size -> 0x0098 (FullSize[0x0124] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Loading_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_image_death_v16;                                       // 0x008C(0x0008)
		class UBrgUIImage*                                         l_image_death_v15;                                       // 0x0094(0x0008)
		class UBrgUIImage*                                         l_image_death_v14;                                       // 0x009C(0x0008)
		class UBrgUIImage*                                         l_image_death_v13;                                       // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_image_death_v12;                                       // 0x00AC(0x0008)
		class UBrgUIImage*                                         l_image_death_v11;                                       // 0x00B4(0x0008)
		class UBrgUIImage*                                         l_image_death_v10;                                       // 0x00BC(0x0008)
		class UBrgUIImage*                                         l_image_death_v09;                                       // 0x00C4(0x0008)
		class UBrgUIImage*                                         l_image_death_v08;                                       // 0x00CC(0x0008)
		class UBrgUIImage*                                         l_image_death_v07;                                       // 0x00D4(0x0008)
		class UBrgUIImage*                                         l_image_death_v06;                                       // 0x00DC(0x0008)
		class UBrgUIImage*                                         l_image_death_v05;                                       // 0x00E4(0x0008)
		class UBrgUIImage*                                         l_image_death_v04;                                       // 0x00EC(0x0008)
		class UBrgUIImage*                                         l_image_death_v03;                                       // 0x00F4(0x0008)
		class UBrgUIImage*                                         l_image_death_v02;                                       // 0x00FC(0x0008)
		class UBrgUIImage*                                         l_image_death_v01;                                       // 0x0104(0x0008)
		class UBrgUIImage*                                         l_image_death_v00;                                       // 0x010C(0x0008)
		class UBrgUISpriteAnim*                                    mRootSpriteAnim;                                         // 0x0114(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim;                                         // 0x011C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Loading_v00_Blue
	 * Size -> 0x0098 (FullSize[0x0124] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Loading_v00_Blue : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_image_death_v16;                                       // 0x008C(0x0008)
		class UBrgUIImage*                                         l_image_death_v15;                                       // 0x0094(0x0008)
		class UBrgUIImage*                                         l_image_death_v14;                                       // 0x009C(0x0008)
		class UBrgUIImage*                                         l_image_death_v13;                                       // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_image_death_v12;                                       // 0x00AC(0x0008)
		class UBrgUIImage*                                         l_image_death_v11;                                       // 0x00B4(0x0008)
		class UBrgUIImage*                                         l_image_death_v10;                                       // 0x00BC(0x0008)
		class UBrgUIImage*                                         l_image_death_v09;                                       // 0x00C4(0x0008)
		class UBrgUIImage*                                         l_image_death_v08;                                       // 0x00CC(0x0008)
		class UBrgUIImage*                                         l_image_death_v07;                                       // 0x00D4(0x0008)
		class UBrgUIImage*                                         l_image_death_v06;                                       // 0x00DC(0x0008)
		class UBrgUIImage*                                         l_image_death_v05;                                       // 0x00E4(0x0008)
		class UBrgUIImage*                                         l_image_death_v04;                                       // 0x00EC(0x0008)
		class UBrgUIImage*                                         l_image_death_v03;                                       // 0x00F4(0x0008)
		class UBrgUIImage*                                         l_image_death_v02;                                       // 0x00FC(0x0008)
		class UBrgUIImage*                                         l_image_death_v01;                                       // 0x0104(0x0008)
		class UBrgUIImage*                                         l_image_death_v00;                                       // 0x010C(0x0008)
		class UBrgUISpriteAnim*                                    mRootSpriteAnim;                                         // 0x0114(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim;                                         // 0x011C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Loading_v00_Bronze
	 * Size -> 0x0098 (FullSize[0x0124] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Loading_v00_Bronze : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_image_death_v16;                                       // 0x008C(0x0008)
		class UBrgUIImage*                                         l_image_death_v15;                                       // 0x0094(0x0008)
		class UBrgUIImage*                                         l_image_death_v14;                                       // 0x009C(0x0008)
		class UBrgUIImage*                                         l_image_death_v13;                                       // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_image_death_v12;                                       // 0x00AC(0x0008)
		class UBrgUIImage*                                         l_image_death_v11;                                       // 0x00B4(0x0008)
		class UBrgUIImage*                                         l_image_death_v10;                                       // 0x00BC(0x0008)
		class UBrgUIImage*                                         l_image_death_v09;                                       // 0x00C4(0x0008)
		class UBrgUIImage*                                         l_image_death_v08;                                       // 0x00CC(0x0008)
		class UBrgUIImage*                                         l_image_death_v07;                                       // 0x00D4(0x0008)
		class UBrgUIImage*                                         l_image_death_v06;                                       // 0x00DC(0x0008)
		class UBrgUIImage*                                         l_image_death_v05;                                       // 0x00E4(0x0008)
		class UBrgUIImage*                                         l_image_death_v04;                                       // 0x00EC(0x0008)
		class UBrgUIImage*                                         l_image_death_v03;                                       // 0x00F4(0x0008)
		class UBrgUIImage*                                         l_image_death_v02;                                       // 0x00FC(0x0008)
		class UBrgUIImage*                                         l_image_death_v01;                                       // 0x0104(0x0008)
		class UBrgUIImage*                                         l_image_death_v00;                                       // 0x010C(0x0008)
		class UBrgUISpriteAnim*                                    mRootSpriteAnim;                                         // 0x0114(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim;                                         // 0x011C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Loading_v00_Gold
	 * Size -> 0x0098 (FullSize[0x0124] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Loading_v00_Gold : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_image_death_v16;                                       // 0x008C(0x0008)
		class UBrgUIImage*                                         l_image_death_v15;                                       // 0x0094(0x0008)
		class UBrgUIImage*                                         l_image_death_v14;                                       // 0x009C(0x0008)
		class UBrgUIImage*                                         l_image_death_v13;                                       // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_image_death_v12;                                       // 0x00AC(0x0008)
		class UBrgUIImage*                                         l_image_death_v11;                                       // 0x00B4(0x0008)
		class UBrgUIImage*                                         l_image_death_v10;                                       // 0x00BC(0x0008)
		class UBrgUIImage*                                         l_image_death_v09;                                       // 0x00C4(0x0008)
		class UBrgUIImage*                                         l_image_death_v08;                                       // 0x00CC(0x0008)
		class UBrgUIImage*                                         l_image_death_v07;                                       // 0x00D4(0x0008)
		class UBrgUIImage*                                         l_image_death_v06;                                       // 0x00DC(0x0008)
		class UBrgUIImage*                                         l_image_death_v05;                                       // 0x00E4(0x0008)
		class UBrgUIImage*                                         l_image_death_v04;                                       // 0x00EC(0x0008)
		class UBrgUIImage*                                         l_image_death_v03;                                       // 0x00F4(0x0008)
		class UBrgUIImage*                                         l_image_death_v02;                                       // 0x00FC(0x0008)
		class UBrgUIImage*                                         l_image_death_v01;                                       // 0x0104(0x0008)
		class UBrgUIImage*                                         l_image_death_v00;                                       // 0x010C(0x0008)
		class UBrgUISpriteAnim*                                    mRootSpriteAnim;                                         // 0x0114(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim;                                         // 0x011C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Loading_v00_Silver
	 * Size -> 0x0098 (FullSize[0x0124] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Loading_v00_Silver : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_image_death_v16;                                       // 0x008C(0x0008)
		class UBrgUIImage*                                         l_image_death_v15;                                       // 0x0094(0x0008)
		class UBrgUIImage*                                         l_image_death_v14;                                       // 0x009C(0x0008)
		class UBrgUIImage*                                         l_image_death_v13;                                       // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_image_death_v12;                                       // 0x00AC(0x0008)
		class UBrgUIImage*                                         l_image_death_v11;                                       // 0x00B4(0x0008)
		class UBrgUIImage*                                         l_image_death_v10;                                       // 0x00BC(0x0008)
		class UBrgUIImage*                                         l_image_death_v09;                                       // 0x00C4(0x0008)
		class UBrgUIImage*                                         l_image_death_v08;                                       // 0x00CC(0x0008)
		class UBrgUIImage*                                         l_image_death_v07;                                       // 0x00D4(0x0008)
		class UBrgUIImage*                                         l_image_death_v06;                                       // 0x00DC(0x0008)
		class UBrgUIImage*                                         l_image_death_v05;                                       // 0x00E4(0x0008)
		class UBrgUIImage*                                         l_image_death_v04;                                       // 0x00EC(0x0008)
		class UBrgUIImage*                                         l_image_death_v03;                                       // 0x00F4(0x0008)
		class UBrgUIImage*                                         l_image_death_v02;                                       // 0x00FC(0x0008)
		class UBrgUIImage*                                         l_image_death_v01;                                       // 0x0104(0x0008)
		class UBrgUIImage*                                         l_image_death_v00;                                       // 0x010C(0x0008)
		class UBrgUISpriteAnim*                                    mRootSpriteAnim;                                         // 0x0114(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim;                                         // 0x011C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_MiniGame_STM_v00
	 * Size -> 0x0194 (FullSize[0x0220] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_MiniGame_STM_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_minigame_stm_v00___bg                       l__bg;                                                   // 0x008C(0x0018)
		struct Fstx_ui_minigame_stm_v00__mark_all                  l_mark_all;                                              // 0x00A4(0x0120)
		struct Fstx_ui_minigame_stm_v00__button_all                l_button_all;                                            // 0x01C4(0x0058)
		unsigned long                                              mAddBlendDraw : 1;                                       // 0x021C(0x0001) BIT_FIELD

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_MiniGame_v00
	 * Size -> 0x02D4 (FullSize[0x0360] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_MiniGame_v00 : public UBrgUIResource_Common
	{
	public:
		EBrgUIResource_MiniGame_v00_UseMaskType                    mUseMask;                                                // 0x008C(0x0001)
		unsigned char                                              UnknownData_Y7B9[0x3];                                   // 0x008D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct Fstx_ui_minigame_v00___bg                           l__bg;                                                   // 0x0090(0x0018)
		class UBrgUIImage*                                         l_base_bg;                                               // 0x00A8(0x0008)
		struct Fstx_ui_minigame_v00__line_all                      l_line_all;                                              // 0x00B0(0x0098)
		struct Fstx_ui_minigame_v00__neon_left_all                 l_neon_left_all;                                         // 0x0148(0x0018)
		struct Fstx_ui_minigame_v00__neon_right_all                l_neon_right_all;                                        // 0x0160(0x0018)
		struct Fstx_ui_minigame_v00__mark_all                      l_mark_all;                                              // 0x0178(0x0128)
		struct Fstx_ui_minigame_v00__count                         l_count;                                                 // 0x02A0(0x0038)
		struct Fstx_ui_minigame_v00__miss                          l_miss;                                                  // 0x02D8(0x0010)
		struct Fstx_ui_minigame_v00__good                          l_good;                                                  // 0x02E8(0x0010)
		struct Fstx_ui_minigame_v00__perfect                       l_perfect;                                               // 0x02F8(0x0038)
		struct Fstx_ui_minigame_v00__button_all                    l_button_all;                                            // 0x0330(0x0030)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_MotherBarbs
	 * Size -> 0x0140 (FullSize[0x01CC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_MotherBarbs : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_motherbarbs_v00___bg                        l__bg;                                                   // 0x008C(0x0010)
		class UBrgUIImage*                                         l_base_title_motherbarbs_off;                            // 0x009C(0x0008)
		class UBrgUIImage*                                         l_base_title_motherbarbs;                                // 0x00A4(0x0008)
		struct Fstx_ui_motherbarbs_v00__base_ravel_all             l_base_ravel_all;                                        // 0x00AC(0x0120)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Mushroom_v00
	 * Size -> 0x0148 (FullSize[0x01D4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Mushroom_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg_v00;                                               // 0x008C(0x0008)
		struct Fstx_ui_mushroom_v00__base_v02_all                  l_base_v02_all;                                          // 0x0094(0x0050)
		struct Fstx_ui_mushroom_v00__base_v01_all                  l_base_v01_all;                                          // 0x00E4(0x0048)
		struct Fstx_ui_mushroom_v00__base_v00_all                  l_base_v00_all;                                          // 0x012C(0x00A8)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_NaomiQuests
	 * Size -> 0x0970 (FullSize[0x09FC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_NaomiQuests : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_questmenu_v00___bg                          l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_questmenu_v00__desktop_all                  l_desktop_all;                                           // 0x0094(0x0030)
		struct Fstx_ui_questmenu_v00__base_questlist_all           l_base_questlist_all;                                    // 0x00C4(0x0698)
		struct Fstx_ui_questmenu_v00__base_summary_all             l_base_summary_all;                                      // 0x075C(0x0120)
		struct Fstx_ui_questmenu_v00__base_contents_all            l_base_contents_all;                                     // 0x087C(0x0018)
		class UBrgUIImage*                                         l_bg_black60;                                            // 0x0894(0x0008)
		struct Fstx_ui_questmenu_v00__base_attachedfile_all        l_base_attachedfile_all;                                 // 0x089C(0x0038)
		struct Fstx_ui_questmenu_v00__base_popup1_all              l_base_popup1_all;                                       // 0x08D4(0x0060)
		struct Fstx_ui_questmenu_v00__base_popup2_all              l_base_popup2_all;                                       // 0x0934(0x0048)
		struct Fstx_ui_questmenu_v00__base_popup3_all              l_base_popup3_all;                                       // 0x097C(0x0048)
		struct Fstx_ui_questmenu_v00__button                       l_button;                                                // 0x09C4(0x0030)
		class UBrgUIImage*                                         l_scope_frame_v00;                                       // 0x09F4(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_PauseMenu_STM_v00
	 * Size -> 0x0664 (FullSize[0x06F0] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_PauseMenu_STM_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_pausemenu_stm_v00__graphic_all              l_graphic_all;                                           // 0x0094(0x00B8)
		struct Fstx_ui_pausemenu_stm_v00__controller_all           l_controller_all;                                        // 0x014C(0x0178)
		struct Fstx_ui_pausemenu_stm_v00__key_all                  l_key_all;                                               // 0x02C4(0x02F8)
		struct Fstx_ui_pausemenu_stm_v00__type_all                 l_type_all;                                              // 0x05BC(0x0030)
		struct Fstx_ui_pausemenu_stm_v00__cursor_all               l_cursor_all;                                            // 0x05EC(0x0030)
		struct Fstx_ui_pausemenu_stm_v00__locater_all              l_locater_all;                                           // 0x061C(0x0090)
		struct Fstx_ui_pausemenu_stm_v00__pickup_all               l_pickup_all;                                            // 0x06AC(0x0040)
		unsigned long                                              mAddBlendDraw : 1;                                       // 0x06EC(0x0001) BIT_FIELD

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_PauseMenu_v01
	 * Size -> 0x27CC (FullSize[0x2858] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_PauseMenu_v01 : public UBrgUIResource_Common
	{
	public:
		unsigned long                                              mAddBlendDraw : 1;                                       // 0x008C(0x0001) BIT_FIELD
		struct Fstx_ui_pausemenu_v01__card_all                     l_card_all;                                              // 0x0090(0x00D8)
		struct Fstx_ui_pausemenu_v01__gameover_all                 l_gameover_all;                                          // 0x0168(0x0010)
		struct Fstx_ui_pausemenu_v01___bg                          l__bg;                                                   // 0x0178(0x0030)
		struct Fstx_ui_pausemenu_v01__menu_setting_v01             l_menu_setting_v01;                                      // 0x01A8(0x0040)
		struct Fstx_ui_pausemenu_v01__menu_setting_v00             l_menu_setting_v00;                                      // 0x01E8(0x0200)
		struct Fstx_ui_pausemenu_v01__fighter_shop_all             l_fighter_shop_all;                                      // 0x03E8(0x0220)
		struct Fstx_ui_pausemenu_v01__fighter_select               l_fighter_select;                                        // 0x0608(0x0018)
		struct Fstx_ui_pausemenu_v01__select_item_all              l_select_item_all;                                       // 0x0620(0x0B50)
		class UBrgUIImage*                                         l__bg_back;                                              // 0x1170(0x0008)
		struct Fstx_ui_pausemenu_v01__limited_all                  l_limited_all;                                           // 0x1178(0x0078)
		struct Fstx_ui_pausemenu_v01__limitedlimit_all             l_limitedlimit_all;                                      // 0x11F0(0x0020)
		struct Fstx_ui_pausemenu_v01__cursor_all                   l_cursor_all;                                            // 0x1210(0x0030)
		struct Fstx_ui_pausemenu_v01__locater_all                  l_locater_all;                                           // 0x1240(0x0090)
		class UBrgUIImage*                                         l__bgbgbgbg;                                             // 0x12D0(0x0008)
		struct Fstx_ui_pausemenu_v01__list_all                     l_list_all;                                              // 0x12D8(0x01F0)
		struct Fstx_ui_pausemenu_v01__info_all                     l_info_all;                                              // 0x14C8(0x0540)
		struct Fstx_ui_pausemenu_v01__mushroom_all                 l_mushroom_all;                                          // 0x1A08(0x05B8)
		class UBrgUIImage*                                         l__bgbg;                                                 // 0x1FC0(0x0008)
		struct Fstx_ui_pausemenu_v01__menu_setup_all               l_menu_setup_all;                                        // 0x1FC8(0x0050)
		struct Fstx_ui_pausemenu_v01__menu_strength_all            l_menu_strength_all;                                     // 0x2018(0x02D0)
		struct Fstx_ui_pausemenu_v01__menu_thumbnail_all           l_menu_thumbnail_all;                                    // 0x22E8(0x02A0)
		struct Fstx_ui_pausemenu_v01__capacity_all                 l_capacity_all;                                          // 0x2588(0x0060)
		struct Fstx_ui_pausemenu_v01__frame_thumbnail_all          l_frame_thumbnail_all;                                   // 0x25E8(0x01C8)
		struct Fstx_ui_pausemenu_v01__dust_all                     l_dust_all;                                              // 0x27B0(0x0050)
		struct Fstx_ui_pausemenu_v01__judge_all                    l_judge_all;                                             // 0x2800(0x0050)
		struct Fstx_ui_pausemenu_v01__icon_guidebuttons_all        l_icon_guidebuttons_all;                                 // 0x2850(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_PauseMenu_v02_Shop
	 * Size -> 0x00F8 (FullSize[0x0184] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_PauseMenu_v02_Shop : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_pausemenu_v02_shop__skilled_v00             l_skilled_v00;                                           // 0x008C(0x0088)
		struct Fstx_ui_pausemenu_v02_shop__skilled_v01             l_skilled_v01;                                           // 0x0114(0x0070)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Prison_v00
	 * Size -> 0x02E1 (FullSize[0x036D] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Prison_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_prison_v00___bg                             l__bg;                                                   // 0x008C(0x0020)
		struct Fstx_ui_prison_v00__status_all                      l_status_all;                                            // 0x00AC(0x0040)
		struct Fstx_ui_prison_v00__fighter_all                     l_fighter_all;                                           // 0x00EC(0x0090)
		struct Fstx_ui_prison_v00__spirit_all                      l_spirit_all;                                            // 0x017C(0x0028)
		struct Fstx_ui_prison_v00__condition_all                   l_condition_all;                                         // 0x01A4(0x0080)
		struct Fstx_ui_prison_v00__monitor_all                     l_monitor_all;                                           // 0x0224(0x0010)
		struct Fstx_ui_prison_v00__fighter_info_all                l_fighter_info_all;                                      // 0x0234(0x0070)
		struct Fstx_ui_prison_v00__menu_all                        l_menu_all;                                              // 0x02A4(0x00A0)
		struct Fstx_ui_prison_v00__psn_resource_name_all           l_psn_resource_name_all;                                 // 0x0344(0x0010)
		class UTextureRenderTarget2D*                              mRenderTargetTexture;                                    // 0x0354(0x0008)
		class UBrgUIImage*                                         mRenderTargetTextureImage;                               // 0x035C(0x0008)
		class UMaterialInstanceConstant*                           mMatInstConst;                                           // 0x0364(0x0008)
		EBrgUIResource_PrisonMenu_Monitor_State                    mState;                                                  // 0x036C(0x0001)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void ChangeMonitorImage(EBrgUIResource_PrisonMenu_Monitor_State _NextState);
		EBrgUIResource_PrisonMenu_Monitor_State GetMonitorImageState();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_questmenu_STM_v00
	 * Size -> 0x0064 (FullSize[0x00F0] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_questmenu_STM_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_questmenu_stm_v00___bg                      l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_questmenu_stm_v00__button                   l_button;                                                // 0x0094(0x0058)
		unsigned long                                              mAddBlendDraw : 1;                                       // 0x00EC(0x0001) BIT_FIELD

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_RadioMenu
	 * Size -> 0x00E8 (FullSize[0x0174] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_RadioMenu : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_radiomenu_v00___bg                          l__bg;                                                   // 0x008C(0x0010)
		class UBrgUIImage*                                         l_base_bg;                                               // 0x009C(0x0008)
		class UBrgUIImage*                                         l_icon_power_on;                                         // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_icon_power_off;                                        // 0x00AC(0x0008)
		class UBrgUIImage*                                         l_icon_light_on;                                         // 0x00B4(0x0008)
		class UBrgUIImage*                                         l_icon_light_off;                                        // 0x00BC(0x0008)
		class UBrgUIImage*                                         l_frame_over;                                            // 0x00C4(0x0008)
		struct Fstx_ui_radiomenu_v00__scrollbar_all                l_scrollbar_all;                                         // 0x00CC(0x0028)
		struct Fstx_ui_radiomenu_v00__icon_scull_all               l_icon_scull_all;                                        // 0x00F4(0x0010)
		struct Fstx_ui_radiomenu_v00__text_all                     l_text_all;                                              // 0x0104(0x0058)
		class UBrgUIImage*                                         l_base_highlight;                                        // 0x015C(0x0008)
		struct Fstx_ui_radiomenu_v00__mask_all                     l_mask_all;                                              // 0x0164(0x0010)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_ReachingMail_v00
	 * Size -> 0x0008 (FullSize[0x0094] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_ReachingMail_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__guide_memo_mail;                                      // 0x008C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Reception_v00
	 * Size -> 0x0144 (FullSize[0x01D0] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Reception_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_base_bg_v03;                                           // 0x008C(0x0008)
		struct Fstx_ui_reception_v00__noise_all                    l_noise_all;                                             // 0x0094(0x0030)
		struct Fstx_ui_reception_v00__target_all                   l_target_all;                                            // 0x00C4(0x0028)
		struct Fstx_ui_reception_v00__logo_all                     l_logo_all;                                              // 0x00EC(0x0010)
		class UBrgUIImage*                                         l_line_noise_v00;                                        // 0x00FC(0x0008)
		class UBrgUIImage*                                         l_line_noise_v01;                                        // 0x0104(0x0008)
		class UBrgUIImage*                                         l_guide_line_noise;                                      // 0x010C(0x0008)
		class UBrgUIImage*                                         l_base_bg_v01;                                           // 0x0114(0x0008)
		class UBrgUIImage*                                         l_base_bg_v00;                                           // 0x011C(0x0008)
		struct Fstx_ui_reception_v00__panel_all                    l_panel_all;                                             // 0x0124(0x0020)
		class UBrgUIImage*                                         l_base_v01;                                              // 0x0144(0x0008)
		struct Fstx_ui_reception_v00__check_all                    l_check_all;                                             // 0x014C(0x0008)
		struct Fstx_ui_reception_v00__mission_all                  l_mission_all;                                           // 0x0154(0x0010)
		struct Fstx_ui_reception_v00__difficulty_all               l_difficulty_all;                                        // 0x0164(0x0008)
		struct Fstx_ui_reception_v00__price_all                    l_price_all;                                             // 0x016C(0x0020)
		class UBrgUIImage*                                         l_base_v00;                                              // 0x018C(0x0008)
		class UBrgUIImage*                                         l_base_v02;                                              // 0x0194(0x0008)
		class UBrgUIImage*                                         l_panel_lightl_r;                                        // 0x019C(0x0008)
		class UBrgUIImage*                                         l_panel_lightl_l;                                        // 0x01A4(0x0008)
		struct Fstx_ui_reception_v00__select_all                   l_select_all;                                            // 0x01AC(0x0010)
		class UBrgUIImage*                                         l_frame_line_v00;                                        // 0x01BC(0x0008)
		class UBrgUIImage*                                         l_guide_mask;                                            // 0x01C4(0x0008)
		unsigned long                                              mAddBlendDraw : 1;                                       // 0x01CC(0x0001) BIT_FIELD

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Result_Floor_Info_v00
	 * Size -> 0x0018 (FullSize[0x00A4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Result_Floor_Info_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_result_floor_info_v00__info_all             l_info_all;                                              // 0x008C(0x0010)
		class UBrgUIImage*                                         l__guide_banner_v00;                                     // 0x009C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Result_Floor_v02
	 * Size -> 0x0398 (FullSize[0x0424] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Result_Floor_v02 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg_v00;                                               // 0x008C(0x0008)
		class UBrgUIImage*                                         l__bg_v01;                                               // 0x0094(0x0008)
		class UBrgUIImage*                                         l__death_v00;                                            // 0x009C(0x0008)
		struct Fstx_ui_result_floor_v02__next_all                  l_next_all;                                              // 0x00A4(0x0020)
		struct Fstx_ui_result_floor_v02__map_result_all            l_map_result_all;                                        // 0x00C4(0x0070)
		struct Fstx_ui_result_floor_v02__result51_all              l_result51_all;                                          // 0x0134(0x00F0)
		struct Fstx_ui_result_floor_v02__resultnew_all             l_resultnew_all;                                         // 0x0224(0x0030)
		struct Fstx_ui_result_floor_v02__lognew_all                l_lognew_all;                                            // 0x0254(0x00A8)
		struct Fstx_ui_result_floor_v02__result_all                l_result_all;                                            // 0x02FC(0x0028)
		struct Fstx_ui_result_floor_v02__log_all                   l_log_all;                                               // 0x0324(0x00A8)
		struct Fstx_ui_result_floor_v02__chala_image_all           l_chala_image_all;                                       // 0x03CC(0x0058)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_RewardBox_v00
	 * Size -> 0x01B4 (FullSize[0x0240] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_RewardBox_v00 : public UBrgUIResource_Common
	{
	public:
		EBrgUIResource_RewardBox_v00_UseMaskType                   mUseMask;                                                // 0x008C(0x0001)
		unsigned char                                              UnknownData_60YY[0x3];                                   // 0x008D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct Fstx_ui_rewardbox_v00___bg_all                      l__bg_all;                                               // 0x0090(0x0010)
		struct Fstx_ui_rewardbox_v00__info_reward_all              l_info_reward_all;                                       // 0x00A0(0x0060)
		struct Fstx_ui_rewardbox_v00___guide_info_reward_all       l__guide_info_reward_all;                                // 0x0100(0x0090)
		class UBrgUIImage*                                         l_mask_v00;                                              // 0x0190(0x0008)
		struct Fstx_ui_rewardbox_v00__num_box                      l_num_box;                                               // 0x0198(0x0028)
		struct Fstx_ui_rewardbox_v00__scrollbar                    l_scrollbar;                                             // 0x01C0(0x0020)
		struct Fstx_ui_rewardbox_v00__icon_sort_r_all              l_icon_sort_r_all;                                       // 0x01E0(0x0050)
		class UBrgUIImage*                                         l__guide_select_item_v00;                                // 0x0230(0x0008)
		class UBrgUIImage*                                         l__guide_select_item_v01;                                // 0x0238(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_RewardBox_v01
	 * Size -> 0x0048 (FullSize[0x00D4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_RewardBox_v01 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_rewardbox_v01___bg                          l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_rewardbox_v01__light_all                    l_light_all;                                             // 0x0094(0x0010)
		struct Fstx_ui_rewardbox_v01__star_all                     l_star_all;                                              // 0x00A4(0x0010)
		struct Fstx_ui_rewardbox_v01__star_d_all                   l_star_d_all;                                            // 0x00B4(0x0010)
		class UBrgUIImage*                                         l__guide_select_item_v00;                                // 0x00C4(0x0008)
		class UBrgUIImage*                                         l__guide_select_item_v01;                                // 0x00CC(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_SkillSticker
	 * Size -> 0x00B0 (FullSize[0x013C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_SkillSticker : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_skillsticker_v00__skill_e_all               l_skill_e_all;                                           // 0x0094(0x0078)
		struct Fstx_ui_skillsticker_v00__frame_thumbnail           l_frame_thumbnail;                                       // 0x010C(0x0030)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_StampEx_v00
	 * Size -> 0x0080 (FullSize[0x010C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_StampEx_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_stampex_v00___bg                            l__bg;                                                   // 0x008C(0x0020)
		struct Fstx_ui_stampex_v00__stampcahnge_all                l_stampcahnge_all;                                       // 0x00AC(0x0038)
		struct Fstx_ui_stampex_v00__guide_all                      l_guide_all;                                             // 0x00E4(0x0028)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_StatusMenu
	 * Size -> 0x0BB0 (FullSize[0x0C3C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_StatusMenu : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_status_v00___bg_all                         l__bg_all;                                               // 0x008C(0x0010)
		struct Fstx_ui_status_v00__menu_top_v00                    l_menu_top_v00;                                          // 0x009C(0x07F8)
		struct Fstx_ui_status_v00__status_exp_all                  l_status_exp_all;                                        // 0x0894(0x0038)
		struct Fstx_ui_status_v00__status_create_all               l_status_create_all;                                     // 0x08CC(0x0148)
		struct Fstx_ui_status_v00__result_drone_all                l_result_drone_all;                                      // 0x0A14(0x0048)
		struct Fstx_ui_status_v00__status_steroid_all              l_status_steroid_all;                                    // 0x0A5C(0x0170)
		struct Fstx_ui_status_v00__status_createlimit              l_status_createlimit;                                    // 0x0BCC(0x0070)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_SystemWindow
	 * Size -> 0x00D0 (FullSize[0x015C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_SystemWindow : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_systemwindow_v00__dead_all                  l_dead_all;                                              // 0x008C(0x0048)
		struct Fstx_ui_systemwindow_v00__disconnect_all            l_disconnect_all;                                        // 0x00D4(0x0058)
		struct Fstx_ui_systemwindow_v00__window_all                l_window_all;                                            // 0x012C(0x0030)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_SystemWindow_v01
	 * Size -> 0x0088 (FullSize[0x0114] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_SystemWindow_v01 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_v00;                                              // 0x0094(0x0008)
		struct Fstx_ui_systemwindow_v01___text_all                 l__text_all;                                             // 0x009C(0x0078)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_SystemWindow_v02
	 * Size -> 0x0070 (FullSize[0x00FC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_SystemWindow_v02 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_v00;                                              // 0x0094(0x0008)
		struct Fstx_ui_systemwindow_v02__line_v01_all              l_line_v01_all;                                          // 0x009C(0x0020)
		struct Fstx_ui_systemwindow_v02___text_all                 l__text_all;                                             // 0x00BC(0x0040)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_SystemWindow_v03
	 * Size -> 0x0080 (FullSize[0x010C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_SystemWindow_v03 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		class UBrgUIImage*                                         l_base_v00;                                              // 0x0094(0x0008)
		class UBrgUIImage*                                         l_base_v01;                                              // 0x009C(0x0008)
		class UBrgUIImage*                                         l_cursor_v00;                                            // 0x00A4(0x0008)
		struct Fstx_ui_systemwindow_v03___text_all                 l__text_all;                                             // 0x00AC(0x0060)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_TengokuMenu
	 * Size -> 0x00D0 (FullSize[0x015C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_TengokuMenu : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_tengokumenu_v00___bg                        l__bg;                                                   // 0x008C(0x0010)
		struct Fstx_ui_tengokumenu_v00__info_buff_all              l_info_buff_all;                                         // 0x009C(0x0038)
		struct Fstx_ui_tengokumenu_v00__info_belongings_all        l_info_belongings_all;                                   // 0x00D4(0x0038)
		struct Fstx_ui_tengokumenu_v00__info_floor_all             l_info_floor_all;                                        // 0x010C(0x0050)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Tips_v00
	 * Size -> 0x0088 (FullSize[0x0114] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Tips_v00 : public UBrgUIResource_Common
	{
	public:
		struct Fstx_ui_tips_v00___bg                               l__bg;                                                   // 0x008C(0x0018)
		struct Fstx_ui_tips_v00__base_all                          l_base_all;                                              // 0x00A4(0x0068)
		class UBrgUIImage*                                         l__guide_base;                                           // 0x010C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title
	 * Size -> 0x0100 (FullSize[0x018C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_bg_title_mask;                                         // 0x008C(0x0008)
		class UBrgUIImage*                                         l_bg_title_t_mask;                                       // 0x0094(0x0008)
		class UBrgUIImage*                                         l_frame_mask_04;                                         // 0x009C(0x0008)
		class UBrgUIImage*                                         l_frame_mask_03;                                         // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_frame_mask_02;                                         // 0x00AC(0x0008)
		class UBrgUIImage*                                         l_frame_mask_01;                                         // 0x00B4(0x0008)
		class UBrgUIImage*                                         l_frame_mask_00;                                         // 0x00BC(0x0008)
		class UBrgUIImage*                                         l_bg_title_v01;                                          // 0x00C4(0x0008)
		class UBrgUIImage*                                         l_bg_title_v02;                                          // 0x00CC(0x0008)
		class UBrgUIImage*                                         l_bg_title_t_v01;                                        // 0x00D4(0x0008)
		class UBrgUIImage*                                         l_bg_title_t_v02;                                        // 0x00DC(0x0008)
		class UBrgUIImage*                                         l_bg_title;                                              // 0x00E4(0x0008)
		class UBrgUIImage*                                         l_bg_title_t;                                            // 0x00EC(0x0008)
		struct Fstx_ui_title_vs_v00__text_all                      l_text_all;                                              // 0x00F4(0x0018)
		struct Fstx_ui_title_vs_v00__button_push                   l_button_push;                                           // 0x010C(0x0008)
		struct Fstx_ui_title_vs_v00__item_all                      l_item_all;                                              // 0x0114(0x0020)
		class UBrgUIImage*                                         l__guide_stm_v05;                                        // 0x0134(0x0008)
		class UBrgUIImage*                                         l__guide_stm_v04;                                        // 0x013C(0x0008)
		class UBrgUIImage*                                         l__guide_stm_v03;                                        // 0x0144(0x0008)
		class UBrgUIImage*                                         l__guide_stm_v02;                                        // 0x014C(0x0008)
		class UBrgUIImage*                                         l__guide_stm_v01;                                        // 0x0154(0x0008)
		class UBrgUIImage*                                         l__guide_stm_v00;                                        // 0x015C(0x0008)
		class UBrgUIImage*                                         l__guide_v04;                                            // 0x0164(0x0008)
		class UBrgUIImage*                                         l__guide_v03;                                            // 0x016C(0x0008)
		class UBrgUIImage*                                         l__guide_v02;                                            // 0x0174(0x0008)
		class UBrgUIImage*                                         l__guide_v01;                                            // 0x017C(0x0008)
		class UBrgUIImage*                                         l__guide_v00;                                            // 0x0184(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_First
	 * Size -> 0x00A8 (FullSize[0x0134] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_First : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_title_first_v00__hudsafety_all              l_hudsafety_all;                                         // 0x0094(0x0038)
		struct Fstx_ui_title_first_v00__title_back_all             l_title_back_all;                                        // 0x00CC(0x0018)
		struct Fstx_ui_title_first_v00__brightness_all             l_brightness_all;                                        // 0x00E4(0x0028)
		struct Fstx_ui_title_first_v00__language_all               l_language_all;                                          // 0x010C(0x0018)
		struct Fstx_ui_title_first_v00__network_all                l_network_all;                                           // 0x0124(0x0010)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_Notice
	 * Size -> 0x0184 (FullSize[0x0210] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_Notice : public UBrgUIResource_Common
	{
	public:
		EBrgUIResource_Title_Notice_UseMaskType                    mUseMask;                                                // 0x008C(0x0001)
		unsigned char                                              UnknownData_HG4S[0x3];                                   // 0x008D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct Fstx_ui_title_notice_v00___bg                       l__bg;                                                   // 0x0090(0x0008)
		struct Fstx_ui_title_notice_v00__notice_all                l_notice_all;                                            // 0x0098(0x0080)
		struct Fstx_ui_title_notice_v00__rule_all                  l_rule_all;                                              // 0x0118(0x0078)
		struct Fstx_ui_title_notice_v00__gdpr_all                  l_gdpr_all;                                              // 0x0190(0x0080)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_Spring00_v00
	 * Size -> 0x00C0 (FullSize[0x014C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_Spring00_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_rabbit_00;                                             // 0x008C(0x0008)
		class UBrgUIImage*                                         l_rabbit_01;                                             // 0x0094(0x0008)
		class UBrgUIImage*                                         l_rabbit_02;                                             // 0x009C(0x0008)
		class UBrgUIImage*                                         l_rabbit_03;                                             // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_rabbit_04;                                             // 0x00AC(0x0008)
		class UBrgUIImage*                                         l_rabbit_05;                                             // 0x00B4(0x0008)
		class UBrgUIImage*                                         l_egg_00;                                                // 0x00BC(0x0008)
		class UBrgUIImage*                                         l_egg_01;                                                // 0x00C4(0x0008)
		class UBrgUIImage*                                         l_egg_02;                                                // 0x00CC(0x0008)
		class UBrgUIImage*                                         l_egg_03;                                                // 0x00D4(0x0008)
		class UBrgUIImage*                                         l_egg_04;                                                // 0x00DC(0x0008)
		class UBrgUIImage*                                         l_egg_05;                                                // 0x00E4(0x0008)
		class UBrgUIImage*                                         l_egg_06;                                                // 0x00EC(0x0008)
		class UBrgUIImage*                                         l_egg_07;                                                // 0x00F4(0x0008)
		class UBrgUIImage*                                         l_egg_08;                                                // 0x00FC(0x0008)
		class UBrgUISpriteAnim*                                    mRootSpriteAnim;                                         // 0x0104(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_RabbitBG;                                // 0x010C(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_EggBG;                                   // 0x0114(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_RabbitCursor;                            // 0x011C(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_EggCursor;                               // 0x0124(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_EggCursorR;                              // 0x012C(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_EggCursorL;                              // 0x0134(0x0008)
		float                                                      mRabbitCursorLoopStartTime;                              // 0x013C(0x0004)
		float                                                      mEggCursorLoopStartTime;                                 // 0x0140(0x0004)
		float                                                      mEggRCursorLoopStartTime;                                // 0x0144(0x0004)
		float                                                      mEggLCursorLoopStartTime;                                // 0x0148(0x0004)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_Spring00_v01
	 * Size -> 0x0008 (FullSize[0x0094] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_Spring00_v01 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_cursor_pic_00;                                         // 0x008C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_VS_Autumn00_v01
	 * Size -> 0x0140 (FullSize[0x01CC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_VS_Autumn00_v01 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_title_vs_autumn00_v01__cover_all            l_cover_all;                                             // 0x0094(0x0008)
		struct Fstx_ui_title_vs_autumn00_v01__candle_all           l_candle_all;                                            // 0x009C(0x0028)
		struct Fstx_ui_title_vs_autumn00_v01__l_pumpkin_all        l_l_pumpkin_all;                                         // 0x00C4(0x0010)
		struct Fstx_ui_title_vs_autumn00_v01__r_pumpkin_all        l_r_pumpkin_all;                                         // 0x00D4(0x0010)
		struct Fstx_ui_title_vs_autumn00_v01__s_pumpkin_all        l_s_pumpkin_all;                                         // 0x00E4(0x0028)
		struct Fstx_ui_title_vs_autumn00_v01__cat_all              l_cat_all;                                               // 0x010C(0x0080)
		class UBrgUISpriteAnim*                                    mRootSpriteAnim;                                         // 0x018C(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_CoverCursor;                             // 0x0194(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_CatCursor;                               // 0x019C(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_CandleCursor;                            // 0x01A4(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_PumpkinLCursor;                          // 0x01AC(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_PumpkinRCursor;                          // 0x01B4(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_PumpkinSCursor;                          // 0x01BC(0x0008)
		float                                                      mPumpkinLCursorLoopStartTime;                            // 0x01C4(0x0004)
		float                                                      mPumpkinRCursorLoopStartTime;                            // 0x01C8(0x0004)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_VS_Autumn00_v02
	 * Size -> 0x0008 (FullSize[0x0094] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_VS_Autumn00_v02 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_base_v00;                                              // 0x008C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_VS_Autumn00_v03
	 * Size -> 0x0040 (FullSize[0x00CC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_VS_Autumn00_v03 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		class UBrgUIImage*                                         l_r_bat_v01;                                             // 0x0094(0x0008)
		class UBrgUIImage*                                         l_r_bat_v02;                                             // 0x009C(0x0008)
		class UBrgUIImage*                                         l_l_bat_v01;                                             // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_l_bat_v02;                                             // 0x00AC(0x0008)
		class UBrgUISpriteAnim*                                    mRootSpriteAnim;                                         // 0x00B4(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_BatL_BG;                                 // 0x00BC(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_BatR_BG;                                 // 0x00C4(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_VS_Summer00_v00
	 * Size -> 0x0010 (FullSize[0x009C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_VS_Summer00_v00 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_bg_title;                                              // 0x008C(0x0008)
		class UBrgUIImage*                                         l_bg_title_t;                                            // 0x0094(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_VS_Summer00_v01
	 * Size -> 0x0170 (FullSize[0x01FC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_VS_Summer00_v01 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_ball_01;                                               // 0x008C(0x0008)
		class UBrgUIImage*                                         l_ball_02;                                               // 0x0094(0x0008)
		class UBrgUIImage*                                         l_ball_03;                                               // 0x009C(0x0008)
		class UBrgUIImage*                                         l_ball_04;                                               // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_ball_05;                                               // 0x00AC(0x0008)
		class UBrgUIImage*                                         l_ball_06;                                               // 0x00B4(0x0008)
		class UBrgUIImage*                                         l_ball_07;                                               // 0x00BC(0x0008)
		class UBrgUIImage*                                         l_ball_08;                                               // 0x00C4(0x0008)
		class UBrgUIImage*                                         l_ball_09;                                               // 0x00CC(0x0008)
		class UBrgUIImage*                                         l_ball_11;                                               // 0x00D4(0x0008)
		class UBrgUIImage*                                         l_ball_12;                                               // 0x00DC(0x0008)
		class UBrgUIImage*                                         l_fish_01;                                               // 0x00E4(0x0008)
		class UBrgUIImage*                                         l_fish_02;                                               // 0x00EC(0x0008)
		class UBrgUIImage*                                         l_fish_03;                                               // 0x00F4(0x0008)
		class UBrgUIImage*                                         l_fish_04;                                               // 0x00FC(0x0008)
		class UBrgUIImage*                                         l_fish_05;                                               // 0x0104(0x0008)
		class UBrgUIImage*                                         l_fish_06;                                               // 0x010C(0x0008)
		class UBrgUIImage*                                         l_fish_07;                                               // 0x0114(0x0008)
		class UBrgUIImage*                                         l_fish_08;                                               // 0x011C(0x0008)
		class UBrgUIImage*                                         l_fish_09;                                               // 0x0124(0x0008)
		class UBrgUIImage*                                         l_fish_11;                                               // 0x012C(0x0008)
		class UBrgUIImage*                                         l_fin_01;                                                // 0x0134(0x0008)
		class UBrgUIImage*                                         l_fin_02;                                                // 0x013C(0x0008)
		class UBrgUIImage*                                         l_fin_03;                                                // 0x0144(0x0008)
		class UBrgUIImage*                                         l_fin_04;                                                // 0x014C(0x0008)
		class UBrgUIImage*                                         l_fin_05;                                                // 0x0154(0x0008)
		class UBrgUIImage*                                         l_fin_06;                                                // 0x015C(0x0008)
		class UBrgUIImage*                                         l_fin_07;                                                // 0x0164(0x0008)
		class UBrgUIImage*                                         l_fin_08;                                                // 0x016C(0x0008)
		class UBrgUIImage*                                         l_fin_09;                                                // 0x0174(0x0008)
		class UBrgUIImage*                                         l_fin_11;                                                // 0x017C(0x0008)
		class UBrgUIImage*                                         l_fin_12;                                                // 0x0184(0x0008)
		class UBrgUIImage*                                         l_fin_13;                                                // 0x018C(0x0008)
		class UBrgUIImage*                                         l_fin_14;                                                // 0x0194(0x0008)
		class UBrgUIImage*                                         l_fin_15;                                                // 0x019C(0x0008)
		class UBrgUIImage*                                         l_fin_16;                                                // 0x01A4(0x0008)
		class UBrgUIImage*                                         l_fin_17;                                                // 0x01AC(0x0008)
		class UBrgUIImage*                                         l_fin_18;                                                // 0x01B4(0x0008)
		class UBrgUIImage*                                         l_arm_01;                                                // 0x01BC(0x0008)
		class UBrgUIImage*                                         l_arm_02;                                                // 0x01C4(0x0008)
		class UBrgUISpriteAnim*                                    mRootSpriteAnim;                                         // 0x01CC(0x0008)
		class UBrgUISpriteAnim*                                    mSpriteAnim_BallCursor;                                  // 0x01D4(0x0008)
		class UBrgUISpriteAnim*                                    mSpriteAnim_FishCursorR;                                 // 0x01DC(0x0008)
		class UBrgUISpriteAnim*                                    mSpriteAnim_FishCursorL;                                 // 0x01E4(0x0008)
		class UBrgUISpriteAnim*                                    mSpriteAnim_FinCursor;                                   // 0x01EC(0x0008)
		class UBrgUISpriteAnim*                                    mSpriteAnim_ArmCursor;                                   // 0x01F4(0x0008)

	public:
		void AddKeyAnimSprite(class UBrgUISpriteAnim* SpriteAnim, float inLocalWaitTime, int32_t InX, int32_t InY, int32_t inImageNo, bool inRLReverse, bool inUDReverse);
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_VS_Summer00_v02
	 * Size -> 0x0008 (FullSize[0x0094] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_VS_Summer00_v02 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_base;                                                  // 0x008C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_VS_Winter00_v01
	 * Size -> 0x0050 (FullSize[0x00DC] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_VS_Winter00_v01 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_skier_run;                                             // 0x008C(0x0008)
		class UBrgUIImage*                                         l_skier_on;                                              // 0x0094(0x0008)
		class UBrgUIImage*                                         l_skier_drop;                                            // 0x009C(0x0008)
		class UBrgUIImage*                                         l_tree_l_left;                                           // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_tree_l_right;                                          // 0x00AC(0x0008)
		class UBrgUIImage*                                         l_tree_l;                                                // 0x00B4(0x0008)
		class UBrgUIImage*                                         l_tree_s;                                                // 0x00BC(0x0008)
		class UBrgUISpriteAnim*                                    mRootSpriteAnim;                                         // 0x00C4(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_SkierCursor;                             // 0x00CC(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_TreeCursor;                              // 0x00D4(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_VS_Winter00_v02
	 * Size -> 0x0008 (FullSize[0x0094] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_VS_Winter00_v02 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_snow;                                                  // 0x008C(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_VS_Winter00_v03
	 * Size -> 0x0038 (FullSize[0x00C4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_VS_Winter00_v03 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_snow_fx_2;                                             // 0x008C(0x0008)
		class UBrgUIImage*                                         l_snow_fx_3;                                             // 0x0094(0x0008)
		class UBrgUIImage*                                         l_snow_fx_4;                                             // 0x009C(0x0008)
		class UBrgUIImage*                                         l_snow_fx_5;                                             // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_snow_fx_6;                                             // 0x00AC(0x0008)
		class UBrgUISpriteAnim*                                    mRootSpriteAnim;                                         // 0x00B4(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_SnowFXCursor;                            // 0x00BC(0x0008)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_Title_VS_Winter00_v04
	 * Size -> 0x00F0 (FullSize[0x017C] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_Title_VS_Winter00_v04 : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l_snowman_01;                                            // 0x008C(0x0008)
		class UBrgUIImage*                                         l_snowman_02;                                            // 0x0094(0x0008)
		class UBrgUIImage*                                         l_snowman_03;                                            // 0x009C(0x0008)
		class UBrgUIImage*                                         l_snowman_04;                                            // 0x00A4(0x0008)
		class UBrgUIImage*                                         l_snowman_05;                                            // 0x00AC(0x0008)
		class UBrgUIImage*                                         l_snowman_06;                                            // 0x00B4(0x0008)
		class UBrgUIImage*                                         l_snowman_07;                                            // 0x00BC(0x0008)
		class UBrgUIImage*                                         l_snowman_08;                                            // 0x00C4(0x0008)
		class UBrgUIImage*                                         l_snowman_09;                                            // 0x00CC(0x0008)
		class UBrgUIImage*                                         l_snowman_11;                                            // 0x00D4(0x0008)
		class UBrgUIImage*                                         l_snowman_12;                                            // 0x00DC(0x0008)
		class UBrgUIImage*                                         l_snowman_13;                                            // 0x00E4(0x0008)
		class UBrgUIImage*                                         l_snowman_14;                                            // 0x00EC(0x0008)
		class UBrgUIImage*                                         l_snowman_15;                                            // 0x00F4(0x0008)
		class UBrgUIImage*                                         l_snowman_16;                                            // 0x00FC(0x0008)
		class UBrgUIImage*                                         l_snowman_17;                                            // 0x0104(0x0008)
		class UBrgUIImage*                                         l_snowman_18;                                            // 0x010C(0x0008)
		class UBrgUIImage*                                         l_snowman_19;                                            // 0x0114(0x0008)
		class UBrgUIImage*                                         l_snowman_20;                                            // 0x011C(0x0008)
		class UBrgUIImage*                                         l_snowman_21;                                            // 0x0124(0x0008)
		class UBrgUIImage*                                         l_snowman_22;                                            // 0x012C(0x0008)
		class UBrgUIImage*                                         l_snowman_23;                                            // 0x0134(0x0008)
		class UBrgUIImage*                                         l_snowman_24;                                            // 0x013C(0x0008)
		class UBrgUIImage*                                         l_snowman_loop_01;                                       // 0x0144(0x0008)
		class UBrgUIImage*                                         l_snowman_loop_02;                                       // 0x014C(0x0008)
		class UBrgUIImage*                                         l_snowman_loop_03;                                       // 0x0154(0x0008)
		class UBrgUISpriteAnim*                                    mRootSpriteAnim;                                         // 0x015C(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_SnowmanLCursor;                          // 0x0164(0x0008)
		class UBrgUISpriteAnim*                                    mLoopSpriteAnim_SnowmanRCursor;                          // 0x016C(0x0008)
		float                                                      mSnowmanLCursorLoopStartTime;                            // 0x0174(0x0004)
		float                                                      mSnowmanRCursorLoopStartTime;                            // 0x0178(0x0004)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_UncleDeath_Anim
	 * Size -> 0x0038 (FullSize[0x00C4] - InheritedSize[0x008C])
	 */
	class UBrgUIResource_UncleDeath_Anim : public UBrgUIResource_Common
	{
	public:
		class UBrgUIImage*                                         l__bg;                                                   // 0x008C(0x0008)
		struct Fstx_ui_hud_uncledeath_anim_v00__death_anim_all     l_death_anim_all;                                        // 0x0094(0x0030)

	public:
		void PrivateSetupImage();
		void PrivateSetupImageNative();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_StreamImageManager
	 * Size -> 0x009D (FullSize[0x00FD] - InheritedSize[0x0060])
	 */
	class UBrgUIResource_StreamImageManager : public UObject
	{
	public:
		int32_t                                                    mMaxLoadNum;                                             // 0x0060(0x0004)
		struct FMap_Mirror                                         mStreamImageMap;                                         // 0x0064(0x0048) Native
		struct FMap_Mirror                                         mLoadStreamImageMap;                                     // 0x00AC(0x0048) Native
		struct FBrgUIMaterialAttr                                  mMaterialDefault;                                        // 0x00F4(0x0004)
		unsigned long                                              mMaterialDefaultEnableEffect : 1;                        // 0x00F8(0x0001) BIT_FIELD
		EMaterialEffect                                            mMaterialDefaultEffect;                                  // 0x00FC(0x0001)

	public:
		bool IsAllLoaded();
		int32_t GetStreamImageMapNum();
		int32_t GetLoadStreamImageMapNum();
		class FString MakeImageKeyString(const class FString& inTexturePath, EMaterialEffect inMaterialEffect);
		void UnloadOldImage(int32_t inNum, class UBrgUIImage_Stream* inStreamImage);
		void Reload(class UBrgUIImage_Stream* inStreamImage);
		void UnloadImage(const class FString& inTexturePath);
		class UBrgUIImage_Stream* GetImage(const class FString& inTexturePath);
		void UnloadAll();
		void ResetDefaultEffectMIC();
		void SetupDefaultEffectMIC(EMaterialEffect inMaterialEffect);
		void SetupDefaultMIC(struct FBrgUIMaterialAttr* inMaterialAttr);
		void InitializeNT(int32_t inMaxLoadNum);
		void Initialize(int32_t inMaxLoadNum);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_EnmaMenuImageManager
	 * Size -> 0x00CB (FullSize[0x01C8] - InheritedSize[0x00FD])
	 */
	class UBrgUIResource_EnmaMenuImageManager : public UBrgUIResource_StreamImageManager
	{
	public:
		unsigned char                                              UnknownData_NG7B[0x3];                                   // 0x00FD(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class UBrgUIManagerBase*                                   mUIManagerBase;                                          // 0x0100(0x0008)
		TArray<class FName>                                        mLoad_SkillStickerImage_SkillIDs;                        // 0x0108(0x0010) NeedCtorLink
		TArray<EBrgSkillStickerImageSize>                          mLoad_SkillStickerImage_SkillStickerSizes;               // 0x0118(0x0010) NeedCtorLink
		TArray<class FName>                                        mLoad_MasterLevelRwdIconImage_IconIDs;                   // 0x0128(0x0010) NeedCtorLink
		TArray<class FName>                                        mLoad_MushroomImage_MushroomIDs;                         // 0x0138(0x0010) NeedCtorLink
		TArray<class FName>                                        mLoad_MushroomArtImage_MushroomIDs;                      // 0x0148(0x0010) NeedCtorLink
		TArray<class FName>                                        mLoad_BeastImage_BeastIDs;                               // 0x0158(0x0010) NeedCtorLink
		TArray<class FName>                                        mLoad_BeastArtImage_BeastIDs;                            // 0x0168(0x0010) NeedCtorLink
		TArray<class FName>                                        mLoad_TalesFromTheBarbsIcon_ImageIDs;                    // 0x0178(0x0010) NeedCtorLink
		TArray<class FName>                                        mLoad_TalesFromTheBarbsImage_ImageIDs;                   // 0x0188(0x0010) NeedCtorLink
		TArray<class FName>                                        mLoad_CatalogIcon_ImageIDs;                              // 0x0198(0x0010) NeedCtorLink
		TArray<class FName>                                        mLoad_CatalogImage_ImageIDs;                             // 0x01A8(0x0010) NeedCtorLink
		TArray<class FName>                                        mLoad_TutorialImage_ImageIDs;                            // 0x01B8(0x0010) NeedCtorLink

	public:
		class FString GetTutorialLoadImagePath(const class FString& inImageID);
		class FString GetTutorialImagePath(const class FString& inImageID);
		void UnloadTutorialImage();
		class UBrgUIImage_Stream* GetTutorialImage(const class FString& inImageID);
		class FString GetCatalogLoadImagePath(const class FString& inImageID);
		class FString GetCatalogImagePath(const class FString& inImageID);
		void UnloadCatalogImage();
		class UBrgUIImage_Stream* GetCatalogImage(const class FString& inImageID);
		class FString GetCatalogLoadIconPath(const class FString& inImageID);
		class FString GetCatalogIconPath(const class FString& inImageID);
		void UnloadCatalogIcon();
		class UBrgUIImage_Stream* GetCatalogIcon(const class FString& inImageID);
		class FString GetTalesFromTheBarbsLoadImagePath(const class FString& inImageID);
		class FString GetTalesFromTheBarbsImagePath(const class FString& inImageID);
		void UnloadTalesFromTheBarbsImage();
		class UBrgUIImage_Stream* GetTalesFromTheBarbsImage(const class FString& inImageID);
		class FString GetTalesFromTheBarbsLoadIconPath(const class FString& inImageID);
		class FString GetTalesFromTheBarbsIconPath(const class FString& inImageID);
		void UnloadTalesFromTheBarbsIcon();
		class UBrgUIImage_Stream* GetTalesFromTheBarbsIcon(const class FString& inImageID);
		class FString GetBeastArtLoadImagePath(const class FString& inBeastID);
		class FString GetBeastArtImagePath(const class FString& inBeastID);
		void UnloadBeastArtImage();
		class UBrgUIImage_Stream* GetBeastArtImage(const class FString& inBeastID);
		class FString GetBeastLoadImagePath(const class FString& inBeastID);
		class FString GetBeastImagePath(const class FString& inBeastID);
		void UnloadBeastImage();
		class UBrgUIImage_Stream* GetBeastImage(const class FString& inBeastID);
		class FString GetMushroomArtLoadImagePath(const class FString& inMushroomID);
		class FString GetMushroomArtImagePath(const class FString& inMushroomID);
		void UnloadMushroomArtImage();
		class UBrgUIImage_Stream* GetMushroomArtImage(const class FString& inMushroomID);
		class FString GetMushroomLoadImagePath(const class FString& inMushroomID);
		class FString GetMushroomImagePath(const class FString& inMushroomID);
		void UnloadMushroomImage();
		class UBrgUIImage_Stream* GetMushroomImage(const class FString& inMushroomID);
		class FString GetMasterLevelRwdIconLoadImagePath(const class FString& inIconID);
		class FString GetMasterLevelRwdIconImagePath(const class FString& inIconID);
		void UnloadMasterLevelRwdIconImage();
		class UBrgUIImage_Stream* GetMasterLevelRwdIconImage(const class FString& inIconID);
		class FString GetSkillStickerLoadImagePath(const class FString& inSkillID, EBrgSkillStickerImageSize inSkillStickerSize);
		class FString GetSkillStickerImagePath(const class FString& inSkillID, EBrgSkillStickerImageSize inSkillStickerSize);
		void UnloadSkillStickerImage();
		class UBrgUIImage_Stream* GetSkillStickerImage(const class FString& inSkillID, EBrgSkillStickerImageSize inSkillStickerSize);
		void Initialize(int32_t inMaxNum);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_FighterIcon
	 * Size -> 0x0003 (FullSize[0x0100] - InheritedSize[0x00FD])
	 */
	class UBrgUIResource_FighterIcon : public UBrgUIResource_StreamImageManager
	{
	public:
		unsigned char                                              UnknownData_0D6G[0x3];                                   // 0x00FD(0x0003) MISSED OFFSET (PADDING)

	public:
		class UBrgUIImage_Stream* GetFitghterBodyHiddenIcon();
		class UBrgUIImage_Stream* GetFitghterBodyIcon(const class FString& BodyId);
		void Initialize(int32_t inMaxNum);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_FortIconImageManager
	 * Size -> 0x000B (FullSize[0x0108] - InheritedSize[0x00FD])
	 */
	class UBrgUIResource_FortIconImageManager : public UBrgUIResource_StreamImageManager
	{
	public:
		unsigned char                                              UnknownData_IZBA[0x3];                                   // 0x00FD(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class UBrgUIManagerBase*                                   mUIManagerBase;                                          // 0x0100(0x0008)

	public:
		class UBrgUIImage_Stream* GetWhistleIconImage(const class FString& inWhistleID);
		void Initialize(int32_t inMaxNum);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_ItemIconManager
	 * Size -> 0x000B (FullSize[0x0108] - InheritedSize[0x00FD])
	 */
	class UBrgUIResource_ItemIconManager : public UBrgUIResource_StreamImageManager
	{
	public:
		unsigned char                                              UnknownData_LG6D[0x3];                                   // 0x00FD(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class UBrgUIManagerBase*                                   mUIManagerBase;                                          // 0x0100(0x0008)

	public:
		class UBrgUIImage_Stream* GetFighterTypeIconSImage(const class FString& inFighterTypeID);
		class UBrgUIImage_Stream* GetItemIconImage(const class FString& inItemId);
		class UBrgUIImage_Stream* GetMushroomBeastIconImage(const class FString& inMushroomBeastID, bool inRoast);
		class UBrgUIImage_Stream* GetMushroomIconImage(const class FString& inMushroomID, bool inRoast);
		class UBrgUIImage_Stream* GetPartIconImage(const class FString& inPartID, bool is_Lemitbreak, unsigned char inGender, bool inLeftHand);
		void Initialize(int32_t inMaxNum);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_PartTypeIconManager
	 * Size -> 0x000B (FullSize[0x0108] - InheritedSize[0x00FD])
	 */
	class UBrgUIResource_PartTypeIconManager : public UBrgUIResource_StreamImageManager
	{
	public:
		unsigned char                                              UnknownData_ZVCC[0x3];                                   // 0x00FD(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class UBrgUIManagerBase*                                   mUIManagerBase;                                          // 0x0100(0x0008)

	public:
		class FString GetPartTypeIconLoadImagePath(const class FString& inPartTypeID);
		class UBrgUIImage_Stream* GetPartTypeIconImage(const class FString& inPartTypeID);
		void Initialize(int32_t inMaxNum);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_QuestPictureManager
	 * Size -> 0x000B (FullSize[0x0108] - InheritedSize[0x00FD])
	 */
	class UBrgUIResource_QuestPictureManager : public UBrgUIResource_StreamImageManager
	{
	public:
		unsigned char                                              UnknownData_4RWE[0x3];                                   // 0x00FD(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class UBrgUIManagerBase*                                   mUIManagerBase;                                          // 0x0100(0x0008)

	public:
		class UBrgUIImage_Stream* GetQuestImage(const class FString& inQuestImageName);
		void Initialize(int32_t inMaxNum);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_TeamEmblemIconImageManager
	 * Size -> 0x000B (FullSize[0x0108] - InheritedSize[0x00FD])
	 */
	class UBrgUIResource_TeamEmblemIconImageManager : public UBrgUIResource_StreamImageManager
	{
	public:
		unsigned char                                              UnknownData_I569[0x3];                                   // 0x00FD(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class UBrgUIManagerBase*                                   mUIManagerBase;                                          // 0x0100(0x0008)

	public:
		class UBrgUIImage_Stream* GetTeamEmblemIconImage(const class FString& inEmblemID, EBrgUIResource_TeamEmblemIconImageSize inSize);
		void Initialize(int32_t inMaxNum);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIResource_TeamEmblemImageManager
	 * Size -> 0x000B (FullSize[0x0108] - InheritedSize[0x00FD])
	 */
	class UBrgUIResource_TeamEmblemImageManager : public UBrgUIResource_StreamImageManager
	{
	public:
		unsigned char                                              UnknownData_TRUA[0x3];                                   // 0x00FD(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class UBrgUIManagerBase*                                   mUIManagerBase;                                          // 0x0100(0x0008)

	public:
		class UBrgUIImage_Stream* GetTeamEmblemImage(const class FString& inEmblemID);
		void Initialize(int32_t inMaxNum);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUISprite
	 * Size -> 0x0038 (FullSize[0x0098] - InheritedSize[0x0060])
	 */
	class UBrgUISprite : public UObject
	{
	public:
		unsigned long                                              mPlay : 1;                                               // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mLoop : 1;                                               // 0x0060(0x0001) BIT_FIELD
		unsigned long                                              mFinished : 1;                                           // 0x0060(0x0001) BIT_FIELD
		int32_t                                                    mPlayAnimIndex;                                          // 0x0064(0x0004)
		float                                                      mPlayTime;                                               // 0x0068(0x0004)
		float                                                      mCalcPlayTime;                                           // 0x006C(0x0004)
		class UBrgUISpriteStatus*                                  mStatus;                                                 // 0x0070(0x0008)
		TArray<class UBrgUISpriteAnimPlayer*>                      mAnimPlayers;                                            // 0x0078(0x0010) NeedCtorLink
		float                                                      mRed;                                                    // 0x0088(0x0004)
		float                                                      mGreen;                                                  // 0x008C(0x0004)
		float                                                      mBlue;                                                   // 0x0090(0x0004)
		float                                                      mAlpha;                                                  // 0x0094(0x0004)

	public:
		void RenderProcess(class ABrgHUDBase* inHUDBase, float inDrawX, float InDrawY);
		void RefreshStatus();
		void TickProcess(float inDeltaTime);
		void SetColor(float inRed, float inGreen, float inBlue, float inAlpha);
		void SetTime(float inTime);
		void ReleasePause();
		void Pause();
		void Start(int32_t inAnimIndex, bool inTopPosition);
		void SetLoop(bool inLoop);
		bool IsFinished();
		void AddAnimInfo(class UBrgUISpriteAnim* inAnim);
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUISpriteAnim
	 * Size -> 0x0038 (FullSize[0x0098] - InheritedSize[0x0060])
	 */
	class UBrgUISpriteAnim : public UObject
	{
	public:
		TArray<class UBrgUIImage*>                                 mImages;                                                 // 0x0060(0x0010) NeedCtorLink
		TArray<struct FBrgUISpriteAnimKey>                         mAnimInfo;                                               // 0x0070(0x0010) NeedCtorLink
		class UBrgUISpriteAnim*                                    mParent;                                                 // 0x0080(0x0008)
		TArray<class UBrgUISpriteAnim*>                            mChilds;                                                 // 0x0088(0x0010) NeedCtorLink

	public:
		void AddKey(float inTime, ESpriteAnimMoveType inNextMoveType, int32_t inImageNo, float inImageCenterX, float inImageCenterY, float inPosX, float inPosY, float inScaleX, float inScaleY, float inAngle, float inColorR, float inColorG, float inColorB, float inAlpha, bool Invisible);
		float GetTotalTime();
		void AddImage(int32_t inImageNo, class UBrgUIImage* inImage);
		void Initialize(class UBrgUISpriteAnim* inParent);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUISpriteAnimPlayer
	 * Size -> 0x0068 (FullSize[0x00C8] - InheritedSize[0x0060])
	 */
	class UBrgUISpriteAnimPlayer : public UObject
	{
	public:
		class UBrgUISpriteAnim*                                    mAnim;                                                   // 0x0060(0x0008)
		int32_t                                                    mKeyIndex;                                               // 0x0068(0x0004)
		float                                                      mKeyRate;                                                // 0x006C(0x0004)
		int32_t                                                    mImageNo;                                                // 0x0070(0x0004)
		class UBrgUISpriteStatus*                                  mStatus;                                                 // 0x0074(0x0008)
		unsigned long                                              mVisible : 1;                                            // 0x007C(0x0001) BIT_FIELD
		unsigned long                                              mFixVisible : 1;                                         // 0x007C(0x0001) BIT_FIELD
		class UBrgUISpriteAnimPlayer*                              mParent;                                                 // 0x0080(0x0008)
		TArray<class UBrgUISpriteAnimPlayer*>                      mChilds;                                                 // 0x0088(0x0010) NeedCtorLink
		float                                                      mCalcTime;                                               // 0x0098(0x0004)
		struct FMatrix3x3CT                                        mFixMatrix;                                              // 0x009C(0x0018)
		float                                                      mFixColorR;                                              // 0x00B4(0x0004)
		float                                                      mFixColorG;                                              // 0x00B8(0x0004)
		float                                                      mFixColorB;                                              // 0x00BC(0x0004)
		float                                                      mFixAlpha;                                               // 0x00C0(0x0004)
		float                                                      mTotalTime;                                              // 0x00C4(0x0004)

	public:
		void RenderProcess(class ABrgHUDBase* inHUDBase, float inDrawX, float InDrawY, float inRed, float inGreen, float inBlue, float inAlpha);
		void SetTime(float inTime);
		float GetTotalTime();
		void Initialize(class UBrgUISpriteAnim* inAnim, class UBrgUISpriteAnimPlayer* inParentAnimPlayer);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUISpriteStatus
	 * Size -> 0x0044 (FullSize[0x00A4] - InheritedSize[0x0060])
	 */
	class UBrgUISpriteStatus : public UObject
	{
	public:
		float                                                      mImageCenterX;                                           // 0x0060(0x0004)
		float                                                      mImageCenterY;                                           // 0x0064(0x0004)
		float                                                      mPosX;                                                   // 0x0068(0x0004)
		float                                                      mPosY;                                                   // 0x006C(0x0004)
		float                                                      mScaleX;                                                 // 0x0070(0x0004)
		float                                                      mScaleY;                                                 // 0x0074(0x0004)
		float                                                      mAngle;                                                  // 0x0078(0x0004)
		float                                                      mColorR;                                                 // 0x007C(0x0004)
		float                                                      mColorG;                                                 // 0x0080(0x0004)
		float                                                      mColorB;                                                 // 0x0084(0x0004)
		float                                                      mAlpha;                                                  // 0x0088(0x0004)
		struct FMatrix3x3CT                                        mCalcMatrix;                                             // 0x008C(0x0018)

	public:
		void RenderProcess(class ABrgHUDBase* inHUDBase, float inDrawX, float InDrawY);
		void CalcMatrix();
		void Initialize();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUITexture2DLoader
	 * Size -> 0x0034 (FullSize[0x0094] - InheritedSize[0x0060])
	 */
	class UBrgUITexture2DLoader : public UObject
	{
	public:
		EBrgUITexture2DLoaderState                                 mState;                                                  // 0x0060(0x0001)
		unsigned char                                              UnknownData_9C5L[0x3];                                   // 0x0061(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		class UTexture2D*                                          mTexture;                                                // 0x0064(0x0008)
		class UBrgUIImageBase*                                     mImageBase;                                              // 0x006C(0x0008)
		class FString                                              mTexturePath;                                            // 0x0074(0x0010) NeedCtorLink
		int32_t                                                    mPixelScale;                                             // 0x0084(0x0004)
		class UBrgResourceLoadManager*                             mResourceLoadManager;                                    // 0x0088(0x0008)
		unsigned long                                              mLoadRequestState : 1;                                   // 0x0090(0x0001) BIT_FIELD

	public:
		int32_t Request(bool inLoadState, bool IsLoadCompCheckOnly);
		void TickProcess();
		void Initialize(class UBrgResourceLoadManager* inResourceLoadManager, const class FString& inTexturePath, int32_t inPixelScale);
		class UBrgUITexture2DLoader* Create(class UBrgResourceLoadManager* inResourceLoadManager, const class FString& inTexturePath, int32_t inPixelScale);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUtilityNativeBase
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgUtilityNativeBase : public UObject
	{
	public:
		void SetScreenShotEnable(bool enableFlag);
		void SetVideoRecordingEnable(bool enableFlag);
		void SetupSkillStickerRT(class UTextureRenderTarget2D* TargetRT, class UMaterialInstanceConstant* MIC);
		bool UpdateSkillStickerRT(class UTextureRenderTarget2D* TargetRT, class UMaterialInstanceConstant* MIC, TArray<struct FBrgDbEqSkill>* DbEqSkills);
		class UTextureRenderTarget2D* CreateSkillStickerRT();
		void SaveString(const class FString& Path, const class FString& String);
		void SaveBinary(const class FString& Path, TArray<unsigned char> Binary);
		int32_t GetBaseUtcSecond();
		void SetBaseUtcSecond(int32_t Time);
		int32_t GetSystemUtcMilliSecond(int32_t* millisec);
		int32_t GetUtcMilliSecond(int32_t* millisec);
		int32_t GetUtcSecond();
		class FString GetTimeStringSpaceDelimiter(int32_t Year, int32_t Month, int32_t Day, int32_t Hour, int32_t Min, int32_t Sec);
		class FString GetTimeString(int32_t Year, int32_t Month, int32_t Day, int32_t Hour, int32_t Min, int32_t Sec);
		void SecondsToLocalTime(int32_t Time, int32_t* Year, int32_t* Month, int32_t* DayOfWeek, int32_t* Day, int32_t* Hour, int32_t* Min, int32_t* Sec);
		float GetDeltaTime();
		bool IsBinkMoviePlaying(const class FString& inMovieFileName);
		void SetSelfShadow(class AActor* pActor, bool bEnabledSelfShadow);
		void RecalcShadowSetting(class AActor* pActor);
		bool SKMC_GetSocketWorldLocationAndRotation(class USkeletalMeshComponent* SKMC, const class FName& InSocketName, struct FVector* OutLocation, struct FRotator* OutRotation, int32_t Space);
		bool PlayAnimSequenceByAnimNodeSequence(class USkeletalMeshComponent* SMC, class UAnimNodeSequence* aSeq, bool bNoNotifies);
		void GetLatestAnimNodeFindFirstByNodeBest(class UAnimNodeSequence** latestAnimNodeSequence, class UAnimNodeBlendBase** latestAnimNodeBlend, class UAnimNode* latestAnimNode);
		class UAnimNodeSequence* GetMainAnimNodeSeq(class USkeletalMeshComponent* SMC);
		class UParticleSystemComponent* CreateParticle(class UParticleSystem* ParticleSys, class AActor* inActor, class USkeletalMeshComponent* SkelMeshComp, EBrgAttachTarget eCreateTarget, const class FName& CreatePointName, bool bAttach);
		int32_t GetMaterialIndex(class USkeletalMeshComponent* MeshComp, const class FName& MaterialName);
		float GetDistanceSqPawnToPawn2D(class APawn* From, class APawn* to);
		float GetDistancePawnToPawn2D(class APawn* From, class APawn* to);
		float GetDistanceSqPawnToPawn(class APawn* From, class APawn* to);
		float GetDistancePawnToPawn(class APawn* From, class APawn* to);
		struct FVector GetMeshLocation(class APawn* P);
		class FString GetWithZeroNumberStr(int32_t Number, int32_t digit);
		TArray<unsigned char> Hex2Bin(const class FString& hexData);
		class FString Bin2Hex(TArray<unsigned char> binData);
		class FString EncodeBase64FromByteArray(TArray<unsigned char> Decoded);
		TArray<unsigned char> DecodeBase64ToByteArray(const class FString& Encoded);
		class FString EncodeBase64(const class FString& Decoded);
		class FString DecodeBase64(const class FString& Encoded);
		void SetMeshActive(class USkeletalMeshComponent* InMesh, bool bActive, bool bWithSetActorCollision);
		void SetPCRBCollideWithChannels(class UPrimitiveComponent* inPC, bool inFlag);
		void SetLightChannel(class ULightComponent* LightComp, const struct FLightingChannelContainer& LightChannels);
		float GetTargetRadAngle(const struct FVector& VecA, const struct FVector& VecB);
		struct FQuat GetQuatNomalized(const struct FQuat& origQuat);
		bool IsInViewCone(const struct FVector& ViewPos, const struct FRotator& ViewRot, float ViewAngle, float ViewDist, const struct FVector& TargetPos, bool bCheckCollide, float* OutTargetDist, float* OutTargetAngle);
		void CallDebugCmd(const class FString& Cmd);
		void DebugMessageBox(const class FString& Message, const class FString& Title, bool bOK);
		void AssertMessageBox(const class FString& Message, const class FString& FuncName);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.MsgpackManager
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UMsgpackManager : public UObject
	{
	public:
		class FString GetMsgPackErrorMessage();
		void ClearMsgPackErrorMessage();
		bool IsEnableMsgPack();
		TArray<unsigned char> GetByteArray(class UJsonObject* jsonObj);
		class UJsonObject* GetJsonObject(TArray<unsigned char> Decoded, int32_t* Sucsess);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgEmitterSpawnable
	 * Size -> 0x0008 (FullSize[0x0298] - InheritedSize[0x0290])
	 */
	class ABrgEmitterSpawnable : public AEmitter
	{
	public:
		class UParticleSystem*                                     ParticleTemplate;                                        // 0x0290(0x0008) Net, RepNotify

	public:
		void ReplicatedEvent(const class FName& VarName);
		void SetTemplate(class UParticleSystem* NewTemplate, bool bDestroyOnFinish);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgFracturedStaticMeshActor
	 * Size -> 0x000C (FullSize[0x031C] - InheritedSize[0x0310])
	 */
	class ABrgFracturedStaticMeshActor : public AFracturedStaticMeshActor_Spawnable
	{
	public:
		unsigned long                                              mbUseDeleteTime : 1;                                     // 0x0310(0x0001) BIT_FIELD
		float                                                      mDeleteTimer;                                            // 0x0314(0x0004)
		float                                                      mFadeTime;                                               // 0x0318(0x0004)

	public:
		class ABrgFracturedStaticMeshActor* CreateFractured(class UFracturedStaticMesh* InMesh, class APawn* InOwner, const struct FVector& CreatePos, const struct FRotator& CreateRot, const struct FVector& BreakDir, float Rate, float Power);
		void Explode();
		void Tick(float DeltaTime);
		void PostBeginPlay();
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkPendingRequest
	 * Size -> 0x0018 (FullSize[0x0078] - InheritedSize[0x0060])
	 */
	class UBrgNetworkPendingRequest : public UObject
	{
	public:
		class UHttpRequestInterface*                               Request;                                                 // 0x0060(0x0008)
		class UBrgNetworkRequestContent*                           Content;                                                 // 0x0068(0x0008)
		class UBrgNetworkResponseInterface*                        Response;                                                // 0x0070(0x0008)

	public:
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkRequestContentInterface
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgNetworkRequestContentInterface : public UInterface
	{
	public:
		class FString ToString();
		bool SetParam(const class FString& Key, const class FString& Value);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgNetworkResponseDummy
	 * Size -> 0x0000 (FullSize[0x015C] - InheritedSize[0x015C])
	 */
	class UBrgNetworkResponseDummy : public UBrgNetworkResponseInterface
	{
	public:
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIDebugGauge
	 * Size -> 0x01C8 (FullSize[0x0228] - InheritedSize[0x0060])
	 */
	class UBrgUIDebugGauge : public UObject
	{
	public:
		EBrgUIDebugGaugeState                                      mState;                                                  // 0x0060(0x0001)
		unsigned char                                              UnknownData_3PMC[0x3];                                   // 0x0061(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
		struct FParamMoveData                                      mAlphaMoveData;                                          // 0x0064(0x006C)
		struct FParamMoveData                                      mGaugeParamMoveData;                                     // 0x00D0(0x006C)
		struct FParamMoveData                                      mSubGaugeParamMoveData;                                  // 0x013C(0x006C)
		struct FParamMoveData                                      mSelectAlpha;                                            // 0x01A8(0x006C)
		int32_t                                                    mLeftUpX;                                                // 0x0214(0x0004)
		int32_t                                                    mLeftUpY;                                                // 0x0218(0x0004)
		int32_t                                                    mSizeX;                                                  // 0x021C(0x0004)
		int32_t                                                    mSizeY;                                                  // 0x0220(0x0004)
		unsigned long                                              mIsSelect : 1;                                           // 0x0224(0x0001) BIT_FIELD

	public:
		void TickProcess(float DeltaTime);
		void RenderProcess(class ABrgHUDBase* inHUDBase);
		void DrawLineBox(class ABrgHUDBase* inHUDBase, float X1, float Y1, float X2, float Y2, bool fill);
		bool CheckEnd();
		void SetSelectState(bool inIsSelect, bool inAnimation);
		void SetVisible(bool Invisible);
		void SetSubParam(float inParam);
		void SetParam(float inParam);
		void SetSize(int32_t InSizeX, int32_t InSizeY);
		void SetPosition(int32_t inLeftUpX, int32_t inLeftUpY);
		void Initialize(int32_t inLeftUpX, int32_t inLeftUpY, int32_t InSizeX, int32_t InSizeY);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_AreaMap_TX_UI_AreaMap_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_AreaMap_TX_UI_AreaMap_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_ButtonGuide_STM_TX_UI_ButtonGuide_STM_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_ButtonGuide_STM_TX_UI_ButtonGuide_STM_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_ButtonGuide_TX_UI_ButtonGuide_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_ButtonGuide_TX_UI_ButtonGuide_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_ElevatorMenu_TX_UI_Elevator_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_ElevatorMenu_TX_UI_Elevator_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_STM_TX_UI_EnmaMenu_STM_Memo_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_STM_TX_UI_EnmaMenu_STM_Memo_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_STM_TX_UI_EnmaMenu_STM_Tab_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_STM_TX_UI_EnmaMenu_STM_Tab_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Memo_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Memo_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Menu_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Menu_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Menu_v01
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Menu_v01 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Beast_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Beast_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Catalog_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Catalog_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Fighter_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Fighter_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Help_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Help_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Index_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Index_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Magazine_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Magazine_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Mail_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Mail_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_MasterLevel_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_MasterLevel_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Mushroom_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Mushroom_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Omoide_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Omoide_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Quest_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Quest_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Senpai_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Senpai_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Sticker_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_Sticker_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Page_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Paperdoll_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Paperdoll_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Stamp_Arrow
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Stamp_Arrow : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Stamp_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Stamp_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Stamp_v01
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Stamp_v01 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Tab_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_Tab_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_v01
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_v01 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_v02
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_v02 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_v03
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_v03 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_v04
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_EnmaMenu_TX_UI_EnmaMenu_v04 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Defense_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Defense_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Facility_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Facility_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Monitor_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Monitor_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_MyTeam_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_MyTeam_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Raid_Info_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Raid_Info_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Report_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Report_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_ReportDetail_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_ReportDetail_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_CHN
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_CHN : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_DEU
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_DEU : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_ESN
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_ESN : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_FRA
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_FRA : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_INT
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_INT : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_ITA
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_ITA : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_JPN
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_JPN : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_KAN
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_KAN : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_KOR
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_KOR : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_PTB
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v00_PTB : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v01
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Result_v01 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_RoomCustom_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_RoomCustom_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_TeamChange_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_TeamChange_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Top_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Top_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Whistle_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Fort_Whistle_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Raid_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Raid_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Fort_TX_UI_Ranking_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Fort_TX_UI_Ranking_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_FreeContinue_TX_UI_FreeContinue_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_FreeContinue_TX_UI_FreeContinue_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_FreezerMenu_STM_TX_UI_FreezerMenu_STM_Name_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_FreezerMenu_STM_TX_UI_FreezerMenu_STM_Name_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_FreezerMenu_TX_UI_FreezerMenu_v01
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_FreezerMenu_TX_UI_FreezerMenu_v01 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_HUD_TX_UI_HUD_Base_Status_v06
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_HUD_TX_UI_HUD_Base_Status_v06 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_HUD_UncleDeath_TX_UI_HUD_UncleDeath_Anim_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_HUD_UncleDeath_TX_UI_HUD_UncleDeath_Anim_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Icon_Info_TX_UI_Icon_Info_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Icon_Info_TX_UI_Icon_Info_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Icon_Info_TX_UI_Icon_Info_v01
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Icon_Info_TX_UI_Icon_Info_v01 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Icon_Info_TX_UI_Icon_Info_v02
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Icon_Info_TX_UI_Icon_Info_v02 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Icon_Item_TX_UI_Icon_Item_S_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Icon_Item_TX_UI_Icon_Item_S_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Icon_Item_TX_UI_Icon_Item_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Icon_Item_TX_UI_Icon_Item_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Icon_MiniMap_TX_UI_Icon_MiniMap_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Icon_MiniMap_TX_UI_Icon_MiniMap_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Icon_Network_TX_UI_Icon_Network_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Icon_Network_TX_UI_Icon_Network_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Insurance_TX_UI_Insurance_v00_JPN
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Insurance_TX_UI_Insurance_v00_JPN : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_InsuranceMenu_TX_UI_InsuranceMenu_Cover_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_InsuranceMenu_TX_UI_InsuranceMenu_Cover_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_InsuranceMenu_TX_UI_InsuranceMenu_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_InsuranceMenu_TX_UI_InsuranceMenu_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_InsuranceMenu_TX_UI_InsuranceMenu_v00_00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_InsuranceMenu_TX_UI_InsuranceMenu_v00_00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_ItemLMenu_TX_UI_ItemLMenu_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_ItemLMenu_TX_UI_ItemLMenu_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Loading_TX_UI_Loading_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Loading_TX_UI_Loading_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Loading_TX_UI_Loading_v00_Blue
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Loading_TX_UI_Loading_v00_Blue : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Loading_TX_UI_Loading_v00_Bronze
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Loading_TX_UI_Loading_v00_Bronze : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Loading_TX_UI_Loading_v00_Gold
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Loading_TX_UI_Loading_v00_Gold : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Loading_TX_UI_Loading_v00_Silver
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Loading_TX_UI_Loading_v00_Silver : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_LockerMenu_TX_UI_Locker_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_LockerMenu_TX_UI_Locker_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_MiniGame_STM_TX_UI_MiniGame_STM_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_MiniGame_STM_TX_UI_MiniGame_STM_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_MiniGame_TX_UI_MiniGame_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_MiniGame_TX_UI_MiniGame_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_MotherBarbs_TX_UI_MotherBarbs_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_MotherBarbs_TX_UI_MotherBarbs_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Mushroom_TX_UI_Mushroom_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Mushroom_TX_UI_Mushroom_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_PauseMenu_STM_TX_UI_PauseMenu_STM_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_PauseMenu_STM_TX_UI_PauseMenu_STM_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_PauseMenu_TX_UI_PauseMenu_v01
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_PauseMenu_TX_UI_PauseMenu_v01 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_PauseMenu_TX_UI_PauseMenu_v02_Shop
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_PauseMenu_TX_UI_PauseMenu_v02_Shop : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Prison_TX_UI_Prison_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Prison_TX_UI_Prison_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_QuestMenu_STM_TX_UI_questmenu_STM_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_QuestMenu_STM_TX_UI_questmenu_STM_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_QuestMenu_TX_UI_questmenu_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_QuestMenu_TX_UI_questmenu_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_RadioMenu_TX_UI_radiomenu_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_RadioMenu_TX_UI_radiomenu_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_ReachingMail_TX_UI_ReachingMail_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_ReachingMail_TX_UI_ReachingMail_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Reception_TX_UI_Reception_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Reception_TX_UI_Reception_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Result_Floor_TX_UI_Result_Floor_Info_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Result_Floor_TX_UI_Result_Floor_Info_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Result_Floor_TX_UI_Result_Floor_v02
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Result_Floor_TX_UI_Result_Floor_v02 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_RewardBoxMenu_TX_UI_RewardBox_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_RewardBoxMenu_TX_UI_RewardBox_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_RewardBoxMenu_TX_UI_RewardBox_v01
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_RewardBoxMenu_TX_UI_RewardBox_v01 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Shop_TX_UI_Shop_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Shop_TX_UI_Shop_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_SkillSticker_TX_UI_SkillSticker_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_SkillSticker_TX_UI_SkillSticker_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_StampExMenu_TX_UI_StampEx_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_StampExMenu_TX_UI_StampEx_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_StatusMenu_TX_UI_Status_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_StatusMenu_TX_UI_Status_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_SystemWindow_TX_UI_SystemWindow_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_SystemWindow_TX_UI_SystemWindow_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_SystemWindow_TX_UI_SystemWindow_v01
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_SystemWindow_TX_UI_SystemWindow_v01 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_SystemWindow_TX_UI_SystemWindow_v02
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_SystemWindow_TX_UI_SystemWindow_v02 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_SystemWindow_TX_UI_SystemWindow_v03
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_SystemWindow_TX_UI_SystemWindow_v03 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_TengokuMenu_TX_UI_TengokuMenu_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_TengokuMenu_TX_UI_TengokuMenu_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Tips_TX_UI_Tips_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Tips_TX_UI_Tips_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_Autumn00_TX_UI_Title_VS_Autumn00_v01
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_Autumn00_TX_UI_Title_VS_Autumn00_v01 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_Autumn00_TX_UI_Title_VS_Autumn00_v02
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_Autumn00_TX_UI_Title_VS_Autumn00_v02 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_Autumn00_TX_UI_Title_VS_Autumn00_v03
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_Autumn00_TX_UI_Title_VS_Autumn00_v03 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_Spring00_TX_UI_Title_Spring00_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_Spring00_TX_UI_Title_Spring00_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_Spring00_TX_UI_Title_Spring00_v01
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_Spring00_TX_UI_Title_Spring00_v01 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_Summer00_TX_UI_Title_VS_Summer00_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_Summer00_TX_UI_Title_VS_Summer00_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_Summer00_TX_UI_Title_VS_Summer00_v01
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_Summer00_TX_UI_Title_VS_Summer00_v01 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_Summer00_TX_UI_Title_VS_Summer00_v02
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_Summer00_TX_UI_Title_VS_Summer00_v02 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_TX_UI_Title_First_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_TX_UI_Title_First_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_TX_UI_Title_Notice_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_TX_UI_Title_Notice_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_TX_UI_Title_Spring_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_TX_UI_Title_Spring_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_TX_UI_Title_VS_v00
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_TX_UI_Title_VS_v00 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_Winter00_TX_UI_Title_VS_Winter00_v01
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_Winter00_TX_UI_Title_VS_Winter00_v01 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_Winter00_TX_UI_Title_VS_Winter00_v02
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_Winter00_TX_UI_Title_VS_Winter00_v02 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_Winter00_TX_UI_Title_VS_Winter00_v03
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_Winter00_TX_UI_Title_VS_Winter00_v03 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfo_UI_Title_Winter00_TX_UI_Title_VS_Winter00_v04
	 * Size -> 0x0050 (FullSize[0x00B0] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfo_UI_Title_Winter00_TX_UI_Title_VS_Winter00_v04 : public UObject
	{
	public:
		struct FImageMapInfo                                       mImageMap;                                               // 0x0060(0x0050) Config, NeedCtorLink

	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

	/**
	 * Class BrgGameBase.BrgUIImageMapInfoRegist
	 * Size -> 0x0000 (FullSize[0x0060] - InheritedSize[0x0060])
	 */
	class UBrgUIImageMapInfoRegist : public UObject
	{
	public:
		void Regist(class UBrgUIImageMapInfo* inImageMapInfo);
		static UClass* StaticClass();
	};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
